## 多线程

### 基本

```java
第一阶段：创建线程方式
//方式1:继承 Thread
public class MyThread extends Thread {
   //重写run方法...
}
MyThread t1 = new MyThread();
t1.setName("线程名t1")
MyThread t2 = new MyThread();
t2.setName("线程名t2")
t1.start();//启动线程
t2.start();

//方式2:实现 Runnable接口
public class MyRunnable implements Runnable {
    @Override
    public void run() {
        for(int i=0;i<100;i++){
            System.out.println(Thread.currentThread().getName()+":"+i);
        }
    }
}
Thread d1 = new Thread(new MyRunnable(),"线程名d1");
Thread d2 = new Thread(new MyRunnable(),"线程名d2");

第二阶段：常用方法
setPriority(int)  //优先级别1-10整数
sleep(long)	//休眠(静态方法) 毫秒单位
join()   //堵塞，线程a内 调用线程b.join 线程a被堵塞
yield()    //礼让（静态方法）   
interrupt() //中断线程
isAlive()  //线程是否处于活跃状态    

super.wait()//一种使线程暂停执行的方法
super.notify()//通知正在等待的其他线程
super.notifyAll()//通知所有等待的线程竞争cpu资源

public synchronized void test（）{ }; //同步方法（只允许一个线程进入）
synchronized(this){ };  //同步块
```

### 线程池

![](images/QQ截图20201113150415.png)

```java
第一阶段：固定线程池
（一）创建线程池
//创建一个可缓存的线程池，有任务时才创建新任务
ExecutorService es = Executors.newCachedThreadPool();
//创建一个单线程池
ExecutorService es = Executors.newSingleThreadExecutor();
//创建一个固定数目的线程池。注：3个线程    
ExecutorService es = Executors.newFixedThreadPool(3);
//(特别)创建一个周期性的线程池，而且以延迟或定时的方式来执行任务，线程数3
ScheduledExecutorService se = Executors.newScheduledThreadPool(3);
se.scheduleAtFixedRate(new Runnable() {
    @Override
    public void run() {
		//...
    }
}, 5, 2, TimeUnit.SECONDS);  //首次执行延迟5秒钟执行，每两秒钟执行一次，时间单位

（二）操作    
//执行一个线程（command,可以用new Runnable。也可以使用Runnable实现类）   
es.execute(Runnable command)   
//提交一个线程，可以判断返回值是否为空来判断是否执行成功    
es.submit(Runnable command) 
//执行一个线程，返回一个结果列表    
invokeAll(Collection<? extends Callable<T>> tasks)    
//关闭一个线程       
es.shutdown()  

第二阶段：自定义线程池
（一）ThreadPoolExecutor类参数
//corePoolSize:核心池的大小      
//maximumPoolSize:线程池最大线程数
//keepAliveTime:表示线程没有任务执行时，最多保持多久时间会终止
//unit:参数keepAliveTime的时间单位  
//workQueue:一个阻塞队列，用来存储等待执行的任务。
//threadFactory:线程工厂，主要用来创建线程
//handler:表示当拒绝处理任务的策略。

 //核心线程数5；最大线程数7；超出的线程多长时间消亡；单位毫秒；阻塞队列容纳四个任务。
 ThreadPoolExecutor executor = new ThreadPoolExecutor(5,7,300, 
       TimeUnit.MICROSECONDS,new ArrayBlockingQueue<Runnable>(4));
 
 for(int j =0;j<11;j++) { //11个任务
    final int x = j;
    executor.submit(new Runnable() {
        @Override
        public void run() {
           System.out.println("任务:"+x);
           executor.getPoolSize(); //线程池中线程数
           executor.getQueue().size(); // 队列等待执行的任务数
           executor.getCompletedTaskCount(); // 已经执行完的任务数
        }
    });
 }     
```

### 认识总结

```java
//（一）线程是什么
线程就是程序内部的一条执行路径，多线程就相当于多条执行路径。线程之间是相互独立的，可以共享进程的资源，可以并行执行各自不同的任务（一个CPU只是交替占用CPU资源，并非真正并行执行）。
//（二）线程有什么用
好处，可以充分利用CPU资源。或是将一些耗时较长的操作：如下载、数据库访问等，放在子线程中执行，可以防止主线程卡死。
//（三）使用多线程会遇到什么问题
1、安全问题
多个线程对同一资源操作，就会产生安全问题。如线程A，进入方法拿到count值。刚读取还没来得及改，B线程又进来了，这就导致他俩读取的值一样。
2、同步代码块导致死锁问题
两个线程都在等对方先完成。死锁条件：
		1.两个或两个以上的线程在活动  
        2.某个线程拿到一个锁以后，还想拿第二个锁，造成锁的嵌套。    
//（四）线程状态
创建状态   就绪状态   运行状态  阻塞状态  死亡状态        
```

### 案例走一波

```java

public class MySemaphore {
 
    public static void main(String[] args) throws IOException, InterruptedException {
        final File stream = new File("c:\\stream.txt");
        final OutputStream os = new FileOutputStream(stream);
        final OutputStreamWriter writer = new OutputStreamWriter(os);
        final Semaphore semaphore = new Semaphore(10); //控制线程数量
        ExecutorService exec = Executors.newCachedThreadPool();
        
        final long start = System.currentTimeMillis();
        for (int i = 0; i < 10000000; i++) {
            final int num = i;
            Runnable task = new Runnable() {
                @Override
                public void run() {
                    try {
                        semaphore.acquire();
                        writer.write(String.valueOf(num)+"\n");
                        semaphore.release();
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            };
            exec.submit(task);
        }
        exec.shutdown();
        while(true){  
           if(exec.isTerminated()){  
                writer.write("---END---\n");
                writer.close();
                System.out.println("所有的子线程都结束了！");  
                break;  
            }  
            Thread.sleep(1000);    
        }
        final long end = System.currentTimeMillis();
        System.out.println((end-start)/1000);
    }
}
```

## 文件流



## 日志

jdbc



## 分页

```java
//起始行偏移量 = (当前页码-1)*页大小。

public class Page{
     private int currentPageNo ;//当前页码数
     private int pageSize; //页面大小
     private int count； //总条数
     private int totalPageCount;  //总页数
     ······
         
     public void setCount(Integer count) {
        this.count = count;
        if(count>0){
            //获取总页数
            totalPageCount = this.count%this.pageSize==0?
                    this.count/this.pageSize:
                    (this.count/this.pageSize)+1;
        }else{
            totalPageCount=0;
        }
    }    
}
```

## 下载



