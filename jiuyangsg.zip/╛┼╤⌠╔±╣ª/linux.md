## Linux目录 

![](images/QQ截图20200503231250.png)

```java
/bin (/usr/bin、/usr/local/bin)  : //存放常用的命令

/sbin (/usr/sbin、/usr/local/sbin) ://存放系统管理程序

/home : //存放普通用户的主目录，Linux中每个用户都有一个自己的目录，目录名一般以用户的账号命名

/root : //系统管理员目录，也称为超级权限者的用户主目录

/boot : //存放启动Linux时的一些核心文件

/proc : //虚拟目录，它系统内存的映射，访问这个目录来获取系统信息

/srv : //目录存放一些服务启动之后需要提取的数据

/sys : //存放一些linux2.6内核的新文件

/tmp : //临时文件

/dev : //类似于windows的设备管理器，把所有的硬件用文件的形式存储

/media : //linux会自动识别一些设备，如U盘、光驱等，识别之后挂载到这个目录下

/mnt ： //让用户挂载别的文件系统

/opt : //安装软件所方的目录

/usr/local //安装软件所安装的目录

/var  //目录存放着不断扩充的东西，如果日志文件

/selinux   //是一个安全子系统它能控制程序只能访问特定文件
```

## 安装linux虚拟机

```java
1.先安装VM软件   2.VM软件创建一个虚拟机空间   3.在虚拟空间上安装我们的CentOS操作系统

//CentOS下载地址
http://mirrors.163.com/centos/6/isos/
```

### **VM安装步骤**

```
1.去 BIOS 里修改设置开启虚拟化设备支持（f2, f10）     2.安装虚拟机软件（vm12）
```

![](images/QQ截图20201126204605.png)

![](images/QQ截图20200503194242.png)

![](images/QQ截图20200503194548.png)

![](images/QQ截图20200503194640.png)

![](images/QQ截图20200503194741.png)

![](images/QQ截图20200503195303.png)

![](images/QQ截图20200503195441.png)

### **CentOS安装步骤**

![](images/QQ截图20200503200028.png)

![](images/QQ截图20200503200202.png)

![](images/QQ截图20200503200248.png)

![](images/QQ截图20200503200325.png)

![](images/QQ截图20200503200526.png)

![](images/QQ截图20200503200722.png)

![](images/QQ截图20200503200632.png)

![](images/QQ截图20200503201105.png)

![](images/QQ截图20200503201356.png)

```
处理器需要根据自己的硬件实际情况来说， cpu0,cpu1,cpu2,cpu3
```

![](images/QQ截图20200503201656.png)

![](images/QQ截图20200503201930.png)

![](images/QQ截图20200503211433.png)

![](images/QQ截图20200503211352.png)

```
1. 桥连接，Linux可以和其他的系统通信但是可能造成IP冲突
如： 192.168.0.1 、192.168.0.255 除去 1 的网关地址和255广播地址 一共有253个网段地址，如果200多个虚拟机都用桥连就会出现IP地址不够用的问题。

2.NAT：网络地址转换方式；linux可以访问外网，不会造成ip冲突
如：原本windows 192.168.0.40 它会再出现一个 192.168.100.200 然后Linux会和后者一个网段；
然后会出现一个问题，其他和192.168.0.40一个网段的机子找不到Linux的Ip,而Linux可以通过本机192.168.0.40来访问和它相同的网段的机子

3.主机模式： 你的linux是一个独立模式不能访问外网
```

![](images/QQ截图20200503200846.png)

```
设置好之后正式使用CentOS
```

![](images/QQ截图20200503211756.png)

![](images/QQ截图20200503212036.png)

![](images/QQ截图20200503212130.png)

```
随后便可以开启虚拟机
```

![](images/QQ图片20200503212347.png)

![](images/QQ截图20200503212549.png)

![](images/QQ截图20200503212637.png)

![](images/QQ截图20200503212846.png)

![](images/QQ截图20200503213000.png)

![](images/QQ截图20200503213103.png)

![](images/QQ截图20200503213223.png)

![](images/QQ截图20200503213314.png)

![](images/QQ截图20200503213421.png)

![](images/QQ截图20200503213624.png)

```
然后下一步，格式化，将修改写入磁盘
```

![](images/QQ截图20200503214017.png)

```
基本系统-->Java平台 不选   //后面主机独立装
基本系统-->基本   要选  
基本系统-->兼容程序库  要选
基本系统-->打印客户端  不选
基本系统-->目录客户端  不选
基本系统-->网络文件系统客户端  不选
应用程序-->互联网浏览器  要选  --其他不选
服务器--> 服务器平台   不选
桌面--> 都保留
```

![](images/QQ截图20200503214824.png)

```
引导完之后一些初始的配置还是要走的，前进--同意，然后到用户管理界面先跳过
```

![](images/QQ截图20200503215143.png)

![](images/QQ截图20200503215301.png)

### vmtools 安装

```
1. 可以直接粘贴命令在 windows  和 centos 系统之间
2. 可以设置 windows  和 centos 的共享文件夹
注意：实际开发中，文件的上传下载是需要使用远程方式完成的
```

![](images/QQ截图20200503224304.png)

![](images/QQ截图20200503224357.png)

![](images/QQ截图20200503224510.png)

```java
//进入opt目录  
cd /opt/  

//解压    
tar -zxvf  VMwareTools-10.0.5-3228253.tar.gz   

//进入到该文件夹
cd /vmware-tools-distrib/  
    
//执行该文件    
./vmware-install.pl  

然后一路回车后。 reboot  重启
```

![](images/QQ截图20200503230108.png)

![](images/QQ截图20200503230304.png)

## 远程登录 Linux 系统

![](images/QQ截图20200504101225.png)

### 安装 Xshell5 并使用

```
如果希望安装好 XShell 5 就可以远程访问 Linux 系统的话，需要有一个前提，就是Linux 启用了 SSHD 服务，该服务会监听 22  号端口。
（一个系统理论上说可以有655个端口，但是为了linux的安全只会开放22号端口，端口开的越多安全性就越弱）
ps: 进入文本模式设置工具： 终端输入 setup
```

![](images/QQ截图20200504101943.png)

```
下面就是傻瓜式的安装了，安装完之后新建一个会话（连接）
```

![](images/QQ截图20200504104127.png)

![](images/QQ截图20200504104421.png)

![](images/QQ截图20200504104654.png)

### 远程上传下载文件Xftp5

```
是一个基于 windows 平台的功能强大的 SFTP、FTP 文件传输软件。使用了 Xftp  以后，windows 用户能安全地在 UNIX/Linux 和 Windows PC 之间传输文件。

安装：傻瓜式安装，然后配置
```

![](images/QQ截图20200504110536.png)

![](images/QQ截图20200504110728.png)

![](images/QQ截图20200504111045.png)

![](images/QQ截图20200504111350.png)

## 基础命令大全

### vi 和 vim 

```java
//概念
vi ： linux内建文本编辑器。
vim： vi的增强版，具有程序编程能力。
三种模式： 1.正常模式(Esc)  2.插入模式(i)  3.命令模式(:)

//命令模式下
wq：保存并推出
q!：强制退出
q ：退出
set nu : 显示行号
set nonu : 取消行号

//正常模式下
dd : 删除当前行。  5dd ：删除当前向下5行。
yy :拷贝。   5yy：拷贝当前向下5行。
p :粘贴
/A : 查找A
gg : 首行
G  : 末行
u  : 撤销
20 shift+g :光标移到二十行
```

### 用户命令

```java
(一)登入登出：

reboot  //重启系统

halt  //关机

sync   //把内存的数据同步到磁盘（看不到效果，关机的时候建议输入下）  

shudown -h 1 //1分钟后关机    

logout //退出(远程连接上使用)。  

(二)用户管理：

useradd 用户名  //添加用户

passwd  用户名  //修改密码列

userdel	用户名  //删除用户

userdel -r zsp  //删除用户以及用户主目录(一般不用)

id  用户名  //查询用户信息（uid:用户id号；git：用户组id号；组：组名）

su - 用户名  //切换用户(返回原来用户exit)    

(三)用户组：类似于角色，系统可以对有共性的多个用户进行统一的管理

groupadd 组名   // 增加组

groupdel 组名   // 删除组

useradd	-g 用户组 用户名	//增加用户时直接加上组

usermod	-g 用户组 用户名  //修改用户组

chown 用户名 文件名   //修改文件所有者
chown -R tom kkk/  //将kkk目录下所有的文件包括子目录文件，改成tom  (递归修改)

chgrp 组名 文件名   //修改文件所在的组
chgrp -R bbb /home/kkk   //将home/kkk目录下所有文件和目录的所在组都修改成 bbb
```

#### 关于权限

```java
（一）权限介绍

-rwxrw-r-- 1 root root 1213 Feb 2 09:39 abc

第一个字符代表文件类型： 文件-，目录 d ,连接 1 , c:字符设备[键盘等] , b:块文件，硬盘
//其余字符三个一组
第一组 rwx :  读(r) 写(w) 执行(x)  
第二组 rw- :  与文件拥有者同一组用户的权限是读和写 但不能执行
第三组 r-- :  不与文件拥有者同组的用户权限是读，不能写和执行

最后一个1  ：  如果是文件，表示硬链接的数，如果是目录表示该目录子目录的个数

root : 用户名

root : 用户组

1213 ：代表文件的大小，如果是目录则是 4096 
    
Feb 2 09:39  文件最后修改时间


(二)权限修改

u:所有者	g:所在组	o:其他人	a:所有人(u、g、o 的总和)
1)	chmod	u=rwx,g=rx,o=x	文件目录名   
2)	chmod	o+w	文件目录名		//代表给该目录其他人添加 w 权限
3)	chmod	a-x	文件目录名       //给所有人减去 x权限
```

### 文件命令

```java
(一)：关于路径

pwd		//显示当前工作目录的绝对路径

cd [参数] 	// 切换到指定目录
	cd ~ 回到家目录
    cd ../home  上级目录
    cd .. 

ls [ 选 项] [目录或是文件] //显示当前目录文件
     -al :显示当前目录所有的文件和目录，包括隐藏
     -l :以列表的方式显示信息
      
(二): 创建、删除、复制、移动

mkdir  [选项]   //创建目录
   mkdir  /home/dog  //表示在/home目录下，创建dog目录

-p  //创建多级目录
   -p /home/animal/tiger  
   
touch //创建空文件
	touch  hello.txt
	touch  ok1.txt ok2.text    

rmdir  [选项]	//要删除的空目录 
   rmdir  /home/dog

rm -rf // 可以删除非空的目录 

rm [选项]  //移除文件或目录
    -r ：递归删除整个文件夹	
    -f ： 强制删除不提示
    rm aaa.text //删除文件
    rm -rf bbb/  //删除整个目录  

cp  //拷贝文件到指定目录  
     cp  aaa.text  bbb/
     cp -r test/ zwj/  //递归复制整个文件夹  

mv   //剪切或重命名
    mv  aaa.text  pig.text  //重命名
    mv  pig.text /root/  //移动
    
(三)压缩和解压:

//1.gz结尾
gzip  hello.txt  //压缩(可以写多个)

gunzip hello.txt.gz  //解压    

//2.zip结尾    
zip   //压缩
   zip -r mypackage.zip /home/     //压缩home目录下的所有文件，递归压缩 

unzip   //解压
    unzip -d /opt/tmp/ mypackage.zip  //将解压的文件放到 tmp文件下去
      
//3.tar.gz 结尾      (.tar后缀结尾的用 -xvf)
tar -zcvf a.tar.gz  al.txt a2.txt  //将 al和a2压缩成 a.tar.gz

tar -zcvf myhome.tar.gz  /home/   //将home下所有文件打包成myhome.tar.gz

tar -zxvf a.tar.gz   // 解压到当前目录  

tar -zxvf myhome.tar.gz -C /opt/    //解压到opt目录下    

(四)查看：

echo   //输出内容到控制台
    echo $PATH //输出当前环境变量路径
    echo "hello"  //输出文本

cat   // 查看文件内容，只读    
    cat /etc/profile   //查看
    cat -n /etc/profile  //查看并显示行号
    cat -n /etc/profile | more  //分页显示
    
more  //以全屏方式按页显示内容。空格键：向下翻一页  Enter:向下翻一行  q：离开  
    more /etc/profile     //= ：输出当前行号  Ctr+F 向下滚动一屏  Ctr+B 向下滚动一屏
    
less //显示大型文件具有较高的效率。空格键：向下翻一页  q：离开 
    less 射雕英雄传.txt
    
head   //用于显示文件的开头部分内容，默认显示前10行内容
    head 文件
    head -n 5 /etc/profile   //显示文件头5行
    
tail   //输出尾部内容，默认10行
    tail -n 5 文件
    tail -f 文件  //实时追踪该文档的变化        
    
history //查看已经执行过的指令
    history  //显示所有执行过的指令
    history 10 //显示最近执行的前十条指令
    ! 178  //执行历史编号为178的指令    
  
(五)写入：
    
ls -l > a.txt  //把当前显示内容写入到a文件，如该文件没有则创建，有则覆盖内容    
    
ls -l >> a.txt //把当前显示内容写入到a文件，如该文件没有则创建，有则进行追加内容    

cat 文件1 > 文件2   //把文件1内容写入到文件2中，不存在则创建

cat 文件1 >> 文件2
```

### 查找命令

```java
find /home -name hello.txt //查找home文件下的hello文件   find /home -name *.txt
    
find /opt -user nobody   //查找opt文件夹下 用户nobody的文件  

find / -size  +20M   //查找大于20M的文件  
find / -size  -20M   //查找小于20M的文件  
find / -size  20M    //查找等于 20M的文件   
    
//grep 指令和 管道符号  
grep 过滤查找 ， 管道符，“|”，表示将前一个命令的处理结果输出传递给后面的命令处理。
cat hello.txt | grep yes  
```

### 时间命令

```java
date   //当前时间
    date "+%Y"  //年
    date "+%m"  //月
    date "+%d"  //日
    date "+%Y-%m-%d %H%M%S"  //年月日 时分秒
    
date  -s  "2018-10-10 11:22:22"  //设置系统当前时间
    
cal   //显示当前的日历
    
cal 2020  //显示某年的日历    
```

### 其他

```java
(一)三个重要文件：

vim /etc/passwd   //用户配置文件（该文件用于记录用户的各种信息）
    
vim /etc/shadow   //口令配置文件

vim /etc/group    //组的配置文件    

(二)运行级别

0：关机  1：单用户(找回丢失密码)  2：多用户无网络  3：多用户有网络   4：保留  5：图像界面  6：重启

1.系统的运行级别配置文件 /etc/inittab
2.常用运行级别3和5

init 3  //切换运行级别
init 0   //关机  
```

## crond任务调度

![](images/QQ截图20200508223118.png)

```java
(一)基本

//1.设置个人任务调度
crontab -e    

//2.输入任务到调度文件
//意思说每小时的每分钟执行 ls –l /etc/ >> /tmp/to.txt 命令
*/1 * * * * ls –l /etc/ >> /tmp/to.txt    

//3.保存后出现 installing new crontab  表示成功
wq!

crontab -r  //关闭当前任务调度  
    
(二)案例

//案例一：每隔一分钟，将当前的日期信息，追加到/tmp/mydate文件中
1. 编写一个文件  /home/mytask1.sh
输入：  date >> /tmp/mydate

2.给mytask1.sh 一个可以执行权限
chmod 744 /home/mytask1.sh

3.crontab -e
输入： */1 * * * *  /home/mytask1.sh

//案例二：每隔一分钟，将当前的日期和日历，追加到/tmp/mycal文件中
1. 编写一个文件  /home/mytask2.sh
输入：  date >> /tmp/mydate
	   cal >> /tmp/mycal
    
2.给mytask2.sh 一个可以执行权限
chmod 744 /home/mytask2.sh

3.crontab -e
输入： */1 * * * *  /home/mytask2.sh
```

```
相关命令：
	1)	conrtab –r：终止任务调度。
	2)	crontab –l：列出当前有那些任务调度
	3)	service crond restart	[重启任务调度]
```

## 网络配置

```java
//可以查看网络是否连通
ping ip地址   //Ctrl C 就退出来了
```

**概念**

![](images/QQ截图20200511221755.png)

**查看虚拟网络编辑器**

![](images/QQ截图20200511222535.png)

**查看网关**

![](images/QQ截图20200511223001.png)

**自动获取IP**

![](images/QQ截图20200512212356.png)

![](images/QQ截图20200512212513.png)



**指定固定的ip**

```
直接修改配置文件来指定IP,并可以连接到外网(程序员推荐)
vim /etc/sysconfig/network-scripts/ifcfg-eth0
```

![](images/QQ截图20200512215117.png)

![](images/QQ截图20200512215138.png)

## 进程管理

```java
(一) 操作进程

ps -aux | grep 某个进程

ps -ef | grep 某个进程  //ps -ef 以全格式显示

kill [选项] 进程号 //通过进程号杀死进程。 选项：-9 表示强迫进程立即停止

killall 进程名称 //通过进程名称杀死进程，也支持通配符，这在系统因负载过大而变得很慢时很有用

pstree [选项] //可以更加直观的来看进程信息。 选项： -p 显示进程的PID  -u  显示进程的所属用户
```

![](images/QQ截图20200512222713.png)

```java
(二)服务本质就是一个进程。如：mysql tomcat 防火墙  SSHD

//语法：  
//注意：在 CentOS7后不再使用service,而是systemctl
service 服务名  [start | stop | restart | reload | status]
 
//操作防火墙    
service iptables status    // 查看当前防火墙的状况
service iptables restart   // 启动防火墙
service iptables stop      // 关闭防火墙
service iptables start     // 重新启动防火墙     
    
//windows（cmd）检查Linux端口是否可以访问
例：  telnet 192.168.231.130 22  //显示 SSH-2.0.省略......  。表示可以访问

//查看服务
 setup  
```

## RPM和 YUM

```java
(一)RPM包： 用于互联网下载包的打包及安装工具。

rpm	–qa|grep 软件包名    //查询已安装的 rpm 列表

rpm -qi 软件包名   //查看软件包信息

rpm -ql 软件包名 //查询软件包中有哪些的文件,并且目录是哪些位置

rpm -qf 文件名 //查询软件包中有哪些的文件,并且目录是哪些位置

rpm -e RPM包的名称 //卸载  带上--nodeps就是强制删除 如： rpm -e --nodeps foo  

rpm -ivh RPM包全路径名称  //安装

(二)YUM:是一个 Shell 前端软件包管理器。基于 RPM 包管理，能够从指定的服务器自动下载 RPM 包并且安装，可以自动处理依赖性关系，并且一次安装所有依赖的软件包。使用 yum 的前提是可以联网。

yum list|grep firefox  //查询 yum 服务器是否有需要安装的软件,如火狐 firefox

yum install firefox  //安装火狐
```

## shell编程

**基本了解**

```java
Shell 是一个命令行解释器，它为用户提供了一个向 Linux 内核发送请求以便运行程序的界面系统级程序，用户可以用 Shell 来启动、挂起、停止甚至是编写一些程序.

//shell格式要求

1)	脚本以#!/bin/bash 开头
2)	脚本需要有可执行权限
```

### **快速入门**

```java
案例一： 创建一个 Shell 脚本，输出 hello world!

//1.在/root/shell/目录创建一个shell脚本  
vim myShell.sh   

//2.输入
#!/bin/bash
echo "hello,world!"
    
//3.保存退出
wq!
    
//4.给所有者一个执行权限
chmod 744 myShell.sh    
    
//5.执行
/root/shell/myShell.sh
```

### **shell 变量**

```java
（一）基本了解：

//定义变量的规则
1)	变量名称可以由字母、数字和下划线组成，但是不能以数字开头。
2)	等号两侧不能有空格
3)	变量名称一般习惯为大写

//描述
1）Linux Shell 中的变量分为，系统变量和用户自定义变量。
2）系统变量：$HOME、$PWD、$SHELL、$USER 等等比如：  echo $HOME等等.
3）显示当前 shell 中所有变量：set

//例子：
echo "PATH=$PATH"  //输出系统变量
echo "user=$USER"      
    
（二）基本变量语法

//基本语法    
变量名=值  //定义变量(=之间不能又空格)
unset 变量名  //撤销变量
readonly 变量名=值 //声明静态变量  

//例子：
A=100  //定义A变量
echo "A=$A"  //引用的时候需要加$  

//将命令的返回值赋给变量（重点）
1）	A=`ls -la` 反引号，运行里面的命令，并把结果返回给变量 A
2）	A=$(ls -la) 等价于反引号

(三)环境变量

//基本语法
1)	export 变量名=变量值 （功能描述：将 shell 变量输出为环境变量）
2)	source 配置文件  （功能描述：让修改后的配置信息立即生效）
3)	echo $变量名  （功能描述：查询环境变量的值）

//例子
1.在/etc/profile脚本中定义TOMCAT_HOME环境变量:
TOMCAT_HOME=/opt/tomcat
export TOMCAT_HOME

2.刷新profile
source /etc/profile

3.查看
echo $TOMCAT_HOME

4.在另一个shell文件中可以使用 TOMCAT_HOME

//附加：  :<<! 内容 !  多行注释

(四)参数变量

//基本语法
$*  //把所有参数看成一个整体
$@  //把每个参数区分对待
$#  //参数个数

//例子
1.编写ppp shell脚本
echo "$0 $1 $2"
echo "$*"
echo "$@"
echo "参数个数=$#"    
    
2.执行并带上参数30 60 
./ppp.sh 30 60   //此处执行用的是相对路径
    
3.结果
./ppp.sh 30 60 
30 60 
30 60 
参数个数两个  

(五)预定义变量

//基本语法
$$  //当前进程的进程号PID
$!  //后台运行的最后一个进程号
$?  //最后一次执行的命令返回状态   

//例
1.编写shell脚本
#！/bin/bash    
echo "当前进程号=$$"
#后台的方式运行 myShell.sh
./myShell.sh &        // &代表后台方式运行shell
echo "最后的进程号=$!"
echo "执行的值=$?"    
```

### **运算符**

```java
//基本语法：
1)  “$((运算式))”或“$[运算式]”
2)	expr m + n
3)	expr m - n
4)	expr \*, /, %	乘，除，取余

//例子
//第一种方式$()
RESULT1=$(((2+3)*4))   
echo " result1=SRESULT1"
    
//第二种方式[]
RESULT2=$[(2+3)*4]
echo "result2= SRESULT2"
    
//expr方式省略...    
```

### **条件判断**

![](images/QQ截图20200516214202.png)

```java
//注意事项：[ 条件判断式 ]，中括号和条件判断式之间必须有空格 

if [ 条件判断式 ]
then
	程序
fi

//-----

if [ 条件判断式 ]
then
	程序
elif [条件判断式]
then
	程序
fi

//switch

case $变量名 in
	"值 1"）
			如果变量的值等于值 1，则执行程序 1
	;;
    "值 2"）
			如果变量的值等于值 2，则执行程序 2
	*）
			如果变量的值都不是以上的值，则执行此程序
    ;;
esac
```

### **循环**

```java
//•	基本语法 1
for 变 量 in 值 1 值 2 值 3…
 do
	程序
 done

//•	基本语法 2
for (( 初始值;循环控制条件;变量变化 ))
 do
	程序
 done
 
 //•基本语法 3
while [ 条件判断式 ]
do
	程序
done
```

### **函数**

```java
系统函数
//•	basename 基本语法
功能：返回完整路径最后 / 的部分，常用于获取文件名
basename [pathname] [suffix]
basename [string] [suffix]	（功能描述：basename 命令会删掉所有的前缀包括最后一个（‘/’）字符，然后将字符串显示出来。
选项：
suffix 为后缀，如果 suffix 被指定了，basename 会将 pathname 或 string 中的 suffix 去掉。

//•	dirname 基本语法
功能：返回完整路径最后 / 的前面的部分，常用于返回路径部分
dirname 文件绝对路径 （功能描述：从给定的包含绝对路径的文件名中去除文件名（非目录的部分），然后返回剩下的路径（目录的部分））
```

![](images/QQ截图20200516222559.png)

```
自定义函数
```

![](images/QQ截图20200516223808.png)

![](images/QQ截图20200516223927.png)

### **综合案例**

需求分析

1)每天凌晨 2:10  备份 数据库 atguiguDB 到 /data/backup/db

2)备份开始和备份结束能够给出相应的提示信息

3)备份后的文件要求以备份时间为文件名，并打包成 .tar.gz 的形式，比如：

2018-03-12_230201.tar.gz

3)    在备份的同时，检查是否有 10 天前备份的数据库文件，如果有就将其删除。

![](images/QQ截图20200516224519.png)

![](images/QQ截图20200516224620.png)

![](images/QQ截图20200516225339.png)

![](images/QQ图片20200516231032.png)

```
crontab -e
```

![](images/QQ截图20200516231624.png)

![](images/QQ截图20200516224830.png)