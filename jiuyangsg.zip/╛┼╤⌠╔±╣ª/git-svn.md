# git

## 安装设置

https://blog.csdn.net/qq_43384381/article/details/104503721 安装和配置地址

![](images/QQ截图20201219211309.png)

![](images/QQ截图20200529171158.png)

```java
//桌面空白处右键，点击 Git Bash Here 以打开Git命令窗口
$ git config --global user.name "用户名"   --去掉用户名则表示打印
$ git config --global user.email "邮箱地址"
```

## 基础操作

![](images/QQ截图20200529185420.png)

![](images/QQ截图20200529191540.png)

```java
git init   //创建版本库
    
touch a.txt //新增文本
vi a.txt  //编辑文本

第一阶段（基本）：
git status //git仓库中的状态
git add a.txt //将a.txt纳入git管理(暂存区)
git commit -m "提交修改的信息说明"  //提交（本地库）

git checkout -- a.txt  //回撤（修改的文件回撤成没修改的时候）
git reset HEAD a.txt //回撤（提交暂存区的回退回工作区）

第二阶段（查看）：
cat a.txt  //查看内容
git diff //查看内容不同(目前工作空间和本地库有什么区别)
git log  a.txt //查看a.txt修改日志
git log --pretty=oneline //可以一行显示，查看关键信息

第三阶段（回退）：
git reset --hard HEAD^   //几个^代表回退几步
git reset --hard HEAD~3  //回退3步
git reflog a.txt 获得头7位版本号，然后  git reset --hard 7位版本号 //穿梭穿越

git rm -f b.txt //删除

第四阶段（分支）：
ls -l //查看当前分支目录
 
git branch  //查看分支
git branch dev  //创建dev分支
git checkout dev  //切换分支 
git merge dev //把当前的分支合并dev分支 
git branch -d 分支名	//作用是删除分支
git checkout -b 分支名	//作用是新建+切换一步搞定

其他（git区域）：
（一）1.工作区空间：电脑本地硬盘目录。  2.版本库：有个隐藏目录.git。 
（二）2.工作区：红色   2.暂存区： Add以后   3.本地库： commit
（三）Git Repository（Git仓库）  最终确定的文件保存到仓库，成为一个新的版本，并且对他人可见。
```

# gitHub

```java
https://github.com/   //网址
wxq292775032@qq.com   wxq7408695W233
```

## ssh秘钥连接

![](images/QQ截图20200530090552.png)

```java
ssh-keygen -t rsa -C wxq292775032@qq.com //生成功钥和私钥
```

![](images/QQ截图20200530092337.png)

![](images/QQ截图20200530092530.png)

```java
ssh -T git@github.com  //连接测试
```

![](images/QQ截图20200530092917.png)

## 本地库推送/拉取

```
git remote add origin git@github.com:wxq292775032com/oa.git
git push -u origin master
```

![](images/QQ截图20200530095248.png)

![](images/QQ截图20200530095459.png)

```java
git push origin master  //把本地的东西推送到远程服务器上面
git pull origin master  //从远程拉取更新
    
git clone git@github.com:wxq292775032com/oa.git  //从gitHub上拉下oa项目 （重点）
```

![](images/QQ截图20200530101710.png)

![](images/QQ截图20200530102428.png)

# TortoiseGit

## 安装

```java
https://www.jb51.net/softjc/711629.html  //安装地址
```

![](images/QQ截图20200530203737.png)

![](images/QQ截图20201220002753.png)

![](images/QQ截图20201220001758.png)

![](images/QQ截图20201220002228.png)

![](images/QQ截图20201220002347.png)

## 介绍

![](images/QQ截图20200530132122.png)

![](images/QQ截图20200530211630.png)

## 操作

```java
//进入一个文件夹创建一个本地仓库
```

![](images/QQ截图20200530204000.png)

```java
//选择文本执行 git add操作
```

![](images/QQ截图20200530204356.png)

![](images/QQ截图20200530204644.png)

![](images/QQ截图20201220003900.png)

![](images/QQ截图20201220004816.png)

![](images/QQ截图20201220005009.png)

![](images/QQ截图20201220005153.png)

![](images/QQ截图20201220005450.png)

![](images/QQ截图20201220010321.png)

# 其他	

![](images/QQ截图20200530124927.png)



![](images/QQ截图20200530125254.png)

# --------------------------

# SVN

```java
https://svnbucket.com/#/login  //网址
账号：wxq292775032   密码：wxq7408695W233
```

## 基本界面操作

![](images/QQ截图20201220200837.png)

![](images/QQ截图20201220201748.png)

![](images/QQ截图20201220202255.png)

![](images/QQ截图20201220202648.png)

![](images/QQ截图20201220203115.png)

![](images/QQ截图20201220203501.png)

![](images/QQ截图20201220204451.png)

## 创建分支

```
SNV目录机构：(一)trunk主干；(二)branches分支；(三)tags标签。
```

![](images/QQ截图20201220211130.png)