## Shiro 

### **(一)导入相关依赖**

```xml
<!--*shiro*-->
<dependency> <!--shiro整合springboot依赖-->
    <groupId>org.apache.shiro</groupId>
    <artifactId>shiro-spring-boot-starter</artifactId>
    <version>1.5.3</version>
</dependency>
<dependency><!--shiro缓存-->
    <groupId>org.apache.shiro</groupId>
    <artifactId>shiro-ehcache</artifactId>
    <version>1.5.3</version>
</dependency>
<!--shiro整合thymeleaf-->
<dependency>
    <groupId>com.github.theborakompanioni</groupId>
    <artifactId>thymeleaf-extras-shiro</artifactId>
    <version>2.0.0</version>
</dependency>

 <!--*thymeleaf*-->
<dependency><!--thymeleaf整合springboot模板引擎-->
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-thymeleaf</artifactId>
</dependency>

<!--有可能thymeleaf 会出现模板版本有问题，需要修改版本，看具体情况-->
<properties>
    <thymeleaf.version>3.0.11.RELEASE</thymeleaf.version>
    <thymeleaf-layout-dialect.version>2.3.0</thymeleaf-layout-dialect.version>
</properties>
```

### (二)编写Shiro配置类

```java
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * shiro配置类
 */
@Configuration
public class MyShiroConfig {

    //创建ShiroFilterFactoryBean
    @Bean
    public ShiroFilterFactoryBean getShiroFilterFactoryBean(
        @Qualifier("securityManager") DefaultWebSecurityManager securityManager){
        ShiroFilterFactoryBean shiroFilterFactoryBean = new ShiroFilterFactoryBean();   
         //1.设置安全管理器
        shiroFilterFactoryBean.setSecurityManager(securityManager);

        //2.添加Shiro内置过滤器
        Map<String, String> filterMap = new LinkedHashMap<String,String>();
        filterMap.put("/user/login","anon");//不需要校验的请求(进登入页、校验请求)
       
        //表示身份校验以后，该请求还需要有相关权限
        filterMap.put("/user/update","perms[user:update]");
        
        filterMap.put("/**","authc");//没校验前对所有请求进行拦截(除不需要校验的请求)

        //提示页面
        shiroFilterFactoryBean.setLoginUrl("/thymeleaf/index");//被拦截的请求，返回登录页   
        shiroFilterFactoryBean.setUnauthorizedUrl("/thymeleaf/noAuth");//未授权提示页面

        shiroFilterFactoryBean.setFilterChainDefinitionMap(filterMap);
        return shiroFilterFactoryBean;
    }

    //2.创建DefaultWebSecurityManager
    @Bean(name = "securityManager")
    public DefaultWebSecurityManager getDefaultWebSecurityManager(
        @Qualifier("userRealm")UserRealm userRealm){
        DefaultWebSecurityManager securityManager = new DefaultWebSecurityManager();  
        securityManager.setRealm(userRealm); //关联realm
        return securityManager;

    }

   	//3.创建Realm
    @Bean(name="userRealm")
    public UserRealm getRealm(){
        UserRealm userRealm = new UserRealm();
        
        //修改凭证校验匹配器,不使用加盐处理，可以不加
       	HashedCredentialsMatcher credentialsMatcher = new HashedCredentialsMatcher();
       	credentialsMatcher.setHashAlgorithmName("MD5"); //设置加密算法为md5
       	credentialsMatcher.setHashIterations(1024); //设置散列次数
       	userRealm.setCredentialsMatcher(credentialsMatcher);
        
        //开启缓存管理,可以不加可以不开，但是要开启必须注意添加依赖
        userRealm.setCacheManager(new EhCacheManager());
        userRealm.setCachingEnabled(true);//开启全局缓存
        userRealm.setAuthenticationCachingEnabled(true);//认证缓存
        userRealm.setAuthenticationCacheName("authenticationCache");
        userRealm.setAuthorizationCachingEnabled(true);//开启授权缓存
        userRealm.setAuthorizationCacheName("authorizationCache");
        
        return userRealm;
    }
}


//常用的过滤器：
anon: 无需认证（登录）可以访问
authc: 必须认证才可以访问
user: 如果使用rememberMe的功能可以直接访问
perms： 该资源必须得到资源权限才可以访问
role: 该资源必须得到角色权限才可以访问
logout:登出过滤器
```

### **(三)认证与授权**

```java
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 自定义Realm
 */
public class UserRealm extends AuthorizingRealm {

    @Autowired
    private UserService userService;

    @Autowired
    private RoleService roleService;

    //执行授权逻辑
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo
        (PrincipalCollection principals) {
        //1.给资源进行授权
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
       
        //2.获取当前登录用户的信息，就是 SimpleAuthenticationInfo
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal(); 

        //3.到数据库查询当前登录用户的授权字符串
        Role role = new Role();
        role.setId(user.getRole_id());
        role = roleService.findRoleIdentification(role)；
        String identification = role.getIdentification(); //授权字符串
   
        //4.添加资源的授权字符串，相当于info.addStringPermission("user:update");
        info.addStringPermission(identification);
        return info;
    }

   //执行认证逻辑
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo
        (AuthenticationToken token) throws AuthenticationException {
     	//获取用户输入值
        UsernamePasswordToken upt = (UsernamePasswordToken) token; 
      
       //查询数据库
        User user = new User();
        user.setName(upt.getUsername());  //用户名
        List<User> list = userService.findUser(user);

         //1.判断用户名
        if (list == null || (list != null && list.size() < 1)) {
            return null; //用户名不存在,shiro底层户抛出UnknowAccountException
        }

        //2.判断密码
        //参数1：当前用户信息  参数2：用户密码 参数3:realm的名字
        return new SimpleAuthenticationInfo
            (list.get(0),list.get(0).getPassword(), this.getName());
        //加盐时使用
       //new SimpleAuthenticationInfo(list.get(0),list.get(0).getPassword(), ByteSource.Util.bytes("数据库查出来的盐值字段"), this.getName());
    }
```

### **(四)登录逻辑处理**

```java
    @RequestMapping("/login")
    public String login(String name, String password, Model model){
        // 使用Shiro编写认证操作
        // 1.获取Subject
        Subject subject = SecurityUtils.getSubject();
      
        // 2.封装用户数据，注意：加盐时之间放入明文密码
        UsernamePasswordToken token = 
            new UsernamePasswordToken(name, MD5Tools.shiroMd5(password,3));
        // 3.执行登录方法
        try{
            subject.login(token);
            return "redirect:homePage"; //登录成功
        }catch (UnknownAccountException e){//登录失败：用户名不存在     
            model.addAttribute("msg","用户名不存在");
            return "index";
        }catch (IncorrectCredentialsException e) { //登录失败：密码错误     
            model.addAttribute("msg","密码错误");
            return "index";
        }
        //LockedAccountException  lae  //用户被锁定的异常
        //AuthenticationException  ae  //所有认证异常的父类
    }


//代码级别
subject.getSession();//获取当前用户拿到的session
subject.isAuthenticated();//判断当前用户是否已经被认证

subject.hasRole("admin");//是否有admin权限？
subject.hasRoles(Arrays.asList("admin","users")); //是否属于其中一个角色？
subject.hasAllRoles(Arrays.asList("admin","user"));//是否同时具有admin和user权限？


subject.isPermitted("user:*:*"); //是否访问该资源的权限？
subject.isPermitted("user:*:01","order:*:10"); //分别具有
subject.isPermittedAll("user:*:01","order:*:10");//同时具有哪些权限

subject.logout(); //执行登出
token.setRememberMe(true);//记住我

//方法请求级别
@RequiresRoles("damin") //需要哪个角色
@RequiresPermissions("user:update:01") //资源
```

### (五)标签管理

```java
//1.注意相关依赖的添加。

//2.在MyShiroConfig配置类中添加该项，用于thymeleaf和shiro标签配合使用
@Bean
public ShiroDialect getShiroDialect(){
    return new ShiroDialect();
}
```

```html
<!--3.html页面 -->
<html lang="en" xmlns:th="http://www.thymeleaf.org" xmlns:shiro="http://www.pollix.at/thymeleaf/shiro"> //不添加这引用会报红

     <!--该标签，在用户有user:update权限才显示-->    
    <div shiro:hasPermission="user:update"></div>  

    <!--获取身份信息,不需要写内容-->       
    <span shiro:principal=""></span>  
    
	<!--认证处理-->       
    <span shiro:authenticated="">认证通过展示的内容</span>    
    <span shiro:notAuthenticated="">没有认证展示的内容</span>     
    
	<!--授权角色-->
    <span shiro:hasRole ="admin">this is admin</span> 

```

```xml
https://www.bilibili.com/video/BV1uz4y197Zm?p=22  shiro整合Redis缓存

1.拦截所有请求.
	 filterMap.put("/*","authc");

	2.哪些请求不拦截？
	 filterMap.put("/thymeleaf/index","anon");
	
	3.被拦截后的请求,应该跳转到哪个页面？	
	shiroFilterFactoryBean.setLoginUrl("/thymeleaf/index");

	4.授权拦截器
	
	
	5.未授权跳转到的页面
	shiroFilterFactoryBean.setUnauthorizedUrl("/thymeleaf/noAuth");


	6.标签管理：前端标签的隐藏和显示的问题。

```

