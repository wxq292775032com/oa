

## JAVA核心

### 基本概念

```
八大数据类型:byte short int long float double char boolean
 
static: 被static修饰的属性或方法，是先于对象创建而加载的。

接口:1.方法是抽象方法 2.属性是静态常量  3.接口之间可以多继承，但不能继承类

StringBuffer和StringBuilder的区别：前者的方法加了同步锁，线程安全，后者则没有。

String: String是一个常量，是不可变的，所以对于每一次赋值都会创建一个新的对象。

学过哪些设计模式： mvc模式   单例模式（加载配置文件） 工厂模式（Spring框架对Bean管理） 代理模式（spring使用Aop实现使用了jdk动态代理）。

jdk和jre区别：JDK就包含了JRE，但是JRE是可以独立安装，它是Java程序运行环境，包含了Java虚拟机。JDK是Java的开发工具包，主要包含了各种类库和工具。

jvm 的内存结构：java 虚拟机的内存结构分为堆(heap)和栈(stack),堆里面存放是对象实例也就是 new 出来的对象。栈里面存放的是基本数据类型以及引用数据类型的地址。对于所谓的常量是存储在方法区的常量池里面。
```

### JDBC+集合+线程

```java
//JDBC怎么连接数据库:
1.Class.forName()加载驱动。 
2.通过DriverManager获得数据库连接。
3.创建Statement对象。  
4.发送sql处理结果。

//list、map、set 三个接口，各有什么特点:
1.list和set他们有一个共同的父接口Collection。
2.List集合值可以重复，有序的，set集合值不允许重复无序的。
3.list接口实现类有ArrayList、LinkedList；set接口有HashSet，LinkedHashSet等。
4.Map是键值对，key值不要求有序 , 但key值不允许重复。常用实现类有HashMap、Hashtable

//ArrayList 和 LinkedList区别:
1.它俩都是list接口的实现类。
2.ArrayList存储方式，像数组一样，开辟一连串空间；而LinkedList是链表式存储数据。
3.ArrayList在数据的循环遍历上效率比较高，LinkedList对数据的增加和删除效率比较高。

//hashtable 和 hashmap的区别：
1.Hashtable是线程安全的，它的每个方法中都加了同步锁，HashMap则没有。  
2.Hashtable的key值不能为null，HashMap可以。
3.父类不同。HashTabale继承自Dictionnary；而HashMap继承自AbstractMap。

//线程是什么：
线程就是程序内部的一条执行路径，多线程就相当于多条执行路径。线程之间是相互独立的，可以共享进程的资源，可以并行执行各自不同的任务
//线程有什么用
好处，可以充分利用CPU资源。或是将一些耗时较长的操作：如下载、数据库访问等，放在子线程中执行，可以防止主线程卡死。
//安全问题
多个线程对同一资源操作，就会产生安全问题。如线程A，进入方法拿到count值。刚读取还没来得及改，B线程又进来了，这就导致他俩读取的值一样。
```

### Spring框架

```
《Ioc工作原理》
就是把原先我们代码里面需要实现的对象创建、
依赖的代码，反转给容器来帮忙实现。所以我们需要创建一个容器，
同时需要一种描述（可配置的文件）来让容器知道需要创建的对象
与对象的关系。

《AOP工作原理》
指在程序运行期间将某段代码，动态的切入到某个类
的指定方法的指定位置简单说就是在不改变源程序的基础上为代码
段增加新的功能，对代码进行增强处理。设计思想来源于代理设计模式。

《SpringMVC实现》
  1.springMVC所有请求都是提交给DispatcherServlet,
     然后通过它委托给应用系统的其他模块，负责对请求进行真正的处理工作。
  2. DispatcherServlet查询一个或多个 HandleMapping，
     找到处理请求的Contrller
  3. Contrller进行业务逻辑处理后，会返回一个ModelAndView
  4. DispatcherServlet 查询一个或多个ViewResolver
           视图解析器，找到ModelAndView对象指定视图对象负责渲染返回给客户端  
    
《Spring提供了哪些 Bean 的作用域》
 singleton  单例方式存在
 prototype 每次获取Bean实例都返回一个新实例
 request  每次Http请求都会创建一个新实例
 session  同一个Http会话共享一个Bean的实例
```

### servlet

```
Servlet具体执行过程是什么：
         1. 用户发送请求，容器分析请求，如果该请求指向
	    一个Servlet,容器创建两个对象，
            一个是HttpServletRequest请求对象，
            一个是HttpServletResponse对象
         2. 容器调用Servlet的service()方法，
            把请求和响应对象作为参数传递给该方法。
         3. service()方法，根据客户发出请求的是get还是post方法，
            决定调用Servlet的doGet()方法或者doPost()方法
         4.然后通过response响应通过容器发送给浏览器
          （然后请求和响应出了作用域，或将被销毁）  

jsp九大内置对象：
      page    表示本页面产生的一个Servlet实例
      requst  生命周期：比如访问某个页面，
	就是一次请求。页面访问结束，该页面的request就结束了
      session  生命周期：打开浏览器，Session开始，
       当超过时间限制Session就会失效，或者调用invalidate()方法使Session失效
      application  生命周期为：应用程序启动到停止。
      pageContext  该对象代表该JSP 页面上下文，可以访问一些共享数据
      response
      out
      config
      exception

转发与重定向的区别：
	1. 转发是在服务器端发挥作用，重定向是在客户端发挥作用。
	2. 转发是将同一请求，在服务器资源之间进行传递，重定向是通
           过发送一个新的请求实现页面转向
	3.转发时，浏览器的地址不会显示转向后的地址； 重定向时在地
           址栏可以显示转向后的地址

Servlet生命周期：
	Servlet通过调用init()方法进行初始化
	Servlet通过service()方法来处理客户端的请求
	Servlet通过调用destroy()方法终止，最后由垃圾回收站进行垃圾回收

request 跟 session 的区别
	1.他们的生命周期不同，request对应的是一次请求，
          session对应的是一次会话
	2.request占用资源比较少，相对来说缺乏持续性，
         而session资源消耗比较大，所以通常使用request来保存信息。

session和cookie的区别：
	session是存储在服务器端，cookie是存储在客户端，
         session安全性比cookie高。
	session里的东西增加会造成服务器的负担，
        所以一些不重要的信息会存储在cookie里
          
get传参和post传参有什么区别：
	1.  get参数通过url传递 ， post放在  requestbody 中
                2.  get请求在url传递的参数是有长度限制的，而post没有
                3.  get相对post来说，安全性不高，因为参数直接暴露在url中
	4.get是从服务器上获取数据，post是向服务器传送数据          
```

### 数据库

![](images/QQ图片20201210193540.png)

![](images/QQ截图20201210193648.png)

```java
第一阶段：基础
事务的四大特征：原子性、一致性、隔离性、持久性

并发事务所带来的问题：
	脏读：一个事务读取了另外一个事务未提交(回滚)的数据。
 	不可重读：一个事务读取某一行数据，多次读取结果不同。
	幻读：一个事务内读取到了别的事务插入的数据，导致前后读取不一致。

隔离级别：
	Read uncommitted（最低级别，任何情况都无法保证）
	Read committed（可避免脏读的发生）
	Repeatable read（可避免脏读、不可重复读的发生）
	Serializable（可避免脏读、不可重复读、幻读的发生）
	
Spring事务的传播特性:
(一)REQUIRED(事物存在支持当前事物，不存在则开启事务)
(二)SUPPORTS(存在一个事务，则支持当前事务。如果没有则非事务运行)
    

第二阶段：关于索引
//什么是索引？
索引就是数据结构，一种排好序可以快速查找的数据结构。它主要影响where子句和order by排序这两方面。

//关于建索引
1.索引一般建在经常作为查询条件或排序的字段上。
2.经常修改，删除的字段，不适合建索引。

//索引失效问题
not null 、查询条件范围之后、模糊查询，都会导致索引失效

//如何索引分析
可以通过explain关键字
id：
type:ref>range>index>ALL
key:
key_len:

第三阶段：数据库优化
1.Mysql常见瓶颈cpu饱和，io装入数据大于内存容量，然后就是sql问题。
2.sql性能慢，要么就是表结构设计使得关联查询太多join,要么就是索引失效。
3.具体可以开启慢查询日志，设置阙值，将查询慢的sql记录下来。 set global slow_query_log = 1;
4.然后再逐条具体分析。

第四阶段：关于锁
MyISAM：只支持表锁(读写)
InnoDB：既支持表锁(没使用索引)、也支持行锁(使用索引)。
show status like
键值在条件范围内，但是不存在的值。叫着间隙锁


第五阶段：树结构：
(一)二叉树：一个节点有两个子节点，比本节点大的在右边，小的在左边。但是会犯左倾或右倾的问题。
(二)平衡二叉树：上面的节点会变，不会犯左倾或者右倾的错误。缺点是数据量越多，树高就越高，树高越高，说明遍历查找的次数就越多，io就多，随着数据量的加大导致系统性能下降。

(三)B树：B树会比平衡二叉树减少一次IO操作。它一个节点可以放两个。它每个节点既有键值，也有数据记录，每个磁盘页的存储空间有限，能存储的key值数量较小，导致树高较高

(四)B+树：根节点和枝节点只存储这个键值信息。数据记录是按顺序存放在叶子节点中的。所以加大了每个节点存储的key值数量，降低B+树的高度。

(五)利用索引查询的时候，不可能一次将几个G的索引加载进内存，只能逐一加载每个磁盘页，而磁盘页对应了索引树的节点。(InnoDB存储引擎最小存储单元是页,一页为16K)

redis分布式锁：
1.通过setNX()方法加锁，delete()方法释放锁。
2.系统宕机了或逻辑报错导致锁没释放掉，一般会通过expire给它指定个失效时间。
3.a线程的redis锁失效了，逻辑还没处理完，b线程进来加锁，这时候可能导致a线程把b线程的锁给释放了。删除时要判断下是不是自己的锁。
4.保证redis释放锁的原子性，可以使用redis事务监控和lua脚本。

5.redis以外宕机了怎么办？直接使用Redisson

多语言：
1.创建多个properties文件，格式是message_语言_国家。
2.使用ResourceBundleMessageSource管理国际化资源文件。
3.fmt:mesaage标签。

高并发：
1.将一个系统拆分为多个子系统。
2.缓存用上，比如用redis在数据库前挡一层，应对大多数读操作。
3.MQ用上，将增删改操作放入mq，让后边系统慢慢消费慢慢写。
4.再不行就分库分表，将一个库拆分为多个库，一个表拆分为多个表

动态代理：
它有两个媒介InvocationHandler和Proxy。
实现InvocationHandler接口，将代理对象通过构造注入进来，使用invoke方法做增强处理。
然后将InvocationHandler实现类，交给proxy,通过它的静态方法生成动态代理类。


```

nnoDB最小单位为页,一页为16K,主键一般为bigint 8字节,指针大小在InnoDB是6字节,这样一共14字节那么一页总指针数为 (16*1024) / (8+4) = 1170 假设每行数据为1K那么一页是16行记录 所以当前B+数总行数为 1170*16 = 18720, 三层总指针为1170*1170*16 = 21902400所以当数据到达千万时可以考虑分表了,否则树高超过三层,会导致查询效率变差.

## 技术总结

![](images/QQ截图20201120122151.png)

### *Socket

```
Socket就是实现客户端与服务端之间的双向通信。

实现方式，两个方面服务端和客户端：
第一服务端。通过创建ServerSocket对象指定端口来建立，然后通过Socket的输入输出流来获取和响应数据。
第二客户端。直接通过创建Socket指定连接地址和端口号，通过输出和输入流来发送和接受信息。
```

### WebService

![](images/QQ截图20201203200543.png)

```
weService就是向外部提供访问的接口，让其他系统对它进行访问。优点是跨平台跨语言。

规范有三种常用的有两种：一种是JAX-WS基于soap协议；一种是JAX-RS它是restful风格基于http协议的。

实现方式：
(一)导入相关的依赖。
(二)在web.xml中配置cxf的sevlet。
(三)编写相关的实现类，通过jaxws或jaxrs标签配置webservice服务。
(四)相关的注解，@POST、@Path、@Produces(指定返回的数据类型)、@Consumes(指定请求的数据格式类型)。
访问。定义一个目录层次一样的接口，通过jaxws:client联系访问路径，就可以了。
```

### Quertz

![](images/QQ截图20201203204641.png)

```
Quartz就是指定的时间内执行任务。它有三个核心：Job任务、触发器(Trigger)、调度器(Scheduler)。Job具体做事情的；Trigger设置规则，规定什么时间执行；Scheduler整合Job类和触发器。

实现方式：
(一)导入相关的依赖。
(二)实现Job接口重写execute方法。
(三)进行配置。创建JobDetail绑定任务类；创建触发器设定规则；创建调度器关联任务和触发器。最后启动。
```

### Swagger

```java
Swagger配置API规范文档。

实现方式：
(一)导入相关的依赖。
(二)编写swagger配置：
1、创建ApiInfo重写配置信息，如标题、版本号、作者信息、描述等。
2、配置Docket的bean实例。如指定扫描包的路径，是否启动Swaager等
3、常用的注解。@ApiModel,@ApiModelProperty,@ApiOperation,@ApiParam
```

### Shiro

![](images/QQ截图20201203213842.png)

```
Shiro这类框架主要完成两方面的功能：(一)用户认证；(二)授权。然后加一些辅助性的密码加密，会话管理等功能。
它有三个核心对象：Subject、SecurityManager、Realm。Subject就是用户主体，他把操作交给SecurityManager；SecurityManager是安全管理器，它关联Realm；Realm就相当于Shiro连接数据的桥梁，它具体执行认证和授权的逻辑。

实现方式：
(一)创建UserRealm继承AuthorizingRealm类，实现认证和授权两个方法的逻辑。
(二)创建ShiroConfig。把UserRealm关联上securityManager，然后设置进ShiroFilterFactoryBean
(三)编写具体的登入逻辑，通过Subject对象，把用户信息传递进去，让UserRealm执行具体的认证和授权操作。

常用方法：
subject.getSession();
subject.hasRole("admin");
subject.isPermitted("user:*:*");
token.setRememberMe(true);
```

### Redis

![](images/QQ截图20201203225226.png)

![](images/QQ截图20201203234551.png)

```java
//Redis基本了解
1、redis一般作为缓存数据库，它的特点是K-V模式存储，读写速度快、支持事务备份、支持持久化等。

2、所有操作都是单线程,原子性的。redis是个单进程以epoll包装以后在大批量文件操作里面多路的IO复用。

3、默认16个数据库，下表从0开始。

4.默认端口6379

5.redis中字符串value最多可以是512M

//Redis持久化：两种方式rdb、aof。
(一)RDB:它会在指定时间间隔内，将内存数据快照到临时文件中。
具体说就是单独fork一个子进程来进行持久化，将数据写入dump.rdb，等持久化过程都结束了，再用这个临时文件再替换已经上次持久化好的文件。

1、默认3种持久化规则：1分钟内10000个key值改变，5分钟内10个key值改变，15分钟内1个key值改变。

2、缺点：如果redis意外挂了，会导致可能有几分钟的数据丢失。

3、优点：RDB效率比AOF更高效。

(二)ROF:它就是以日志(appendonly.aof)的形式来记录每个操作。而且在aof文件体积变大时，会自动对AOF进行重写。

1、aof和rdb两个都开启的话，会先加载appendonly.aof。

2.缺点：对于相同的数据集来说，AOF文件的体积通常要大于RDB文件的体积，AOF的速度会慢于RDB。

3.优点：数据完整性高。

4.appendonly.aof文件有误，纠正方式：  redis-check-aof --fix 

//Redis事务
1.redis事务相当于一组命令的集合，multi开启事务后，会把命令先入队到事务队列里面，等exec命令触发事务后一次性执行。

2.redis部分支持事务，他并不完全保证原子性，可能第一条命令执行失败了，其后的命令仍然会被执行，没有回滚。

//CAP理论
强一致性、高可用性、分区容错性(分布式内由于网络原因，系统不能在时限内达成数据一致性，就意味着发生了分区)
    
CAP理论核心：一个分布式系统不可能很好的满足一致性，可用性和分区容错性这三个需求，最多只能同时满足两个。而由于当前的网络硬件肯定会出现延迟等问题，所以分区容错性是必须实现的，只能在一致性和高可用之间进行权衡。 

//五大数据类型：String List Hash Set ZSet

String: append setnx msetnx mset mget incr decr incrby decrby
List: lpush rpush lpop rpop lindex llen
Hash:hset  hmset  hget  hmget  hgetall
Set: sadd  smembers    //唯一、无序
Zset:zadd  zrange zrangebyscore  //有序且不重复,每个元素会关联一个double分数
```

### RabbitMQ

![](images/QQ截图20201204130621.png)

![](images/QQ截图20201204140508.png)

```java
//概念:
RabbitMQ是基于AMQP协议的，这种协议也基于生产者与消费者模型。生产者会与RabbitServer建立连接，建立连接之后通过通道形式来传递消息。而一个生产者会对应broker里面的一个虚拟主机，虚拟主机访问它是需要权限的，一般一个项目或应用只能访问一个虚拟主机，多个应用互不影响。生产者进入虚拟主机后，就可以把消息放到我们的交换机中。而消费者也通过它获取消息。所以消费者和生产者之间是完全解耦的，不需要关心生产者有没有运行，只需要关心队列里面有没有相应的消息。简单说RabbitMQ就像个中间商一样，生产者向它生产消息，消费者向它消费消息。

//java普通连接
1.先创建用户，再创建虚拟主机。
2.将用户和虚拟主机进行绑定。
3.通过ConnectionFactory创建连接。
4.通过createChannel获取连接通道。
5.通过queueDeclare绑定队列。
6.通过basicPublish向交换机发送消息。

//spirngboot常用注解
@RabbitListener   @RabbitHandler  @QueueBinding

//常用模型
点对点、工作模型、广播模型(fanout)、路由模型(direct)、订阅模型(topic)

//防止消息丢失
1.队列进行持久化
2.把自动确认机制，改为ACK手动确认机制。方法：basicAck
```

### **Docker**

![](images/QQ截图20201204144059.png)

![](images/QQ截图20201204153102.png)

![](images/QQ截图20201204161926.png)

```java
//docker概念
Docker就是是一个容器运行载体。它把应用程序所需要的系统环境，由下而上打包，形成一个image镜像文件。通过这个镜像文件才能生成Docker容器。可以做到一次封装，到处运行。不用在新机子上又要重新配置那些麻烦的环境。

//docker三要素：
仓库、镜像、容器

//Docker和传统虚拟化方式不同之处
1.传统虚拟机技术是虚拟出一套硬件后，在其上运行一个完整操作系统，然后在该系统上再运行所需应用进程；

2.而容器内的应用进程直接运行于宿主的内核，容器内没有自己的内核，因此容器要比传统虚拟机更轻便。而且每个容器之间互相隔离，互不影响。
	
//镜像原理
它其实是一种分层的联合文件系统，一次同时加载多个文件系统，但从外面看起来就是一个文件系统。
主要有两个bootfs和rootfs,bootfs是用来加载kernel的，rootfs就是各种不同的操作系统发行版本，比如Ubuntu,Centos等。	

//容器数据卷
主要是做数据持久化工作和容器之间共享数据的。docker -v 宿主机绝对路径对应容器目录

//DockerFile
1.通过编写DockerFile文件 Build以后可以创建新的镜像。
2.docker从基础镜像运行一个容器，执行指令做出修改，提交一个镜像层。然后又基于镜像执行下一条指令，这样一层一层的创建，直到所有指令执行完。
3.常用关键字：FROM、RUN、EXPOSE、ENV、ADD、COPY、CMD

//常用方法
docker search  //查询gitHub镜像
docker pull   //下载gitHub镜像
docker images  //列出本地主机上的镜像
docker rmi    //删除某个本地镜像

docker run   //通过镜像创建容器
	-d,-it,-name="" -p
docker ps   //列出所有启动的容器
docker start[stop] 容器id  //启动关闭容器
docker attach 容器id   //重新进入容器
docker rm  //删除容器
```

### Linux

![](images/QQ截图20201204163737.png)

```java
//部分目录了解
bin:命令    sbin:系统管理程序   home：用户目录   boot：核心文件   opt:安装包   
/usr/local   安装软件的目录

//常用命令
更改权限：chown	创建目录：mkdir  创建空文件：touch   压缩：tar -zcvf  输出控制台：echo
查看进程:ps -ef | grep   安装： yum install   
```

### Nginx

![](images/QQ截图20201204170605.png)

![](images/QQ截图20201204183126.png)

![](images/QQ截图20201204191121.png)

```java
//nginx概念：
nginx就是个代理服务器，可以做反向代理、负载均衡等。

//正反向代理：
正向代理：依赖代理服务器进行网络访问，它隐藏真实的客户端。
反向代理：反向代理服务器转向到某个tomcat也就是目标服务器。这样子对外暴露的只就是反向代理服务器地址，隐藏了真实服务器IP地址。
总结：反向代理是代理目标服务器被请求，正向代理是服务器代理客户端去请求。

//负载均衡：
将请求分发到多个服务器上。

//动静分离：
把动态页面和静态页面由不同的服务器来解析，加快解析速度。

//nginx内容有三部分组成
全局块:主要设置一些影响nginx整体运行的配置指令。如worker_processes，值越大并发处理量也越多。
events块：主要影响 Nginx 服务器与用户的网络连接。如：worker_connections 表示支持的最大连接数。 
http块：http又包含了 server 块，server块里面可以配置监听配置主机Ip,有location块，反向代理就可以在这里配置。

//配置反向代理
1.在server块中配置 监听和请求客户端请求地址 server_name
2.在server的location块中，在proxy_pass属性中配置目标服务器地址。

//配置负载均衡
1.定义个upstream块，将多个目标服务器地址配置进去
2.然后在localhost块里面引用就行了，默认是轮询方式。

//负载均衡怎么解决session问题
配置  ip_hash 可以让每个客户固定访问一个后端服务器

//nginx基本流程	
	客户端发送请求给Master，然后由它将请求分派给worker, worker通过争抢机制得到一个任务，然后它可以进行反向代理，用tomcat完成我们的具体操作；
	
//附加：
nginx同redis类似都采用io多路复用机制，每个worker都是一个独立进程，每个进程只有一个主线程，通过一步非堵塞方式来处理请求，所以速度特别快。
```

### springBoot

![](images/QQ截图20201204215125.png)

```java
SpringBoot它产生的目的就是为了简化繁琐的配置，核心思想就是自动配置。
两个要点POM文件和启动类：

1、POM文件它通过starter-parent这个父项目管理所有依赖版本。springBoot将所有功能场景都抽取出来，做成一个个starters，在项目中只需要引入这些starter，相关场景的依赖就会导入进来。要用什么功能就导入什么场景依赖。

2、启动类它依靠一个注解@SpringBootApplication，它是一个组合注解，其中里面有一个 @EnableAutoConfiguration注解它就是开启自动配置功能的，它里面也几个注解最终会通过一些列的逻辑从 META-INF下的spring.factories获取定制的值，这些值导入到容器中，自动配置类就生效了。
3、我们开发时只要在application里配置一些少量的东西就行了。

//与配置文件的属性绑定
@ConfigurationProperties
@Value
//加载指定的配置
@PropertySource 

//标注为容器组件
@Component  
```

### springCloud

![](images/QQ截图20201204230322.png)

![](images/QQ截图20201205102113.png)

![](images/QQ截图20201205111037.png)

![](images/QQ截图20201205185844.png)

![](images/QQ截图20201205202756.png)

![](images/QQ截图20201205223828.png)

![](images/QQ截图20201205230145.png)

```java
spirngCloud分布式微服务架构的解决方案，是多种微服务架构技术的集合.

//采用的方案是：
SpringBoot2.2版 和 SpringCloud H版

第一阶段：服务注册中心：

//概念
就是管理服务与服务之间的依赖关系，将服务注册到中心，服务与服务之间就可以通过别名的方式实现远程调用。

//Eureka
Eureka有两个组件：
	1.一个是Eureka Server,当各个微服务节点配置启动后会在Eureka Server中进行注册，然后它上面就会		存储所有可用服务节点的信息。(每隔30秒发送一次心跳判断服务是否存在，过了90秒不在就会移除)AP
	2.另一个是EurekaClient用于服务之间进行交互的，同时内置了一个使用轮询负载算法的负载均衡器。
		
//服务调用
Eureka集成了Ribbon。


第二阶段：服务调用：

//Ribbon概念
就是一个负载均衡的组件加RestTemplate调用。

//Ribbon负载均衡和nginx负载均衡的区别
Nginx是服务器负载均衡，客户端所有请求都会交给Nginx，然后由nginx实现转发请求。即负载均衡是由服务端实现
Ribbon本地负载均衡，在调用微服务接口时候，会在注册中心上获取注册信息服务列表，从而在本地实现远程服务调用。

//Ribbon工作分为两步
第一会先选择在同一区域内负载较少的server 
第二再根据用户指定的策略，轮询还是随机从server取到的服务注册列表中选择一个地址。

//常用方法。
postForObject  PostForEntity

//IRule接口实现的算法，把实例改为RandomRule就可以变为随机

//OpenFegin
OpenFegin是SpirngCloud在Feign的基础上添加了SpringMVC注解的支持。OpenFegin的@FeignClient可以解析SpringMVC的@RequestMapping注解下的接口，通过动态代理的方式产生实现类，实现类中做负载均衡并调用服务

//Fegin
他就是一个服务接口绑定器，内置了Ribbon用来做负载均衡。只要创建一个微服务接口，在接口上面添加与Feign相关的注解，就能实现微服务之间的调用。


第三阶段：服务降级

//概念
微服务链路中互相调用，A调用B,B调用C,如果某个链路出现问题了就会发生级联故障。

//Hystrix
主要解决的是分布式链路系统中，某一链路发生超时、异常等情况，不会导致整体服务失败，避免级联故障。

//服务降级
某一链路发生超时、异常等情况，返回一个兜底备选的响应，不会长时间等待或抛出异常。

//注解：
方法内：
@HystrixCommand
fallbackMethod
commandProperties{
  @HystrixProperty =""3秒超时
}
全局降级：
@DefaultProperties
defaultFallback

//服务熔断
它是一种保护程序链路的方式，当某个链路出现响应时间太长或者报错时，会进行服务降级，进而开启熔断在一定时间窗内让请求不再调用当前服务。

//开启服务熔断三个重要参数：
1.快照时间窗：默认10秒
2.请求总数：默认20
3.错误百分比：百分之50
十秒内请求总数超过20,并且错误率达到百分之50就开启断路器

//开启熔断
circuitBreaker.enabled 设为 true

//服务限流
秒杀高并发等操作，严禁一窝蜂过来拥挤，大家排队，一秒钟N个，有序进行。

第四阶段：SpringCloud GateWay:

//GateWay有三个核心概念：
路由、断言、过滤。路由它由ID,目标URL,一系列的断言和过滤器组成，如果断言为true则匹配。过滤，可以在请求被路由前或者之后对请求进行修改，可以做参数校验，权限校验，日志输出等。

//请求流程
客户端向Gateway发送请求，然后在GatewayHandler Mapping中找到与请求相匹配的路由进行转发，然后我们再通过过滤器将请求发送到我们实际干活的逻辑上。过滤器还可以在代理请求前(pre)或请求后(post)执行一些业务逻辑。

核心逻辑就是路由转发和执行过滤链

第五阶段：分布式事务管理：

//基本概念
seta它由一个ID和三个组件组成。
ID:全局唯一事务ID，只要在同一个ID下不管几个库都证明它是一套的。
TC:负责协调全局事务的提交或回滚。
TM:事务发起方，负责开启一个全局事务，并最终决定全局事物提交或回滚。
RM:资源，相当于一个数据库就是一个RM。

//处理过程
TM向TC申请开启一个全局事务，全局事务创建并生成一个全局唯一XID。
全局ID在微服务调用链路的上下文中传播。
RM向TC注册分支事务，进入ID对应全局事务的管辖。
然后TM向TC发起提交或回滚协议
最后TC调度全局ID管辖下的分支事务完成提交或回滚

//具体执行过程
Seata实际使用上只要在方法上加一个@GlobalTransactional注解就行了，只是使用Seata要先配置一个存储数据的Seta数据库，以及其他数据库如订单表库存表等都要加一个回滚日志表。在执行业务sql之前，保存原快照beforeImage，执行业务sql之后，保存新快照afterImage，并生成行锁。如果顺利提交，快照数据删除。如果需要回滚，它先用afterImage校验是否有脏数据，然后用beforeimage回滚。    
```

```
分布式缓存、jvm原理、html-css

vue  nodejs Echarts表格 elasticsearch  cdn加速
easyCode插件、第三方登入、分享、短信、表格导出、微信支付、支付宝支付、地图、爬虫、公众号、录音、全景图
```

