## nginx简介

### **基本介绍**

```
Nginx是代理服务器,可以做反向代理、负载均衡等；能经受高负载的考验，据说可以高达50000个并发连接数
```

### **什么是反向代理**

![](images/QQ截图20200603210504.png)

```
依赖代理服务器进行网络访问
```

![](images/QQ截图20200603210611.png)

```
客户端发送请求，经过反向代理服务器，再通过反向代理服务器转向到某个tomcat也就是目标服务器。这样子对外暴露的只就是反向代理服务器地址，隐藏了真实服务器IP地址

反向代理是代理目标服务器被请求，正向代理是服务器代理客户端去请求。
```

### **什么是负载均衡**

```
将请求分发到多个服务器上，将负载分发到不同的服务器。
```

### **什么是动静分离**

![](images/QQ截图20200603210931.png)

```
就是为了加快网站的解析速度，把动态页面和静态页面由不同的服务器来解析，加快解析速度。降低原来单个服务器的压力。
```

## nginx 安装

![](images/QQ截图20200604124859.png)

```java
//获取nginx安装包
http://nginx.org/     
//获取pcre辅助依赖
wget http://downloads.sourceforge.net/project/pcre/pcre/8.37/pcre-8.37.tar.gz  
```

```java
/*1.安装pcre依赖 */
  * 把安装压缩文件放到linux系统中
  * 解压压缩文件： tar -xvf pcre-8.37.tar.gz
  * 进入解压之后目录执行 ./configure
  * 把文件编译并且安装: make && make install
  * 查看版本号看是否安装成功： pcre-config --version
    
    // 注意：如果./configure执行不了则需要安装gcc
    #yum install gcc-c++ -y
    #yum -y install gcc

/*2.安装其他的依赖 */
yum -y install make zlib zlib-devel gcc-c++ libtool openssl openssl-devel

/*3.安装Nginx*/
	* 把安装压缩文件放到linux系统中
	* 解压压缩文件：tar -xvf nginx-1.12.2.tar.gz
	* 进入解压之后目录执行 ./configure
	* 把文件编译并且安装: make && make install
	* 安装成功之后，在usr多出来一个文件夹local/nginx,在nginx有sbin有启动脚本：
		cd /usr   cd /local   local文件中会有个nginx文件
		cd /nginx  cd sbin  ls 
	* 启动：  cd /      cd /usr/local/nginx/sbin/	 ./nginx
    * 查看nginx进程：  ps -ef | grep nginx
    * 如果windows访问不了关闭防火墙： iptables -F  但是不建议，应该设置端口号开放
    
查看开放的端口号
firewall-cmd --list-all
设置开放的端口号
firewall-cmd --add-service=http –permanent
sudo firewall-cmd --add-port=80/tcp --permanent //用这个
重启防火墙
firewall-cmd –reload
```

```java
//出现以下错误
./nginx: error while loading shared libraries: libpcre.so.1: cannot open shared object file: No such file or directory

输入：ln -s /usr/local/lib/libpcre.so.1 /lib64
```

##  nginx 常用的命令

```java
//首先进入该目录
cd /usr/local/nginx/sbin/
    
./nginx -v   //查看nginx的版本号  
./nginx   //启动nginx
ps -ef | grep nginx  //查看nginx是否启动  
./nginx  -s stop   //停止nginx
./nginx -s reload  //重新加载nginx    
```

## nginx配置文件

### 基本介绍

```java
//配置文件路径
cd /
cd /usr/local/nginx/
cd conf
nginx.conf   //配置文件
```

![](images/QQ截图20200604151815.png)

```java
//--第一部分全局块
从配置文件开始到 events 块之间的内容，主要会设置一些影响 nginx 服务器整体运行的配置指令，主要包括配
置运行 Nginx 服务器的用户（组）、允许生成的 worker process 数，进程 PID 存放路径、日志存放路径和类型以及配置文件的引入等。
比如上面第一行配置的  worker_processes  1; 这是 Nginx 服务器并发处理服务的关键配置，worker_processes 值越大，可以支持的并发处理量也越多，但是会受到硬件、软件等设备的制约。

//--第二部分events块
events 块涉及的指令主要影响 Nginx 服务器与用户的网络连接，常用的设置包括是否开启对多 work process
下的网络连接进行序列化，是否允许同时接收多个网络连接，选取哪种事件驱动模型来处理连接请求，每个 word
process 可以同时支持的最大连接数等.上述 worker_connections  1024 表示每个 work process 支持的最大连接数为 1024.
这部分的配置对 Nginx 的性能影响较大，在实际中应该灵活配置。    

//--第三部分
这算是 Nginx 服务器配置中最频繁的部分，代理、缓存和日志定义等绝大多数功能和第三方模块的配置都在这里。
需要注意的是：http 块也可以包括 http 全局块、server 块。
//http块
http 全局块配置的指令包括文件引入、MIME-TYPE 定义、日志自定义、连接超时时间、单链接请求数上限等。
//server块
这块和虚拟主机有密切关系，虚拟主机从用户角度看，和一台独立的硬件主机是完全一样的，该技术的产生是为了
节省互联网服务器硬件成本.
    每个 http 块可以包括多个 server 块，而每个 server 块就相当于一个虚拟主机。
    而每个 server 块也分为全局 server 块，以及可以同时包含多个 locaton 块。
    1、全局 server 块
	最常见的配置是本虚拟机主机的监听配置和本虚拟主机的名称或 IP 配置。
	2、location 块
	一个 server 块可以配置多个 location 块。
```

### 反向代理

```java
//先安装JDK
yum -y list java*   //查看可安装的jdk版本
yum install -y java-1.8.0-openjdk-devel.x86_64   //安装1.8
java -version   //查看版本号，测试是否安装成功    
```

```java
//在安装tomcat
*将tomcat移至linux的 /usr/src目录中
*解压tomcat: tar -xvf apache-tomcat-7.0.90.tar.gz
*进入到tomcat的bin目录中进行启动： ./startup.sh

//如果启动tomcat提示权限不够则按以下操作
先进入bin目录： cd /soft/apache-tomcat-7.0.59/bin
然后执行以下命令： chmod u+x *.sh
最后再在bin命令行重启应用服务：./startup.sh 
```

```java
//进入配置文件进行修改
cd /usr/local/nginx/
cd conf
vi nginx.conf
```

当我们访问192.168.17.129如果它是80端口它就会转发到127.0.0.1:8080上

实现效果就是通过请求nginx让其转发到linux的tomcat主页面上

![](images/QQ截图20200605153738.png)

**方式二**

![](images/QQ截图20200605161050.png)

![](images/QQ截图20200605161712.png)

![](images/QQ截图20200605162705.png)

### 负载均衡

![](images/QQ截图20200605194222.png)

**分配方式(策略)**

```
1、轮询（默认）
每个请求按时间顺序逐一分配到不同的后端服务器，如果后端服务器 down 掉，能自动剔除。
2 、weight
weight 代表权,重默认为 1,权重越高被分配的客户端越多
3 、ip_hash
每个请求按访问 ip 的 hash 结果分配，这样每个访客固定访问一个后端服务器，可以解决 session 的问题
4 、fair （第三方）
按后端服务器的响应时间来分配请求，响应时间短的优先分配。
```

![](images/QQ截图20200716123936.png)

### 动静分离

![](images/QQ截图20200716124056.png)

```java
autoindex on  表示列出当前文件夹的内容

//请求例子：
http://192.168.231.129:9002/image/QQ%E6%88%AA%E5%9B%BE20200605202217.png
http://192.168.231.129:9002/www/a.html     
```

## 搭建nginx高可用集群

![](images/QQ截图20200605205532.png)

```java
//需要两台服务器
//在两台服务器安装nginx
//在两台服务器安装keepalived
//安装keepalived
cd /usr
yum install keepalived -y
//查看版本
rpm -q -a keepalived

//安装之后，在 etc 里面生成目录 keepalived ，有文件 keepalived.conf
1 ）修改/etc/keepalived/keepalivec.conf 配置文件
2 ）在/usr/local/src 添加检测脚本  nginx_check.sh

//启动
service keepalived start
service keepalived stop

ps -ef | grep keepalived

//keepalived的日志文件路径
/var/log/messages
```

**keepalivec.conf**

```properties
! Configuration File for keepalived
global_defs {
	router_id hadoop1  路由id,通常为 hostname
	vrrp_skip_check_adv_addr
	vrrp_garp_interval 0
	vrrp_gna_interval 0
} 

vrrp_script chk_nginx {
	script "/etc/keepalived/nginx_check.sh"  # 检测 nginx 状态的脚本路径
	interval 2 
	weight -20 
}

vrrp_instance VI_1 {
	state MASTER     # 主节点为 MASTER， 对应的备份节点为 BACKUP
	interface eth0   # 绑定虚拟 IP 的网络接口，与本机 IP 地址所在的网络接口相同
	virtual_router_id 51   # 虚拟路由的 ID 号， 两个节点设置必须一样
	mcast_src_ip 192.168.231.129 # 本机 IP 地址
	priority 100 # 节点优先级， 值范围 0-254， MASTER 要比 BACKUP 高,backup为90
	nopreempt #主节点有
	advert_int 1 #心跳间隔
	authentication {  #服务之间通信密码
		auth_type PASS
		auth_pass 1111 
	}
	track_script {
		chk_nginx  # 执行 Nginx 监控的服务
	} 
	virtual_ipaddress { #自定义虚拟ip
		192.168.50.130 
	}
}
```

**nginx_check.sh**

```sh
#!/bin/bash
A=`ps -C nginx –no-header |wc -l`
if [ $A -eq 0 ];then
	/usr/local/nginx/sbin/nginx
	sleep 2
	if [ `ps -C nginx --no-header |wc -l` -eq 0 ];then
		killall keepalived
	fi
fi
```

## nginx原理

![](images/QQ截图20200716125110.png)

![](images/QQ截图20200716125352.png)

```java
//nginx基本流程	
	客户端发送一个请求发送给Master，然后由它将请求分派给worker, 而worker有多个它通过争抢机制得到一个任务，然后它可以进行反向代理，用tomcat完成我们的具体操作；
	
//一个 master 和多个 woker 有好处	
1.可以使用 nginx –s reload 热部署，利用 nginx 进行热部署操作
2.每个 woker 是独立的进程，如果有其中的一个 woker 出现问题，其他 woker 独立的，继续进行争抢，实现请求过程，不会造成服务中断。

//设置多少个 woker 合适
worker 数和服务器的 cpu 数相等是最为适宜的

//nginx 有一个master，有四个woker，每个woker支持最大的连接数 1024 ，支持的最大并发数是多少？
1.普通的静态访问最大并发数是： 最大连接数 * 几个woker/2 
2.而如果是 HTTP 作 为反向代理: 最大连接数 * 几个woker/4
```

