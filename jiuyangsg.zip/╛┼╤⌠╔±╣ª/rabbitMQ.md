## 概述 

![](images/QQ截图20200724155008.png)

```
RabbitMQ是基于AMQP协议的，这种协议也基于生产者与消费者模型。生产者会与RabbitServer建立连接，建立连接之后通过通道形式来传递消息。而一个生产者会对应broker里面的一个虚拟主机，虚拟主机访问它是需要权限的，一般一个项目或应用只能访问一个虚拟主机，多个应用互不影响。生产者进入虚拟主机后，就可以把消息放到我们的交换机中。而消费者也通过它获取消息。所以消费者和生产者之间是完全解耦的，不需要关心生产者有没有运行，只需要关心队列里面有没有相应的消息。简单说RabbitMQ就像个中间商一样，生产者向它生产消息，消费者向它消费消息。

1.消息队列一般用来解决解耦，异步消息，流量削锋等问题。如：发送邮件和短信，订单系统库存系统，秒杀活动。

2.AMQP是一种消息队列协议，用于定义数据的客户端和服务器端的一种标准；
```

## 安装Rabbit

```java
//官网
https://www.rabbitmq.com/  

//erlang对应表
https://www.rabbitmq.com/which-erlang.html
//erlang下载
http://dl.bintray.com/rabbitmq-erlang/rpm/erlang/
//socat下载
http://repo.iotti.biz/CentOS/6/x86_64/
//RabbitMQ下载
https://www.rabbitmq.com/download.html
```

![](images/QQ截图20200718141111.png)

**安装**

```java
//--安装依赖以及rabbitmq
rpm -ivh erlang-23.0-1.el6.x86_64.rpm
rpm -ivh socat-1.7.3.2-1.el6.lux.x86_64.rpm 
rpm -ivh rabbitmq-server-3.8.5-1.el6.noarch.rpm 

//启动rabbitmq   restart  stop  status
service rabbitmq-server start

//--启用管理插件(查看页面需要的)
rabbitmq-plugins enable rabbitmq_management

//查看进程
ps -ef |grep rabbitmq

//访问（默认账号guest不可以远程连接）
http://192.168.231.131:15672/
端口：
	5672：rabbitMq的编程语言客户端连接端口
	15672：rabbitMq管理界面端口
	25672：rabbitMq集群的端口
```

```java
关于问题：

//启动rabbitmq报该错误： check /var/log/rabbitmq/startup_{log, _err}
vim /etc/hosts  添加一行：  127.0.0.1 我的主机名

//启动管理页面的插件报该错误{:query, :rabbit@mysql, {:badrpc, :timeout}}
在 etc/rabbitmq 目录下创建文件 enabled_plugins
加入这行  [rabbitmq_management].
```

**常用命令**

```java
 //添加管理员账号        账号   密码
 rabbitmqctl add_user admin admin
 
 //分配账号权限（administrator代表管理员权限）
 rabbitmqctl set_user_tags admin administrator
 
 //修改密码
 rabbitmqctl change_password admin 123456
     
 //查看用户列表
 rabbitmqctl list_users    
 
 //卸载
 rpm-qa | grep rabbitmq
 rpm -e rabbitmq-server
```

## 管理页面介绍

```
Connections:查看生产者和消费者的连接情况
channels:通道，建立连接后，会形成通道，消息的投递获取依赖通道。
Exchanges:交换机，用来实现消息的路由
Queues:队列，即消息队列，消息存放在队列中，等待消费，消费后被洗出队列
```

![](images/QQ截图20200721174355.png)

![](images/QQ截图20200722172919.png)

![](images/QQ截图20200722175137.png)

![](images/QQ截图20200722175859.png)

![](images/QQ截图20200722181437.png)

## Java普通连接

**连接工具类**

```xml
<!-- rabbitmq依赖-->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-amqp</artifactId>
</dependency>
```

```java
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class ConnectionUtil {

    private static ConnectionFactory connectionFactory;

    static {
        connectionFactory = new ConnectionFactory();
        //设置服务地址
        connectionFactory.setHost("192.168.231.131");
        //端口
        connectionFactory.setPort(5672);
        //设置账号信息，用户名，密码，vhost
        //设置虚拟机，一个mq服务可以设置多个虚拟机，每个虚拟机就相当于一个独立的mq
        connectionFactory.setVirtualHost("/shopping");
        connectionFactory.setUsername("admin");
        connectionFactory.setPassword("admin");
    }

    //获取连接
    public static Connection getConnection() {
        Connection connection = null;
        try {
            connection = connectionFactory.newConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return connection;
    }

    //关闭通道和关闭连接
    public static void closeConnectionAndChanel
        (Channel channel, Connection connection) {
        try {
            if (channel != null) channel.close();
            if (connection != null) connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
```

![](images/QQ截图20200726115331.png)

### **1(点对点)**

```java
import com.huaji.springcloud.util.ConnectionUtil;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;

/**
 * 生产者
 */
public class Send {

    private final static String QUEUE_NAME = "simple_queue";

    public static void main(String[] args) throws Exception {
        //获取连接
        Connection connection = ConnectionUtil.getConnection();
        //从连接中创建通道，使用通道才能完成消息相关的操作
        Channel channel = connection.createChannel();
       
        //通道绑定对应消息队列
        //参数1:队列名称 如果队列不存在自动创建
        //参数2:用来定义队列特性是否要持久化   true持久化队列   false不持久化
        //参数3:是否独占队列   true 独占队列   false不独占
        //参数4:是否消费完成后自定删除队列		true删除		false不删除
        //参数5:额外附加参数
        channel.queueDeclare(QUEUE_NAME,false,false,false,null);
      
        //消息内容
        String message = "Hello World";
        //向指定的队列发送消息
        //参数1：交换机名称   参数2:队列名称   参数3:传递消息额外设置  参数4：消息的具体内容
        channel.basicPublish("",QUEUE_NAME,null,message.getBytes());

        //关闭通道和连接
        ConnectionUtil.closeConnectionAndChanel(channel,connection);
    }
}


import com.huaji.springcloud.util.ConnectionUtil;
import com.rabbitmq.client.*;
import java.io.IOException;

/**
 * 消费者
 */
public class Recv {

    private final static String QUEUE_NAME = "simple_queue";

    public static void main(String[] args) throws Exception {
        //获取连接
        Connection connection = ConnectionUtil.getConnection();
        //创建通道
        Channel channel = connection.createChannel();
        //通道绑定对象（生产者和消费者参数要一致）
        channel.queueDeclare(QUEUE_NAME, false, false, false, null);
       
        //定义队列的消费者
        DefaultConsumer consumer = new DefaultConsumer(channel) {
            //获取消息，并且处理，这个方法类似事件监听，如果有消息的时候，就会被自动调用
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, 		           AMQP.BasicProperties properties,byte[] body) throws IOException {
                //body 即消息体
                String msg = new String(body);
                System.out.println("[x] received : " + msg + "!");
            }
        };
        
        //消费消息
        //参数1:消费哪个队列消息  队列名称
        //参数2:自动确认机制   自定确认true  手动确认false
        //参数3:消费时的回调接口
        channel.basicConsume(QUEUE_NAME, true, consumer);
        
        //没有关闭信道和连接，消费者可以继续接收处理
    }
}
```

![](images/QQ截图20200726162201.png)

![](images/QQ截图20200726194634.png)

### 2(工作模型)

```java
/**
 * 生产者
 */
public class send {

    private final static String QUEUE_NAME = "test_work_queue";

    public static void main(String[] args) throws Exception {
        Connection connection = ConnectionUtil.getConnection();
        Channel channel = connection.createChannel();
       
        channel.queueDeclare(QUEUE_NAME,false,false,false,null);
       
        //循环发布任务
        for(int i=0;i<50;i++){
            //消息内容
            String message = "task .."+ i;
            channel.basicPublish("",QUEUE_NAME,null,message.getBytes());
            System.out.println("[x] Sent '"+message+"'");
        }

        //关闭通道和连接省略...
    }
}


/**
 * 消费者，可以定义多个消费者
 */
public class Recv {

    private final static String QUEUE_NAME = "test_work_queue";

    public static void main(String[] args) throws Exception{
        Connection connection = ConnectionUtil.getConnection();
        final Channel channel = connection.createChannel();
     
        channel.queueDeclare(QUEUE_NAME,false,false,false,null);
       
        //设置没个消费者同时只能处理一条消息
        //设置之后为能者多劳模式，不设置为平均消费模式245 137
        channel.basicQos(1);
      
        //定义队列的消费者
        DefaultConsumer consumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope,                    AMQP.BasicProperties properties,byte[] body)throws IOException {
                //body 即消息体
                String msg  = new String(body);
                System.out.println("[x] received : "+msg+"!");
                
                //手动ACK确认消息
                //参数1:确认队列中哪个具体消息  参数2:是否开启多个消息同时确认
                channel.basicAck(envelope.getDeliveryTag(),false);
            }
        };
       
        //监听队列，第二个参数是否自动进行消息确认
        channel.basicConsume(QUEUE_NAME,false,consumer);

        //没有关闭信道和连接，消费者可以继续接收处理
    }
}
```

### 3(广播模型)

```java
/**
 * 生产者
 */
public class Send {

    private final static String EXCHANGE_NAME = "fanout_exchange_test";

    public static void main(String[] args) throws Exception {
        Connection connection = ConnectionUtil.getConnection();
        Channel channel = connection.createChannel();

        //参数1：交换机名； 参数2：指定类型为 fanout 广播类型
        channel.exchangeDeclare(EXCHANGE_NAME,"fanout");

        //消息内容
        String message = "Hello everyone";
        //发布消息到Exchange
        channel.basicPublish(EXCHANGE_NAME,"",null,message.getBytes());
        System.out.println("[生产者] Sent '"+message+"'");

        //关闭通道和连接省略...
    }
}


/**
 * 消费者
 */
public class Recv {
	//不同消费者声明不同队列，fanout_exchange_queue_1  fanout_exchange_queue_2
    private final static String QUEUE_NAME = "fanout_exchange_queue_1";
    private final static String EXCHANGE_NAME = "fanout_exchange_test";

    public static void main(String[] args) throws Exception{
        Connection connection = ConnectionUtil.getConnection();
        Channel channel = connection.createChannel();
        
        //声明队列
        channel.queueDeclare(QUEUE_NAME,false,false,false,null);
        //绑定队列到交换机
        channel.queueBind(QUEUE_NAME,EXCHANGE_NAME,"");

        //定义队列的消费者
        DefaultConsumer consumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope,                        AMQP.BasicProperties properties,byte[] body)throws IOException {
                //body 即消息体
                String msg  = new String(body);
                System.out.println("[消费者1] received : "+msg+"!");
            }
        };
        
        channel.basicConsume(QUEUE_NAME,true,consumer);

        //没有关闭信道和连接，消费者可以继续接收处理
    }
}
```

### 4(路由模型)

```java
/**
 * 生产者
 */
public class Send {
    private final static String EXCHANGE_NAME = "direct_exchange_test";

    public static void main(String[] args) throws Exception {
        //获取连接
        Connection connection = ConnectionUtil.getConnection();
        Channel channel = connection.createChannel();

        //声明exchange，指定类型为 direct（定性类型）
        channel.exchangeDeclare(EXCHANGE_NAME,"direct");

        //消息内容
        String message = "商品删除了， id = 1001";
        //发布消息,并且指定routing key 为：delete,代表新增商品
        channel.basicPublish(EXCHANGE_NAME,"delete",null,message.getBytes());

       //关闭通道和连接省略...
    }
}


/**
 * 消费者
 */
public class Recv {
    //不同消费者声明不同队列，direct_exchange_queue_1  direct_exchange_queue_2
    private final static String QUEUE_NAME = "direct_exchange_queue_2";
    private final static String EXCHANGE_NAME = "direct_exchange_test";

    public static void main(String[] args) throws Exception{
        //获取连接
        Connection connection = ConnectionUtil.getConnection();
        Channel channel = connection.createChannel();
        
        //声明队列
        channel.queueDeclare(QUEUE_NAME,false,false,false,null);

        //绑定队列到交换机,同时需要订阅routing key.假设此处需要update和delete消息
        channel.queueBind(QUEUE_NAME,EXCHANGE_NAME,"update");
        channel.queueBind(QUEUE_NAME,EXCHANGE_NAME,"delete");
        channel.queueBind(QUEUE_NAME,EXCHANGE_NAME,"insert");

        //定义队列的消费者
        DefaultConsumer consumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope,                         AMQP.BasicProperties properties,byte[] body)throws IOException {
                //body 即消息体
                String msg  = new String(body);
                System.out.println("[消费者2] received : "+msg+"!");
            }
        };
        //监听队列，第二个参数；是否自动进行消息确认
        channel.basicConsume(QUEUE_NAME,true,consumer);

        //没有关闭信道和连接，消费者可以继续接收处理
    }
}
```

### 5(订阅模型)

```
通配符匹配规则：# 匹配0或多个词(含零个)    * 匹配不多不少恰好1个词（不含零个）
```

![](images/QQ截图20200723173022.png)

```java
/**
 * 生产者
 */
public class Send {
    private final static String EXCHANGE_NAME = "topic_exchange_test";

    public static void main(String[] args) throws Exception {
        //获取连接
        Connection connection = ConnectionUtil.getConnection();
        Channel channel = connection.createChannel();
        
        //声明exchange,指定类型为topic
        channel.exchangeDeclare(EXCHANGE_NAME,"topic",true);

        //消息内容
        String message = "更新商品：id = 1001";
        //发送消息，并且指定routing key 为：insert,代表新增商品
        channel.basicPublish(EXCHANGE_NAME,"item.insert", 	                                          MessageProperties.PERSISTENT_TEXT_PLAIN,message.getBytes());
        System.out.println("[商品服务：] Sent '"+message+"'");

        //关闭通道和连接省略...
    }
}


/**
 * 消费者
 */
public class Recv {
    //不同消费者声明不同队列，topic_exchange_queue_1  topic_exchange_queue_2
    private final static String QUEUE_NAME = "topic_exchange_queue_1";
    private final static String EXCHANGE_NAME = "topic_exchange_test";

    public static void main(String[] args) throws Exception{
        //获取连接
        Connection connection = ConnectionUtil.getConnection();
        //创建通道
        Channel channel = connection.createChannel();
        //声明队列
        channel.queueDeclare(QUEUE_NAME,false,false,false,null);

        //绑定队列到交换机,同时需要订阅routing key.假设此处需要update和delete消息
        channel.queueBind(QUEUE_NAME,EXCHANGE_NAME,"item.update");
        channel.queueBind(QUEUE_NAME,EXCHANGE_NAME,"item.delete");
        channel.queueBind(QUEUE_NAME,EXCHANGE_NAME,"item.*");

        //定义队列的消费者
        DefaultConsumer consumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope,                           AMQP.BasicProperties properties,byte[] body)throws IOException {
                //body 即消息体
                String msg  = new String(body);
                System.out.println("[消费者1] received : "+msg+"!");
            }
        };
        //监听队列，第二个参数；是否自动进行消息确认
        channel.basicConsume(QUEUE_NAME,true,consumer);

        //没有关闭信道和连接，消费者可以继续接收处理
    }
}
```

![](images/QQ截图20200723175820.png)

## SpringBoot连接

```xml
<!-- rabbitmq依赖-->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-amqp</artifactId>
</dependency>
```

```yaml
#application.yal
spring:
  rabbitmq:
    host: 192.168.231.131
    username: admin
    password: admin
    virtual-host: /shopping
    port: 5672
```

### 1(点对点)

```java
/*
 * 生产者
 */
@Test
public void testHello() {
    //创建一个Hello队列，注意如果队列没有消费者，那么队列时创建不成功的
    rabbitTemplate.convertAndSend("hello","hello world");
}

/**
 * 消费者
 */
import org.springframework.amqp.rabbit.annotation.*;
import org.springframework.stereotype.Component;

@Component					//1.队列名hello;2.是否持久化；3.是否自动删除
@RabbitListener(queuesToDeclare = @Queue(value = "hello",durable = "true",
                                         autoDelete = "true"))
public class Customer {

    @RabbitHandler
    public void receivel(String message) {
        System.out.println("点对点消费者："+message);
    }
}
```

### 2(工作模型)

```java
/*
 * 生产者
 */
@Test
public void testWork(){
    for(int i=0;i<50;i++){
        rabbitTemplate.convertAndSend("work","work模型"+i);
    }
}

/**
 * 消费者
 */
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class WorkCustomer {
	
    //平均消费
    @RabbitListener(queuesToDeclare = @Queue("work"))
    public void receivel(String message) {
        System.out.println("消费者1" + message);
    }
	
    //平均消费
    @RabbitListener(queuesToDeclare = @Queue("work"))
    public void receive2(String message) {
        System.out.println("消费者2" + message);
    }
}
```

### 3(广播模型)

```java
/*
 * 生产者
 */
@Test
public void testFanout() {
    //参数1：交换机名字；参数2：路由key,消息
    rabbitTemplate.convertAndSend("logs","","Fanout的模型发送的消息");
}


/**
 * 消费者
 */
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class FanoutCustomer {

      @RabbitListener(bindings = {
            @QueueBinding(value = @Queue,//创建临时队列   也可以指定名字@Queue("name")
                    exchange = @Exchange(value = "logs",type = "fanout")) //绑定的交换机
    })
    public void receivel1(String message) {
        System.out.println("message1 ="+message);
    }

    @RabbitListener(bindings = {
            @QueueBinding(value = @Queue,//创建临时队列   也可以指定名字@Queue("name")
                    exchange = @Exchange(value = "logs",type = "fanout")) //绑定的交换机
    })
    public void receivel2(String message) {
        System.out.println("message2 ="+message);
    }
}
```

### 4(路由模型)

```java
/*
 * 生产者
 */
@Test
public void testRoute() {
     //参数1：交换机名字；参数2：路由key,消息
    rabbitTemplate.convertAndSend("directs","info","发送info的key的路由信息");
}


/**
 * 消费者
 */
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class RouteCustomer {

    @RabbitListener(bindings = {
            @QueueBinding(
                    value = @Queue, //创建临时队列
                    //自定义交换机名称和类型
                    exchange = @Exchange(value = "directs", type = "direct"), 
                    key = {"info", "error", "warn"}
            )
    })
    public void receivel1(String message) {
        System.out.println("message =" + message);
    }

    @RabbitListener(bindings = {
            @QueueBinding(
                    value = @Queue, //创建临时队列
                    //自定义交换机名称和类型
                    exchange = @Exchange(value = "directs", type = "direct"), 
                    key = {"error"}
            )
    })
    public void receivel2(String message) {
        System.out.println("message =" + message);
    }
}
```

### 5(订阅模型)

```java
/*
 * 生产者
 */
@Test
public void testTopic(){
    rabbitTemplate.convertAndSend("topics","user.save","动态路由");
}


/**
 * 消费者
 */
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class TopicCustomer {

    @RabbitListener(bindings = {
            @QueueBinding(
                    value = @Queue,
                    exchange = @Exchange(type = "topic",name = "tipics"),
                    key = {"user.save","user.*"}
            )
    })
    public void rceivel(String message) {
        System.out.println("消费者1"+message);
    }

    @RabbitListener(bindings = {
            @QueueBinding(
                    value = @Queue,
                    exchange = @Exchange(type = "topic",name = "tipics"),
                    key = {"order.#","user.*"}
            )
    })
    public void rceivel2(String message) {
        System.out.println("消费者2"+message);
    }
}
```

### ACK确认机制案例

**application.yml**

```yaml
spring:
  rabbitmq:
    host: 192.168.231.166
    virtual-host: /zsb
    username: admin
    password: admin
    port: 5672
    publisher-confirm-type: correlated  #必须配置这个才会确认回调
    publisher-returns: true  #支持发布返回
    listener:
      type: simple
      simple:
        acknowledge-mode: manual  #手动确认
        prefetch: 1	 #限制每次发送一条数据
        concurrency: 3  #同一个队列启动几个消费者
        max-concurrency: 3  #启动消费者最大数量
        #重试策略相关配置
        retry:
          enabled: true  #是否支持重试
          max-attempts: 5
          stateless: false
          multiplier: 1.0
          initial-interval: 1000ms
          max-interval: 10000ms
        default-requeue-rejected: true
```

**生产配置类**

```java
import lombok.extern.java.Log;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
 
import java.util.HashMap;
import java.util.Map;

@Configuration
@Log
public class RabbitMQConfig {
    @Autowired
    private CachingConnectionFactory connectionFactory;
 
    //目标转换器，需要哪种类型的转换器就创建哪种类型的转换器
    @Bean
    public DirectExchange exchangeHello(){
        Map<String, Object> eArguments = new HashMap<>();
        //备份交换器参数
        eArguments.put("alternate-exchange", "exchange.ae");
        return new DirectExchange("exchange.hello",true,false,eArguments);
    }
    //备份转换器
    @Bean
    public FanoutExchange exchangeAE(){
        return new FanoutExchange("exchange.ae",true,false,null);
    }
    //死信转换器
    @Bean
    public TopicExchange exchangeDLX(){
        return new TopicExchange("exchange.dlx",true,false,null);
    }
 
    //目标对列
    @Bean
    public Queue queueHello() {
        Map<String, Object> args = new HashMap<>();
        //声明死信交换器
        args.put("x-dead-letter-exchange", "exchange.dlx");
        //声明死信路由键
        args.put("x-dead-letter-routing-key", "dlx.test" );
        //声明队列消息过期时间 5000ms
        args.put("x-message-ttl", 5000);
        return new Queue("queue.hello",true,false,false,args);
    }
 
    //备份对列
    @Bean
    public Queue queueAE() {
        return new Queue("queue.ae",true,false,false,null);
    }
 
    //死信对列
    @Bean
    public Queue queueDLX() {
        return new Queue("queue.dlx",true,false,false,null);
    }
 
    //绑定目标对列
    @Bean
    public Binding bindingExchangeDirect(@Qualifier("queueHello")Queue queueHello, @Qualifier("exchangeHello") DirectExchange exchangeHello){
        return  BindingBuilder.bind(queueHello).to(exchangeHello).with("helloKey");
    }
    //绑定备份对列
    @Bean
    public Binding bindingExchangeAE(@Qualifier("queueAE")Queue queueAE, @Qualifier("exchangeAE") FanoutExchange exchangeAE){
        return  BindingBuilder.bind(queueAE).to(exchangeAE);
    }
 
    //绑定死信对列
    @Bean
    public Binding bindingExchangeDLX(@Qualifier("queueDLX")Queue queueAE, @Qualifier("exchangeDLX") TopicExchange exchangeDLX){
        return  BindingBuilder.bind(queueAE).to(exchangeDLX).with("dlx.*");
    }
 
    /**
     * 如果需要在生产者需要消息发送后的回调，
     * 需要对rabbitTemplate设置ConfirmCallback对象，
     * 由于不同的生产者需要对应不同的ConfirmCallback，
     * 如果rabbitTemplate设置为单例bean，
     * 则所有的rabbitTemplate实际的ConfirmCallback为最后一次申明的ConfirmCallback。
     * @return
     */
    @Bean
    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public RabbitTemplate rabbitTemplate() {
        RabbitTemplate template = new RabbitTemplate(connectionFactory);
        return template;
    }
 
}
```

**发送消息类**

```java
import lombok.extern.java.Log;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.UUID;

@RestController
@Log
public class RabbitMQController implements  RabbitTemplate.ConfirmCallback,RabbitTemplate.ReturnCallback{

    private RabbitTemplate rabbitTemplate;

    //构造方法注入
    @Autowired
    public RabbitMQController(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
        //这是是设置回调能收到发送到响应
        rabbitTemplate.setConfirmCallback(this);
        //如果设置备份队列则不起作用
        rabbitTemplate.setMandatory(true);
        rabbitTemplate.setReturnCallback(this);
    }

    @GetMapping("/rabbitMQController/testHello")
    public void testHello() {
        CorrelationData correlationId = 
            new CorrelationData(UUID.randomUUID().toString());
        String sendMsg = "hello1 " + new Date();
        //1.交换机名称;2.路由关键字;3.发送的消息内容;4.消息ID
        rabbitTemplate.convertAndSend ("exchange.hello", "helloKey",
                "Hello World!!!",correlationId);
    }

    //回调确认
    @Override
    public void confirm(CorrelationData correlationData, boolean b, String s) {
        if(b){
            log.info("消息发送成功:"+CorrelationData+","+b+","+s);
        }else{
            log.info("消息发送失败:"+CorrelationData+","+b+","+s);
        }
    }

    //消息发送到转换器的时候没有对列,配置了备份对列该回调则不生效
    @Override
    public void returnedMessage(Message message, int i, String s,
                                String s1, String s2) {
       // log.info("消息丢失:exchange({}),route({}),replyCode({}),replyText({}),message:{}",exchange,routingKey,replyCode,replyText,message);
    }
}
```

**接收消息**

```java
 @RabbitHandler
    @RabbitListener(queues = "queue.hello")
    public void process(Message message, Channel channel) throws IOException {
        log.info("receive: " + new String(message.getBody()) + "《线程名：》" + Thread.currentThread().getName() + "《线程id:》" + Thread.currentThread().getId());
       	//手动确认
        channel.basicAck(message.getMessageProperties().getDeliveryTag(), true);
    }
```

## *RabbitMQ的集群

### 普通集群

![](images/QQ图片20200728150614.png)

```java
//集群cookie必须一样
//进入目录  查看隐藏文件 .erlang.cookie    
cd /var/lib/rabbitmq/
ls -a
//查看
cat /var/lib/rabbitmq/.erlang.cookie  

//修改主机名
vim /etc/sysconfig/network
cat /etc/sysconfig/network     // 查看下
vim /etc/hosts    // 编辑下hosts文件， 给127.0.0.1添加hostname
cat /etc/hosts   //检查   


//后台启动

rabbitmq-server -detached
```



### 镜像集群

![](images/QQ截图20200728150525.png)

# 华丽分割线----

### Rabbit安装和测试

```
安装查看 docker
```

![](images/QQ截图20200517170222-1589706712712.png)

**Test**

![](images/QQ截图20200810094554.png)

![](images/QQ截图20200810094727.png)



![](images/QQ截图20200810094957.png)

![](images/QQ截图20200810095102.png)

![](images/QQ截图20200810095204.png)

```java
//------------给每个队列发送些消息来测试下哪个队列能收到这些消息
```

![](images/QQ截图20200810095621.png)

![](images/QQ截图20200810095742.png)

### spring整合Rabbit

![](images/QQ截图20200517190312-1589717030331.png)

```java
//1. 导入相关依赖
 testImplementation 'org.springframework.amqp:spring-rabbit-test'
//2. 相关配置
spring.rabbitmq.host=192.168.5.110
spring.rabbitmq.username=guest
spring.rabbitmq.password=guest
# spring.rabbitmq.port=5672  端口默认5672可以不写
#spring.rabbitmq.virtual-host= 默认访问/可以不写
```

```java
//3. 具体示例
import org.junit.jupiter.api.Test;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@SpringBootTest
class WylApplicationTests {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    /**
     * 1.单播（点对点）
     */
    @Test
    void contextLoads() {
        //参数：交换器，路由件，消息
        //Message需要组件构造一个；定义消息内容和消息头
        //rabbitTemplate.send(exchage,routeKey,message);

        //object默认当成消息体，只需要传入要发送的对象，自动序列化给rabbitmq
        //rabbitTemplate.convertAndSend(exchage,routeKey,object);
        Map<String,Object> map = new HashMap<>();
        map.put("msg","这是第一个消息");
        map.put("data", Arrays.asList("helloworld",123,true));
        //对象被默认序列化以后发送出去
        rabbitTemplate.convertAndSend("exchange.direct", "atguigu.news",map);
    }

    /**
     * 广播
     */
    @Test
    public void sendMsg(){
        rabbitTemplate.convertAndSend("exchange.fanout","","所有消息队列都收到");
    }
    
    //接受数据
    @Test
    public void receive(){
        Object o =  rabbitTemplate.receiveAndConvert("atguigu.news");
        System.out.println(o.getClass());
        System.out.println(o);
    }
}

//-------如果需要以JSON格式保存，则需要进行以下配置
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyAMQPConfig {

    @Bean
    public MessageConverter messageConverter(){
        return new Jackson2JsonMessageConverter();
    }
}
```

```java
/* 4. 监听消息
	在实际开发中需要一些监听场景，如：有两个系统订单系统和库存系统，为了解耦它两个之间数据交互都是通过消息队列，某个人下了单以后将它的订单信息放在消息队列，库存系统需要实时监听消息队列里面的内容一旦有新的订单进来库存系统就要进行相关的操作 */

//----------------1.
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

import java.util.Map;
//定义监听类
@Service
public class MapService {

    //方式1
    @RabbitListener(queues = "atguigu.news")
    public void receive(Map map){
        System.out.println("收到消息----------："+map);
    }

    //方式2
    @RabbitListener(queues = "atguigu")
    public void receive02(Message msg){
        System.out.println(msg.getBody());  //消息主内容
        System.out.println(msg.getMessageProperties()); //消息头信息
    }
}

//-------------2.启动类添加注解

import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@EnableRabbit //开启基于注解的RabbitMQ模式
@SpringBootApplication
public class WylApplication {
	//......
}
```

```java
//---------------------------华丽分割线--------------------------------
//前面的案例是基于交换器和消息队列都创建好的基础上，如果没创建好程序中怎么创建呢？
```

![](images/QQ截图20200517200835.png)

```java
import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.Binding;
//此处省略整体类

    @Autowired
    AmqpAdmin amqpAdmin;

    public void createExchange(){
        //凡是以declare开头的都是创建一些组件

        //创建一个DirectExchange交换器，创建别的则输入别的
        //参数：名字，是不是持久化的，是不是自动删除的
        //此处只给一个名字参数
       amqpAdmin.declareExchange(new DirectExchange("amqpadmin.exchange"));

        //创建一个队列
        //不传名字的情况下，默认定义一个随机名字
        //Queue队列的详细参数：队列名字，是否持久化，等等..
       amqpAdmin.declareQueue(new Queue("amqpadmin.queue",true));

        //创建绑定规则
        //Binding参数：目的地，目的地类型（消息队列/交换器），交换器名字，路右件名字，参数头
        amqpAdmin.declareBinding(new Binding("amqpadmin.queue",
                Binding.DestinationType.QUEUE,"amqpadmin.exchange",
                "amqp.haha",null));
        System.out.println("创建完成----");
    }
```

