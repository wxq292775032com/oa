## 概念

```java
//基本认识
webService就是向外界暴露出一个能够通过web进行调用方法API.    
webService他是跨平台跨语言的远程调用技术，它适用于不同系统之间的交互数据传递。
如果一个功能，需要被多个系统使用可以使用webservice开发一个服务端接口，供不同的客户端应用。
 
//soap协议
SOAP 协议是WebService 的特有协议，它是在http协议的基础上加上xml数据

//关于规范
webService有三种规范，但常用的有两种，一种是JAX-WS它是基于soap协议的，另一种是JAX-RS它是restful风格基于http协议的。

//应用场景
如果有一些功能希望给多个应用场景使用，我们就可以使用webService对外发布接口

```

![](images/QQ截图20200904072709.png)

![](images/QQ截图20200918171224.png)

## Spring实现webService（Jax-ws）

**pom.xml文件**

```xml
   <dependencies>
        <!-- CXF WS开发  -->
        <dependency>
            <groupId>org.apache.cxf</groupId>
            <artifactId>cxf-rt-frontend-jaxws</artifactId>
            <version>3.0.1</version>
        </dependency>

        <dependency>
            <groupId>junit</groupId>
            <artifactId>junit</artifactId>
            <version>4.12</version>
        </dependency>
        <dependency>
            <groupId>org.springframework</groupId>
            <artifactId>spring-context</artifactId>
            <version>4.2.4.RELEASE</version>
        </dependency>
        <dependency>
            <groupId>org.springframework</groupId>
            <artifactId>spring-web</artifactId>
            <version>4.2.4.RELEASE</version>
        </dependency>
        <dependency>
            <groupId>org.springframework</groupId>
            <artifactId>spring-test</artifactId>
            <version>4.2.4.RELEASE</version>
        </dependency>
   </dependencies>
   
	<build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.2</version>
                <configuration>
                    <source>1.8</source>
                    <target>1.8</target>
                    <encoding>UTF-8</encoding>
                    <showWarnings>true</showWarnings>
                </configuration>
            </plugin>
            <!-- 运行tomcat7方法：tomcat7:run -->
            <plugin>
                <groupId>org.apache.tomcat.maven</groupId>
                <artifactId>tomcat7-maven-plugin</artifactId>
                <version>2.2</version>
                <configuration>
                    <!-- 指定端口 -->
                    <port>8080</port>
                    <!-- 请求路径 -->
                    <path>/</path>
                </configuration>
            </plugin>
        </plugins>
    </build>
```

### 服务端发布服务

![](images/QQ截图20200918203710.png)

**web.xml**

```xml
<!DOCTYPE web-app PUBLIC
        "-//Sun Microsystems, Inc.//DTD Web Application 2.3//EN"
        "http://java.sun.com/dtd/web-app_2_3.dtd" >
<web-app>
  <display-name>Archetype Created Web Application</display-name>
  <!--1. cxfsevlet配置-->
  <servlet>
    <servlet-name>cxfservlet</servlet-name>
    <servlet-class>org.apache.cxf.transport.servlet.CXFServlet</servlet-class>
  </servlet>
  <servlet-mapping>
    <servlet-name>cxfservlet</servlet-name>
    <url-pattern>/ws/*</url-pattern>
  </servlet-mapping>

  <!--2.spring容器配置-->
  <context-param>
    <param-name>contextConfigLocation</param-name>
    <param-value>classpath:applicationContext.xml</param-value>
  </context-param>
  <listener>
    <listener-class>
      org.springframework.web.context.ContextLoaderListener
    </listener-class>
  </listener>
</web-app>
```

**applicationContext.xml**

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:cxf="http://cxf.apache.org/core"
       xmlns:jaxws="http://cxf.apache.org/jaxws"
       xmlns:jaxrs="http://cxf.apache.org/jaxrs"
       xsi:schemaLocation="
        http://www.springframework.org/schema/beans
        http://www.springframework.org/schema/beans/spring-beans.xsd
        http://cxf.apache.org/core
        http://cxf.apache.org/schemas/core.xsd
        http://cxf.apache.org/jaxws
        http://cxf.apache.org/schemas/jaxws.xsd
        http://cxf.apache.org/jaxrs
        http://cxf.apache.org/schemas/jaxrs.xsd">
        <!--
            Spring整合cxf发布服务，关键点：
            1. 服务地址
            2. 服务类
            服务完整访问地址：
                http://localhost:8080/ws/hello
        -->
    <jaxws:server address="/hello">
        <jaxws:serviceBean>
            <bean class="com.wxq.service.impl.HelloServiceImpl"></bean>
        </jaxws:serviceBean>
    </jaxws:server>
</beans>
```

**定义接口及实现类**

```java
/**
 * 对外发布服务的接口
 */
import javax.jws.WebService;

@WebService
public interface HelloService {
   
    public String sayHello(String name);
}


//实现类
public class HelloServiceImpl implements HelloService {
 
    @Override
    public String sayHello(String name) {
        return name + ",Welcome to wxq!";
    }
}
```

```java
//访问地址
http://localhost:8000/ws/hello  
//具体
http://localhost:8000/ws/hello?wsdl
```

### 客户端获取服务

![](images/QQ截图20200918203921.png)

**applicationContext.xml**

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:cxf="http://cxf.apache.org/core"
       xmlns:jaxws="http://cxf.apache.org/jaxws"
       xmlns:jaxrs="http://cxf.apache.org/jaxrs"
       xsi:schemaLocation="
        http://www.springframework.org/schema/beans
        http://www.springframework.org/schema/beans/spring-beans.xsd
        http://cxf.apache.org/core
        http://cxf.apache.org/schemas/core.xsd
        http://cxf.apache.org/jaxws
        http://cxf.apache.org/schemas/jaxws.xsd
        http://cxf.apache.org/jaxrs
        http://cxf.apache.org/schemas/jaxrs.xsd">
        <!--
            Spring整合cxf发布服务，关键点：
            	1.服务地址
            	2.服务接口类型
            	3.服务完整访问地址： http://localhost:8080/ws/hello 
 		-->
    <jaxws:client id="helloService" 
           serviceClass="com.wxq.service.HelloService" 			                                  address="http://localhost:8080/ws/hello">
    </jaxws:client>
</beans>
```

**只需要定义接口**

```java
import javax.jws.WebService;

/**
 * 此接口和服务端发布的接口一致
 * 注意：层级目录也要与服务端的一致
 */
@WebService
public interface HelloService {
    public String sayHello(String name);
}
```

**测试访问**

```java
import com.wxq.service.HelloService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext.xml")
public class Client {

    @Resource
    private HelloService helloService;

    @Test
    public void remote(){

        //查看接口代理对象类型
        System.out.println(helloService.getClass());

        //远程访问服务端方法
        System.out.println(helloService.sayHello("Jerry"));
    }
}
```

## Spring实现webService（Jax-rs）

**pom.xml**

```xml
<dependencies>
        <!-- cxf 进行rs开发 必须导入  -->
        <dependency>
            <groupId>org.apache.cxf</groupId>
            <artifactId>cxf-rt-frontend-jaxrs</artifactId>
            <version>3.0.1</version>
        </dependency>
        <!-- 日志引入  -->
        <dependency>
            <groupId>org.slf4j</groupId>
            <artifactId>slf4j-log4j12</artifactId>
            <version>1.7.12</version>
        </dependency>
        <!-- 客户端 -->
        <dependency>
            <groupId>org.apache.cxf</groupId>
            <artifactId>cxf-rt-rs-client</artifactId>
            <version>3.0.1</version>
        </dependency>
        <!-- 扩展json提供者 -->
        <dependency>
            <groupId>org.apache.cxf</groupId>
            <artifactId>cxf-rt-rs-extension-providers</artifactId>
            <version>3.0.1</version>
        </dependency>

        <!-- 转换json工具包，被extension providers 依赖 -->
        <dependency>
            <groupId>org.codehaus.jettison</groupId>
            <artifactId>jettison</artifactId>
            <version>1.3.7</version>
        </dependency>

        <!-- spring 核心 -->
        <dependency>
            <groupId>org.springframework</groupId>
            <artifactId>spring-context</artifactId>
            <version>4.2.4.RELEASE</version>
        </dependency>
        <!-- spring web集成 -->
        <dependency>
            <groupId>org.springframework</groupId>
            <artifactId>spring-web</artifactId>
            <version>4.2.4.RELEASE</version>
        </dependency>
        <!-- spring 整合junit  -->
        <dependency>
            <groupId>org.springframework</groupId>
            <artifactId>spring-test</artifactId>
            <version>4.2.4.RELEASE</version>
        </dependency>
        <!-- junit 开发包 -->
        <dependency>
            <groupId>junit</groupId>
            <artifactId>junit</artifactId>
            <version>4.12</version>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.2</version>
                <configuration>
                    <source>1.8</source>
                    <target>1.8</target>
                    <encoding>UTF-8</encoding>
                    <showWarnings>true</showWarnings>
                </configuration>
            </plugin>
            <!-- 运行tomcat7方法：tomcat7:run -->
            <plugin>
                <groupId>org.apache.tomcat.maven</groupId>
                <artifactId>tomcat7-maven-plugin</artifactId>
                <version>2.2</version>
                <configuration>
                    <!-- 指定端口 -->
                    <port>8080</port>
                    <!-- 请求路径 -->
                    <path>/</path>
                </configuration>
            </plugin>
        </plugins>
    </build>
```

**实体类**

```java
import javax.xml.bind.annotation.XmlRootElement;

/**
 *  基于restful风格的webservice，客户端与服务端之间通讯可以传递xml数据、json数据。
 *  @XmlRootElement 指定对象序列化为xml或json数据时根节点的名称
 */
@XmlRootElement(name = "User")
public class User {
    //......
}
```

### 服务端发布服务

**web.xml**

```xml
<!DOCTYPE web-app PUBLIC
        "-//Sun Microsystems, Inc.//DTD Web Application 2.3//EN"
        "http://java.sun.com/dtd/web-app_2_3.dtd" >
<web-app>
  <display-name>Archetype Created Web Application</display-name>
  <!--1. cxfsevlet配置-->
  <servlet>
    <servlet-name>cxfservlet</servlet-name>
    <servlet-class>org.apache.cxf.transport.servlet.CXFServlet</servlet-class>
  </servlet>
  <servlet-mapping>
    <servlet-name>cxfservlet</servlet-name>
    <url-pattern>/ws/*</url-pattern>
  </servlet-mapping>
  <!--2.spring容器配置-->
  <context-param>
    <param-name>contextConfigLocation</param-name>
    <param-value>classpath:applicationContext.xml</param-value>
  </context-param>
  <listener>
    <listener-class>
      org.springframework.web.context.ContextLoaderListener
    </listener-class>
  </listener>
</web-app>
```

**applicationContext.xml**

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:cxf="http://cxf.apache.org/core"
       xmlns:jaxws="http://cxf.apache.org/jaxws"
       xmlns:jaxrs="http://cxf.apache.org/jaxrs"
       xsi:schemaLocation="
        http://www.springframework.org/schema/beans
        http://www.springframework.org/schema/beans/spring-beans.xsd
        http://cxf.apache.org/core
        http://cxf.apache.org/schemas/core.xsd
        http://cxf.apache.org/jaxws
        http://cxf.apache.org/schemas/jaxws.xsd
        http://cxf.apache.org/jaxrs
        http://cxf.apache.org/schemas/jaxrs.xsd">
        
        <!--
            Spring整合cxf发布基于restful风格的服务，关键点：
            1. 服务地址
            2. 服务类
            3. 服务完整访问地址：http://localhost:8080/ws/hello
        -->
        <jaxrs:server address="/userService">
                <jaxrs:serviceBeans>
                    <bean class="com.wxq.service.UserServiceImpl"></bean>
                </jaxrs:serviceBeans>
        </jaxrs:server>
</beans>
```

**定义接口及实现类**

```java
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

@Path("/userService")//  访问当前服务接口对应的路径
@Produces("*/*")  // 服务器支持的返回的数据格式类型
public interface IUserService {
    
    //post增 DELETE删 PUT改  GET查
	@GET
    // 访问当前服务接口方法对应的路径。 【.../userService/user】
	@Path("/user/{id}")
     //服务器支持的请求的数据格式类型 
    @Consumes({ "application/xml", "application/json" })
     //服务器支持的返回的数据格式类型
	@Produces({ "application/xml", "application/json" })
	public User finUserById(@PathParam("id") Integer id);

	@PUT
	@Path("/user")
	@Consumes({ "application/xml", "application/json" })
	public void updateUser(User user);
    
}

/**
 * 实现类
 */
public class UserServiceImpl implements IUserService {
	//......
}
```

### 客户端获取服务

**测试访问**

```java
import org.apache.cxf.jaxrs.client.WebClient;
import org.junit.Test;

import javax.ws.rs.core.MediaType;

public class Client {

    @Test
    public void testSave() {
        User user = new User();
        user.setId(100);
        user.setUsername("Jerry");
        user.setCity("gz");
        // 通过WebClient对象远程调用服务端,后面那个userService是接口path
        WebClient.create("http://localhost:8080/ws/userService/userService/user")
                .type(MediaType.APPLICATION_JSON)  // 指定请求的数据格式为json
                .post(user);
    }

    @Test
    public void testGet() {
        // 查询一个
        User user = WebClient
            .create("http://localhost:8080/ws/userService/userService/user/1")
            .accept(MediaType.APPLICATION_JSON)
            .get(User.class);
        System.out.println(user);
    }
}
```

