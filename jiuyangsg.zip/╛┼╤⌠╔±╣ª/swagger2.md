## 一、导入maven依赖包

```groovy
compile group: 'io.springfox', name: 'springfox-swagger2', version: '2.9.2'
compile group: 'io.springfox', name: 'springfox-swagger-ui', version: '2.9.2' 
```

```xml
<dependency>
    <groupId>io.springfox</groupId>
    <artifactId>springfox-swagger2</artifactId>
    <version>2.9.2</version>
    <exclusions>
        <exclusion>
            <groupId>io.swagger</groupId>
            <artifactId>swagger-models</artifactId>
        </exclusion>
    </exclusions>
</dependency>
<dependency>
    <groupId>io.springfox</groupId>
    <artifactId>springfox-swagger-ui</artifactId>
    <version>2.9.2</version>
</dependency>
<dependency>
    <groupId>io.swagger</groupId>
    <artifactId>swagger-models</artifactId>
    <version>1.5.21</version>
</dependency>
```

## 二、创建配置swagger类

### 1、单包扫描

```java
@Configuration
@EnableSwagger2  // 开启Swagger2
public class Swagger2Config {
    
     //1.重写swagger配置信息
    private ApiInfo apiInfo(){
        return new ApiInfoBuilder()
            .title("标题")
            .version("版本号")
            .description("描述")
            .termsOfServiceUrl("")
            .contact(new Contact("wxq", "http://baidu.com", "110@qq.com")) //作者信息 
            .build();
    }
    
    //2.设置要显示的Swaager环境
    private boolean enable(Environment environment) {
        Profiles profiles = Profiles.of("dev", "test");//设置要显示的Swagger环境
        boolean flag = environment.acceptsProfiles(profiles);//判断是否处在自己设定的环境中
        return flag;
    }
      
    //3.配置swagger的bean实例
    @Bean
    public Docket docket(Environment environment){ 			
        return new Docket(DocumentationType.SWAGGER_2)
            .apiInfo(apiInfo())
            .select()
            .enabler(enable(environment)) //是否启动Swagger
            
            //指定扫描的包
            .apis(RequestHandlerSelectors.basePackage("com.wxq.controller"))
            //扫描类上的注解,(@RestController都扫描);withMethodAnnotation()扫描方法上的注解
            [.apis(RequestHandlerSelectors.withClassAnnotation(RestController.class))]
            
            .paths(PathSelectors.any()) //any()扫描全部；none()不扫描
            .paths(PathSelectors.ant("/test/get/**")) //过滤什么路径
            .build();
    }

}
```

```java
//分组
@Bean
public Docket a(){
    return new Docket(DocumentationType.Swagger_2).groupName("A");
}
@Bean
public Docket b(){
    return new Docket(DocumentationType.Swagger_2).groupName("B");
}
```

### 2、多个包扫描

```java
@Configuration
@EnableSwagger2
public class Swagger2Config {
    
    //多包访问
     // 定义分隔符
    private static final String splitor = ";";

    @Bean
    public Docket createRestApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiInfo())
                .select()
                //此处添加需要扫描接口的包路径
                .apis(basePackage("com.wxq.Controller" + splitor + "com.wxq.Controller2" + splitor + "com.wxq.Controller3"))
                .paths(PathSelectors.any())
                .build();
    }


    /**
     * 重写basePackage方法，使能够实现多包访问
     */
    public static Predicate<RequestHandler>
        basePackage(final String basePackage) {
        return input -> declaringClass(input)
            .transform(handlerPackage(basePackage)).or(true);
    }

    private static Function<Class<?>, Boolean> 
        handlerPackage(final String basePackage)     {
        return input -> {
            for (String strPackage : basePackage.split(splitor)) {// 循环判断匹配
                boolean isMatch = input.getPackage().getName().startsWith(strPackage);
                if (isMatch) {
                    return true;
                }
            }
            return false;
        };
    }

    private static Optional<? extends Class<?>> declaringClass(RequestHandler input) {
        return Optional.fromNullable(input.declaringClass());
    }
}


```

## 三、swagger常用注解

```java
@Api() //用于类；表示标识这个类是swagger的资源 
tags–表示说明 
value–也是说明，可以使用tags替代 

@ApiOperation() //用于方法；表示一个http请求的操作 
value用于方法描述 
notes用于提示内容 


@ApiParam() //用于方法，参数，字段说明；表示对参数的添加元数据（说明或是否必填等） 
name–参数名 
value–参数说明 
required–是否必填

@ApiModel()	//用于类。表示对类进行说明，用于参数用实体类接收 
value–表示对象名 

@ApiModelProperty() //用于方法，字段； 表示对model属性的说明或者数据操作更改 
value–字段说明 
name–重写属性名字 
dataType–重写属性类型 
required–是否必填 
example–举例说明 
hidden–隐藏

@ApiImplicitParam() //用于方法表示单独的请求参数

@ApiImplicitParams() //用于方法，包含多个 @ApiImplicitParam 
name–参数ming 
value–参数说明 
dataType–数据类型 
paramType–参数类型 
example–举例说明

@ApiIgnore //作用于方法上，使用这个注解swagger将忽略这个接口

//例子：
@ApiModel("用户实体类")
public class User{
    @ApiModelProperty("用户名")
    public String userName;
     @ApiModelProperty("密码")
    public String password;    
}

@Controller
public class HelloController{
    
    @ApiOperation("Hello控制类")
    @GetMapping("hello")
    public String  hello(@ApiParam("用户名") String userName){
        
    }
}
```

## 四、其他

![](images/swagger信息.png)

```java
//打开 swagger 页面 ：    
http://localhost:8080/swagger-ui.html
//   
http://localhost:8080/v2/api-docs
```

