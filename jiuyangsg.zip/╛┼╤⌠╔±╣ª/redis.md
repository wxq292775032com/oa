# Redis简介

```java
//Redis基本了解
1、redis一般作为缓存数据库，它的特点是K-V模式存储，读写速度快、支持事务备份、支持持久化等。

2、所有操作都是单线程,原子性的。redis是个单进程以epoll包装以后在大批量文件操作里面多路的IO复用。
 
3、默认16个数据库，下表从0开始。

4.默认端口6379

5.redis中字符串value最多可以是512M

6.redis日志级别：debug、verbose、notice、warn

7.常用方式：排行榜zset;手机验证expire过期;计数器秒杀incr、decr;

//官网地址和下载地址 
http://redis.io/
http://www.redis.cn/ 
```

**CAP理论**

```
C: 强一致性
A: 高可用性
P: 分区容错性（在分布式系统中，由于网络原因，无法避免有时候出现数据不一致情况，系统如果不能在时限内达成数据一致性，就意味着发生了分区的情况）

CAP理论核心：一个分布式系统不可能很好的满足一致性，可用性和分区容错性这三个需求，最多只能同时满足两个。而由于当前的网络硬件肯定会出现延迟等问题，所以分区容错性是必须实现的，只能在一致性和高可用之间进行权衡。

CA：单点集群，满足一致性，可用性的系统，通常可扩展上不太强。（传统Oracle数据库）
CP: 满足一致性，分区容错性的系统，通常性能不是特别高。（Redis）
AP: 满足可用性，分区容错性，通常可能对一致性要求低一些。（大多数网络架构的选择）
```

# Redis安装

**docker安装**

```properties
#方式一：
#拉取镜像
docker pull redis
#挂载数据卷并运行容器
docker run -p 6379:6379 --name redis -v /root/redis/data:/data -v /root/redis/conf/redis.conf:/usr/local/etc/redis/redis.conf -d redis redis-server /usr/local/etc/redis/redis.conf --appendonly yes --requirepass "xxx"

#方式二：
docker pull redis
docker run -d --name redis -p 6379:6379 redis
docker exec -it redis redis-cli
```

**Linux安装**

```java
第一阶段：设置环境
//确保安装gcc。gcc是linux下的一个编译程序，是C程序的编译工具

//方式一：
要能上网：yum install gcc-c++  
安装完以后还不行，执行下 make distclean

//方式二：
yum -y install gcc automake autoconf libtool make
注意：运行yum时出现/var/run/yum.pid已被锁定，PID为xxx
rm -f /var/run/yum.pid

第二阶段：正式开始安装
1.下载获得 redis-3.0.4.tar.gz 后将它放入我们的Linux目录/opt
2.解压： tar -zxvf redis-3.0.4.tar.gz
3.进入目录： cd redis-3.0.4
4.执行 make 命令，make命令完成后继续执行 make install（安装）
5.查看默认安装目录： cd /usr/local/bin 是否有redis-server等等
6.重新回到 cd /opt/redis-3.0.4 目录，修改redis.conf ---> daemonize 改为 yes
```

![](images/QQ截图20200616161314.png)

```
7.回到 cd /usr/local/bin 目录下，执行  redis-server /opt/redis-3.0.4/redis.conf 
8.redis-cli -p 6379
9.执行下 ping 如果显示PONG 表示成功
```

![](images/QQ截图20200616163039.png)

# 基本命令

```java
redisdoc.com   //命令文档
```

```java
//切换数据库 
select 0 、 select 1  

//查看当前库的key数量    
dbsize 

//显示所有key
keys *  
    
//清除当前库
FLUSHDB  

//通杀全部库
FLUSHALL 

//检查keyName是否存在,1有,0没有
exists keyName

//将 keyName移到2号库
move keyName 2 
    
//将keyName设置过期时间为10秒        
expire keyName 10： 

//查看k1还有多秒过期，-1表示永不过期，-2已过期
ttl keyName

//查keyName是什么类型
type keyName 

//删除keyName
del keyName
```

```java
//Redis默认不需要密码，但需要也可以设置    
	config  get  requirepass
	config  set  requirepass "123456"
	auth 123456
```

# Redis的五大数据类型

## **String**

```
1、String通常用于保存单个字符串或JSON字符串数据
2、因为String是二进制安全的，所以可以把保密要求高的图片文件内容作为字符串来存储
3、计数器：常规Key-Value缓存应用，如微博数、粉丝数。INCR本身就具有原子性特性，所以不会有线程安全问题
```

```java
//设置值，keyName区分大小
set keyName value

//追加,如果key不存在则赋值
append keyName value

//当key不存在时设置key的值
setnx keyName value

//设置多个key值
mset keyName1 value1 keyName2 value2

//设置多个key值--key不存在才设置key值，但有一个设置失败，则整体失败
msetnx  keyName1 value1 keyName2 value2

//返回旧值设置新值
getset keyName value 

//获取值
get keyName : 获取值

//获取多个key值
mget keyName1 keyName2

//获取长度
strlen keyName

//获取key字符串中从start开始，end结束,下标0开始
getrange keyName start end     

//设置从offset往后的值
setrange keyName offset value

//创建一个key，并且设置他的过期时间为10秒
setex keyName 10 value

//自增加1，如果不存在该key则初始化为0，注意值要为数字
incr keyName

//指定增量值为2
incrby keyName 2
    
//自减1    
decr keyName    

//指定自减值3
decrby keyName 3
```

## List

```
1. 对数据大的集合数据删减
	 列表显示、关注列表、粉丝列表、留言评价...分页、热点新闻等
2. 任务队列
	list通常用来实现一个消息队列，而且可以确保先后顺序，不必像MySQL那样通过order by来排序.
```

```java
//从左侧插入，右边的先出,相当于一个栈(正的进反的出)
lpush keyName value1 [value2]

//从右侧插入，左边的先出（怎么进怎么出）
rpush keyName value1 [value2]

//从左侧移除第一个元素
lpop keyName

//移除列表最后一个元素
rpop keyName：

//获取指定索引的元素,从零开始
lindex keyName index

//集合长度
llen keyName

//删除2个22
lrem keyName 2 22

//对列表进行修改，让列表只保留指定区间的元素，不在指定区间的元素就会被删除
ltrim keyName start stop   

//删除list01最后一个元素，同时将其添加到list02中
rpoplpush list01 list02

//替换指定索引的值
lset keyName index value 

//在列表元素前或者后插入元素，如果有两个相同的元素采用的是第一个
linsert keyName before|after world value

//获取列表指定范围的元素
lrange keyName start stop 
```

## Set

```
唯一、无序
```

```java
//向集合添加成员,值不允许重复
sadd keyName value1 [value2]

//返回集合中所有成员
smembers keyName

//返回集合成员数
scard keyName

//删除集合中一个元素或多个元素
srem keyName value [value2]

//返回集合中一个或多个随机数
srandmember keyName [count]

//随机移除并返回集合中的一个元素
spop keyName

//将member元素从source集合移动到destination集合
smove source destination member

//返回给定的第一个集合和其他集合的差集(即在key1中的值而在其他key中找不到)
sdiff key1 [key2]

//返回所有集合的交集
sinter key1 [key2]

//返回所有集合的并集
sunion key1 [key2]

//返回给定的第一个集合与其他的集合的差集并存储在destination中
sdiffstore destination key1 [key2]

```

## Hash

```
Redis hash是一个string类型的field和value的映射表，hash特别适用于存储对象。每个hash可以存储232-1(40亿左右)键值对。可以看成KEY和VALUE的MAP容器。相比于JSON，hash占用很少的内存空间。

KV模式不变但V是一个键值对

Hash的应用场景，通常用来存储一个用户信息的对象数据。
1. 相比于存储对象的string类型的json串，json串修改单个属性需要将整个值取出来。而hash不需要。
2. 相比于多个key-value存储对象，hash节省了很多内存空间
3. 如果hash的属性值被删除完，那么hash的key也会被redis删除
```

```java
//为指定的key设定field和value
hset keyName field value

//指定多个
hmset keyName field1 value1 [field2 value2]  
    
//获取key下面某个field的值
hget keyName field

//获取多个
hmget keyName field1 [field2]

//返回hash表中所有字段和值
hgetall keyName

//删除一个或多个hash表的字段
hdel keyName field [field1]

//获取hash表中的字段数量
hlen keyName

//在key里面是否存在指定的field
hexists keyName field

//获取hash表所有字段
hkeys keyName

//获取hash表所有值
hvals keyName

//增加某个field的值,注意必须是数字
hincrby keyName field number

//增加值为小数
hincrbyfloat keyName field number

//当不存在才创建该field
hsetnx keyName field value
```

## Zset

```
有序且不重复。每个元素都会关联一个double类型的分数，Redis通过分数进行从小到大的排序。分数可以重复.
在set的基础上，加一个score值
```

```java
//添加
zadd keyName score1 memeber1 [score2 memeber2]

//查看score值
zrange keyName 0 -1

//查看包括score值和memeber
zrange keyName 0 -1 withscores  

//指定输出score区间内的成员
zrangebyscore keyName min max 
zrangebyscore keyName (60 (90   //min大于60  max小于90
zrangebyscore keyName 60 90  //60-90之间 
zrangebyscore keyName 60 90 limit 2 2 //筛选出来后再进行筛选

//移除有序集合中的一个或多个成员
zrem keyName score1 [score2]

//获取集合中的元素数量
zcard keyName

//计算在有序集合中指定区间分数的成员数
zcount keyName min max 

//返回有序集合指定成员的索引
zrank keyName score

//获取scrore对应的值
zscore keyName scrore

//与zrange显示的顺序相反
zrevrange keyName 0 -1

//与zrank相反
zrevrank keyName score    

// 移除有序集合中给定的索引区间的所有成员(第一名是0)(低到高排序）
zrevrangebyrank keyName start stop

//移除有序集合中给定的分数区间的所有成员
zrevrangebyscore keyName min max 
```

# 解析配置文件

```properties
################################## INCLUDES ###################################
# INCLUDES 模块是指引入其他配置文件

################################ GENERAL  #####################################
#通用

#是否在后台运行；no：不是后台运行   (num 37)
daemonize yes
 
#redis的进程文件
pidfile /var/run/redis/redis-server.pid 
 
#redis监听的端口号。
port 6379 
 
#此参数确定了TCP连接中已完成队列(完成三次握手之后)的长度， 当然此值必须不大于Linux系统定义的/proc/sys/net/core/somaxconn值，默认是511，而Linux的默认参数值是128。当系统并发量大并且客户端速度缓慢的时候，可以将这二个参数一起参考设定。该内核参数默认值一般是128，对于负载很大的服务程序来说大大的不够。一般会将它修改为2048或者更大。在/etc/sysctl.conf中添加:net.core.somaxconn = 2048，然后在终端中执行sysctl -p。
tcp-backlog 511 
 
#是否开启保护模式，默认开启。要是配置里没有指定bind和密码。开启该参数后，redis只会本地进行访问，拒绝外部访问。
protected-mode yes
 
#指定 redis 只接收来自于该 IP 地址的请求，如果不进行设置，那么将处理所有请求
#bind 127.0.0.1
#bind 0.0.0.0

#配置unix socket来让redis支持监听本地连接。
# unixsocket /var/run/redis/redis.sock
 
#配置unix socket使用文件的权限
# unixsocketperm 700
 
# 此参数为设置客户端空闲超过timeout，服务端会断开连接，为0则服务端不会主动断开连接，不能小于0。
timeout 0
 
#tcp keepalive参数。如果设置不为0，就使用配置tcp的SO_KEEPALIVE值，使用keepalive有两个好处:检测挂掉的对端。降低中间设备出问题而导致网络看似连接却已经与对端端口的问题。在Linux内核中，设置了keepalive，redis会定时给对端发送ack。检测到对端关闭需要两倍的设置值。
tcp-keepalive 0
 
#指定了服务端日志的级别。级别包括：debug（很多信息，方便开发、测试），verbose（许多有用的信息，但是没有debug级别信息多），notice（适当的日志级别，适合生产环境），warn（只有非常重要的信息）
loglevel notice
 
#指定了记录日志的文件。空字符串的话，日志会打印到标准输出设备。后台运行的redis标准输出是/dev/null。
logfile /var/log/redis/redis-server.log
 
#是否打开记录syslog功能
# syslog-enabled no
 
#syslog的标识符。
# syslog-ident redis
 
#日志的来源、设备
# syslog-facility local0
 
#数据库的数量，默认使用的数据库是DB 0。可以通过SELECT命令选择一个db
databases 16

################################ SNAPSHOTTING  ################################
#快照

# redis是基于内存的数据库，可以通过设置该值定期写入磁盘。
# 注释掉“save”这一行配置项就可以让保存数据库功能失效
# 900秒（15分钟）内至少1个key值改变（则进行数据库保存--持久化） 
# 300秒（5分钟）内至少10个key值改变（则进行数据库保存--持久化） 
# 60秒（1分钟）内至少10000个key值改变（则进行数据库保存--持久化）
save 900 1
save 300 10
save 60 10000
 
#当RDB持久化出现错误后，是否依然进行继续进行工作，yes：不能进行工作，no：可以继续进行工作，可以通过info中的rdb_last_bgsave_status了解RDB持久化是否有错误
stop-writes-on-bgsave-error yes
 
#使用压缩rdb文件，rdb文件压缩使用LZF压缩算法，yes：压缩，但是需要一些cpu的消耗。no：不压缩，需要更多的磁盘空间
rdbcompression yes
 
#是否校验rdb文件。从rdb格式的第五个版本开始，在rdb文件的末尾会带上CRC64的校验和。这跟有利于文件的容错性，但是在保存rdb文件的时候，会有大概10%的性能损耗，所以如果你追求高性能，可以关闭该配置。
rdbchecksum yes
 
#rdb文件的名称
dbfilename dump.rdb
 
#数据目录，数据库的写入会在这个目录。rdb、aof文件也会写在这个目录
dir /data
 
################################# REPLICATION ################################# 
############### 主从复制 ###############
 
#复制选项，slave复制对应的master。
# slaveof <masterip> <masterport>
 
#如果master设置了requirepass，那么slave要连上master，需要有master的密码才行。masterauth就是用来配置master的密码，这样可以在连上master后进行认证。
# masterauth <master-password>
 
#当从库同主机失去连接或者复制正在进行，从机库有两种运行方式：1) 如果slave-serve-stale-data设置为yes(默认设置)，从库会继续响应客户端的请求。2) 如果slave-serve-stale-data设置为no，除去INFO和SLAVOF命令之外的任何请求都会返回一个错误”SYNC with master in progress”。
slave-serve-stale-data yes
 
#作为从服务器，默认情况下是只读的（yes），可以修改成NO，用于写（不建议）。
slave-read-only yes
 
#是否使用socket方式复制数据。目前redis复制提供两种方式，disk和socket。如果新的slave连上来或者重连的slave无法部分同步，就会执行全量同步，master会生成rdb文件。有2种方式：disk方式是master创建一个新的进程把rdb文件保存到磁盘，再把磁盘上的rdb文件传递给slave。socket是master创建一个新的进程，直接把rdb文件以socket的方式发给slave。disk方式的时候，当一个rdb保存的过程中，多个slave都能共享这个rdb文件。socket的方式就的一个个slave顺序复制。在磁盘速度缓慢，网速快的情况下推荐用socket方式。
repl-diskless-sync no
 
#diskless复制的延迟时间，防止设置为0。一旦复制开始，节点不会再接收新slave的复制请求直到下一个rdb传输。所以最好等待一段时间，等更多的slave连上来。
repl-diskless-sync-delay 5
 
#slave根据指定的时间间隔向服务器发送ping请求。时间间隔可以通过 repl_ping_slave_period 来设置，默认10秒。
# repl-ping-slave-period 10
 
#复制连接超时时间。master和slave都有超时时间的设置。master检测到slave上次发送的时间超过repl-timeout，即认为slave离线，清除该slave信息。slave检测到上次和master交互的时间超过repl-timeout，则认为master离线。需要注意的是repl-timeout需要设置一个比repl-ping-slave-period更大的值，不然会经常检测到超时。
# repl-timeout 60
 
#是否禁止复制tcp链接的tcp nodelay参数，可传递yes或者no。默认是no，即使用tcp nodelay。如果master设置了yes来禁止tcp nodelay设置，在把数据复制给slave的时候，会减少包的数量和更小的网络带宽。但是这也可能带来数据的延迟。默认我们推荐更小的延迟，但是在数据量传输很大的场景下，建议选择yes。
repl-disable-tcp-nodelay no
 
#复制缓冲区大小，这是一个环形复制缓冲区，用来保存最新复制的命令。这样在slave离线的时候，不需要完全复制master的数据，如果可以执行部分同步，只需要把缓冲区的部分数据复制给slave，就能恢复正常复制状态。缓冲区的大小越大，slave离线的时间可以更长，复制缓冲区只有在有slave连接的时候才分配内存。没有slave的一段时间，内存会被释放出来，默认1m。
# repl-backlog-size 5mb
 
#master没有slave一段时间会释放复制缓冲区的内存，repl-backlog-ttl用来设置该时间长度。单位为秒。
# repl-backlog-ttl 3600
 
#当master不可用，Sentinel会根据slave的优先级选举一个master。最低的优先级的slave，当选master。而配置成0，永远不会被选举。
slave-priority 100
 
#redis提供了可以让master停止写入的方式，如果配置了min-slaves-to-write，健康的slave的个数小于N，mater就禁止写入。master最少得有多少个健康的slave存活才能执行写命令。这个配置虽然不能保证N个slave都一定能接收到master的写操作，但是能避免没有足够健康的slave的时候，master不能写入来避免数据丢失。设置为0是关闭该功能。
# min-slaves-to-write 3
 
#延迟小于min-slaves-max-lag秒的slave才认为是健康的slave。
# min-slaves-max-lag 10
 
# 设置1或另一个设置为0禁用这个特性。
# Setting one or the other to 0 disables the feature.
# By default min-slaves-to-write is set to 0 (feature disabled) and
# min-slaves-max-lag is set to 10.
 
################################## SECURITY ################################### 
############### 安全相关 ###############
 
#requirepass配置可以让用户使用AUTH命令来认证密码，才能使用其他命令。这让redis可以使用在不受信任的网络中。为了保持向后的兼容性，可以注释该命令，因为大部分用户也不需要认证。使用requirepass的时候需要注意，因为redis太快了，每秒可以认证15w次密码，简单的密码很容易被攻破，所以最好使用一个更复杂的密码。注意只有密码没有用户名。
# requirepass foobared
 
#把危险的命令给修改成其他名称。比如CONFIG命令可以重命名为一个很难被猜到的命令，这样用户不能使用，而内部工具还能接着使用。
# rename-command CONFIG b840fc02d524045429941cc15f59e41cb7be6c52
 
#设置成一个空的值，可以禁止一个命令
# rename-command CONFIG ""
 
################################### LIMITS ####################################
############### 进程限制相关 ###############
 
# 设置能连上redis的最大客户端连接数量。默认是10000个客户端连接。由于redis不区分连接是客户端连接还是内部打开文件或者和slave连接等，所以maxclients最小建议设置到32。如果超过了maxclients，redis会给新的连接发送’max number of clients reached’，并关闭连接。
# maxclients 10000
 
#redis配置的最大内存容量。当内存满了，需要配合maxmemory-policy策略进行处理。注意slave的输出缓冲区是不计算在maxmemory内的。所以为了防止主机内存使用完，建议设置的maxmemory需要更小一些。
# maxmemory <bytes>
 
#内存容量超过maxmemory后的处理策略。
#volatile-lru：利用LRU算法移除设置过过期时间的key。
#volatile-random：随机移除设置过过期时间的key。
#volatile-ttl：移除即将过期的key，根据最近过期时间来删除（辅以TTL）
#allkeys-lru：利用LRU算法移除任何key。
#allkeys-random：随机移除任何key。
#noeviction：不移除任何key，只是返回一个写错误。
#上面的这些驱逐策略，如果redis没有合适的key驱逐，对于写命令，还是会返回错误。redis将不再接收写请求，只接收get请求。写命令包括：set setnx setex append incr decr rpush lpush rpushx lpushx linsert lset rpoplpush sadd sinter sinterstore sunion sunionstore sdiff sdiffstore zadd zincrby zunionstore zinterstore hset hsetnx hmset hincrby incrby decrby getset mset msetnx exec sort。
# maxmemory-policy noeviction
 
#lru检测的样本数。使用lru或者ttl淘汰算法，从需要淘汰的列表中随机选择sample个key，选出闲置时间最长的key移除。
# maxmemory-samples 5
 
############################## APPEND ONLY MODE ############################### 
############### APPEND ONLY 持久化方式 ###############
 
#默认redis使用的是rdb方式持久化，这种方式在许多应用中已经足够用了。但是redis如果中途宕机，会导致可能有几分钟的数据丢失，根据save来策略进行持久化，Append Only File是另一种持久化方式，可以提供更好的持久化特性。Redis会把每次写入的数据在接收后都写入 appendonly.aof 文件，每次启动时Redis都会先把这个文件的数据读入内存里，先忽略RDB文件。
appendonly no
 
#aof文件名
appendfilename "appendonly.aof"
 
#aof持久化策略的配置
#no表示不执行fsync，由操作系统保证数据同步到磁盘，速度最快。
#always表示每次写入都执行fsync，以保证数据同步到磁盘。
#everysec表示每秒执行一次fsync，可能会导致丢失这1s数据。
appendfsync everysec
 
# 在aof重写或者写入rdb文件的时候，会执行大量IO，此时对于everysec和always的aof模式来说，执行fsync会造成阻塞过长时间，no-appendfsync-on-rewrite字段设置为默认设置为no，是最安全的方式，不会丢失数据，但是要忍受阻塞的问题。如果对延迟要求很高的应用，这个字段可以设置为yes，，设置为yes表示rewrite期间对新写操作不fsync,暂时存在内存中,不会造成阻塞的问题（因为没有磁盘竞争），等rewrite完成后再写入，这个时候redis会丢失数据。Linux的默认fsync策略是30秒。可能丢失30秒数据。因此，如果应用系统无法忍受延迟，而可以容忍少量的数据丢失，则设置为yes。如果应用系统无法忍受数据丢失，则设置为no。
no-appendfsync-on-rewrite no
 
#aof自动重写配置。当目前aof文件大小超过上一次重写的aof文件大小的百分之多少进行重写，即当aof文件增长到一定大小的时候Redis能够调用bgrewriteaof对日志文件进行重写。当前AOF文件大小是上次日志重写得到AOF文件大小的二倍（设置为100）时，自动启动新的日志重写过程。
auto-aof-rewrite-percentage 100
#设置允许重写的最小aof文件大小，避免了达到约定百分比但尺寸仍然很小的情况还要重写
auto-aof-rewrite-min-size 64mb
 
#aof文件可能在尾部是不完整的，当redis启动的时候，aof文件的数据被载入内存。重启可能发生在redis所在的主机操作系统宕机后，尤其在ext4文件系统没有加上data=ordered选项（redis宕机或者异常终止不会造成尾部不完整现象。）出现这种现象，可以选择让redis退出，或者导入尽可能多的数据。如果选择的是yes，当截断的aof文件被导入的时候，会自动发布一个log给客户端然后load。如果是no，用户必须手动redis-check-aof修复AOF文件才可以。
aof-load-truncated yes
 
 
############### LUA SCRIPTING ###############
 
# 如果达到最大时间限制（毫秒），redis会记个log，然后返回error。当一个脚本超过了最大时限。只有SCRIPT KILL和SHUTDOWN NOSAVE可以用。第一个可以杀没有调write命令的东西。要是已经调用了write，只能用第二个命令杀。
lua-time-limit 5000
 
 
############### 集群相关 ###############
 
#集群开关，默认是不开启集群模式。
# cluster-enabled yes
 
#集群配置文件的名称，每个节点都有一个集群相关的配置文件，持久化保存集群的信息。这个文件并不需要手动配置，这个配置文件有Redis生成并更新，每个Redis集群节点需要一个单独的配置文件，请确保与实例运行的系统中配置文件名称不冲突
# cluster-config-file nodes-6379.conf
 
#节点互连超时的阀值。集群节点超时毫秒数
# cluster-node-timeout 15000
 
#在进行故障转移的时候，全部slave都会请求申请为master，但是有些slave可能与master断开连接一段时间了，导致数据过于陈旧，这样的slave不应该被提升为master。该参数就是用来判断slave节点与master断线的时间是否过长。判断方法是：
#比较slave断开连接的时间和(node-timeout * slave-validity-factor) + repl-ping-slave-period
#如果节点超时时间为三十秒, 并且slave-validity-factor为10,假设默认的repl-ping-slave-period是10秒，即如果超过310秒slave将不会尝试进行故障转移 
# cluster-slave-validity-factor 10
 
#master的slave数量大于该值，slave才能迁移到其他孤立master上，如这个参数若被设为2，那么只有当一个主节点拥有2 个可工作的从节点时，它的一个从节点会尝试迁移。
# cluster-migration-barrier 1
 
#默认情况下，集群全部的slot有节点负责，集群状态才为ok，才能提供服务。设置为no，可以在slot没有全部分配的时候提供服务。不建议打开该配置。
# cluster-require-full-coverage yes
 
 
############### SLOW LOG 慢查询日志 ###############
 
###slog log是用来记录redis运行中执行比较慢的命令耗时。当命令的执行超过了指定时间，就记录在slow log中，slog log保存在内存中，所以没有IO操作。
#执行时间比slowlog-log-slower-than大的请求记录到slowlog里面，单位是微秒，所以1000000就是1秒。注意，负数时间会禁用慢查询日志，而0则会强制记录所有命令。
slowlog-log-slower-than 10000
 
#慢查询日志长度。当一个新的命令被写进日志的时候，最老的那个记录会被删掉。这个长度没有限制。只要有足够的内存就行。你可以通过 SLOWLOG RESET 来释放内存。
slowlog-max-len 128
 
############### 延迟监控 ###############
#延迟监控功能是用来监控redis中执行比较缓慢的一些操作，用LATENCY打印redis实例在跑命令时的耗时图表。只记录大于等于下边设置的值的操作。0的话，就是关闭监视。默认延迟监控功能是关闭的，如果你需要打开，也可以通过CONFIG SET命令动态设置。
latency-monitor-threshold 0
 
############### EVENT NOTIFICATION 订阅通知 ###############
#键空间通知使得客户端可以通过订阅频道或模式，来接收那些以某种方式改动了 Redis 数据集的事件。因为开启键空间通知功能需要消耗一些 CPU ，所以在默认配置下，该功能处于关闭状态。
#notify-keyspace-events 的参数可以是以下字符的任意组合，它指定了服务器该发送哪些类型的通知：
##K 键空间通知，所有通知以 __keyspace@__ 为前缀
##E 键事件通知，所有通知以 __keyevent@__ 为前缀
##g DEL 、 EXPIRE 、 RENAME 等类型无关的通用命令的通知
##$ 字符串命令的通知
##l 列表命令的通知
##s 集合命令的通知
##h 哈希命令的通知
##z 有序集合命令的通知
##x 过期事件：每当有过期键被删除时发送
##e 驱逐(evict)事件：每当有键因为 maxmemory 政策而被删除时发送
##A 参数 g$lshzxe 的别名
#输入的参数中至少要有一个 K 或者 E，否则的话，不管其余的参数是什么，都不会有任何 通知被分发。详细使用可以参考http://redis.io/topics/notifications
 
notify-keyspace-events ""
 
############### ADVANCED CONFIG 高级配置 ###############
#数据量小于等于hash-max-ziplist-entries的用ziplist，大于hash-max-ziplist-entries用hash
hash-max-ziplist-entries 512
#value大小小于等于hash-max-ziplist-value的用ziplist，大于hash-max-ziplist-value用hash。
hash-max-ziplist-value 64
 
#数据量小于等于list-max-ziplist-entries用ziplist，大于list-max-ziplist-entries用list。
list-max-ziplist-entries 512
#value大小小于等于list-max-ziplist-value的用ziplist，大于list-max-ziplist-value用list。
list-max-ziplist-value 64
 
#数据量小于等于set-max-intset-entries用iniset，大于set-max-intset-entries用set。
set-max-intset-entries 512
 
#数据量小于等于zset-max-ziplist-entries用ziplist，大于zset-max-ziplist-entries用zset。
zset-max-ziplist-entries 128
#value大小小于等于zset-max-ziplist-value用ziplist，大于zset-max-ziplist-value用zset。
zset-max-ziplist-value 64
 
#value大小小于等于hll-sparse-max-bytes使用稀疏数据结构（sparse），大于hll-sparse-max-bytes使用稠密的数据结构（dense）。一个比16000大的value是几乎没用的，建议的value大概为3000。如果对CPU要求不高，对空间要求较高的，建议设置到10000左右。
hll-sparse-max-bytes 3000
 
#Redis将在每100毫秒时使用1毫秒的CPU时间来对redis的hash表进行重新hash，可以降低内存的使用。当你的使用场景中，有非常严格的实时性需要，不能够接受Redis时不时的对请求有2毫秒的延迟的话，把这项配置为no。如果没有这么严格的实时性要求，可以设置为yes，以便能够尽可能快的释放内存。
activerehashing yes
 
##对客户端输出缓冲进行限制可以强迫那些不从服务器读取数据的客户端断开连接，用来强制关闭传输缓慢的客户端。
#对于normal client，第一个0表示取消hard limit，第二个0和第三个0表示取消soft limit，normal client默认取消限制，因为如果没有寻问，他们是不会接收数据的。
client-output-buffer-limit normal 0 0 0
#对于slave client和MONITER client，如果client-output-buffer一旦超过256mb，又或者超过64mb持续60秒，那么服务器就会立即断开客户端连接。
client-output-buffer-limit slave 256mb 64mb 60
#对于pubsub client，如果client-output-buffer一旦超过32mb，又或者超过8mb持续60秒，那么服务器就会立即断开客户端连接。
client-output-buffer-limit pubsub 32mb 8mb 60
 
#redis执行任务的频率为1s除以hz。
hz 10
 
#在aof重写的时候，如果打开了aof-rewrite-incremental-fsync开关，系统会每32MB执行一次fsync。这对于把文件写入磁盘是有帮助的，可以避免过大的延迟峰值。
aof-rewrite-incremental-fsync yes
```

# Redis的持久化

## RDB

```java
//一、概念了解：
RDB:它会在指定时间间隔内，将内存数据快照到临时文件中。
具体说就是单独fork一个子进程来进行持久化，将数据写入dump.rdb，等持久化过程都结束了，再用这个临时文件再替换已经上次持久化好的文件。

//二、三个要点：

(一)默认3种持久化规则：1分钟内10000个key值改变，5分钟内10个key值改变，15分钟内1个key值改变。

(二)Fork:复制一个与当前进程一样的进程，进程中所有数据和原进程一致，作为原进程的子进程。

(三)考虑点：Fork时，内存中的数据被克隆了一份，大致2倍的膨胀性需要考虑。

(四) 缺点：如果redis意外挂了，会导致可能有几分钟的数据丢失。

//三、操作问题：
1.要备份的和要恢复的机器最好是两台。
2.save和bgsave：
	save:只管保存，其他不管，全部阻塞
	BGSAVE:Redis会在后台异步进行快照操作，快照同时还可以相应客户端请求，可以通过lastsave命令获取最后一次成功执行快照的时间。
3.执行flushall命令,	也会产生dump.rdb文件，但里面是空的无意义。
4.如何恢复：将备份文件dump.rdb移动到redis安装目录并启动服务即可。CONFIG GET dir获取目录。
5.如果一个值特别重要，需要马上保存，set以后,可以直接使用 save指令。
```

```java
################################ SNAPSHOTTING  ################################
//生成 dump.rdb  快照的规则（重点）
#   save ""    //如果要禁用RDB持久化策略，不要设置任何save指令或者 save传入空字符串也可以
save 900 1	   //15分钟以内redis里面只要有一个key被改动过了我就给你存，自定存成一个dump.rdb
save 300 10    //5分钟以内key被改过十次
save 60 10000   //1分钟以内有一万次变更

//如果你后save保存命令的时候出错了，前台需要停止stop写
stop-writes-on-bgsave-error yes  

/*对于存储到磁盘中的快照，可以设置是否进行压缩存储，如果是的话，redis会采用LZF算法进行压缩。
如果你不想消耗CPU来进行压缩的话，可以设置为关闭此功能*/
rdbcompression yes

/*在存储快照后，还可以让redis使用CRC64算法进行数据校验，但是这样做会增加大约10%的性能消耗，
如果希望获取到最大的性能提升，可以关闭此功能*/
rdbchecksum yes

//redis.conf文件下面我不管你有多少rdb我只认我自己这个rdb
dbfilename dump.rdb

//目录config.dir
dir ./
```

## AOF

```java
//一、概念了解
ROF:它就是以日志(appendonly.aof)的形式来记录每个操作。而且在aof文件体积变大时，会自动对AOF进行重写。

(一)aof和rdb两个都开启的话，会先加载appendonly.aof。
(二)缺点：对于相同的数据集来说，AOF文件的体积通常要大于RDB文件的体积，AOF的速度会慢于RDB。
(三)优点：数据完整性高。
(四)如果appendonly.aof文件有误，纠正方式：  redis-check-aof --fix appendonly.aof
```

```java
############################## APPEND ONLY MODE ###############################
//默认是no,yes就打开aof持久化
appendonly no

//默认文件名字
appendfilename "appendonly.aof"
   
# appendfsync always //同步持久化，每次发生数据变更会被立即记录到磁盘，性能较差，但数据完整性较好。
appendfsync everysec  //出厂默认推荐，异步操作，每秒记录，如果一秒内宕机，有数据丢失
# appendfsync no  //不同步

/*AOF采用文件追加方式，文件会越来越大为避免出现此种情况，新增了重写机制，
  当AOF文件的大小超过所设定的阀值，Redis就会启动AOF文件的内容压缩，只
  保留可以恢复数据的最小指令集，可以使用命令bgrewriteaof
  
  AOF文件持续增长而过大时，会fork出一条新进程来将文件重写（也是先写临时文件最后再rename）
  重写aof文件的操作，并没有读取旧的aof文件。而是将整个内存中的数据库内容用命令的方式重写
  了一个新的aof文件，这点和快照有点类似
  
  触发机制：Redis会记录上次重写时的AOF大小，默认配置是当AOF文件大小是上次rewrite后大小的
  一倍且文件大于64M时触发
  */
no-appendfsync-on-rewrite no     //重写时是否可以运行Appendfsync,用默认no即可，保证数据安全性
auto-aof-rewrite-percentage 100  //设置重写的基准值，表示一倍
auto-aof-rewrite-min-size 64mb   //设置重写的基准值，实际生产上3G是起步价


aof-load-truncated yes
```

## 两者总结

```
(一)只做缓存： 
如果你只希望你的数据在服务器运行的时候存在，可以不适用任何持久化方式。
   
(二)官网建议是同时开启两种持久化方式：
1.redis重启的时候会优先载入AOF恢复数据，因为AOF文件保存的数据集要比RDB文件保存的数据集要完整。
2.RDB更适合用于（备份数据库AOF在不断变化不好备份），而且不会有AOF可能潜在的bug,留着作为一个万一的手段。
   
(三)性能建议：
1.RDB只做后备用途，建议备份规则留save900这条。
2.只要硬盘许可，应该减少rewrite到新文件的频率，AOF重写的基础大小默认值64M太小了，可以设置到5G以上。
4.如果不使用AOF也可以，能省掉一大笔IO,代价是会丢掉十几分钟的数据，新浪微博就选用这种架构。
```

# 事务

```
1.redis事务相当于一组命令的集合，multi开启事务后，会把命令先入队到事务队列里面，等exec命令触发事务后一次性执行。

2.redis部分支持事务，才并不完全保证原子性，可能第一条命令执行失败了，其后的命令仍然会被执行，没有回滚。
(如k1=v1 在incr k1 时事务队列不会显示错误，那么执行事务后，incr k1这条失败，其他的会正常。"冤头债主"
 如果入队时就报错，那么所有命令都失败。---"全体连坐")

3.单独的隔离操作：事务中的所有命令都按顺序的执行。事务在等待执行的时候，不会被其他客户端发送来的米命令请求打断。
```

```java
//开启事务
multi  
//执行事务内的命令
exec   
//取消事务，放弃执行事务块内的所有命令
discard 
    
//监视命令：类似乐观锁，事务提交时，如果key的值已被别的客户端改变，整个事务队列都不会被执行。   
watch key [key] 监视一个(或多个) key 

//取消watch命令对所有 key 的监视（注意：执行了exec之前加的监控锁都会被取消了）
unwatch 
```

# 发布订阅

```java
Redis 发布订阅(pub/sub)是一种消息通信模式：发送者(pub)发送消息，订阅者(sub)接收消息。

//订阅一个或多个频道的信息  channel可以使用通配父如:new*
subscribe channel [channel…]

//将信息发送到指定频道
publish channel message

//订阅一个或多个符合规定模式的频道
psubscribe pattern [pattern…]

//退订频道
unsubscribe [channel[channel…]]

//退订所有给定模式的频道
punsubscribe [pattern[pattern…]]
```

# 主从复制

```java
//概念
主机数据更新后根据配置和策略，自动同步到备机上(Master以写为主，Slave以读为主)。
可以做到读写分离,容灾恢复。
```

```java
//常用模式：1、一主二从。2、薪火相传。3、反客为主。4、哨兵模式。

一、一主二从（一个master两个slave）

//(一)复制3个redis.conf模拟多台机器，如(redis6379.conf、redis6380.conf、redis6381.conf)。
具体配置修改：
1、daemonize no 修改为： daemonize yes

2、pidfile /var/run/redis.pid   修改为：  pidfile /var/run/redis自定义端口号.pid

3、port 6379   修改为：    port 自定义端口号

4、logfile ""  修改为：    logfile "自定义端口号.log"

5、dbfilename dump.rdb  修改为：  dbfilename dump端口号.rdb  

//(二)三个窗口各自启动，如：
1. redis-server /xxx/redis6379.conf     redis-cli -p 6379
2. redis-server /xxx/redis6380.conf     redis-cli -p 6380
3. redis-server /xxx/redis6381.conf     redis-cli -p 6381

//(三)查看redis主从复制的情况:
info replication

//(四)配置从库，如我是6380和6381进程：
slaveof 主库IP 主库端口  //如： slaveof 127.0.0.1 6379


//注意问题：
1.从库一配置就能拿到主库所有数据。
2.从库是不能写操作的
3.主机死了，从机从库会原地待命
4.如果从机挂了，就必须从新slaveof一次，除非你配置进redisc.conf

二、薪火相传
//概念：6381是6380的从机，6380是6379的从机。
(一)我是6380： slaveof 127.0.0.1 6379
(二)我是6381： slaveof 127.0.0.1 6380
    
三、反客为主  
//概念：主机挂了，从机转成主机
从机转主机： slaveof no one 

四、哨兵模式（sentinel）
//概念：反客为主的自动版。能够后台监控Master库是否故障，如果故障了根据投票数自动将slave库转换为主库。一组sentinel能同时监控多个Master。
(一)在redis.conf同目录下新建sentinel.conf文件（名字绝对不能错）；

(二)配置哨兵。在sentinel.conf文件中填入内容(可以配置多个)：
//说明：最后一个数字1，表示主机挂掉后slave投票看让谁接替成为主机，得票数多少后成为主机。
sentinel monitor 被监控数据库名字（自己起名字如：host6379） ip port 1

(三)启动哨兵模式(路径按照自己的需求进行配置)：  
redis-sentinel  /myredis/sentinel.conf

```

# 集群*

```
Redis集群实现了对Redis的水平扩容，即启动N个redis节点，将整个数据库分布存储在这N个节点中，每个节点存储总数据的1/N

Redis集群通过分区（partition）来提供一定程度的可用性（availability）：即使集群中有一部分节点失效或者无法进行通讯，集群也可以继续处理命令请求。
```

```java
//redis cluster如何分配这六个节点
1.一个集群至少要有三个主节点
2.选项 --replicas 1 表示我们希望为集群中的每个主节点创建一个从节点(即要有6个节点)。
3.分配原则尽量保证每个主数据库运行在不同的IP地址，每个从库和主库不在一个IP地址上。

4.当主节点崩了，从节点能自动升为主节点；当主节点再次恢复时，主节点变为slave。

//关于槽(slots)
一个Redis 集群包含16384个插槽，数据库中的每个键都属于这16384个插槽的其中一个，集群使用公式计算键key属于哪个槽。

集群中的每个节点负责处理一部分插槽。 
    如：节点A负责处理0号至5500号插槽 
    如：节点B负责处理5501号至11000号插槽
    如：节点C负责处理11001号至16383号插槽
    
不在一个slot下的键值，是不能使用mget，mset等多键操作
可以通过{}来定义`组的概念`，从而使key中{}内相同内容的键值对放到一个slot中去。

```

**配置集群**

```java
//安装ruby环境:
yum install ruby
yum install rubygems
```

```java
//集群多个配置
include /opt/myRedis/redis.conf
pidfile "/var/run/redis6379.pid"
port 6379
dbfilename "dump6379.rdb"
cluster-enabled yes   //打开集群模式
cluster-config-file nodes-6379.conf  //设置节点配置文件名
cluster-node-timeout 15000  //设置节点失联时间，超过该时间(毫秒)，集群自动进行主从切换
    
//合体
//组合之前请确保所有redis实例启动后，nodes-xxx.conf文件都生成正常

//1.进入src目录
cd /opt/redis-3.2.5/src

//2.执行命令
./redis-trib.rb create --replicas 1
192.168.231.129:6379   192.168.231.129:6380
192.168.231.129:6381   192.168.231.129:6389
192.168.231.129:6390   192.168.231.129:6391    

//3.客户端提供-c参数实现自动重定向
//不在一个slot下的键值，是不能使用mget，mset等多键操作   
redis-cli -c -p 端口号   
```

**相关语法**

```java
//打印集群信息
cluster info 

//列出集群当前已知的所有节点（node），以及这些节点的相关信息。  
cluster nodes

//让某集群下线    
redis-cli -p 6381  shutdown   

//---节点
//将 ip 和 port 所指定的节点添加到集群当中，让它成为集群的一份子。 
cluster meet <ip> <port>

//从集群中移除 node_id 指定的节点
cluster forget <node_id> 

//将当前节点设置为 node_id 指定的节点的从节点。
cluster replicate <node_id> 

//将节点的配置文件保存到硬盘里面。  
cluster saveconfig


//---槽(slot)
//将一个或多个槽指派给当前节点
cluster addslots <slot> [slot ...] 

//移除一个或多个槽对当前节点的指派。 
cluster delslots <slot> [slot ...]  

//移除指派给当前节点的所有槽，让当前节点变成一个没有指派任何槽的节点。
cluster flushslots

//将槽 slot 指派给 node_id 指定的节点，如果槽已经指派给另一个节点，那么先让另一个节点删除该槽，然后再进行指派。 
cluster setslot <slot> node <node_id>

//将本节点的槽 slot 迁移到 node_id 指定的节点中。 
cluster setslot <slot> migrating <node_id>  

//从 node_id 指定的节点中导入槽 slot 到本节点。 
cluster setslot <slot> importing <node_id>  

//取消对槽 slot 的导入（import）或者迁移（migrate）
cluster setslot <slot> stable


//---键 (key) 
//计算键 key 应该被放置在哪个槽上。 
cluster keyslot <key> 
//返回槽 slot 目前包含的键值对数量。 
cluster countkeysinslot <slot> 
//返回 count 个 slot 槽中的键。
cluster getkeysinslot <slot> <count> 
        
```

# 整合

## Jedis

jedis-2.8.1jar
commons-pool2-2.4.2.jar

**事务**

```java
import redis.clients.jedis.Jedis;
import redis.clients.jedis.Transaction;

public class TestTX {
    
	public boolean transMethod() throws InterruptedException {
	     Jedis jedis = new Jedis("127.0.0.1", 6379);
	     int balance;// 可用余额
	     int debt;// 欠额
	     int amtToSubtract = 10;// 实刷额度

	     jedis.watch("balance");
	     //jedis.set("balance","5");//此句不该出现，模拟其他程序已经修改了该条目
	     Thread.sleep(7000);
	     balance = Integer.parseInt(jedis.get("balance"));
	     if (balance < amtToSubtract) {
	       jedis.unwatch();
	       System.out.println("modify");
	       return false;
	     } else {
	       System.out.println("***********transaction");
	       Transaction transaction = jedis.multi();
	       transaction.decrBy("balance", amtToSubtract);
	       transaction.incrBy("debt", amtToSubtract);
	       transaction.exec();
	       balance = Integer.parseInt(jedis.get("balance"));
	       debt = Integer.parseInt(jedis.get("debt"));

	       System.out.println("*******" + balance);
	       System.out.println("*******" + debt);
	       return true;
	     }
	  }

	  /**
	   * 通俗点讲，watch命令就是标记一个键，如果标记了一个键， 
	   * 在提交事务前如果该键被别人修改过，那事务就会失败，这种情况通常可以在程序中
	   * 重新再尝试一次。
	   */
	  public static void main(String[] args) throws InterruptedException {
	     TestTX test = new TestTX();
	     boolean retValue = test.transMethod();
	     System.out.println("main retValue-------: " + retValue);
	  }	
}
```

**测试主从复制**

```java
import redis.clients.jedis.Jedis;

public class TestMS {
	public static void main(String[] args) {
		Jedis jedis_M = new Jedis("127.0.0.1",6379);
		Jedis jedis_S = new Jedis("127.0.0.1",6380);
		
		jedis_S.slaveof("127.0.0.1",6379);
		
		jedis_M.set("class","1122V2");
		
		String result = jedis_S.get("class");
		System.out.println(result);
	}
}
```

**连接池**

![](images/QQ截图20200621114621.png)

```java
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

public class JedisPoolUtil {
	private static volatile JedisPool jedisPool = null;
	
	private JedisPoolUtil(){}
	
    //从连接池获取连接
	public static JedisPool getJedisPoolInstance(){
		if(null == jedisPool){
			synchronized (JedisPoolUtil.class){
				
				if(null == jedisPool){
					JedisPoolConfig poolConfig = new JedisPoolConfig();
					poolConfig.setMaxActive(1000);
					poolConfig.setMaxIdle(32);
					poolConfig.setMaxWait(100*1000);
					poolConfig.setTestOnBorrow(true);

					jedisPool = new JedisPool(poolConfig,"127.0.0.1",6379);
				}
			}
		}
		return jedisPool;
	}
	
    //返回连接池
	public static void release(JedisPool jedisPool,Jedis jedis){
		if(null != jedis){
			jedisPool.returnResourceObject(jedis);
		}
	}
	
}


//==============================测试=======================================
public static void main(String[] args) {
    JedisPool jedisPool = JedisPoolUtil.getJedisPoolInstance();
    Jedis jedis = null;
    try {
        jedis = jedisPool.getResource();
        jedis.set("aa","bb");
    } catch (Exception e) {
        e.printStackTrace();
    }finally{
        JedisPoolUtil.release(jedisPool, jedis);
    }
}
```

**集群测试**

```java
set<HostAndPort> nodes = new HashSet<>();
nodes.add(new HostAndPort("192.168.242.132",6379));
JedisCluster cluster = new JedisCluster(nodes);

cluster.set("keyName","value");
cluster.get("keyName");

cluster.close();
```

## SpringBoot整合Redis

```xml
<!--导入相关依赖-->
<dependency>
	<groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-redis</artifactId>
</dependency>
```

```yaml
#redis虚拟机的主机地址
#springBoot引入了redis就不会匹配原来的默认缓存,不会将使用ConCurrntMap来进行缓存，而是将数据缓存到Redis中。
spring:
	redis:
		host = 192.168.5.100
```

```java
第一种方式：

//1.操作k-v字符串的
@Autowired
StringRedisTemplate stringRedisTemplate;  

//Redis五大数据类型(了解)
stringRedisTemplate.opsForValue() //String
stringRedisTemplate.opsForList()  //List
stringRedisTemplate.opsForHash()  //散列
stringRedisTemplate.opsForSet()  //set
stringRedisTemplate.opsForZSet()  //ZSet

//2.使用
stringRedisTemplate.opsForValue.append("msg","hello");


第二种方式：

//1.保存对象的
@Autowired
RedisTemplate redisTemplate;  

//2.使用。序列化后的数据保存到redis中(一般不会使用默认保存方式)    
redisTemplate.opsForValue().set("emp01",emp);  //emp是个对象，需要实现序列化  

第三种方式：

(一)将自己对象转为json
	//......
(二)重写序列化器:
//第一
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;

import java.net.UnknownHostException;

@Configuration
public class MyRedisConfig {

    @Bean
    public RedisTemplate<Object, Object> thisRedisTemplate
        (RedisConnectionFactory redisConnectionFactory) throws UnknownHostException {
       
        RedisTemplate<Object, Object> template = new RedisTemplate<Object, Object>();
        template.setConnectionFactory(redisConnectionFactory);

        Jackson2JsonRedisSerializer<Object> ser = 
            new Jackson2JsonRedisSerializer<Object>(Object.class);
        template.setDefaultSerializer(ser);
        return template;
    }
}

//第二
@Autowired
private RedisTemplate<Object,Object> thisRedisTemplate;

//第三(会存入json)
thisRedisTemplate.opsForValue().set("emp01",emp);
```

# Redis分布式锁

![](images/QQ截图20201210180017.png)

```java
//传统的synchronized只能保证单体应用，并发安全，但是在集群分布式的环境下，则无法保证并发的一致性。

1.通过setNX()方法加锁，delete()方法释放锁。
2.系统宕机了或逻辑报错导致锁没释放掉，一般会通过expire给它指定个失效时间。
3.a线程的redis锁失效了，逻辑还没处理完，b线程进来加锁，这时候可能导致a线程把b线程的锁给释放了。删除时要判断下是不是自己的锁。
4.保证redis释放锁的原子性，可以使用redis事务监控和lua脚本。

5.redis以外宕机了怎么办？直接使用Redisson
```

![](images/QQ截图20201210182101.png)