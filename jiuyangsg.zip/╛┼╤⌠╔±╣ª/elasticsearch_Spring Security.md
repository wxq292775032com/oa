## 检索 

![](images/QQ截图20200517204936.png)

![](images/QQ截图20200517222823.png)

![](images/QQ截图20200517222920.png)

![](images/QQ截图20201129235716.png)



```
Postman账号密码： wxqPostman  wxq7408695
```

![](images/QQ截图20200517225540.png)

![](images/QQ截图20200517225810.png)

```
如果变为delete则是删除
```

## 整合Elasticsearch

```java
//1.引入相关jar包
  implementation 'org.springframework.boot:spring-boot-starter-data-elasticsearch'
//2. SpringBoot默认支持两种技术来和ES交互：
    1.Jest(默认不生效)
      	需要导入jest的工具包 
        compile group: 'io.searchbox', name: 'jest', version: '5.3.3'
    2.SpringData ElasticSearch
    	1)、Client 节点信息clusterNodes;clusterName
    	2)、ElasticsearchTemplate 操作es
    	3)、编写一个ElasticsearchRepository的子接口来操作
```

```java
// Jest 方式：
	//1.配置虚拟机IP和端口号
	spring.elasticsearch.jest.uris=http://192.168.5.110:9200

    //2.创建相关实体类
    import io.searchbox.annotations.JestId;

    public class Aticle {
        @JestId
        private Integer id;
        private String title;
        private String author;
        private String content;
        //...
    }

    //3.保存文档和构建搜索
    @Autowired
    JestClient jestClient ;
	
    //3.1
    @Test
    public void contextLoads(){
        //1.给 ES 中索引 （保存） 一个文档
        Aticle aticle = new Aticle();
        aticle.setId(2);
        aticle.setTitle("好消息");
        aticle.setAuthor("zhangsan");
        aticle.setAuthor("Hello world");

        //构建一个索引功能
        Index index = new Index.Builder(aticle).index("atguigu").type("news").build();
        try {
            jestClient.execute(index);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

     //3.2测试搜索
    @Test
    public void serach(){
        String json = "  {\n" +
                "            \"query\" : {\n" +
                "                \"match\" : {\n" +
                "                    \"author\" : \"Hello\"\n" +
                "                }\n" +
                "          }\n" +
                "\n" +
                "        }";

    //构建搜索功能
     Search search = new Search.Builder(json).addIndex("atguigu")
            .addType("news").build();
     //执行
        try {
            SearchResult result = jestClient.execute(search);
            System.out.println(result.getJsonString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
```

```java
//SpringData ElasticSearch 方式： 注意未能测试成功
	//1.配置虚拟机IP和端口号
	spring.data.elasticsearch.cluster-name=elasticsearch   
    spring.data.elasticsearch.cluster-nodes=192.168.5.110:9300
    
    //2.创建相关实体类
     import org.springframework.data.elasticsearch.annotations.Document;
	 
	 @Document(indexName = "atguigu",type = "book")
	 public class Book {
 	    private Integer id;
    	private String bookName;
    	private String author;  
        //...
     }    
        
    //3.创建相关集成接口 Book为实体类
    import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
	public interface BookRepository extends ElasticsearchRepository<Book,Integer> {
	}

    //4.使用
    @Autowired
    BookRepository bookRepository;

    @Test
    public void test01(){
        Book book = new Book();
        book.setId(1);
        book.setAuthor("吴承恩");
        book.setBookName("西游记");
        bookRepository.index(book);
    }

```

![](images/QQ截图20201129235935.png)

## Spring Security

### 介绍

![](images/QQ截图20201130000042.png)

### 具体操作

```java
// 1.引入SpringSecurity依赖
	    implementation 'org.springframework.boot:spring-boot-starter-security'
//为了方便测试同时引用 thymeleaf 模板引擎
     implementation 'org.springframework.boot:spring-boot-starter-thymeleaf'
//由于 thymeleaf 模板版本有问题，需要修改版本
ext['thymeleaf.version'] = '3.0.11.RELEASE'
ext['thymeleaf-layout-dialect.version'] = '2.3.0'
ext['environment'] = System.getProperty("env", "dev")// 运行和打包的环境选择, 默认是开发环境 ,获取 gradle 参数中 -Dprofile 的值: gradle -Denv=production clean build
         
```

```java
// 2.编写引入SpringSecurity的配置类	

import  org.springframework.security.config.annotation.
    authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.
    web.builders.HttpSecurity;
import org.springframework.security.config.annotation.
    web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.
    web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@EnableWebSecurity
public class MySecurityConfig extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
       // super.configure(http);
        //定制请求的授权规则           "/"代表访问首页的请求. permitAll 代表所有人都可以
        http.authorizeRequests().antMatchers("/").permitAll()
                // level1下的所有角色的所有请求，都必须是VIP1
                .antMatchers("/level1/**").hasRole("VIP1")
                // level2下的所有角色的所有请求，都必须是VIP2
                .antMatchers("/level2/**").hasRole("VIP2")
                // level2下的所有角色的所有请求，都必须是VIP2
                .antMatchers("/level3/**").hasRole("VIP3");

        //开启自动配置的登录功能
         //1. /login来到登录页
        //2. 重定向到/login？error表示登录失败
        //3. 更多详细规定
          //4. 默认post形式的/login代表处理登录
        //5. 一但定制loginpage;那么 loginPage的post请求就是登录
        //http.formLogin();  // 默认路径/login
          http.formLogin().usernameParameter("user")
           .passwordParameter("pwd")
           .loginPage("/userlogin");  //转到自己的登录页
       
        //开启自动配置的注销
      //访问 /logout 表示用户注销，注销后就会返回 /Login?logout页面（默认生成的登录页）
      //  http.logout();  
          http.logout().logoutSuccessUrl("/");  //注销成功以后来到自定义首页
        
       
        //开启记住我的功能
        //登录成功以后，将cookie发送给浏览器保存，以后访问页面带上这个cookie，
        //如果注销则换删除cookie 
       // http.rememberMe();
       http.rememberMe().rememberMeParameter("remember");//remember自定义页面时定义的参数名
    }

    //定义认证规则
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        //super.configure(auth);
        auth.inMemoryAuthentication().
            passwordEncoder(new BCryptPasswordEncoder())
            .withUser("zhangsan").password(
            new BCryptPasswordEncoder().encode("123456")).roles("VIP1","VIP2")
                .and()
                .withUser("lisi").password(
            new BCryptPasswordEncoder().encode("123456")).roles("VIP2","VIP3");
    }
}
```

![](images/QQ截图20201130000123.png)



```java
//1.当用户没有登录，页面内容显示为游客欢迎的信息，如果登录了再来显示用户信息

//2.只显示当前用户有权限的页面

//注意：未获得实现成功 讲解在 100集

// 3.控制强求的访问权限   
```

