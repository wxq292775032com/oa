## Quertz

### 概念了解

```java
Quartz的三个核心概念：调度器(Scheduler)、任务(Job)、触发器(Trigger)
1.Job任务类，具体做事情的
2.Trigger触发器，设置规则，规定什么时间执行，执行多少次。(时间触发器，日历触发器)
3.Scheduler调度器，它相当于把job和触发器整合起来，根据触发器设定的时间执行Job
 
Quartz监听器：任务监听（全局/局部）、触发器监听（全局/局部）、调度器监听
```

### **pom.xml**

```xml
<!--核心包-->
<dependency>
    <groupId>org.quartz-scheduler</groupId>
    <artifactId>quartz</artifactId>
    <version>2.3.2</version>
</dependency>
<!--工具包-->
<dependency>
    <groupId>org.quartz-scheduler</groupId>
    <artifactId>quartz-jobs</artifactId>
    <version>2.3.0</version>
</dependency>
```

### **任务类**

```java
import org.quartz.*;

@PersistJobDataAfterExecution //obDataMap不重新创建，可以保存一些数据的信息，如count。
public class HelloJob implements Job {
    //任务逻辑在此编写
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        System.out.println("Job任务开始工作......");
      
        //(一)获取JobDetail的内容
        JobDetail jobDetail = context.getJobDetail();
        
        jobDetail.getKey().getName(); //工作任务名称
        jobDetail.getKey().getGroup(); //工作任务的组
      
        jobDetail.getJobClass().getName();//任务类的名称(带路径的名称)
        jobDetail.getJobClass().getSimpleName();//任务类的名称
      
        JobDataMap jobDataMap = jobDetail.getJobDataMap();//实现了Map接口
        String message1 = jobDataMap.getString("message1");//任务数据传递的参数值
        int count = jobDataMap.getString("count");
        
        //(二)获取Trigger的内容
        Trigger trigger = context.getTrigger();
        
        trigger.getKey().getName(); //触发器的名称
        trigger.getKey().getGroup();//触发器的组
        
        trigger.getJobKey().getName(); //jobKey的名称
        trigger.getJobKey().getGroup();//jobKey的组名称
        
        trigger.getStartTime();//任务开始时间
        trigger.getEndTime(); //任务结束时间
        
        JobDataMap triggerDataMap = trigger.getJobDataMap();
        String message2 = triggerDataMap.getString("message2");//触发器传递的参数值
        
        //(三)其它内容
        context.getFireTime()； //当前任务的执行时间
        context.getNextFireTime(); //下次任务的执行时间
        
        jobDataMap.put("count",++count);//类上面的注解配合，可以保存数据
    }
}

//(1)每次调度器执行Job，会创建一个新的Job实例，execute方法执行完成后销毁回收。
//(2)JobDetail用来存储特定Job实例的状态信息，调度器需要借助JobDetail对象来添加Job实例。
//(3)Job能通过JobExecutionContext对象访问到Quartz运行时候的环境以及Job本身的明细数据
```

### **核心调度**

```java
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;	

public static void main(String[] args) throws Exception {
    
    //1：调度器（Scheduler）,从工厂中获取调度的实例。
    Scheduler scheduled = StdSchedulerFactory.getDefaultScheduler();
   
    //2: 任务实例（JobDetail）,加载任务类，与HelloJob完成绑定。
    JobDetail jobDetail = JobBuilder.newJob(HelloJob.class)
        .withIdentity("job1","group1") //参数1:任务名,参数2：组名
        .usingJobData("message","参数由JobDataMap接受") //传递参数(可以直接放，JobDataMap)
        .build();
 
    //3: 触发器(Trigger)，（触发器方式很多，看下面）
    Trigger trigger = TriggerBuilder.newTrigger()
        .withIdentity("trigger1","group1")//参数1:触发器的名,参数2：触发器组名
        .startNow()//马上启动触发器
        .withSchedule(SimpleScheduleBuilder.simpleSchedule()//(时间触发器)重复执行间隔5秒
                      .withIntervalInSeconds(5).repeatForever())
        .build();
    
    //4：调度器关联任务和触发器
    scheduled.scheduleJob(jobDetail,trigger);
    
    [监听代码处]
    
    //启动
    scheduled.start();
    
  //scheduled.standby();//任务挂起(暂停)，如果重启重新start()
  //scheduled.shutdown();//加参数true则等待所有执行的Job执行完毕之后关闭，false则直接关闭。
    
}


//Trigger(有注解的表示和之前的有差异)
 Trigger trigger = TriggerBuilder.newTrigger()
        .withIdentity("trigger1","group1")
        .startAt(startDate) //设置任务的开始时间
        .endAt(endDate)  //设置任务的结束时间
        .withSchedule(SimpleScheduleBuilder.simpleSchedule()  
                      .withIntervalInSeconds(5).repeatForever())
        .build();


Trigger trigger = TriggerBuilder.newTrigger()
        .withIdentity("trigger1","group1")
        .startNow()
    	.withSchedule(SimpleScheduleBuilder.repeatSecondlyForever(5)
                       .withRepeatCount(3)) //5秒一次，执行4次(值从0开始)
        .build();


Trigger trigger = TriggerBuilder.newTrigger()
        .withIdentity("trigger1","group1")
        .startAt(startDate) 
        .endAt(endDate) 
    	.withSchedule(CronScheduleBuilder.cronSchedule("0/8 * * * * ?")) //日历触发器
        .build();
```

**core表达式，用于日历触发器**

![](../%E4%B9%9D%E9%98%B3%E7%A5%9E%E5%8A%9F/images/QQ%E6%88%AA%E5%9B%BE20201114203810.png)

![](../%E4%B9%9D%E9%98%B3%E7%A5%9E%E5%8A%9F/images/QQ%E6%88%AA%E5%9B%BE20201114210529.png)

![](../%E4%B9%9D%E9%98%B3%E7%A5%9E%E5%8A%9F/images/QQ%E6%88%AA%E5%9B%BE20201115110320.png)

### **监听器**

**监听代码**

```java
//1.创建一个全局的Job监听
scheduled.getListenerManager().addJobListener(
    new MyJobListener(), EverythingMatcher.allJobs());
//2.创建一个局部的Job监听。只监听任务名叫job1、组名叫group1的
scheduled.getListenerManager().addJobListener(
    new MyJobListener(), KeyMatcher.keyEquals(JobKey.jobKey("job1","group1")));

----------------------------------------------------------------------------------

//1.创建一个全局的触发器（Trigger）监听
scheduled.getListenerManager().addTriggerListener(
    new MyTriggerListener(), EverythingMatcher.allTriggers());

//2.创建个局部的触发器（Trigger）监听
        scheduled.getListenerManager().addTriggerListener(new MyTriggerListener(), KeyMatcher.keyEquals(TriggerKey.triggerKey("trigger1","group1")));
  
-----------------------------------------------------------------------------------

//1.创建调度器监听
scheduled.getListenerManager().addSchedulerListener(new MySchedulerListener());
//移除
scheduled.getListenerManager().removeSchedulerListener(new MySchedulerListener());
```

**监听实现类**

```java
import org.quartz.*;

//job任务监听类
public class MyJobListener implements JobListener {
   
    @Override
    public String getName() {
        return this.getClass().getSimpleName();//job名称
    }

    //调度器在任务将要被执行前调用该方法
    @Override
    public void jobToBeExecuted(JobExecutionContext context) {
        String name = context.getJobDetail().getKey().getName(); //job名称
        //......
    }

    //调度器在任务即将执行，但又被触发器监听否决时调用该方法
    @Override
    public void jobExecutionVetoed(JobExecutionContext context) {
        //......
    }

    //调度器在任务执行后调用该方法
    @Override
    public void jobWasExecuted(JobExecutionContext context, 
                               JobExecutionException jobException) {
    	//......
    }
}


//触发器监听类
public class MyTriggerListener implements TriggerListener {
   
    @Override
    public String getName() {
        return this.getClass().getSimpleName(); //触发器的名称
    }

    //被触发调用该方法
    @Override
    public void triggerFired(Trigger trigger, JobExecutionContext context) {
        String name = trigger.getKey().getName();
    }

    //触发器监听可以否决Job的执行，方法返回true,这个job任务将不会因为调度触发而得到执行。
    @Override
    public boolean vetoJobExecution(Trigger trigger, JobExecutionContext context) {
        return true; //表示不会执行Job的方法
    }

    //错过触发调用该方法
    @Override
    public void triggerMisfired(Trigger trigger) {
        //......
    }

    //触发器被触发并完成了Job任务的执行时，调用这个方法。
    @Override
    public void triggerComplete(Trigger trigger, JobExecutionContext context, 	                        Trigger.CompletedExecutionInstruction triggerInstructionCode) {
  		//......
    }
}


//调度器监听类
public class MySchedulerListener implements SchedulerListener {
	
    //用于部署任务实例（JobDetail）时调用
    @Override
    public void jobScheduled(Trigger trigger) {
        String name = trigger.getKey().getName();
        //......
    }

    //用于卸载任务实例（JobDetail）时调用
    @Override
    public void jobUnscheduled(TriggerKey triggerKey) {
        String name = triggerKey.getName();
     	//......
    }

    //当一个触发器不会触发的状态时，调用这个方法。除非这个Job设置成了持久性，否则会从Scheduler中移除
    @Override
    public void triggerFinalized(Trigger trigger) {
        //......
    }

    //调度器调用这方法，发生在一个Trigger或Trigger组被暂停时
    @Override
    public void triggerPaused(TriggerKey triggerKey) {
        //假如是Trigger组的话，triggerName参数为null
    }

    //触发器组正在暂停时
    @Override
    public void triggersPaused(String triggerGroup) {
        //......
    }

    //触发器从暂停中恢复时
    @Override
    public void triggerResumed(TriggerKey triggerKey) {
        //......
    }

    //触发器组 正在被恢复
    @Override
    public void triggersResumed(String triggerGroup) {
        //......
    }

    //添加功能任务时
    @Override
    public void jobAdded(JobDetail jobDetail) {
        //......
    }
	
    //删除工作任务
    @Override
    public void jobDeleted(JobKey jobKey) {
        //......
    }

    //暂停工作任务
    @Override
    public void jobPaused(JobKey jobKey) {
        //......
    }

    //工作组任务正在被暂停
    @Override
    public void jobsPaused(String jobGroup) {
        //......
    }

    //正在从暂停中恢复
    @Override
    public void jobResumed(JobKey jobKey) {
       //......
    }

    //工作组正在从暂停中恢复
    @Override
    public void jobsResumed(String jobGroup) {
       //......
    }

    //正常运行期间产生一个严重错误时调用这个方法
    @Override
    public void schedulerError(String msg, SchedulerException cause) {
        cause.getUnderlyingException();//异常信息
    }

     //当Scheduler处于挂起的模式，调用该方法
    @Override
    public void schedulerInStandbyMode() {
        //......
    }

    //当Scheduler开启的时候调用
    @Override
    public void schedulerStarted() {
       //......
    }

    //调度器正在开启的时候调用
    @Override
    public void schedulerStarting() {
       //......
    }

    //调度器关闭的时候调用
    @Override
    public void schedulerShutdown() {
        //......
    }

    //调度器正在关闭的时候调用
    @Override
    public void schedulerShuttingdown() {
        //......
    }

    //调度器的数据被清除的时候调用
    @Override
    public void schedulingDataCleared() {
         //......
    }
}
```

## Spring Boot整合

### **pom.xml**

```xml
<!--Quartz坐标-->
<dependency>
    <groupId>org.quartz-scheduler</groupId>
    <artifactId>quartz</artifactId>
    <version>2.3.2</version>
    <exclusions>
        <exclusion>
        	<artifactId>slf4j-api</artifactId>
            <groupId>org.slfj</groupId>
        </exclusion>
    </exclusions>
</dependency>

<!--添加Scheduled坐标,对于spring5不用加了-->
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-context-support</artifactId>
</dependency>

<!--Spring tx坐标-->
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-tx</artifactId>
</dependency>
```

### 编写Job任务类

```java
public class QuartzDemo implements Job {

    @Autowired
    private UserService userService;

    @Override
    public void execute(JobExecutionContext jobExecutionContext) 
        throws JobExecutionException {
        userService.addUsers();
     	//......
    }
}
```

### 编写配置类

```java
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.scheduling.quartz.SimpleTriggerFactoryBean;

/**
 * Quartz配置类
 */
@Configuration
public class QuartzConfig {

    /**
     * 1.创建Job对象
     */
    @Bean
    public JobDetailFactoryBean jobDetailFactoryBean(){
        JobDetailFactoryBean factory = new JobDetailFactoryBean();
        factory.setJobClass(QuartzDemo.class); //关联Job类
        return factory;
    }

    /**
     * 2.1 创建Triiger对象（时间触发器）
     */
    @Bean
    public SimpleTriggerFactoryBean simpleTriggerFactoryBean
        (JobDetailFactoryBean jobDetailFactoryBean){  
        SimpleTriggerFactoryBean factory = new SimpleTriggerFactoryBean();
         //关联JobDetail
        factory.setJobDetail(jobDetailFactoryBean.getObject());
        factory.setRepeatInterval(2000); //表示执行的一个毫秒
        factory.setRepeatCount(5); //重复次数
        return factory;
    }
  
    /**
     * 2.2 创建Triiger对象（日历触发器）
     */
    @Bean
    public CronTriggerFactoryBean cronTriggerFactoryBean
        (JobDetailFactoryBean jobDetailFactoryBean){
        CronTriggerFactoryBean factoryBean = new CronTriggerFactoryBean();
        //关联JobDetail
        factoryBean.setJobDetail(jobDetailFactoryBean.getObject()); 
        factoryBean.setCronExpression("0/2 * * * * ?"); //设置触发时间
        return factoryBean;
    }

    /**
     * 3.1创建Scheduler对象（关联时间触发器）
     */
    @Bean
    public SchedulerFactoryBean schedulerFactoryBean
        (SimpleTriggerFactoryBean simpleTriggerFactoryBean){
        SchedulerFactoryBean factoryBean = new SchedulerFactoryBean();
        //关联trigger
        factoryBean.setTriggers(simpleTriggerFactoryBean.getObject()); 
        return factoryBean;
    }
    
    /**
     * 3.2创建Scheduler对象（关联日历触发器）
     */
    @Bean
    public SchedulerFactoryBean schedulerFactoryBean
        (CronTriggerFactoryBean cronTriggerFactoryBean){
        SchedulerFactoryBean factoryBean = new SchedulerFactoryBean();
        //关联trigger
        factoryBean.setTriggers(cronTriggerFactoryBean.getObject()); 
        return factoryBean;
    }
}
```

### 启动类

```java
@SpringBootApplication
@EnableScheduling  //启动类添加该注解
public class HuajiV03Application {
	//......
}
```

### IOC容器注入问题

解决在Job任务类中的 UserService userService，无法完成自动装配的问题。

```java
import org.quartz.spi.TriggerFiredBundle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.scheduling.quartz.AdaptableJobFactory;
import org.springframework.stereotype.Component;

@Component("myAdaptableJobFactory")
public class MyAdaptableJobFactory extends AdaptableJobFactory {

    @Autowired
    private AutowireCapableBeanFactory autowireCapableBeanFactory;

    /**
     * 该方法需要将实例化的任务对象手动的添加到springIOC容器中，并且完成对象的注入
     */
    @Override
    protected Object createJobInstance(TriggerFiredBundle bundle) 
        throws Exception {
        Object obj = super.createJobInstance(bundle);
        //将obj对象添加springIOC容器中，并完成注入
        this.autowireCapableBeanFactory.autowireBean(obj);
        return obj;
    }
}
```



