# 基本介绍

```java
//docker官网
https://www.docker-cn.com/
//搜索镜像
https://hub.docker.com/ 

https://hub.docker.com/   账号密码：wxqdocker  wxq7408695   邮箱是qq邮箱
```

![](images/QQ截图20200623015308.png)

```java
//docker概念
Docker就是是一个容器运行载体。它把应用程序所需要的系统环境，由下而上打包，形成一个image镜像文件。通过这个镜像文件才能生成Docker容器。可以做到一次封装，到处运行。不用在新机子上又要从新配置哪些麻烦的环境。

//仓库
仓库是集中存放镜像文件的地方，需要时从仓储中拉下来就可以了。每个仓库又包含了多个镜像，每个镜像有不同的标签。

//镜像
镜像(image)就是一个只读的模板，它包含了运行某个软件所需的材料如：代码、环境变量和配置文件等。可以创建一个或多个Docker容器；就相当于Java类一样可以创建多个对象。

//容器
容器是用镜像创建的运行实例。每个容器都是相互隔离的。
```

```java
//Docker和传统虚拟化方式不同之处
	传统虚拟机技术是虚拟出一套硬件后，在其上运行一个完整操作系统，在该系统上再运行所需应用进程；
	而容器内的应用进程直接运行于宿主的内核，容器内没有自己的内核，因此容器要比传统虚拟机更轻便。而且每个容器之间互相隔离，每个容器有自己的文件系统，容器之间进程不会相互影响，能区分计算资源。
```

![](images/QQ截图20200623013844.png)

```java
//镜像原理
它其实是一种分层的联合文件系统，一次同时加载多个文件系统，但从外面看起来就是一个文件系统。
   主要有两个bootfs和rootfs,bootfs是用来加载kernel的，rootfs就是各种不同的操作系统发行版本，比如Ubuntu,Centos等。
   精简版的contOS只包括最基本的命令、工具和程序库，底层直接使用主机内核。
```

![](images/QQ截图20200705141559.png)

# docker安装

**前提条件**

```java
//CentOS Dcoker安装：
CentOS 7(64-bit)
CentOS 6.5(64-bit)或更高的版本

//前提条件
目前，CentOS仅发型版本中的内核支持Docker.
Docker运行在CentOS7上，要求系统64位，系统内核版本为3.1.0以上
Docker运行在CentOS-6.5或更高的版本的CentOS上，要求系统为64位，系统内核版本为2.6.32-431或者更高版本

uname -r  //查看内核
cat /etc/redhat-release  //
```

```java
//内核升级相关文章
https://blog.csdn.net/qq_34430649/article/details/103603294

//--
yum -y update nss

rpm --import https://www.elrepo.org/RPM-GPG-KEY-elrepo.org
rpm -Uvh http://www.elrepo.org/elrepo-release-6-8.el6.elrepo.noarch.rpm

yum --enablerepo=elrepo-kernel -y install kernel-lt

修改/etc/grub.conf文件，将default=1修改成default=0。

reboot
```

## centOS 6.8安装docker

```java
//docker需要的依赖库
yum install -y epel-release  

//安装docker，没有root权限可加 sudo 
yum install -y docker-io

//安装后的可以查看配置文件
/etc/sysconfig/docker

//启动docker后台目录
service docker start

//重启
service docker restart

//停止
service stop docker

//查看版本信息
docker version
```

```java
/*安装时出现以下错误，你使用该语句安装试试。
  No package docker-io available.
  错误：无须任何处理*/
yum install https://get.docker.com/rpm/1.7.1/centos-6/RPMS/x86_64/docker-engine-1.7.1-1.el6.x86_64.rpm

//错误：no such table: packages
yum clean all   //清理本地yum缓存
```

## centOS 7安装docker

```java
//yum安装gcc相关
yum -y install gcc
yum -y install gcc-c++
    
//卸载旧版本    
sudo yum remove docker \
                  docker-client \
                  docker-client-latest \
                  docker-common \
                  docker-latest \
                  docker-latest-logrotate \
                  docker-logrotate \
                  docker-engine
 
//安装所需要的包
yum install -y yum-utils device-mapper-persistent-data lvm2

//
yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo

//更新yum软件包索引
yum makecache fast

//安装Docker ce
yum -y install docker-ce

//启动docker
systemctl start docker 
```

```java
//卸载
systemctl stop docker
yum -y remove docker-ce
rem-rf /var/lib/docker
```

## 阿里云镜像加速

```java
//阿里云网站  wxq292775032 wxq7408695
https://dev.aliyun.com/search.html
//专属加速地址
https://if26f4c2.mirror.aliyuncs.com
//阿里云仓库
https://cr.console.aliyun.com/cn-hangzhou/instances/repositories
```

![](images/QQ截图20200623010736.png)

```java
//centOS 6配置
vim /etc/sysconfig/docker
other_args="--registry-mirror=https://if26f4c2.mirror.aliyuncs.com"
    
//centOS 7配置
1. vim /etc/docker/daemon.json
2.
    {
      "registry-mirrors": ["https://if26f4c2.mirror.aliyuncs.com"]
    }
3.sudo systemctl daemon-reload
4.sudo systemctl restart docker
```

## 测试

```
docker run hello-world
```

![](images/QQ截图20200623012154.png)

# 命令

## **帮助命令**

```java
docker version  //版本号
docker info  //信息描述
docker --help //帮助手册    
```

## **镜像命令**

```java
//列出本地主机上的镜像
docker images  
    -a:列出本地所有镜像(含中间映象层)
    -q:只显示镜像ID
    --digests:显示镜像的摘要信息
    --no-trunc:显示完整的镜像信息

//查询镜像
docker search 某个xxx镜像名字
	--no-trunc:显示完整的镜像描述  // docker search --no-trunc mysql
	-s:列出收藏数不小于指定值的镜像 //  docker search -s 2000 mysql
	--automated:只列出 automated build类型的镜像；

//下载镜像,不加后缀默认:latest
docker pull 某个xxx镜像名字

//删除镜像,不加后缀默认:latest
docker rmi 某个xxx镜像名字	//普通删除
docker rmi -f XXX //强制删除
docker rmi -f XXX XXX//删除多个
docker rmi -f ${docker images -qa} //批量删除
```

![](images/QQ截图20200706124500.png)

## 容器命令

```java
//启动容器
docker run [OPTIONS] IMAGE [COMMAND] [ARG...]
	--name="容器新名字"：为容器指定一个名称
	-d:后台运行容器，并返回容器ID，也即启动守护式容器；
	-i:以交互模式运行容器，通常与-t同时使用；
	-t:为容器重新分配一个伪输入终端，通常与-i同时使用；
	-P:随机端口映射;                //大p
	-p：指定端口映射，有以下四种格式。  //小p
		ip:hostPort:containerPort
		ip::containerPort
		hostPort:containerPort
		containerPort
	//例:
	//i和t可以一起用，表示会弹出一个输入命令行的终端(进入容器里面)
 	docker run -it  容器id 
    //docker容器后台运行，就必须有一个前台进程，否则会自动退出
    docker run -d 容器id
    //8888是对外暴露的端口号，小p对外暴露端口，大P随机端口
	docker run -it -p 8888:8080
        
//列出所有启动的容器
docker ps
	-l:上一次运行的容器
	-n 3:上三次运行的容器
	-a:当前正在运行的和过往的容器
	-lq:只显示容器编号
	
//退出容器
exit   //在命令终端上使用,容器停止退出
ctrl+P+Q  //容器不停止退出

//重新进容器
docker attach 容器id   //直接进入到根目录
docker exec -t 容器id ls -l /tmp  //直接在宿主机外面返回结果
docker exec -it 7b9d13f76080 /bin/bash   //修改tomcat例子

//启动容器
docker start 容器id

//重启容器
docker restart 容器id

//停止容器
docker stop 容器id //普通停止
docker kill 容器id //强制停止

//删除已停止的容器
docker rm 容器id	//删除单个
docker rm -f $(docker ps -a -q)  //删除多个      

//容器日志
docker logs -f -t --tail 容器id
	-t是加入时间戳
	-f跟随最新的日志打印
	--tail数字显示最后多少条
	
//查看容器内的进程
docker top 容器id

//查看容器内部细节
docker inspect 容器id

//从容器内拷贝文件到主机上
docker cp 容器id:/tmp/yum.log /root   //将容器里面的yum.log拷贝到 root路径下 
```

```java
//更多命令参看
https://docs.docker.com/engine/reference/commandline/docker/
```

## docker镜像commit

```java
//容器副本使之成为一个新的镜像
docker commit -m="提交的描述信息" -a="作者" 容器ID 要创建的目标镜像名:[标签名]     
```

# 容器数据卷

```
主要是做数据持久化工作的，容器之间共享数据的

特点：
1：数据卷可在容器之间共享或者重用数据
2：卷中的更改可以直接生效
3：数据卷中的更改不会包含在镜像的更新中
4：数据卷的生命期一直持续到没有容器使用它为止

主要功能：容器的持久化+容器间继承+共享数据
```

```java
一、添加数据卷
(一)普通方式：

//---加数据卷(此处目录会自动创建),两个目录数据共享
docker run -it -v /宿主机绝对路径目录:/容器内目录 镜像名

//容器的目录只读不可写(只允许主机单向的传给容器，容器只能看不能改)
docker run -it -v /宿主机绝对路径目录:/容器内目录:ro 镜像名  

(二)DockerFile 方式：

//1.mydocker目录内创建 Dockerfile
# volume test
FROM centos  #以改centos为模板构建一个新的镜像
VOLUME ["/dataVolumeContainer1","/dataVolumeContainer2"]
CMD echo "finished,----------success1"
CMD /bin/bash

//2.执行（centos11为自命名）
docker build -f /mydocker/Dockerfile -t centos11 .
```

![](images/QQ截图20200628143720.png)

```java
二、容器间传递和共享
//dco1。运行第一个容器(centos11自己做的镜像)
docker run -it --name dc01 centos11

//dco2。继承于dco1,以centos11为模板
docker run -it --name dco2 --volumes-from dco1 centos11    

//dco3。继承于dco1,以centos11为模板
docker run -it --name dco3 --volumes-from dco1 centos11   
 
结论：
(一)三个文件的(dataVolumeContainer1或2)都能达到共享的目的
(二)dco2和dco3都继承于dco1。dco1要是被删除了，并不影响2和3的文件。
(三)容器之间配置信息的传递，数据卷的生命周期一直持续到没有容器使用它为止。
```

# DockerFile解析

![](images/QQ截图20200629114712.png)

```
Dockerfile内容基础知识：
	1.每条保留字指令都必须为大写字母且后面要跟随至少一个参数
	2.指令按照从上到下，顺序执行
	3.#表示注释
	4.每条指令都会创建一个新的镜像层，并对镜像进行提交

Docker执行Dockerfile的大致流程：
	1.docker从基础镜像运行一个容器
	2.执行一条指令并对容器做出修改
	3.执行类似docker commit的操作提交一个新的镜像层
	4.docker再基于刚提交的镜像运行一个新容器
	5.执行docker中的下一条指令直到所有指令都执行完成
    
构建三步骤： 1.编写Dockerfile文件；2.docker build；3.docker run    
```

**DockerFile体系结构(保留字指令)**

```java
//基础镜像，当前新镜像是基于哪个镜像的
FROM   

//镜像维护者的姓名和邮箱地址
MAINTAINER 

//容器构建时需要运行的命令
RUN 

//暴露端口号
EXPOSE 

//终端默认登录进来工作目录
WORKDIR 

//用来构建镜像过程中设置环境变量
ENV 

//将宿主机目录下的文件拷贝进镜像且ADD命令会自动处理URL和解压tar压缩包
ADD 

//类似ADD拷贝文件和目录到镜像中
//将构建上下文目录中<源文件>的文件/目录问题复制到新的一层镜像内的<目标路径>位置
COPY 

//容器数据卷，用于数据保存和持久化工作
VOLUME 

//指定一个容器启动时要运行的命令(Dockerfile中可以有多个cmd指令，但只有最后一个生效)
//CMD会被docker run之后的参数替换
CMD 

//和CMD一样,指定一个容器启动时要运行的命令
//docker run之后的参数会进行追加
ENTRYPOINT 

//当构建一个被继承的Dockerfile时运行命令，父镜像在被子继承后父镜像的onbuild被触发
//ONBUILD RUN echo ".....hello"
ONBUILD 
```

**案例一**

```properties
#继承自本地镜像的centos
FROM centos
#作者信息
MAINTAINER wxq<xxx>

#用来构建环境过程中设置环境变量
ENV MYPATH /usr/local
WORKDIR $MYPATH  //引用

#安装vim
RUN yum -y install vim
#安装net-tools
RUN yum -y install net-tools

#暴露端口
EXPOSE 80

CMD echo $MYPATH
CMD echo "success---------ok"
CMD /bin/bash
```

```java
//docker build。mycentos:1.3自定义的名字
docker build -f /mydocker/Dockerfile2 -t mycentos:1.3 .

//列出镜像的变更历史
docker history  容器Id    
```

**案例二**

```properties
FROM  centos
MAINTAINER  wxq<qq.com>

#把宿主机当前上下文的c.txt拷贝到容器/usr/local路径下
COPY c.txt  /usr/local/cincontainer.txt

#把java与tomcat添加到容器中
ADD jdk-8u171-linux-x64.tar.gz  /usr/local/
ADD apache-tomcat-9.0.8.tar.gz  /usr/local/

#安装vim编辑器
RUN yum -y install vim

#设置工作访问时候的WORKDIR路径，登录落脚点
ENV MYPATH  /usr/local
WORKDIR $MYPATH

#配置java与tomcat环境变量
ENV JAVA_HOME /usr/local/jdk1.8.0_171
ENV CLASSPATH $JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
ENV CATALINA_HOME /usr/local/apache-tomcat-9.0.8
ENV CATALINA_BASE /usr/local/apache-tomcat-9.0.8
ENV PATH $PATH:$JAVA_HOME/bin:$CATALINA_HOME/lib:$CATALINA_HOME/bin

#容器运行时监控的端口
EXPOSE 8080

#启动时运行tomcat
# ENTRYPOINT ["/usr/local/apache-tomcat-9.0.8/bin/startup.sh"]
# CMD ["/usr/local/apache-tomcat-9.0.8/bin/catalina.sh","run"]
# CMD ["curl","-s","http://ip.cn"]
CMD /usr/local/apache-tomcat-9.0.8/bin/startup.sh && 
tail -F /usr/local/apache-tomcat-9.0.8/bin/logs/catalina.out

```

```java
//docker build。不需要-f是因为刚好在和Dockerfile在同一个目录，不需要名字是因为系统会自动寻找名字为Dockerfile的文件，如果名字叫Dockerfile2则需要-f指定。-t后面的名字是自定义的
docker build -t zzyytomcat9 .

//-v：添加容器卷；privileged=true：写权限不够设为true；zzyytomcat9自定义的镜像名
docker run -d -p 9080:8080 --name myt9
-v /zzyyuse/mydockerfile/tomcat9/test:/usr/local/apache-tomcat-9.0.8/webapps/test
-v /zzyyuse/mydockerfile/tomcat9/logs/:/usr/local/apache-tomcat-9.0.8/logs
--privileged=true
zzyytomcat9
```

![](images/QQ截图20200629114559.png)

# 本地镜像推送的阿里云

![](images/QQ截图20200702101019.png)

```java
//概念
仓库存东西、取东西的，存取需要身份认证。

//仓库地址   wxq292775032 wxq7408695
https://cr.console.aliyun.com/cn-hangzhou/instances/repositories  
```

```java
 //1.登入仓库
 sudo docker login --username=wxq292775032 registry.cn-hangzhou.aliyuncs.com
 //2.选择镜像。  [ImageId]:镜像ID； test:[镜像版本号]：自定义名字：id
 sudo docker tag [ImageId] registry.cn-hangzhou.aliyuncs.com/wxqwxq/test:[镜像版本号]
 //3.提交。 test:[镜像版本号]：与上面保持一致
 sudo docker push registry.cn-hangzhou.aliyuncs.com/wxqwxq/test:[镜像版本号]
```

```java
//拉取
sudo docker pull registry.cn-hangzhou.aliyuncs.com/wxqwxq/test:[镜像版本号]
```

# 常用容器

## 安装mysql

```java
//拉取
docker pull mysql:5.7

//运行
docker run -p 3306:3306 --name mysql
-v /zzyyuse/mysql/conf:/etc/mysql/conf.d
-v /zzyyuse/mysql/logs:/logs
-v /zzyyuse/mysql/data:/var/lib/mysql
-e MYSQL_ROOT_PASSWORD=123456
-d mysql:5.7
```

## 安装redis

```java
//拉取
docker pull redis  

//运行
docker run -p 6379:6379 --name myredis
-v /zzyyuse/myredis/data:/data
-v /zzyyuse/myredis/conf/redis.conf:/usr/local/etc/redis/redis.conf
-d redis:3.2 redis-server /usr/local/etc/redis/redis.conf
--appendonly yes

//docker exec -it 运行的redis容器id  redis-cli
```

## **安装nginx**

```java
//查询
docker search nginx

//拉取
docker pull nginx:latest

//运行
docker run -p --name nginx01 -p:3344:80
```

## 安装zookeeper

```java
docker pull daocloud.io/library/zookeeper    //拉取
docker run --name zk01 -p 2181:2181 --restart always -d 4f58c04512fb //运行
```

## 安装nacos

```java
docker search nacos  //查询
docker pull nacos/nacos-servern //拉取   
```

## 安装rabbit

```java
docker pull rabbitmq:3-management //拉取
//主机的5672映射到docker容器的5672这是我们客户端和rabbitMQ进行通信的端口
//15672这是管理界面访问web页面的端口    
docker run -d -p 5672:5672 -p 15672:15672 --name myrabbit 1c1e1f201079 
```

![](images/QQ截图20200706130521.png)

## 安装elasticsearch

```java
 docker pull daocloud.io/library/elasticsearch  //拉取
 // 它默认初始会占用2个G的内存空间，而我的虚拟机内存空间不够，可以加个-e命令限制它对内存的使用
 //    "-Xms256 -Xmx256m"  初始使用，最大使用
 // 默认进行web通信使用 9200端口
 // 在分布式的情况下在各个节点之间使用 9300端口    
 docker run -e ES_JAVA_OPTS="-Xms256m -Xmx256m" -d -p 9200:9200 -p 9300:9300  --name ES01 5acf0e8da90b    //
```

![](images/QQ截图20200706130732.png)