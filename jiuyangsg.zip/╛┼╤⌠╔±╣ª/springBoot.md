# 四大要基础素

## 1.场景依赖

```java
//网址： 
https://docs.spring.io/spring-boot/docs/1.5.9.RELEASE/reference/htmlsingle/
#using-boot-starter

POM文件它通过starter-paren来管理所有依赖版本。springBoot将所有功能场景都抽取出来，做成一个个starters（启动），在项目中只需要引入这些starter，相关场景的依赖就会导入进来。要用什么功能就导入什么场景依赖。
```

**pom.xml**

```xml
<!-- SpringBoot工程父类依赖-->
<parent>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-parent</artifactId>
    <version>1.3.3.RELEASE</version>
</parent>
<!--SpringBoot web 组件-->
<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
</dependencies>
```

## 2.主启动类

```java
//主程序类，说明这是一个spring Boot 应用。
@SpringBootApplication  
public class WxqSpringbootApplication {

    public static void main(String[] args) {
        SpringApplication.run(WxqSpringbootApplication.class, args);
    }
}

// @SpringBootApplication 是一个组合注解 
   // 1.
	  @SpringBootConfiguration //标注在某个类上，表示这是一个spring Boot的配置类
		  // 1.1  
			@Configuration // 标注配置类
   // 2.
 	  @EnableAutoConfiguration  //开启自动配置功能(以前需要配置的东西，让SpringBoot配置)
   		 // 2.1
			@AutoConfigurationPackage //自动配置包   
                //2.1.1
					//给容器导入一个组件
					// AutoConfigurationPackages.Registrar 制定导入什么组件
					// 将主配置类（@SpringBootApplication标注的类）的所在包以及下面所有子包里面 						的所有组件扫描到 Spring容器内
					@Import(AutoConfigurationPackages.Registrar.class) 
        // 2.2
			//给容器导入非常多的配置类（xxxAutoConfiguration）
			@Import(AutoConfigurationImportSelector.class) 

1、启动类它依靠一个注解@SpringBootApplication，它是一个组合注解，其中里面有一个 @EnableAutoConfiguration注解它就是开启自动配置功能的，它里面也几个注解最终会通过一些列的逻辑从 META-INF下的spring.factories获取定制的值，这些值导入到容器中，自动配置类就生效了。

2、这个场景SpringBoot帮我们配置了什么？能不能修改？能修改哪些配置？能不能扩展？


J2EE的整体整合解决方案和自动配置在这个jar包中：
spring-boot-autoconfigure-2.2.5.RELEASE.jar
```

## 3.配置文件

### **yml语法**

```yaml
(一)语法规范：
1.值与冒号之间要有空格；
2.属性和值之间大小写敏感；
3.字符串默认不用添加单引号和双引号(双引号不会转义字符串、单引号会转义字符串)；
# 如：name: "as\nx"   输出: wxq 换行 aq
# 如：name: "as\nx"   输出 wxq \n aq 

(二)数据类型：
person:
    lastName: zhangsan  #字符串
    age: 18				#数值
    boss: false			#布尔
    birth: 2017/12/12	#时间
    maps: {k1:v1,k1:v2}	#Map
    lists: 				#List
        - lisi
        - zhaoliu
    dog: 				#对象
        name: 小狗
        age: 2
     
(三)在yml占位符：

${random.uuid}   # 随机生成uuid
${random.int}    # 随机生成数字 
${person.hello}  # 在配置文件中 获取配置文件中的其他值  
${person.hello：hello}  # 通过冒号加默认值，如果person.hello没有则默认hello     
```

### 获取配置文件数据

```java
（一）Java类获取配置文件数据：

//只能读取全局配置文件(application.yml)里面的数据
@Component  //只有组件是容器中的组件，才能使用容器提供的注解
@ConfigurationProperties(prefix="person") //与配置文件中的person属性绑定	
public class Person{
    private String lastNmae;
    private Integer age;
    private Boolean boss;
    private Date birth;
    //其他属性以及get、set方法省略......
}

//加入相关依赖可以解决使用该注解的提示问题   
<dependency>
	<groupId>org.springframework.boot</groupId>
	<artifactId>spring-boot-configuration-processor</artifactId>
	<optional>true</potional>
</dependency>

(二)Java类获取配置文件数据：

//只能读取全局配置文件(application.yml)里面的数据
//导包 org.springframework.beans.factory....开头
@Component  
public class Person{
    @Value("${person.lastName}") 
    private String lastName
    @Value("#{11*2}")
    private Integer age;
    @Value("true")
    private Boolean boss;
    //其他属性以及get、set方法省略......
}

//@Value 和 @ConfigurationProperties 区别
1. @Value需要一个一个注入， @ConfigurationProperties 批量注入
2. @Value可以是用#{11*2}，@ConfigurationProperties 不行
3. @Value不支持JSR303数据校验，@ConfigurationProperties 支持
4. @Value 只能获取基本数据类型， @ConfigurationProperties 则可以获取Map之类的复杂类型。

(三)Java类获取配置文件数据：

//1:默认支持 properties
// 该注解可以加载指定的配置文件，将数据映射到实体类中。
@PropertySource(value={"classpath:person.properties"})
@ConfigurationProperties(prefix="person")
@Component    
public class Person{
	//属性上无需加任何注解，名字相同就能映射。
}    

//2:修改为支持yml方式
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.support.DefaultPropertySourceFactory;
import org.springframework.core.io.support.EncodedResource;

import java.io.IOException;
import java.util.Properties;

public class YamlConfigFactory  extends DefaultPropertySourceFactory {

    @Override
    public PropertySource<?> createPropertySource
        (String name, EncodedResource resource) throws IOException {
        String sourceName = name != null ? name : resource.getResource().getFilename();
        if (!resource.getResource().exists()) {
            return new PropertiesPropertySource(sourceName, new Properties());
        } else if (sourceName.endsWith(".yml") || sourceName.endsWith(".yaml")) {
            Properties propertiesFromYaml = loadYml(resource);
            return new PropertiesPropertySource(sourceName, propertiesFromYaml);
        } else {
            return super.createPropertySource(name, resource);
        }
    }

    private Properties loadYml(EncodedResource resource) throws IOException {
        YamlPropertiesFactoryBean factory = new YamlPropertiesFactoryBean();
        factory.setResources(resource.getResource());
        factory.afterPropertiesSet();
        return factory.getObject();
    }
}

@Component
@PropertySource(value={"classpath:config/test02.properties"},
                factory = YamlConfigFactory.class)
@ConfigurationProperties(prefix="person")
```

### application.yml

```yaml
debug= true #开启springBoot的Debug模式
server:
	port: 8081     #指定端口号
	path: /action  #指定访问路径
spring:
	profiles:
		#application-dev.yml 开发环境 、-test.yml测试环境、-prod.yml 生产环境 
		active: dev #环境切换 
		mvc：
			date-format=yyyy-MM-dd  #日期格式化
```

```yaml
附加：

(一)配置文件扫描优先级
#springboot启动优先级从高到低扫描application.yml作为默认配置文件
# 高优先级配置内容会覆盖低优先级配置内容他们之间相互互补

-file:./config/    #当前项目的根目录config
-file:./		   #当前项目的根目录	
-classpath:/config #类路径 比如在resources 文件夹下 config 
-classpath:/	   #类路径 比如在resources

(二)手动改变配置目录
# 我们也可以通过配置spring.config.location来改变默认配置
java -jar spring-bootXXX.jar --spring.config.location = G:/application.yml

(三)环境切换
#除了在配置文件中设置环境切换，也可以用以下两种方式进行切换
# 1.命令行： 
java -jar spring-bootXXX.jar --spring-profiles.active=dev;
# 2.虚拟机参数：
#在idea的  run/Debug Configurations 点击springboot项目 VM options里输入
-Dspring.profiles.active = dev
```

## 4.配置类

```java
//以前总是用spring.xml配置类，依赖注入Bean实例，现在不用了，直接用配置类。

@Configuration  //标明配置类
public class MyAppConfig{
	
	//该注解的作用就是将方法的返回添加到容器中，容器中这个组件的id就是方法名
	@Bean
    public HelloService helloService(){
    	return new HelloService
    }
}


附：
//以前的xml,可以通过这个注解标注在类启动上进行注入，但一般不会这样用。
@ImportResource(locations="classpath:beans.xml")  
```

## 自动配置原理(精髓)

```java
自动配置原理：

一、SpringBoot启动的时候加载主配置，开启了自动配置功能 @EnableAutoConfiguration

二、@EnableAutoConfiguration 作用：

 //给容器导入(Import)一些组件
 1.利用AutoConfigurationImportSelector类导入组件，具体查看selectImports()方法。 
 2.查看 getAutoConfigurationEntry()方法 中的 getCandidateConfigurations（）。
  // spring-boot-autoconfigure-2.2.5.RELEASE.jar  
  // 扫描jar包类路径下 META-INF/spring.factories
 3.它调用了 SpringFactoriesLoader.loadFactoryNames 。
 5.loadSpringFactories（）方法  把扫描到的这些文件的内容包装成 properties对象。
 6.从preperties中获取到EnableAutoConfiguration.class类型(类名)对应的值然后把他们添加到容器中。
 7.autoConfigurationEntry.getConfigurations() //所以它就是获取候选的配置
 
 总结：@EnableAutoConfiguration就是将类路径下 META/INF/spring.factories 里面配置的所有EnableAutoConfiguration的值加入到了容器中,每一个这样的 xxxAutoConfiguration 类都是容器中的一个组件，都加入到容器中；用他们来做自动配置。
 
三、以HttpEncodingAutoConfiguration为例解释自动配置原理:

@Configuration(proxyBeanMethods = false) //标明配置类
@EnableConfigurationProperties(HttpProperties.class) //获取配置文件的值进行绑定
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)//是否生效 
@ConditionalOnClass(CharacterEncodingFilter.class) //乱码解决的过滤器 
@ConditionalOnProperty(prefix = "spring.http.encoding", value = "enabled", matchIfMissing = true)  //判断配置文件中是否存在这个配置
      
 总结：根据当前不同的条件判断，决定这个配置类是否生效；如果配置类生效了就给容器中添加各种组件，
这些组件的属性是从对应的properties类中获取的，这些类里面的每一个属性又是和配置文件绑定的
  

精髓：
1. SpringBoot启动会加载大量的自动配置类;
2. 我们看我们需要的功能有没有springBoot默认写好的自动配置类；
3. 我们再看这个自动配置类中到底配置了哪些组件；（只要我们要用的组件有，我们就不需要再配置）
4. 给容器中自动配置添加组件的时候，会从properties类中获取某些属性，我们就可以在配置文件中指定这些属性的值;
```

**@Conditionnal派生注解**

作用：必须是@Conditional指定的条件成立，才给容器中添加组件，配置配里面的所有内容才生效；

|      @Conditional扩展注解       |         作用（判断是否满足当前指定条件）         |
| :-----------------------------: | :----------------------------------------------: |
|       @ConditionalOnJava        |            系统的java版本是否符合要求            |
|       @ConditionalOnBean        |               容器中存在指定Bean；               |
|    @ConditionalOnMissingBean    |              容器中不存在指定Bean；              |
|    @ConditionalOnExpression     |                满足SpEL表达式指定                |
|       @ConditionalOnClass       |                 系统中有指定的类                 |
|   @ConditionalOnMissingClass    |                系统中没有指定的类                |
|  @ConditionalOnSingleCandidate  | 容器中只有一个指定的Bean，或者这个Bean是首选Bean |
|     @ConditionalOnProperty      |          系统中指定的属性是否有指定的值          |
|     @ConditionalOnResource      |           类路径下是否存在指定资源文件           |
|  @ConditionalOnWebApplication   |                  当前是web环境                   |
| @ConditionalOnNotWebApplication |                 当前不是web环境                  |
|       @ConditionalOnJndi        |                  JNDI存在指定项                  |

# 关于日志

SpringBoot能自动适配所有的日志，而且底层使用slf4j+logback的方式记录日志，引入其他框架的时候，只需要把这个框架依赖的日志框架排除掉

## **日志输出**

```java
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ApiTest {
    //必须先定义Logger，LoggerFactory.getLogger才不会报错
    Logger logger = LoggerFactory.getLogger(getClass());

    public void contextLoads(){
        //日志的级别
        //由低到高 trace<debug<info<warn<error
        //可以调整输出的日志级别：日志就只会在这个级别以后的高几倍的生效
        logger.trace("这是trace日志...");
        logger.debug("这是debug日志...");
        //springBoot默认使用的是Info级别的日志
        logger.info("这是info日志...");
        logger.warn("这是warn日志...");
        logger.error("这是erroer日志");
    }
}
```

## **日志的配置**

```yaml
logging:
	level:
		com:
			atguigu: trace	#设置日志输出级别
	file: springboot.log  #当前项目下生成springlog日志			
	file: D:/springboot.log  #指定在D盘生成
    path: /spring/log #在当前磁盘的根路径下创建spring文件和log文件夹，使用spring.log作为默认文件
    pattern:
    	console:  #在控制台输出的日志的格式
    	file: 	  #指定在文件中日志输出的格式	
  #格式
  	#日期                       线程       靠左对齐  全类名50个字符  消息带上换行
   %d{yyyy-MM-dd HH:mm:ss.SSS} [%thread] %-5level %logger{50} - %msg%n
```

**指定输出文件**

```java
//springBoot的默log文件在spring-boot-2.2.7.RELEASE.jar的logging下面。 

// 指定配置
给类路径下放上每个日志框架组件的配置文件即可；springboot就不使用他默认配置的了

// 规则(后缀不加spring直接被日志框架识别，加了有SpringBoot解析，可以使用springProfile特性)
Logback: logback-spring.xml
Log4j2: log4j2.xml
JDK(Java Util Logging): logging.properties

//指定某段日志在指定级别输出
<springProfile name="dev"> //name="!dev"
	...日志的输出
</springProfile>
```

## AOP统一处理日志

```xml
<!-- 1.pom文件新增AOP依赖 -->
<dependency>
	<groupId>org.springframework.boot</groupId>
	<artifactId>spring-boot-starter-aop</artifactId>
</dependency>
```

```java
@Aspect   //定义切面
@Component //注入spring容器
public class WebLogAspect {
	private Logger logger = LoggerFactory.getLogger(getClass());	
    @Pointcut("execution(public * com.itmayiedu.controller..*.*(..))")
	public void webLog() { }
	
    @Before("webLog()")
	public void doBefore(JoinPoint joinPoint) throws Throwable {
		// 接收到请求，记录请求内容
		ServletRequestAttributes attributes = 
            (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
		HttpServletRequest request = attributes.getRequest();
        
        logger.info("################请求开始###################")
        
		// 记录下请求内容
		logger.info("URL : " + request.getRequestURL().toString());
		logger.info("HTTP_METHOD : " + request.getMethod());
		logger.info("IP : " + request.getRemoteAddr());
		Enumeration<String> enu = request.getParameterNames();
		while (enu.hasMoreElements()) {
			String name = (String) enu.nextElement();
			logger.info("name:{"+name+"},value:{"+request.getParameter(name)+"}");
		}
	}

    @AfterReturning(returning = "ret", pointcut = "webLog()")
	public void doAfterReturning(Object ret) throws Throwable {
		// 处理完请求，返回内容
		logger.info("RESPONSE : " + ret);
        logger.info("################请求结束###################")
	}
}
```

# Web开发

## SpringMVC自动配置原理

```java
(一)概念：
1.springMvc的配置都在 WebMvcAutoConfiguration.java。
2.自动配置了ViewResolver(视图解析器：根据方法返回值得到视图对象,视图对象决定如何渲染，转发？重定向？
3.ContentNegotiatingViewResolver.java组合所有视图解析器。
4. 如何定制：我们可以自己给容器中添加一个视图解析器；自动的将其组合进来？

//例子：定制视图解析器 
// DispatcherServlet.java 的doDispatch（） 方法 可以查看视图解析器
@Bean  //只需要放在容器中即可
public ViewResolver myViewReolver(){
    return new MyViewResolver();
}
//内部类
private static class MyViewResolver implements ViewResolver{
    @Override
    public View resolveViewName(String viewName,Locale locale)throws Exception{
        return null
    }
}

(二)百度自己自定义配置：
Converter:转换器
Formatter： 格式化器   //配置了springBoot才用，不配不用
HttpMessageConverter: //SpringMVC用来转换Http请求和响应的
MessageCodesResolver  //定义错误代码生成规则的
```

### 自定义视图映射

```java
(一)方式1 （springBoot2.0以后改用方式2）：

// 不能标注@EnableWebMvc (既保留了所有自动配置也能用我们的扩展配置)
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Configuration
public class MyMvcConfig extends WebMvcConfigurerAdapter {

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        //super.addViewControllers(registry);
            registry.addViewController("/atguigu").setViewName("success");
    }

     //所有的webMvcConfigurerAdapter组件都会一起起作用
    @Bean //将组件注册在容器
    public WebMvcConfigurerAdapter webMvcConfigurerAdapter(){
        WebMvcConfigurerAdapter adapter = new WebMvcConfigurerAdapter() {
            @Override
            public void addViewControllers(ViewControllerRegistry registry) {
                registry.addViewController("/").setViewName("index");
                registry.addViewController("/index.html").setViewName("index");
            }
        };
        return adapter;
    }
}

（二）方式2：

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class MyMvcConfig implements WebMvcConfigurer {

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/atguigu").setViewName("success");
    }
}
```

## 静态资源

```java
(一)在webjars里面获取资源：
1. 获取webjars依赖的网址： www.webjars.org
2. 所有webjars,都去classpath:/META-INF/resources/webjars/ 找资源,所以引用的时候只需要引用   /webjars/... 下面的资源名称就可以了。
3.如我引用了jquery的webjars： localhost:8080/webjars/jquery/3.3.1/query.js 
 
(二)访问项目的任何资源如果没人处理会在以下路径寻找： 
1.classpath:/META-INF/resources/
2.classPath:/resources/
3.classpath:/static/
4.classpath:/public/
    
// 欢迎页。静态资源文件夹下的所有index.html页面，会被 "/**" 映射    
如：localhost:8080/  ———>  resource/public/index.html  
        
// 配置喜欢的图标
静态资源文件夹下找  **/favicon.ico  

//改变静态资源文件夹下的路径,多个路径有逗号分隔（yml中配置）
spring.resources.static-location=classpath:/hello/,classpath:/hello2/
```

## Thymeleaf

```html
一、基本了解

<!-- *** 1.引入thymeleaf相关依赖，可以参看shiro笔记 -->
<!-- *** 2.只要我们把HTML页面放在classpath:/templates/,Thymeleaf就能自动渲染> 
<!-- *** 3. 在使用Thymeleaf时页面要引入名称空间  -->
<html lang="en" xmlns:th="http://www.thymeleaf.org">   

二、关于th:语法 
 1） th:text:文本替换		 
 2） th:utext：支持html的文本替换。
 3） th:value：属性赋值    
 4） th:href    
 5） th:src	 th:class  	 th:id
 6） th:each：遍历循环元素   
 7） th:if： 判断条件，类似的还有th:unless，th:switch，th:case
 8） th:insert：代码块引入，类似的还有th:replace，th:include，常用于公共代码块提取的场景
 9） th:fragment：定义代码块，方便被th:insert引用
10） th:object：声明变量，一般和*{}一起配合使用，达到偷懒的效果。
    *{...} 选择变量表达式	 
    <!--  *{...}用于配合th:object使用，获取值 -->
    <div th:object="${session.user}">
        <p>Name:<span th:text="*{filsName}"></span></p>
        <p>Name:<span th:text="*{filsName}"></span></p>
    </div> 
11） th:attr：设置标签属性，多个属性可以用逗号分隔，类似的还有  th:attrprepend  th:attrappend
 
三、${...} 变量表达式

(一)可以获取对象的属性和方法：
<!-- ${person.father.name} -->
<!-- ${person['father']['name']} -->
<!-- ${personsByName['Stephen Zuchini'].age} -->
<!-- ${persionArray[0].name} -->
<!-- ${persion.createCompleteName()}  //方法调用 -->  
       
(二)可以获取常用的内置对象：
1、ctx ：上下文对象。
2、vars ：上下文变量。
3、locale：上下文的语言环境。
4、request：（仅在web上下文）的 HttpServletRequest 对象。
5、response：（仅在web上下文）的 HttpServletResponse 对象。
6、session：（仅在web上下文）的 HttpSession 对象。
7、servletContext：（仅在web上下文）的 ServletContext 
<!-- th:text="${session.userinfo}" -->    
    
(三)常用的内置方法
1、strings：字符串格式化方法，常用的Java方法它都有。
比如：equals，equalsIgnoreCase，length，trim，toUpperCase，
toLowerCase，indexOf，substring，replace，startsWith，endsWith，
contains，containsIgnoreCase等。
<!-- th：if = ${#string.isEmpty(msg)}  判断是否为空  -->     
    
2、numbers：数值格式化方法，常用的方法有：formatDecimal等。
    
3、bools：布尔方法，常用的方法有：isTrue，isFalse等。
     
4、arrays：数组方法，常用的方法有：toArray，length，isEmpty，contains，containsAll等。
  <!-- ${not #arrays.isEmpty(itdragonArray)}	-->
  <!-- ${#arrays.length(itdragonArray)} -->  
    
5、lists，sets：集合方法，常用的方法有：toList，size，isEmpty，contains，containsAll，sort等。
  <!-- ${not #lists.isEmpty(itdragonList)} --> 
    
6、maps：对象方法，常用的方法有：size，isEmpty，containsKey，containsValue等。
   <!-- ${#maps.size(itdragonMap)} -->   
    
7、dates：日期方法，常用的方法有：format，year，month，hour，createNow等。
  <!-- th:text="${#dates.format(birth,'dd/MM/yyyy HH:mm')}"  日期格式化 -->  	
       
    
四、@{...} 链接表达式      
<!-- 不管是静态资源的引用，form表单的请求，凡是链接都可以用@{...}
这样可以动态获取项目路径，即便项目名变了，依然可以正常访问-->
1、无参：@{/xxx}
2、有参：@{/xxx(k1=v1,k2=v2)} 对应url结构：xxx?k1=v1&k2=v2
3、引入本地资源：@{/项目本地的资源路径}
4、引入外部资源：@{/webjars/资源在jar包中的路径}	
<a th:href="@{http://localhost:8080/gtvg/order/details(orderId=${o.id})}">
        <a th:href="@{order/details(orderId=${o.id})}">       
        
五、#{...} 消息表达式   
<!-- 消息表达式一般用于国际化的场景。-->   
    	

六、~{...} 代码块表达式
<!-- templatename：模版名Thymeleaf会根据模版名解析完整路径：
         /resources/templates/templatename.html，要注意文件的路径。
		fragmentname：片段名，Thymeleaf通过th:fragment声明定义代码块，即:
		th:fragment="fragmentname" -->	
~{templatename::fragmentname}   
     
<!-- id：HTML的id选择器，使用时要在前面加上#号，不支持class选择器。 -->
~{templatename::#id}  
<div th:fragment="copy">要抽取的公告片段 </div>
<div th:insert="~{footer::copy}"></div>     //模板名：片段名
<div th:insert="~{footer:: #copy}"></div>   //选择器方式                           
    	
七、其他    
+ , - , * , / , %
and , or, not
> , < , >= , <= , == , != ( gt, lt, ge, le, eq, ne)             
<h2 th:text="${expression} ? 'Hello' : Something else'"></h2>
转义字符 [[${user}]]  不转义字符[(${user})]    
             
<!-- 开发期间模板引擎页面修改以后，要实时生效 -->
<!-- 1. yml中禁用 模板引擎的缓存 -->
spring.thymleleaf.cache = false
<!-- 2. --> 
idea中 Ctrl+F9重新编译             
```

```
th:value="${resultMsg.msg}"  获取对象数据
th:href="${'/userController/updatePage?id='+list.id}" 
th:src="@{/images/admin_logo.png}"
th:each="list: ${resultMsg.data}"
```

## 国际化

```java
(一)编写国际化配置文件：
//idea识别到你要做国际化文件的时候就会切换到国家化视图
1、在resources建立i18n文件夹。
2、文件夹下建立login.properties  //默认文件
3、login_zh_CN.properties  //中文国际化文件  语言代码加国家代码
4、login_en_US.properties  //英文国际化文件  语言代码加国家代码

(二)yml配置路径：
spring:
  messages:
    basename: i18n.login
    
(三)Thymeleaf使用#{}获取国际化信息
//1、input里面是没有text的，可以用 [[]]
//2、idea乱码问题： 在setting里面 搜索 file Encodeings  
// --> Default encoding properties files: 改 UTF-8  √ Transparent native-to-asclli...
// --> setting里面设置的是当前项目编码，
// --> 设置全局编码 Other settings - setting for new project 里面设置 file Encodeings 
<div...  th:text=#{login.name}>
<input ...> [[#{login.name}]] </input>


(四)默认根据浏览器语言信息来展示，所以要自己配置解析器

第一、配置标签：
<a ... th:href="@{/index.html(l='zh_CN')}">中文 </a>
<a ... th:href="@{/index.html(l=en_US)}"> English</a>

第二、解析区域信息
//1、配置区域解析器
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.servlet.LocaleResolver;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Locale;

public class MyLocaleResolver implements LocaleResolver {
    @Override
    public Locale resolveLocale(HttpServletRequest request) {
        String l = request.getParameter("l");
        Locale locale = Locale.getDefault();  //参数中没带区域信息就系统默认的
        if(!StringUtils.isEmpty(l)){
           String[] split = l.split("_");
           //获取语言代码和国家代码
           locale = new Locale(split[0],split[1]);
        }
        return locale;
    }

    @Override
    public void setLocale
        (HttpServletRequest request, HttpServletResponse response, Locale locale) {

    }
}

//2 装配到容器中
@Configuration
public class MyMvcConfig extends WebMvcConfigurerAdapter {
   //....省略之前的代码
    
    @Bean
    public LocaleResolver localeResolver(){
        return  new MyLocaleResolver();
    }
}

//原理
国际化Locale(区域信息对象)； LocaleResolver(获取区域信息对象)
默认就是根据请求头带来的区域信息获取Locale进行国际化    
```

## 拦截器

```java
// 防止表单重复提交，登录的时候使用重定向跳转页面

// 拦截器进行登录检查
// 1.配置拦截器	
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginHandlerInterceptor implements HandlerInterceptor {

    //目标方法执行之前
    @Override
    public boolean preHandle(HttpServletRequest request,
                HttpServletResponse response, Object handler) throws Exception {
       Object user = request.getSession().getAttribute("User");
       if( user == null){
            // 未登陆，返回登陆页面
           request.setAttribute("msg","没有权限");
           request.getRequestDispatcher("/index.html").forward(request,response);
           return false;
       }else {
           //已登陆
           return true;
       }
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

    }
}

// 2. 添加到容器中
@Configuration
public class MyMvcConfig extends WebMvcConfigurerAdapter {
   //....省略之前的代码
    
    // 所有的webMvcConfigurerAdapter组件都会一起起作用
    @Bean //将组件注册在容器
    public WebMvcConfigurerAdapter webMvcConfigurerAdapter(){
        WebMvcConfigurerAdapter adapter = new WebMvcConfigurerAdapter() {
            //...省略视图解析器代码
            
            //注册拦截器
            @Override
            public void addInterceptors(InterceptorRegistry registry) {
                // super.addInterceptors(registry);
                //  addPathPatterns 拦截器要拦哪些请求？
                //  excludePathPatterns 排除什么请求? 如：访问欢迎页的请求、以及登陆的请求
                // 注意：springBoot已经做好静态资源映射了，不用管可以，
                //如果拦截了就排除 /static/ /webjars/等
                registry.addInterceptor
                    (new LoginHandlerInterceptor()).addPathPatterns("/**")
                        .excludePathPatterns("/index.html","/","/user/login");
            }
        };
        return adapter;
    }
}
```

## 错误机制处理

```java
(一)关于原理。可以参照ErrorMvcAutoConfiguration 给容器添加了以下组件：
1、DefaultErrorAttributes
2、BasicErrorController
3、ErrorPageCustomizer
4、DefaultErrorViewResolver

一旦系统出现400或500等错误，ErrorPageCustomizer就会生效（定义错误的响应规则）；就会来到/error请求；然后就会被BasicErrorController处理，它来处理请求会有两种方式，一种是响应页面，一种是响应json数据。

(二)如何定制错误的页面				//4xx表示以4开头的错误
1. 有模板引擎的情况下。将错误页面命名为错误状态码（4XX）.html 放在resource/erroer文件下。

页面能获取的信息：
timestamp:时间戳  status:状态码  error:错误提示  exception:异常对象  message:异常消息
errors:JSR303数据校验的错误都在这里

(三)自己定制的json数据
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.Map;

@ControllerAdvice //表示标记为为全局异常处理的切面类，可以指定扫描范围
public class MyExceptionHandler  {

    //第一种方式：只要出现该异常springMVC就会调用该方法 
    //（但没有字适应效果，浏览器和客户端返回的都是json）
    @ResponseBody
    @ExceptionHandler(UserNotExistException.class)
    public Map<String,Object> handleException(Exception e){
        Map<String,Object> map = new HashMap<>();
        map.put("code","user.notexist");
        map.put("message",e.getMessage());
        return map;
    }  
    
   //第二种方式（转发到自适应效果处理，既返能返回页面，也能返回json数据）
   // 1.
    @ExceptionHandler(UserNotExistException.class)
    public String handleException(Exception e, HttpServletRequest request){
        //传入我们自己的状态码
        request.setAttribute("javax.servlet.error.status_code",500);
        //传入自己的异常数据
        Map<String,Object> map = new HashMap<>();
        map.put("code","user.notexist");
        map.put("message",e.getMessage());
        request.setAttribute("ext",map);
        return "forward:/error";
    }
}

  // 2.
   import org.springframework.boot.web.servlet.error.DefaultErrorAttributes;
   import org.springframework.web.context.request.WebRequest;

   import java.util.Map;
   // 自定义错误处理器
   public class MyErrorAttributes extends DefaultErrorAttributes {

    // 返回值得map就是页面和json能获取的所有字段
    @Override
    public Map<String, Object> getErrorAttributes(WebRequest webRequest, 
                                                  boolean includeStackTrace) {
        Map<String,Object> map =  super.
            getErrorAttributes(webRequest,includeStackTrace);
        //从request请求域中获取map (这就是我们异常处理器携带的数据)
        Map<String,Object> ext = (Map<String, Object>) webRequest.
            getAttribute("ext",0);
        map.put("ext",ext);
        return map;
    }
}

```

```java
//自定义异常
public class UserNotExistException extends RuntimeException {
    public UserNotExistException(){
        super("用户不存在");
    }
}
```

## 配置嵌入式servelet容器

```java
一、如何定制和修改Servlet容器的相关配置

(一)修改和server有关的配置（serverProperties）:
 //例：
 server.prot=8081
 server.context-path=/crud
 server.tomcat.uri-encoding=UTF-8

(二)编写一个WebServerFactoryCustomizer:嵌入式的Servlet容器的定制器，来修改Servlet容器的配置：
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.boot.web.servlet.server.ConfigurableServletWebServerFactory;
@Configuration
public class MyMvcConfig extends WebMvcConfigurerAdapter {

    @Bean
    public WebServerFactoryCustomizer webServerFactoryCustomizer(){
        return new WebServerFactoryCustomizer<ConfigurableServletWebServerFactory>() {
            //定制嵌入式的Servlet容器相关的规则
            @Override
            public void customize(ConfigurableServletWebServerFactory factory) {
                factory.setPort(8083);
            }
        };
    }  
}   

二、注册Servlet三大组件(Servlet、Filter、Listener)
由于SpringBoot默认是以jar包方式启动嵌入式的Servlet容器来启动SpringBoot的应用，没有web.xml文件
注册三大组件用以下方式。

(一)ServletRegistrationBean：

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class MyServlet extends HttpServlet {

    //处理get请求
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
        throws ServletException, IOException {
        super.doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
        throws ServletException, IOException {
       resp.getWriter().write("hello MyServlet!");
    }
}

(二)FilterRegistrationBean：

import javax.servlet.*;
import java.io.IOException;

public class MyFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, 
                         FilterChain chain) throws IOException, ServletException {
        System.out.println("MyFilter process...");
        chain.doFilter(request,response);
    }

    @Override
    public void destroy() {

    }
}

(三)ServletListennerRegistrationBean：

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class MyListener implements ServletContextListener {
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("contextInitialized...Web应用启动");
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("contextDestroyed...当前web项目销毁");
    }
}

(四)三大组件 注册：

import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.boot.web.servlet.server.ConfigurableServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Arrays;

@Configuration
public class MyServerConfig {

    //注册三大组件
    @Bean
    public ServletRegistrationBean myServlet(){
        ServletRegistrationBean registrationBean = 
            new ServletRegistrationBean((new MyServlet()),"/myServlet");
        return registrationBean;
    }

    @Bean
    public FilterRegistrationBean myFilter(){
        FilterRegistrationBean registrationBean = new FilterRegistrationBean();
        registrationBean.setFilter(new MyFilter()); //设置我们的Filter
        registrationBean.setUrlPatterns(Arrays.asList("/hello","/myServlet")); //设置要拦截的url路径
        return registrationBean;
    }

    @Bean
    public ServletListenerRegistrationBean myListener(){
        ServletListenerRegistrationBean registrationBean = 
            new ServletListenerRegistrationBean<MyListener>(new MyListener());
        return registrationBean;
    }

    //配置嵌入式的Servlet容器
    @Bean
    public WebServerFactoryCustomizer webServerFactoryCustomizer(){
        return new WebServerFactoryCustomizer<ConfigurableServletWebServerFactory>() {
            //定制嵌入式的Servlet容器相关的规则
            @Override
            public void customize(ConfigurableServletWebServerFactory factory) {
                factory.setPort(8083);
            }
        };
    }
}
```

# 访问数据库

## 介绍

```
1. 默认是用org.apache.tomcat.jdbc.pool.DataSource作为数据源；
2. 数据源的相关配置都在DataSourceProperties里面；
3. SpringBoot默认可以支持org.apache.tomcat.jdbc.pool.DataSource、HikariDataSource、BasicDataSource；
4. springBoot自动配置了JdbcTemplate操作数据库
```

## 关于自动建表

```yaml
schema-*.sql  建表语句  # 默认规则：schema.sql，schema-all.sql；
data-*.sql    数据语句

#yml配置指定
spring:
 datasource:
    schema:   #DDL
      - classpath:department.sql
      - classpath:department.sql
    data:    #DML
```

## 引入druid数据源

```xml
<dependency>
    <groupId>com.alibaba</groupId>
    <artifactId>druid</artifactId>
    <version>1.1.19</version>
</dependency>
```

```yaml
## --------------- 具体配置（注意：数据源其他配置是默认绑定不上的需要自定义配置绑定）  ---------
spring:
  datasource:
#   数据源基本配置
    username: root
    password: 123456
    driver-class-name: com.mysql.jdbc.Driver
    url: jdbc:mysql://localhost:3306/ssm_crud
    type: com.alibaba.druid.pool.DruidDataSource  #指定数据源类型
#   数据源其他配置
    initialSize: 5
    minIdle: 5
    maxActive: 20
    maxWait: 60000
    timeBetweenEvictionRunsMillis: 60000
    minEvictableIdleTimeMillis: 300000
    validationQuery: SELECT 1 FROM DUAL
    testWhileIdle: true
    testOnBorrow: false
    testOnReturn: false
    poolPreparedStatements: true
#   配置监控统计拦截的filters，去掉后监控界面sql无法统计，'wall'用于防火墙  
    filters: stat,wall,log4j
    maxPoolPreparedStatementPerConnectionSize: 20
    useGlobalDataSourceStat: true  
    connectionProperties: druid.stat.mergeSql=true;druid.stat.slowSqlMillis=500
```

```java
//----------------------------   自定义配置绑定  ---------------------------
@Configuration
public class DruidConfig {
	
    //----------获取yml配置
    @ConfigurationProperties(prefix = "spring.datasource")
    @Bean
    public DataSource druid(){
       return  new DruidDataSource();
    }
   
    
    //-----------配置Druid的监控
    //1、配置一个管理后台的Servlet
    @Bean
    public ServletRegistrationBean statViewServlet(){
        ServletRegistrationBean bean = 
            new ServletRegistrationBean(new StatViewServlet(), "/druid/*");
        Map<String,String> initParams = new HashMap<>();

        initParams.put("loginUsername","admin");
        initParams.put("loginPassword","123456");
        initParams.put("allow","localhost"); //允许localhost（不写则默认是允许所有访问）
        initParams.put("deny","192.168.15.21"); //拒绝谁来访问

        bean.setInitParameters(initParams);
        return bean;
    }
    //2、配置一个web监控的filter
    @Bean
    public FilterRegistrationBean webStatFilter(){
        FilterRegistrationBean bean = new FilterRegistrationBean();
        bean.setFilter(new WebStatFilter());

        Map<String,String> initParams = new HashMap<>();
        // 排除哪些请求
        initParams.put("exclusions","*.js,*.css,/druid/*");

        bean.setInitParameters(initParams);

        bean.setUrlPatterns(Arrays.asList("/*")); //拦截所有请求

        return  bean;
    }
}


// 进入 druid的管理后台
localhost:8080/druid/login.html
```

## 整合mybatis

```java
//1. 引入相关依赖
//2. 指定这是一个操作数据库的mapper
@Mapper
public interface DepartmentMapper {
    @Select("select * from department where id=#{id}")
    public Department getDeptById(Integer id);

    @Delete("delete from department where id=#{id}")
    public int deleteDeptById(Integer id);

    @Options(useGeneratedKeys = true,keyProperty = "id") //插入返回主键
    @Insert("insert into department(departmentName) values(#{departmentName})")
    public int insertDept(Department department);

    @Update("update department set departmentName=#{departmentName} where id=#{id}")
    public int updateDept(Department department);
}

//3.使用MapperScan批量扫描所有的Mapper接口；
@MapperScan(value = "com.atguigu.springboot.mapper")
@SpringBootApplication
public class SpringBoot06DataMybatisApplication {
	public static void main(String[] args) {
		SpringApplication.run(SpringBoot06DataMybatisApplication.class, args);
	}
}

// xml映射方式
// 1. yml配置映射路径
mybatis:
   type-aliases-package=com.baizhi.entity  //扫描包
   config-location: classpath:mybatis/mybatis-config.xml //指定全局配置文件的位置
   mapper-locations: classpath*:/mybatis/**/*Mapper.xml  //指定sql映射文件的位置
// 具体配置省略......  
```

## 整合JPA

```java
//先导入相关的JPA依赖
//-------------------- 1. 编写一个实体类（bean）和数据表进行映射，并且配置好映射关系 -----------
import javax.persistence.Entity
import javax.persistence.Table
import javax.persistence.Id
....

//使用JPA注解配置映射关系
@Entity //告诉JPA这是一个实体类（和数据表映射的类）
@Table(name = "tbl_user") //@Table来指定和哪个数据表对应;如果省略默认表名就是user；
public class User {
    
    @Id //这是一个主键
    @GeneratedValue(strategy = GenerationType.IDENTITY)//自增主键
    private Integer id;

    @Column(name = "last_name",length = 50) //这是和数据表对应的一个列
    private String lastName;
    @Column //省略默认列名就是属性名
    private String email;
}

//-------------------  2. 编写一个Dao接口来操作实体类对应的数据表（Repository）  ------------
//继承JpaRepository来完成对数据库的操作                  映射的对象类  主键类型
public interface UserRepository extends JpaRepository<User,Integer> {
}
```

```yaml
#----------------------3. 基本的配置JpaProperties  ---------------------------------
spring:  
 jpa:
    hibernate:
		#更新或者创建数据表结构
    	ddl-auto: update
		#控制台显示SQL
    	show-sql: true
```

## 整合多数据源

**pom.xml**

```xml
<dependency>
	<groupId>org.springframework.boot</groupId>
	<artifactId>spring-boot-starter-jta-atomikos</artifactId>
</dependency>
```

**application.yml**

```
jdbc:mysql://localhost/emm_ms?useUnicode=true&characterEncoding=utf8&useSSL=false&allowMultiQueries=true&rewriteBatchedStatements=true
```

```yaml
spring:
    output.ansi.enabled: ALWAYS
    datasource:
        # 数据源1 - 默认数据源
        data01:
            driver-class-name: com.mysql.jdbc.Driver
            url: 太长省略....看上面
            username: root
            password: 123456
        # 数据源2                   192.168.0.200:3306
        data02:
            driver-class-name: com.mysql.jdbc.Driver
            url: 太长省略....看上面
            username: root
            password: 123456
```

**获取配置信息的实体类**

```java
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

//获取开头为mysql.datasource.test数据源
@Data
@ConfigurationProperties(prefix = "spring.datasource.data01")
public class DBConfig1 {
    private String username;
    private String password;
    private int minPoolSize;
    private int maxPoolSize;
    private int maxLifetime;
    private int borrowConnectionTimeout;
    private int loginTimeout;
    private int maintenanceInterval;
    private int maxIdleTime;
    private String testQuery;
    private String url;
}

@Data
@ConfigurationProperties(prefix = "spring.datasource.data02")
public class DBConfig2 {
    private String username;
    private String password;
    private int minPoolSize;
    private int maxPoolSize;
    private int maxLifetime;
    private int borrowConnectionTimeout;
    private int loginTimeout;
    private int maintenanceInterval;
    private int maxIdleTime;
    private String testQuery;
    private String url;

}
```

**配置数据源类**

```java
import com.mysql.jdbc.jdbc2.optional.MysqlXADataSource;
import lombok.extern.java.Log;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.jta.atomikos.AtomikosDataSourceBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import tk.mybatis.spring.annotation.MapperScan;

import javax.sql.DataSource;
import java.sql.SQLException;

@Configuration
//com.wxq.mapper.db01下面的都访问data01数据源
@MapperScan(basePackages = "com.wxq.mapper.db01", 
            sqlSessionTemplateRef = "sqlSessionTemplate01")
public class DataSource1 {
    
    // 配置数据源
    @Primary
    @Bean(name = "dataSource01")
    public DataSource dataSource01(DBConfig1 dbConfig1) throws SQLException {

        MysqlXADataSource mysqlXaDataSource = new MysqlXADataSource();
        mysqlXaDataSource.setUrl(dbConfig1.getUrl());
        mysqlXaDataSource.setPinGlobalTxToPhysicalConnection(true);
        mysqlXaDataSource.setPassword(dbConfig1.getPassword());
        mysqlXaDataSource.setUser(dbConfig1.getUsername());
        mysqlXaDataSource.setPinGlobalTxToPhysicalConnection(true);

        AtomikosDataSourceBean xaDataSource = new AtomikosDataSourceBean();
        xaDataSource.setXaDataSource(mysqlXaDataSource);
        xaDataSource.setUniqueResourceName("dataSource01");

        xaDataSource.setMinPoolSize(dbConfig1.getMinPoolSize());
        xaDataSource.setMaxPoolSize(dbConfig1.getMaxPoolSize());
        xaDataSource.setMaxLifetime(dbConfig1.getMaxLifetime());
        xaDataSource
              .setBorrowConnectionTimeout(dbConfig1.getBorrowConnectionTimeout());
        xaDataSource.setLoginTimeout(dbConfig1.getLoginTimeout());
        xaDataSource.setMaintenanceInterval(dbConfig1.getMaintenanceInterval());
        xaDataSource.setMaxIdleTime(dbConfig1.getMaxIdleTime());
        xaDataSource.setTestQuery(dbConfig1.getTestQuery());
        return xaDataSource;
    }

  
    @Primary //多个数据源时要设定一个默认的数据源	
    @Bean(name = "sqlSessionFactory01") //sql会话工厂
    public SqlSessionFactory sqlSessionFactory01(
        @Qualifier("dataSource01") DataSource dataSource)throws Exception {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        bean.setTypeAliasesPackage("com.wxq.entity;com.wxq.dto"); //扫实体类包和dto包
        // myBatis写配置文件要读它路径代码的地址   
        bean.setMapperLocations(new PathMatchingResourcePatternResolver()
                                .getResources("classpath*:/mybatis/**/*Mapper.xml"));
        bean.setDataSource(dataSource);
        return bean.getObject();
    }

    //创建session模板
    @Primary
    @Bean(name = "sqlSessionTemplate01")
    public SqlSessionTemplate sqlSessionTemplate01(
            @Qualifier("sqlSessionFactory01") SqlSessionFactory sqlSessionFactory
    ) throws Exception {
        return new SqlSessionTemplate(sqlSessionFactory);
    }
}

<!-- 3.一般事务 -->    
@Transactional //springboot默认集成事物,只主要在方法上加上@Transactional即可  
```

```java
import com.mysql.jdbc.jdbc2.optional.MysqlXADataSource;
import lombok.extern.java.Log;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.jta.atomikos.AtomikosDataSourceBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import tk.mybatis.spring.annotation.MapperScan;

import javax.sql.DataSource;
import java.sql.SQLException;

@Configuration
@MapperScan(basePackages = "com.wxq.mapper.db02", 
            sqlSessionTemplateRef = "sqlSessionTemplate02")
public class DataSource2 {

    // 配置数据源
    @Bean(name = "dataSource02")
    public DataSource dataSource02(DBConfig2 dbConfig2) throws SQLException {
        MysqlXADataSource mysqlXaDataSource = new MysqlXADataSource();
        mysqlXaDataSource.setUrl(dbConfig2.getUrl());
        mysqlXaDataSource.setPinGlobalTxToPhysicalConnection(true);
        mysqlXaDataSource.setPassword(dbConfig2.getPassword());
        mysqlXaDataSource.setUser(dbConfig2.getUsername());
        mysqlXaDataSource.setPinGlobalTxToPhysicalConnection(true);

        AtomikosDataSourceBean xaDataSource = new AtomikosDataSourceBean();
        xaDataSource.setXaDataSource(mysqlXaDataSource);
        xaDataSource.setUniqueResourceName("dataSource02");

        xaDataSource.setMinPoolSize(dbConfig2.getMinPoolSize());
        xaDataSource.setMaxPoolSize(dbConfig2.getMaxPoolSize());
        xaDataSource.setMaxLifetime(dbConfig2.getMaxLifetime());
        xaDataSource
            .setBorrowConnectionTimeout(dbConfig2.getBorrowConnectionTimeout());
        xaDataSource.setLoginTimeout(dbConfig2.getLoginTimeout());
        xaDataSource.setMaintenanceInterval(dbConfig2.getMaintenanceInterval());
        xaDataSource.setMaxIdleTime(dbConfig2.getMaxIdleTime());
        xaDataSource.setTestQuery(dbConfig2.getTestQuery());
        return xaDataSource;
    }

    @Bean(name = "sqlSessionFactory02")
    public SqlSessionFactory sqlSessionFactory02(
        @Qualifier("dataSource02") DataSource dataSource)
            throws Exception {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        bean.setTypeAliasesPackage("com.wxq.entity;com.wxq.dto"); 
        bean.setMapperLocations(new PathMatchingResourcePatternResolver()
                                .getResources("classpath*:/mybatis/**/*Mapper.xml"));
        bean.setDataSource(dataSource);
        return bean.getObject();
    }

    @Bean(name = "sqlSessionTemplate02")
    public SqlSessionTemplate sqlSessionTemplate02(
            @Qualifier("sqlSessionFactory02") 
        SqlSessionFactory sqlSessionFactory) throws Exception {
        return new SqlSessionTemplate(sqlSessionFactory);
    }
}
```

**启动类**

```java
@EnableConfigurationProperties({DBConfig1.class, DBConfig2.class})
```

# 高级点

## spring缓存

### 一种表达式三个注解

```java
一、spel表达式
//1.可能会用到的
 root.args[0]  获取第一个参数值
 root.caches[0].name  获取第一个缓存列表
 #id  参数为id的值

//2.不常用了解就够
#root.methodName  当前被调用的方法名
#root.method.name  当前被调用的方法
#root.target  被调用的目标对象
#root.target  被调用的目标对类
#result  获取返回值   

二、三个注解

了解1： 缓存管理器>缓存名>缓存key
了解2： 缓存key默认使用参数值来当缓存key
了解3： 使用缓存注解，要在类启动器上添加，@EnableCaching 开启缓存
了解4： 注解都属于该包下的 import org.springframework.cache.annotation

(一)@Cacheable： 缓存存入
1.cacheNames/value: 指定缓存名(可以看着表)； 
2.key:指定缓存key(看着id);
3.keyGenerator: key的生成器；可以指定key的生成器的组件id,key/keyGennerator: 二选一使用
4.cacheManager:指定缓存管理器；或者cacheResolver 指定解析器
5.condition: 符合条件才缓存
6.unless: 符合条件不缓存
7.sync：是否使用异步模式  

(二)@CacheEvict：缓存清除
1.allEntries = true 指定这个缓存中的所有数据
2.beforeInvocation = false 是否在方法之前执行，默认之后

(三)@CachePut：缓存更新
//参数同上......

(四)@CacheConfig(cacheNames = "emp") 这个注解公共的缓存名。以上三个注解都在方法上，这个在类上
```

### 推荐使用方案

```java
//增删改都清空缓存，保证了查询数据的正确性，这样简单有效不复杂

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class UserService {
	
    //emp表缓存名
    final String cacheName = "com.huaji.service.UserService_emp01";

    //查询时存入缓存，key值默认为参数列表的值
    @Cacheable(cacheNames = cacheName) 
    public String findInfo(String id,String name){
        System.out.println("执行查询！");
        //......
    }
	
    //更新时清空缓存
    @CacheEvict(cacheNames = cacheName,allEntries = true)
    public String updateInfo(String id,String name){
        System.out.println("执行更新！");
    }
	
    //删除时清空缓存
    @CacheEvict(cacheNames = cacheName,allEntries = true)
    public void delInfo(){
        System.out.println("执行删除！");
    }
}
```

### 自定义key生成(作为了解)

```java
//1.实现生成类
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.lang.reflect.Method;
import java.util.Arrays;

@Configuration
public class MyCacheConfig {

    //自定义key的生成策略
    @Bean("myKeyGenerator")
    public KeyGenerator keyGenerator() {
        return new KeyGenerator() {
            @Override
            public Object generate(Object target, Method method, Object... params) {
                return method.getName()+"["+ Arrays.asList(params).toString() +"]";
            }
        };
    }
}

//2. 使用 keyGenerator设置自定义key
@Cacheable(cacheNames = {"emp"},keyGenerator = "myKeyGenerator",condition = "#id>1")
public Employee getEmp(Integer id){
    //.......
}
```

## 发送邮件

![](images/QQ截图20200518234405.png)

![](images/QQ截图20200518235239.png)

![](images/QQ截图20201129233715.png)

![](images/QQ截图20201129233845.png)

```xml
(一)导入依赖：
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-mail</artifactId>
</dependency>
```

```
(二)配置地址：
spring.mail.username=wxq292775032@qq.com   
spring.mail.password=zcukqcfeblmwbhef
spring.mail.host=smtp.qq.com
spring.mail.properties.mail.smtp.ssl.enable=true    
```

```java
(三)测试：

import org.springframework.mail.javamail.JavaMailSenderImpl;

    @Autowired
    JavaMailSenderImpl mailSender;

	//简单邮件发送
    @Test
    public void contextLoads2(){
        SimpleMailMessage mailMessage = new SimpleMailMessage();
        mailMessage.setSubject("通知-今晚开会"); //标题
        mailMessage.setText("今晚7:30开会");  //邮件内容
        mailMessage.setTo("451377407@qq.com"); //发给谁，可以写多个地址
        mailMessage.setFrom("wxq292775032@qq.com"); //邮件是谁发的
        mailSender.send(mailMessage);
    }

    @Test
    public void contextLoads3() throws MessagingException {
        //1.创建一个复杂的消息邮件
        MimeMessage mimeMessage = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage,true);

        //2.邮件设置
        helper.setSubject("通知-今晚开会"); //标题
        helper.setText("<b style='color:red'>今晚7:30开会</b>",true); //邮件内容

        helper.setTo("451377407@qq.com"); //发给谁，可以写多个地址
        helper.setFrom("wxq292775032@qq.com"); //邮件是谁发的

        //3.上传文件
        helper.addAttachment("1.txt",
                             new File("C:\\Users\\Administrator\\Desktop\\集数.txt"));
        helper.addAttachment("2.txt",
                             new File("C:\\Users\\Administrator\\Desktop\\集数.txt"));
        
        mailSender.send(mimeMessage);
    }
```

# 其他

```java
(一)实现异步调用：
// 1.启动类加上
@EnableAsync
//2.需要执行异步方法上加入	
@Async

(二)定时任务：
//1.启动类上开启注解
@EnableScheduling

//2.需要执行定时任务的方法上加入
@Scheduled(cron="0/4 * * * * * *")
    
@RestController //表示修饰该Controller所有的方法返回JSON格式,直接可以编写Restful接口    
```

## 单元测试

```java
// SpringBoot单元测试
@RunWith(SpringRunner.class)
@SpringBootTest
public class Test{
    
    @Autowired
    Person person;
    
    //获取OC容器的方式
    @Autowired
    ApplicationContext ioc;
    
    @Test
    public void contextLoads(){
        bolean flag = ioc.containsBean("helloService"); // 容器中是否有该ben 
        System.out.println(person);
    }
}
```

## 目录结构

```
resources文件夹目录结构
	static: 保存所有静态资源，js css images;
	templates: 保存所有的模板页面，freemarker、thymeleaf (默认不支持JSP);
	application.yml: spirngBoot应用配置文件，可以修改一些默认设置
```

## Restfule风格

```
URI: /资源名称/资源标识  HTTP请求方式区分资源CRUD(增删改查)操作
其实就是一种风格，能更好的区分增删改查
GET 查询  Post 添加  Put 修改  Delete 删除
```

微服务概念

```
微服务：架构风格
一个应用应该是一组小型服务；可以通过HTTP的方式进行互通
每一个功能元素最终都是一个可独立替换和独立升级的软件
https://www.bilibili.com/video/BV1Et411Y7tQ?p=67
```

