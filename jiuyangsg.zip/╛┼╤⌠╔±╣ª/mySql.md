## Mysql安装 

**安装**

![](images/QQ截图20201011145855.png)

![](images/QQ截图20201011150335.png)

![](images/QQ截图20201011150815.png)

![](images/QQ截图20201011151053.png)

![](images/QQ截图20201011151247.png)

![](images/QQ截图20201011151343.png)

![](images/QQ截图20201011151813.png)

![](images/QQ截图20201011151929.png)

**配置步骤**

![](images/QQ截图20201011152318.png)

![](images/QQ截图20201011153332.png)

![](images/QQ截图20201011161245.png)

![](images/QQ截图20201011161835.png)

![](images/QQ截图20201011162208.png)

![](images/QQ截图20201011162509.png)

![](images/QQ截图20201011162850.png)

![](images/QQ截图20201011163409.png)

![](images/QQ截图20201011163825.png)

![](images/QQ截图20201011164212.png)

![](images/QQ截图20201011165009.png)

![](images/QQ截图20201011165253.png)

## 数据库设计

### 需求分析

```text
1.概念
数据库设计就是将数据库中的数据实体，以及这些数据实体之间的关系进行规划和结构化的过程。
2.需求分析
	2.1 收集信息：了解数据需要存储哪些信息（数据）实现哪些功能
	2.2 标识实体：标识数据库要管理的关键对象或实体
	2.3 标识属性：标识每个实体存储的详细信息
	2.4 标识关系: 分析数据库表，确认逻辑上的相关，添加关系列建立表之间的连接。
```

### 三大范式

```
1.原子性，不可再分
2.一张表只做一件事
3.其他列必须和主键直接相关
注意： 满足三大范式性能会受到相应的影响，有时为了提高数据库访问性能，允许适当的数据冗余。
```

## 操作数据库

### 概要

```sql
--1.管理员窗口 (如果修改了配置文件，必须重新启动MySQL)
	net start mysql  --启动Mysql服务
	net stop mysql  --关闭Mysql服务
--2.连接数据库	
	mysql -h 服务器主机地址 -P 端口号 -u 用户名 -p密码
--3.选择数据库
	use 数据库名
--4.退出数据库
	exit	
--5.查看MySql版本信息
	select version() ,user();
```

### 操作数据库

```sql
--1.创建数据库/创建表
create database 数据库名；
create table [if not exists] 表名(
	字段 数据类型 [属性|约束] [索引] [注释]，
    --... 多字段使用逗号分隔        if not exists：判断表是否存在，不存在就执行
)
--2.查看大体表
show databases;  -- 所有数据库
show tables;   -- 所有表
--3.删除
drop database  数据库名;
drop table 表名；
--4.查看具体表
describe 表名；
desc 表名;
```

```sql
--1. 修改表名
alter table 旧表名 rename 新表名；
--2. 添加字段
alter table 表名 add 字段名 数据类型[属性];
--3. 修改字段
alter table 表名 change 原字段名 新字段名 数据类型[属性];
--4. 删除字段
alter table 表名 drop 字段名;

--5.添加主键					--pk_
alter table 表名 add constraint 主键名 primary key 表名(主键字段)；
--6.添加外键					--fk
alter table 表名 add constraint 外键名 foreign key (外键字段) references  
关联表名(关联字段)；
--注意：1. InnoDB存储类型的表支持外键，MyISAM不支持。
--     2. 被关字段，一定是关联表的主键
--     3. 给哪个表添加外键alter table 后面就跟哪个表

--7.删除主键
alter table 表名 drop primary key;
--8.删除外键
alter table 表名 drop foreign key '外键名';
```

### 数据类型

```sql
--1.数值类型
	--1.1 整数
		tinyint  --非常小的数据  1字节
		smallint --较小的数据    2字节
		mediumint  --中等大小的数据  3字节
		int		-- 标准整数 4字节
	--1.2 小数
    	float	--单精 4字节   float(5,2) 5表示全部几位  2表示小数点后保留几位
    	double  --双精 8字节  
--2.字符
	char --固定长度 长度：0~255
    varchar --可变长度  0~65535
    tinytext --微型文本串
    text -- 文本串
    blob -- 较大的二进制
--3.日期
	date  --日期
	datetime --日期和时间
	time  -- 时间
	timestamp --时区
	year
```

### 约束

```sql
not null --非空
default --默认
unique key --唯一
primary key  --主键
foreign key  --外键
auto_increment --自增
```

### 存储引擎

```sql
InnoDB: 多删除更新操作，完整性高，并发控制
MyISAm: 不需事务，空间小，以查询访问为主
-- 查看当前默认引擎：
show variables like 'storage_engine%';
-- 修改配置文件 my.ini 修改默认引擎
default - storage - engine = InnoDB
--语法
	--指定表的存储引擎
	create table 表名(
    	--省略
    )engine = MyIsAM 或 InnoDB
```

### DML--SQL

```sql
select <字段名列表>
from <表名或视图>
[where<查询条件>]
[group by <分组字段名>]   [HAVING  [条件]]
[order by <排序的列名>[ASC 或 DESC]]     
[limit[位置偏移量,]行数]；   --偏移量从0开始    当前页面减1乘以页大小

--子连接：
	select ... from (子查询)
	where 字段 比较运算符(子查询) 
	
	in 子查询可以返回多条记录 not in 
    ANY: 字段>any(子查询)  比其中一个大就OK
    all: 字段>all(子查询)  要比所有都大才OK
	
	注意：select后面支持一行一列，from后面支持整个表，where 多行单列。
	where 多行多列：
	 SELECT * FROM  USER u 
        WHERE  (u.id,u.id) IN (
             SELECT b.id,b.id FROM USER b
        )
--exists
select ... from 表名 where exists(子查询)
注：子查询有返回行，则exists为true,此时再执行外层查询；如果子查询没有返回行，则外层查询不执行
Not exists ：实现取反操作
注：任何允许使用表达式的地方都可以使用子查询
--多表连接
内连接
  	等值连接
  		select  <字段名列表>
  		from  表名1
  		INNer join 表名2  on  等值条件
  		INNer join 表名3  on  等值条件
  		[where<查询条件>]
  	非等值连接： 
  	自连接：同一张表当成两张表用

外连接：主表全显示;从表有则显示，没有则显示null
    左外连接:左为主
    	left join 表名2  on  等值条件
    右外连接：右为主
    	right join
    全外连接
        full join
--附加：
 ab的共有         INNER JOIN ...
 ab的共有加a独有  LEFT JOIN ...
 ab的共有加b独有  RIGHT  JOIN  ...
 a的独有     b.`id` IS NULL
 b的独有     a.`deptId` IS NULL;
 ab独有的合体  UNION   
```

```sql
--插入：
	--插入单行：
    	insert into 表名[(字段名列表)]
    	values(值列表)
    --插入多行：
    	insert into 表名（字段列表）
    	values(值列表1),(值列表2),......;
    --查询插入：
    <1>	insert into 新表名(字段1,字段2,......)
    	select 字段1,字段2,......
    	from 原表名。
    <2>	create table 新表名(select 字段1,字段2,......from 原表)；
--修改：
	update 表名
	[inner join 表名2  on  等值条件]
	set 字段1 = 值1, 字段2 = 值2
	[where条件];
--删除
	delete from 表名
	[inner join 表名2  on  等值条件]
	[where条件]；
	truncate table 表名；  //毁灭删
```

## 常用函数

### 字符串函数

```sql
--连接字符str1,str2为一个完整字符串
--select concat('a','b'); 返回：ab
concat(str1,str2,...) 

--将字符串str从pos位置开始，len个字符长的子串替换为字符串newstr
--select insert('这是abcd字母',3,4,'A');  返回： 这是A字母
insert(str,pos,len,newstr)

--将字符串str中所有字符变为小写
lower(str)
--将字符串str中所有字符变为大写
upper(str)

--返回字符串str的第num个位置开始长度为len的字符串
--select substring('javaMySQLAA',5,5)  返回： MySQL
substring(str,num,len)
--截取
SUBSTR("李莫愁爱上尹志平",6)

-- instr返回索引  数据库索引从1开始
INSTR('张三丰爱上灭绝师太','灭')

-- 左填充指定长度
LPAD('殷素素殷素素殷素素',10,'*')

--替换
REPLACE('张无忌爱上了周芷若','周芷若','赵敏')

-- 获取参数符的字节
SELECT LENGTH("aaaassssss")
```

### 时间日期函数

```sql
--获取当前日期   
curdate()
--获取当前时间
curtime()
--获取当前日期和时间
now()   SYSDATE()
--返回日期date为一年中的第几周
week(date)
--返回日期date年份
year(data)    MONTH(date) 月   DAY(date)  日
--返回日期time的小时值
hour(time)
--返回时间time的分钟值
minute(time)
--返回日期参数 date1 和 date2之间相隔的天数
datediff(date1,date2)
--计算日期参数date加上n天后的日期
adddate(date,n)
--计算日期参数date减去n天后的日期
subdate(date,n)
--季度函数
quarter(time)

--将字符通过指定的格式转换为日期
SELECT STR_TO_DATE('1998-3-3','%Y-%c-%d') AS A
--将日期转换成字符
SELECT DATE_FORMAT(NOW(),'%Y年%m月%d日')

-- %Y 四位年   %'y' 两位的年
-- %m 月（单数用0填充） %c(单数不填充)
-- %d  日
-- %H  24小时制   %h 12小时制
-- %i  分钟    
-- %s 秒
```

### 数学函数

```sql
--返回大于或等于X的最小整数
-- select ceil(2.3) 返回 3
ceil(x)
--返回小于或等于x的的最大整数
-- select floor(2.3) 返回 2
floor(x)
-- 返回0~1之间的随机数
rand()
-- 四舍五入
ROUND(123.5)
-- 小数点后保留4位
ROUND(1.567,4)
-- 取余
MOD(10,3)
-- 截断  返回 1.52
SELECT TRUNCATE(1.523,2)  
```

### 判断函数

```sql
-- if()函数
SELECT IF(1=1,'a','b') FROM DUAL

-- case函数
SELECT  CASE  1+1 
	WHEN 1 THEN 'bbb'
	WHEN 2 THEN 'ccc'
	END
    -------方式2
SELECT CASE WHEN 1!=1 THEN 'a'
             WHEN 1>3 THEN'b'
	     ELSE 'c'  END
	     
--如果A等于Null 则为B	
  ifNull(A,B)
     
--去重
 distinct 
 
--多表相连 
union all 

--大于0返回1, 小于0返回-1, 等于0返回0
SIGN(-3) 
```

## 事务/视图/索引

### 事务

```sql
并发事务处理带来的问题：更新丢失、脏读、不可重复读、幻读。
--1.概念: 事务是指将一系列数据捆绑成一个整体一起向系统提交撤销
--2.四个特性(ACID)：
	2.1：原子性：对数据修改，要么全执行，要么全不执行。
	2.2：一致性：事务从一个一致性状态变到另一个一致性状态。
	2.3：隔离性：事务之间相互独立。
	2.4：持久性：数据修改是永久性的。
--3.语法：
	设置自动提交  关闭/开启  set autocommit = 0|1;  -- 0禁止自动提交	1自动提交
	开始事务： begin
	提交事务： commit
	回滚：	   rollback
--4.并发事务所带来的问题：
	脏读：一个事务读取了另外一个事务未提交(回滚)的数据。
 	不可重读：一个事务读取某一行数据，多次读取结果不同。
	幻读：一个事务内读取到了别的事务插入的数据，导致前后读取不一致。
    更新丢失：撤销一个事务时，把其他事务已提交的更新数据覆盖。
--5.隔离级别	
	show variables like 'tx_isolation';  --查看默认级别
	Read uncommitted（最低级别，任何情况都无法保证）
	Read committed（可避免脏读的发生）
	Repeatable read（可避免脏读、不可重复读的发生）
	Serializable（可避免脏读、不可重复读、幻读的发生）
```

### 视图

```sql
--1.概念：视图是一种虚拟表，通常是作为来自一个或多个表的行或列的子集创建的
--2.场景：赛选表中的行，防止未经许可的用户访问敏感数据，将多个物理数据表抽象为一个逻辑数据表。
--3.创建视图:
	create view 视图名
	AS
	<select 语句>
--4.删除视图：
	drop view [if exists] 视图名；
--5.查询视图：
	select 字段1，字段2，... from 视图名;
```

### 索引

```sql
-- 1.创建索引
-- unique唯一索引  fulltext全文索引  spatial空间索引
create [unique |fulltext | spatial ] index 索引名 on 指定表名(指定索引列)
-- 2.删除索引
drop index 索引名 on 表名
-- 3.查看索引
show index from 表名
```

## 存储过程

```sql
--系统变量
   SHOW GLOBAL VARIABLES   -- 查看系统全局变量
   SHOW SESSION VARIABLES  -- 查看系统会话变量
   SHOW GLOBAL [SESSION] VARIABLES  LIKE '%char%'  -- 查看满足条件的部分系统变量
   SELECT @@global.系统变量名    -- 查看某个系统变量的值
   SET GLOBAL [SESSION] 系统变量名 = 值;  -- 为某个系统变量赋值
   
--自定义变量
   --1.用户变量
      1.1.声明并赋值   
      	  SET @用户变量名 :=值;
      1.2.赋值
          SELECT 字段 INTO @变量名
          FROM 表;
      1.3.查看
          SELECT @变量名
      --示例
       SET @m=1;
       SET @n =2;
       SET @sum = @m+@n;
       SELECT @sum;
   
   --2.局部变量    
       2.1.声明
            DECLARE 变量名 类型;
            DECLARE 变量名 类型  DEFAULT 值;
       2.2.赋值
			SET 局部变量名 := 值;
            SELECT 字段 INTO 局部变量名
            FROM 表;     
       2.3.查看
            SELECT @变量名  -- 查看依然要加@符号
       --示例（注意要放在  BEGIN AND 中才能执行）
        DECLARE m INT DEFAULT 1;
        DECLARE n INT DEFAULT 2;
        DECLARE SUM INT;
        SET SUM = m + n;
        SELECT SUM;
        
   --用户变量和局部变量的区别: 
   --1.作用域:用户变量为当前会话,局部变量只在 BEGIN END 中，且为第一句话。
   --2.语法: 用户变量必须加@符号，并且不用限定类型; 局部变量一般不用加@符号，需要限定类型。     
```

```sql
-- 概念
	1. 如果存储过程仅仅只有一句话，begin  end 可以省略
	2. 存储过程体中的每条SQL语句结尾要求必须加分号
	3. 存储过程的结尾可以使用  delimiter 重新设置  delimiter $
	
-- 1.创建存储过程
	CREATE PROCEDURE 存储过程名(IN NAME VARCHAR(20))
	BEGIN
	 
	END
    -- IN    该参数可以作为输入，就是传入值
    -- OUT   该参数可以作为输出，就是返回值
    -- INOUT 既可以作为输入，又可以返回值	
	
-- 2.调用存储过程
    CALL 存储过程名 (实参列表)
-- 3.删除存储过程
	 DROP PROCEDURE 存储过程名
-- 4.查看存储过程的信息
     SHOW CREATE PROCEDURE  存储过程名
```

```sql
-- 基础案例
DELIMITER $
CREATE PROCEDURE  test01(IN id INT,OUT result VARCHAR(20),INOUT outIn INT)
BEGIN
    DECLARE resultSerial VARCHAR(20) DEFAULT '';  --声明并初始化	
  
    SELECT SERIAL INTO resultSerial --赋值
    FROM payment p
    WHERE p.id = id;

    SET result := resultSerial;
    --select resultSerial into result; --使用
    SELECT resultSerial;
    SET outIn = outIn * 2;
END $

-------########调用##########------------
SET @id := 1;
SET @result := "";
SET @outIn := 2;
CALL test01(@id,@result,@outIn)

SELECT @result,@outIn
```

### 分支和循环

```sql
--if结构 不是if函数 只能应用在存储过程或函数中
SELECT
	IF 1>0 THEN 'a'
	ELSEIF 1<3 THEN 'b'
	ELSE 'c'
	END IF
FROM DUAL

--循环结构 ，标签是可选的 ； iterate 类似于 continue；leave 类似于 break

    -- while循环
    [标签:] while 循环条件 do
        --循环体
     end while [标签];

    -- loop循环
    [标签:] loop
        --循环体
    end loop [标签];	

    -- repeat循环
    [标签:]repeat
        --循环体
     until 结束循环的条件
    end repeat [标签];	
```

![](images/QQ截图20201016144420.png)

```sql
-- 基础案例
DELIMITER $
  CREATE PROCEDURE  testWhile(IN counts INT)
  BEGIN
	DECLARE i INT DEFAULT  1;	
	a: WHILE  i<= counts DO
		INSERT INTO USER(NAME,PASSWORD,role_id) VALUES(CONCAT('w',i),'123456',1);
		
		IF i>=10 THEN  LEAVE  a;  --要使用循环控制必须添加标签
		END IF;
		 
		 SET i = i+1;	
		
	END WHILE a;	
  END $
```

### 游标

```sql
    
 --------------游标语法
 	   --cur 游标名称  table可以是你查询出来的任意集合   	
 declare cur  CURSOR for table
     --游标中的内容执行完后将done设置为1 ; done为自定义的变量
     DECLARE CONTINUE HANDLER FOR NOT FOUND SET done=1;   
    --打开游标  
     open cur;     
   --取游标中的值    testrangeid 和  versionid  为自定义的变量
     FETCH cur into testrangeid,versionid;  
    --释放游标  
	CLOSE cur;  
 
 ------------- 游标实例	
	
    -- 创建 用于接收游标值的变量
    declare id,age,total int;
    -- 注意 接收游标值为中文时 需要 给变量 指定 字符集为utf8
    declare name,sex varchar(20) character set utf8;
     -- 游标结束的标志
    declare done int default 0;
    
     -- 声明游标
    declare cur cursor for 
    	select stuId,stuName,stuSex,stuAge from student where stuAge > 19;
    -- 指定游标循环结束时的返回值 
    declare continue handler for not found set done =1; 
    -- 打开游标
    open cur;
    
     -- 初始化 变量
    set total = 0;
    
      -- loop 循环
    xxx:loop
        -- 根据游标当前指向的一条数据  
        fetch cur into id,name,sex,age;
        -- 当 游标的返回值为 1 时 退出 loop循环 
        if done = 1 then
            leave xxx;
        end if;
        -- 累计
        set total = total + 1;
    end loop;
    -- 关闭游标
    close cur;
  -- 输出 累计的结果
    select total;
```

## 备份导入数据库/表

```sql
--1.备份数据库
需要备份的数据库名 > 路径加文件名.sql;
--2.导入数据库
source d:\temp.sql;
```

```sql
--1.备份表
<select 语句> into outfile 路径加文件名
--2.导入表
load data 路径加文件名 into table 要导入的表名
```

## 其他

```sql
--创建用户
 create user '用户名' @ '主机名' identified by '密码'
--查看已存在的用户
SELECT DISTINCT CONCAT('User: ''',USER,'''@''',HOST,''';') AS QUERY FROM mysql.user;
--删除用户
DROP USER 'zhangsan'@'192.168.231.166';
--授权
	...省略请百度

---表描述
information_schema ： 存储数据库对象信息
mysql： 存储权限信息
performance_schema ： 存储性能参数
--转码
set names gbk  
charset 'utf8'
--Windows平台下载 
http://dev.mysql.com/downloads/mysql
-- 聚合函数
count sum avg max min

> < = != <>  >= <=   is null   like  %%  in  not in    between...and
```

# ★MySql高级内容★

##   linux下操作mySql

![](images/QQ截图20201022171649.png)

```java
机器读取sql的顺序：  
  //  from  join  
  //  group by  having  
  //  select  
  //  order by 
  //  limit
```

### 安装

```java
第一阶段：安装环境
//1.检查是否安装过MySql
rpm -qa|grep -i mysql

//2.删除Mysql   （如果删不了 加--nodeps）
rpm -e RPM软件包名(该名字是上一个命令查出来的名字)
//rpm -e --nodeps mysql-libs-5.1.52-1.el6_0.1.x86_64(自己的版本)    
    
//检查安装这两步，防止安装失败
yum install -y libaio    
yum install -y libaio.so.1    
 
    
第二阶段：进行安装    
//注意：要将rpm包放入opt目录哦    
//正式安装服务端(一般不加 --force --nodeps，无法安装则添加)
rpm -ivh MySQL-server-5.5.48-1.linux2.6.i386.rpm  --force --nodeps
//正式安装客户端(一般不加 --force --nodeps，无法安装则添加)
rpm -ivh MySQL-client-5.5.48-1.linux2.6.i386.rpm  --force --nodeps


第三阶段：你这么知道mysql安装好了呢？
cat /etc/passwd |grep mysql  //查看它对应的组
cat /etc/group| grep mysql
mysqladmin --version     //版本

ps -ef |grep mysql  //查看进程
```

![](images/QQ截图20201022135257.png)

### 基本操作

```java
第一阶段：启动服务
//1.启动/关闭 mysql 
service mysql start
service mysql stop
//2.设置开机自启动
chkconfig mysql on
//3.使用此命令可以查看linux开机启动的服务
ntsysv
//查看运行级别（没啥用）
chkconfig --list | grep mysql


第二阶段:登入mysql
//1.没密码时直接输入 mysql 即可
//注意出现此错误使用以下命令：error while loading shared libraries: libncurses.so.5: cannot open shared object file: No such file or directory
yum install  libncurses.so.5
    
//2.设置秘密
/usr/bin/mysqladmin -u root password 123456
//3.使用密码进入mysql
mysql -uroot -p    //在下一行填入密码   
```

### 综合要点

```java
第一阶段：一些mysql相关目录了解
// 1.msyql数据文件在这个目录下
cd /var/lib/mysql
// 2.启停相关脚本目录
/etc/init.d/mysql 
// 3.配置文件目录
/usr/share/mysql
// 4.相关命令目录
/usr/bin
// 5.查看安装目录的命令
ps -ef|grep mysql

第二阶段：字符集的设置
//1.查看字符集（character_set_database和character_set_server是不是utf-8）
show variables like '%character%'
//2.进入配置目录
cd /usr/share/mysql/
//3.将配置文件拷贝出来（5.6版本名字叫 my-default.cnf，不叫my-huge.cnf）
cp my-huge.cnf /etc/my.cnf    

//4.修改配置文件（修改完以后保存，对mysql进行重新启动）
//注意：修改字符编码之前建的库，中文还是会乱码的；修改字符编码之后建的库，就不会了。
```

```mysql
#########################   对my.cnf配置文件进行修改（#设置字符集）  #####################

[client]
#password       = your_password
 port            = 3306
 socket          = /var/lib/mysql/mysql.sock
 default-character-set=utf8    #设置字符集
 
 
# Here follows entries for some specific programs

# The MySQL server
 [mysqld]
 port            = 3306
 character_set_server=utf8   #设置字符集
 character_set_client=utf8   #设置字符集
 collation-server=utf8_general_ci  #设置字符集
 socket          = /var/lib/mysql/mysql.sock
 skip-external-locking
 key_buffer_size = 384M
 max_allowed_packet = 1M
 table_open_cache = 512
 sort_buffer_size = 2M   
 read_buffer_size = 2M
 read_rnd_buffer_size = 8M
 myisam_sort_buffer_size = 64M
 thread_cache_size = 8
 query_cache_size = 32M
# Try number of CPU's*2 for thread_concurrency
thread_concurrency = 8

# Don't listen on a TCP/IP port at all. This can be a security enhancement,

[mysql]
no-auto-rehash
default-character-set=utf8  #设置字符集
# Remove the next comment character if you are not familiar with SQL
#safe-updates
```

```java
第三阶段：配置文件的了解
//1.配置文件名
 windows下面的mysql配置文件叫 my.ini文件    
 Linux下面的mysql配置文件叫 /etc/my.cnf文件

//2.配置文件中的日志
   二进制日志log-bin    //相当于小抄写工，用于主从复制
       log-bin=C:/Program Files/MySQL/MySQL Server 5.5/data/mysqlbin （根据自己的路径放）
   错误日志log-error   //默认是关闭的，记录严重的警告和错误信息，每次启动和关闭的详细信息等    
       log-err=D:/devSoft/MySQLSerer5.5/data/mysqlerr
   慢查询日志log  //默认关闭，记录查询的sql语句，开启会减低mysql整体的性能  

//3.数据文件
   两个系统
     windows:  mysql data目录下可以挑选很多库
     linux: 默认路径： /var/lib/mysql
   frm文件  存放表结构
   myd文件  存放表数据
   myi文件  存放表索引
   
第四阶段：windows连接不上虚拟机的数据库？ 
//windows下SQLyog连接要授权
 GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY '123456' WITH GRANT OPTION;
 FLUSH PRIVILEGES;
```

## 关于索引

### 认识索引

![](images/QQ截图20201023155540.png)

![](images/QQ截图20201026154632.png)

```java
第一阶段：什么是索引？
//1.索引就是数据结构，一种排好序可以快速查找的数据结构。
//2.索引会影响到where后面的查找和order by后面的排序。
//3.索引数据结构是独立的存在，也需要占内存，它以某种方式指向数据，常用的索引结构就是B树索引。
//4.B树索引(多路搜索树，不一定是二叉的)

第二阶段：有哪些索引？
//1.主键索引(PRIMARY):一张表只能有一个，值不允许为空的。
//主键是唯一性索引，但唯一性索引不一定是主键。
	alter table mytable add primary key(id);
//2.唯一索引: 一张表可以有多个唯一索引，索引列的值必须唯一，可以允许有空值.
	create [UNIQUE] index indexName on mytable(ID);
//3.普通索引：    
    单值索引: 即一个索引只包含单个列，一个表可以有多个单列索引(唯一符合)
        create index indexName on mytable(ID);
    复合索引：即一个索引包含多个列    
    	create index indexName on mytable(ID1,ID2);
//4.全文索引：用于在一篇文章中，检索文本信息的
	create [fulltext] index indexName on mytable(ID)

//附：
//索引删除
drop index 索引名 on 表名
//查看索引
show index from 表名
//注:一张表建的索引最多不要超过五个

第三阶段：索引优劣
//优势：提高检索效率,降低数据排序的成本
//劣势：索引也要占空间,降低更新表的速度，数据改索引目录指向也要改。

第四阶段：关于建索引
//需要建立索引的情况(mysql 三百万左右的数据性能逐渐下降)
    1.频繁作为查询条件的字段应该创建索引
    2.经常用于排序、分组的字段
    3.查询中与其他表关联的字段，外键关系建立索引
    4.倾向选择复合索引 
//不需要建立索引的情况
    1.表记录少
    2.频繁修改，删除的字段不适合做索引，数据修改索引的指向也要改。
    3.内容重复多，建索引效果不大(如性别字段：不是男就是女)。
    /*如果一个表中有2000条记录，索引列有1980个不同的值，那么这个索引的选择就是1980/2000=0.99。一个     索引的选择性越接近于1,这个索引的效率越高。*/
```

### mySql优化

```java
第一阶段：Mysql常见瓶颈
	//1.CPU：CPU在饱和的时候；一般发生在数据装入内存或磁盘上读取数据时候。
	//2.IO:装入数据远大于内存容量的时候。
    //3.sql语句问题
    
第二阶段：sql语句性能慢问题    
    //1.查询语句写的烂
    //2.索引失效(单值索引：给这张表的某个字段建一个索引、复合索引)
    //3.关联查询太多join(设计缺陷或不得已的需求)
    //4.服务器调优及各个参数设置(缓冲、线程数等)

第三阶段：打开慢查询日志
	//（一）概念认识：
	  1.慢查询是MySQL提供的一种日志行为，用来记录在MySQL中响应时间超过阀值(long_query_time)的sql.
	  2.long_query_time的默认值为10,意思是运行10秒以上的语句。
	  3.慢查询日志默认是关闭的，开启会有性能影响，不是调优需要不建议启动。
	//（二）开启慢查询:
      show variables like '%slow_query_log%'  //查看是否开启
      set global slow_query_log = 1;  //开启（对当前数据库生效，MySQL重启后则会失效）  关闭 0
    //（三）设置日志忍耐值：
      show [global] variables like 'long_query_time%';  //查看忍耐值
      set global long_query_time = 秒数;//设置阙值(重新连接或新开会话才能看到新修改值)
	//（四）查询当前系统有多少条慢查询记录：
	  show global status like '%Slow_queries%';
	
	//（五）附加：
      1.要永久生效，必须修改配置文件my.cnf（[mysqld]下增加或修改参数）。
        slow_query_log =1;
        slow_query_log_file= /var/lib/mysql/mysql-slow.log
        long_query_time=3;
        log_output=FILE
      2.日志分析工具mysqldumpslow。
      	//得到返回记录集最多的10个SQL
      	mysqldumpslow -s r -t 10 /var/lib/mysql/mysql-slow.log 
      	//得到访问次数最多的10个SQL
      	mysqldumpslow -s c -t 10 /var/lib/mysql/mysql-slow.log 
      	//得到按时间排序的前10条里面含有左连接的查询语句
		mysqldumpslow -s t -t 10 -g "left join" /var/lib/mysql/mysql-slow.log 
		//另外建议在使用这些命令时结合|和more使用，否则可能出现爆屏情况
		mysqldumpslow -s r -t 10 /var/lib/mysql/mysql-slow.log | more 

 第四阶段：使用Show Profile (explain使用后，未解决问题才使用它)
 	//(一)概念认识
 		1.可以查询SQL在Mysql服务器里面的执行细节和生命周期情况
 		2.默认参数处于关闭状态，并保存最近15次的运行结果。
 		3.官网：http://dev.mysql.com/doc/refman/5.5/en/show-profile.html
 	//(二)开启
    	show variables like 'profiling';  //查看开关状态
		set profiling = on;	//打开
	//(三)查看
    	show profiles;
	//(四)诊断sql
		show profile cpu [,block io] for query 要诊断拿条sql的query_id;
 		//可以查看的参数
            ALL 显示所有的开销信息
            block io 显示块IO相关开销
            context switches 上下文切换相关开销
            cpu 显示CPU相关开销信息
            IPC 显示发送和接受相关开销信息
            MEMORY 显示内存相关开销信息
            PAGE FAULTS 显示页面错误相关开销信息
            source 显示source_function,source_file,source_line相关的开销信息
            swaps 显示交换次数相关开销的信息
		//这三个问题出现一个你必须优化
			converting HEAP to MyISAM 查询结果太大，内存都不够用了往磁盘上搬了。
    		Creating tmp table 创建临时表
    		Copying to tmp table 把内存中临时表复制到磁盘，危险！！！
    		locked


程序的内存泄漏、死锁、网络、数据库sql写的烂,在传输在网络在连接是否是死锁
5.运维经理 or DBA，进行SQL数据库服务器的参数调优       
EXplain：模拟优化器执行SQL语句，分析sql性能。（ EXPLAIN  SELECT * FROM test）
```

### 索引分析

```java
第一阶段：使用explain
	//id：语句执行权重；值越高越先执行，相同值按顺序由上至下执行。
	//select_type：  
	     SIMPLE  简单查询,查询中不包含子查询或者union
         PRIMARY 主查询
         SUBQUERY 子查询
         DERIVED   衍生表，mysql会递归执行子查询，把结果放在临时表里
         UNION 
         UNION result 从union表获取结果的select
	       
	//table：显示这一行的数据关于哪张表的
	//type：访问类型
	     从最好到最差依次是system>const>eq_ref>ref>range>index>ALL
	     （一般来说，得保证查询至少达到range级别，最好能达到ref）
	     
	     system:表只有一行记录，平时不会出现。
	     const:表示通过索引一次找到,const用于主键索引。因为只匹配一行数据，所以很快。
	     eq_ref:唯一索引扫描，对于每个索引键，表中只有一条记录与之匹配。
	     ref:非唯一索引扫描，返回匹配某个单独的所有行
	     range:只检索给定范围的行，使用一个索引来选择行。一般出现在 between < >  in等查询
	     index:只遍历索引树，索引文件比数据文件小。
	     ALL：全表扫描(数据量是百万以上的，type是ALL请一定要优化).
	//possible_keys：理论上可能会被使用的索引
	//key：实际使用的索引
	//key_len：数值越小越好（但是索引列用的多值自然也会大）
	//ref：索引的哪一列被引用了
	//rows：每张表多少行被优化器查询，值越小越好。
	//Extra： 包含不在其他列显示，但十分重要的额外信息。
	     Using filesort: mysql会对数据使用一个外部的索引排序，不是按照表内索引顺序读取。（危险）
	     Using temporary: 使用了临时表保存中间结果，常见于order by 和 group by (危险)
	      
         Using index:表示相应的 select操作中使用了 覆盖索引，避免访问了表的数据行，效率不错！
	                    如果同时出现using where，表明索引被用来执行索引键值的查找；
	                    如果没有同时出现using where,表明索引用来读取数据而非执行查找动作；
	                    (覆盖索引：我查询的字段，刚好和我的索引字段相吻合)
          
         Using where: 表明用了where过滤。
         using join buffer:使用了连接缓存
         impoossible where: where子句的条件有矛盾。
	    
//要么不建索引，要建索引group by 尽量按着你的索引数量顺序来。
```

![](images/QQ截图20201026165042.png)

```java
第二阶段：索引失效问题
    //条件：假设user表中创建a,b,c三列的符合索引
    //创建方式1：ALTER  TABLE user ADD  INDEX  idx_user_abc(a,b,c);
    //创建方式2：CREATE INDEX idx_user_abc ON user(a,b,c);

    //索引寻找规律：相当于先从1楼按序找a，然后到2楼找b，最后到3楼找c。
        where a=1;                   //索引有效
        where a=1 and b=2;           //索引 ab都有效
        where a=1 and b=2 and c=3;   //索引abc都有效 (全值匹配最好)
        
        where b=2;           //索引无效(1楼未走，无法直接上2楼)
        where b=2 and c=3;   //索引无效
		where c = 3;         //索引无效

        where a=1 and c=3;  //索引使用到了a,但c不可以，b中间短了

		where a=1 order by b;  //排序用到了 b。
		where a=1 order by c;  //排序未用到 c。
		where a=1 order by b,c;//排序用到了bc. 
		where a=1 order by c,b;//排序未用到了bc. 
		where a=1 and b=2 order by c,b;//排序用到了bc. 
	//索引失效注意问题：
		1.不在where索引列上做任何函数操作，会导致索引失效。
				WHERE  LEFT(a,4) = 'july'。
        2.范围条件右边的索引列会失效。  
        		where a=3 and b>4 and c=5;   //索引使用到了a和b,c不能用在范围之后，b断了
        		where a=1 and b>1 order by c //排序c字段，索引失效,出现Using filesort
        		where a=1 and b>1 order by b,c  //索引使用了abc
        3.使用不等于(!= 或者 <>)的时候无法使用索引，会导致全表扫描
        
        4.is null , is not null 也无法使用索引。
        
        5.like以通配符开头('%abc...')索引失效，变成全表扫描；like 'abc%'则不会。
        		where a=1 and b like '%fs';  //索引只用到了a。
        		where a=1 and b like 'k%kk%';  //索引用到了ab。 
        6.索引列使用or也会导致索引失效。
        	
        7.尽量使用覆盖索引(只查询索引列)	
 
第三阶段：深入了解order by 使用索引
	//1.例子：KEY a_b_c(a,b,c)
		SELECT * FROM test  ORDER BY a;    //使用了索引
        SELECT * FROM test  ORDER BY a,b;  //使用了索引
        SELECT * FROM test  ORDER BY a asc,b desc; //索引失效
       //orderby能使用索引最左前缀
        -order by a
        -order by a,b
        -order by a,b,c
        -order by a desc,b desc,c desc;
	   //如果where使用索引的最左前缀定义为常量，则order by能使用索引
        -where a = const order by b,c
        -where a = const and b = const order by c
        -where a = const order by b,c;
        -where a = const and b>const order by b,c;
	   //不能使用索引进行排序
        -order by a ASC,B DESC;  //排序不一致
        -where g = const order by b,c //丢失a索引
        -where a = const  order by c  //丢失b索引
        -where a = const  order by a,d  //d不是索引一部分
        -where a in(...) order by b,c  //a是范围查询    
    
    //2.order by子句，尽量使用Index(索引排序)方式排序，避免使用FileSort(文本排序)方式排序:
    	
    	//我们使用的是单路排序，效率快，但消耗内存。数据超出sort_buffer的容量，会导致大量I/O操作。
    	
		//提高sort_buffer_size会提高效率，当然要根据系统的能力去提高，因为这个参数针对每个进程的。
			
	    //order by 时select * 是一个大忌只query需要的字段，字段查多了会增加内存。
		
		//提高max_length_for_sort_data会增加算法的概率，设值太高数据总量超sort_buffer_size的概           率就增大，会导致高的磁盘I/O活动和低的处理器使用率。	

第四阶段：关于group by
	//group by实质是先排序后进行分组，遵照索引建的最佳左前缀。
	//当无法使用索引列，增大max_length_for_sort_data参数的设置+增大sort_buffer_size参数的设置
	//where高于having,能写在where限定的条件就不要去having限定了。
```

### sql技巧合集

```java
第一优化原则：小表驱动大表，即小的数据集驱动大的数据集
    //B表数据小于A表数据
    select * from A where id in(select id from b)
    等价于：
    for select id from b
    for select * from A where A.id = B.id
	
	//A表数据小于B表的数据集时，用exists优于in。
    select * from A where exists(select 1 from B where B.id = A.id)
    等价于:
    for select * from A
    for select * from B where B.id = A.id

    //注意：A表与B表的ID字段应建立索引。

第二索引使用原则：
 	//1.左连接索引加右表，右连接索引加左表;
	//2.尽可能减少Join语句中的循环次数，永远用小结果集驱动大的结果集(如：书籍类别表驱动书籍表)。
	//3.优先优化内层循环
	//4.保证Join语句中被驱动表上Join条件字段(关联字段)已经被索引
	//5.当无法保证被驱动表的Join条件字段被索引且内存资源充足的前提下，不要吝啬JoinBuffer的设置
```

### 大数据添加

```mysql
第一阶段：可能出现的问题
   #由于做这种大数量操作的时候，mysql会报一个错，我们需要设置一个参数开启。
   #创建函数，假如报错： This function has none of DETERMINISTIC......	
   show variables like '%log_bin_trust_function_creators';   #查看状态
   set global log_bin_trust_function_creators=1;  #设置参数
   
   #这样添加了参数以后，如果mysqld重启，上述参数又会消失，永久方法
   windows下my.ini[mysqld]加上log_bin_trust_function_creators=1
   linux下 /etc/my.cnf下my.cnf[mysqld]加上log_bin_trust_function_creators=1

第二阶段：创建函数（使用SQL格式器）
#指定个数的随机字母函数
DELIMITER $$

 CREATE FUNCTION rand_string(n INT) RETURNS VARCHAR(255)
 BEGIN
	DECLARE chars_str VARCHAR(100) 
	DEFAULT 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	DECLARE return_str VARCHAR(255) DEFAULT '';
	DECLARE i INT DEFAULT 0;
	WHILE i<n DO
		SET return_str = CONCAT(return_str,SUBSTRING(chars_str,FLOOR(1+RAND()*52),1));
		SET i = i+1;
	END WHILE;
	RETURN return_str;
END $$


#随机数(100-109)函数
DELIMITER $$

CREATE FUNCTION rand_num() RETURNS INT(5)
BEGIN
	DECLARE i INT DEFAULT 0;
	SET i = FLOOR(100+RAND()*10);
	RETURN i;
END $$
   
第三阶段：创建存储过程
#emp表插入数据
DELIMITER $$
CREATE PROCEDURE insert_emp(IN START INT(10),IN max_num INT(10))
BEGIN
	DECLARE i INT DEFAULT 0;
	#开启事务
	SET autocommit = 0;
	REPEAT 
		SET i = i+1;
		INSERT INTO emp(empno,eName,job,mgr,hiredate,sal,comm,deptNo) 
		VALUES((START+i),rand_string(6),'SALESMAN',0001,CURDATE(),2000,400,rand_num());
		UNTIL i = max_num
	END REPEAT;
	COMMIT;

END $$;

#dept表插入数据
DELIMITER $$
CREATE PROCEDURE insert_dept(IN START INT(10),IN max_num INT(10))
BEGIN
	DECLARE i INT DEFAULT 0;
	#开启事务
	SET autocommit = 0;
	REPEAT 
		SET i = i+1;
		INSERT INTO dept(deptNo,dName,loc) 
		VALUES((START+i),rand_string(10),rand_string(8));
		UNTIL i = max_num
	END REPEAT;
	COMMIT;

END $$;
```

## 关于锁机制

### 存储引擎

![](images/QQ截图20201022190206.png)

```java
//查看存储引擎
show variables like '%storage_engine%';

(一)MyISAM：
		1.只支持表锁。
		2.查询时会自动给涉及的表加读锁，增删改时会给涉及的表加写锁。
		3.读写锁调度是写优先
		4.事务提交后，锁自动释放
(二)InnoDB：
		1.支持表锁也支持行锁，使用索引作为检索条件修改数据时采用行锁，否则采用表锁(写锁)。
    	2.查询操作不自动加锁。 
    	3.索引失效会导致行锁变表锁。
```

### 认识锁

```java
//概念：
1.好处：保证数据并发访问的一致性、有效性；
2.坏处：锁冲突，影响数据库并发访问性能。
 
//查看哪些表被锁(有1的就是锁了)：
show open tables;

//表锁(偏读)：开销小,加锁快,无死锁；锁定粒度大，发生锁冲突的概率最高，并发度低。
  	//1.手动测试加锁
  	  lock table 表名 read;   //读锁(读共享，当前进程其他进程都可以读，增删改操作不可以)  
      lock table 表名 write;  //写锁(写排它，只允许当前进程操作，会阻塞其他进程)
      lock table 表1 read,表2 write; //综合(读锁会阻塞写，不会堵塞读;写锁会把读和写都堵塞了)
  	//2.锁分析
	  show status like 'table%'; 	
	  Table_locks_immediate:表级锁定的次数。	
	  Table_locks_waited:表锁争用等待的次数。

//行锁(偏写)：开销大,加锁慢,会死锁；锁定粒度小，发生锁冲突的概率最低，并发度高。
  	//1.手动锁行
  	  for update
  	//2.锁分析
  	  show status like 'innodb_row_lock%';
	  Innodb_row_lock_current_waits:当前等待锁定的数量。
      Innodb_row_lock_time:等待总时长（重要）。
      Innodb_row_lock_time_avg:等待平均时长（重要）。
      Innodb_row_lock_time_max:等最长的时长。
      Innodb_row_lock_waits:等待总次数（重要）。
 
//释放锁：
unlock tables;

//间隙锁
键值在条件范围内但并不存在的记录叫间隙锁  
a字段 1345； 插a字段值2影响
```

### 悲/乐观锁

```
表锁：就是对整张表进行加锁，并发性能极差，一致性好

悲观锁：就是很悲观，每次去拿数据的时候都认为别人会修改，所以每次在拿数据的时候都会上锁，这样别人只有拿到锁才能拿数据。传统的数据库里面就用到了很多这种锁的机制，比如行锁，表锁等，读锁，写锁等，都是在做操作之前先上锁。

乐观锁：就是很乐观，每次去拿数据的时候认为别人不会修改，所以不会上锁，但是在更新的时候会判断一下在此期间
别人有没有去更新这个数据，可以使用版本号等机制。乐观锁适用于多读的应用类型，这样可以提高吞吐量。

乐观锁策略：提交版本必须大于记录当前版本才能更新。

每条记录后面加个version
```

## 主从复制

![](images/QQ截图20201108083824.png)

```mysql
#注意问题
1.mysql版本一致
2.互相网络ping的通

#----------------主机配置(修改my.ini,注意此为windows下)------------------
#1.[必须]主机唯一标识符
server-id=1   
#2.[必须]启用二进制日志
log-bin=自己本地的路径/data/mysqlbin 
#3.[可选]启用错误日志
log-err=自己本地的路径/data/mysqlerr
#4.[可选]根目录 basedir="自己本地路径"
basedir="自己本地路径"
#5.[可选]临时目录
tmpdir="自己本地路径"   
#6.[可选]数据目录datadir="自己本地路径/Data/"
datadir="自己本地路径/Data/"
#7.代表主机读写都可以
read-only=0 
#8.[可选]设置不要复制的数据库
binlog-ignore-db=mysql
#9.[可选]需要复制的数据库
binlog-do-db=数据库名
```

![](images/QQ截图20201108092057.png)



```mysql
#----------------从机配置(修改my.cnf,注意此为Linux下)------------------
#[必须]从机服务器唯一ID
 vim /etc/my.cnf   
 server-id=1 #此为主机标识符，把它注释掉
 server-id=2 #把它启用
#[可选]启用二进制日志

#------------------------------华丽分割线--------------------------------------
注意：因修改过配置文件，请主机+从机都重启后台mysql服务。
注意：主从都关闭防火墙。


#在Windows主机上建立账户并授权slave
#1.主机授权从机允许以张三的密码和123456的用户名登入我主机进行复制
GRANT REPLICATION SLAVE ON *.* TO 'zhangsan'@'从机数据库IP' IDENTIFIED BY '123456';
#2.刷新
FLUSH PRIVILEGES;
#3.查看主机状态（记录下File和Posintion的值）
show master status; 

#在linux从机上配置需要的主机（注意网段要一致，就是ip前三位）
change master to master_host='主机IP',
master_user='zhangsan',
master_password='123456',
master_log_file='mysqlbin.具体数字',master_log_pos=position值; 
#如果出现run STOP SLAVE first的报错请先停止。
stop slave;
#启动
start slave;
#查看
show slave status\G;

#Slave_IO_Running: Yes  两个为yes则表示成功
#Slave_SQL_Running:Yes
```

