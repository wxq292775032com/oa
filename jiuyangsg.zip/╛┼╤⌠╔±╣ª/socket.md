## 客户端 

```java
import java.io.*;
import java.net.InetAddress;
import java.net.Socket;

public class TcpClient {

    public static void main(String[] args) {
        Socket socket = null;
        OutputStream os = null;

        InputStream is = null;
        try {
            //建立通信
            socket = new Socket(InetAddress.getByName("127.0.0.1"), 4700);
            //发送信息
            os = socket.getOutputStream();
            os.write("你好服务器".getBytes());

            //从服务端接受响应的信息
            is = socket.getInputStream();
            byte[] b = new byte[1024];
            int len = is.read(b);
            System.out.println("收到谢谢".equals(new String(b,0,len)));
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //4.关闭响应的流和socket对象
            try {
                if(is != null) is.close();
                if (os != null) os.close();
                if (socket != null) socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
```

## 服务端

```java
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class TcpServer {

    public static void main(String[] args) {
        ServerSocket server = null;
        Socket socket = null;
        InputStream is = null;
        OutputStream os = null;
        try {
            server = new ServerSocket(4700);
            socket = server.accept();
            is = socket.getInputStream();

            //获取客户端数据
            byte[] b = new byte[1024];
            int len = is.read(b);
            System.out.println(new String(b,0,len));

            // 响应给客户端的数据
            os = socket.getOutputStream();
            os.write("收到谢谢".getBytes());

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (is != null) is.close();
                if (socket != null) socket.close();
                if (server != null) server.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

```

