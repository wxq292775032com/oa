# 微服务介绍

```
微服务就是一种架构模式，它将单一的应用程序划分为一组小的服务,每个服务可以独立的部署到生产环境中独立运行，服务与服务之间采用通信机制(通常是基于Http协议的RESTful API)互相协作. 
```

![](images/QQ截图20200610215539.png)

![](images/QQ截图20200610220251.png)

```java
//技术选型
SpringBoot2.2.2RELEASE版
SpringCloud Hoxton.SR1版
cloud alibaba 2.1.0.RELEASE
java8
Maven3.5
Mysql5.7以上

//SpringBoot git源码地址
https://github.com/spring-projects/spring-boot/releases/   
//SpringBoot 官网
https://spring.io/projects/spring-boot
//springCloud git源码地址
https://github.com/spring-projects/spring-cloud/wiki
//springCloud 官网
https://spring.io/projects/spring-cloud
//查看springcloud对应springboot的版本选择（最底下）
https://spring.io/projects/spring-cloud#overview
https://start.spring.io/actuator/info
```

```java
/*springCloud alibaba 学习资料获取*/

//官网
https://spring.io/projects/spring-cloud-alibaba#overview
//英文
https://github.com/alibaba/spring-cloud-alibaba
https://spring-cloud-alibaba-group.github.io/github-pages/greenwich/spring-cloud-alibaba.html	
//中文
https://github.com/alibaba/spring-cloud-alibaba/blob/master/README-zh.md
```

# 基本项目创建

## **Maven总父工程**

![](images/QQ截图20200610225111.png)

![](images/QQ截图20200610225758.png)

![](images/QQ截图20200610225903.png)

**创建完之后删除src目录....**

## **父工程创建后的常规设置**

![](images/QQ截图20200610230216.png)

![](images/QQ截图20200610230312.png)

![](images/QQ截图20200610230341.png)

![](images/QQ截图20200610230408.png)

## 父pom.xml

![](images/QQ截图20200610232429.png)

```xml
<?xml version="1.0" encoding="UTF-8"?>

<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>

  <groupId>com.huaji.springcloud</groupId>
  <artifactId>cloud2020</artifactId>
  <version>1.0-SNAPSHOT</version>
  <packaging>pom</packaging>
  
  <!-- 统一管理jar包版本 -->
  <properties>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    <maven.compiler.source>1.8</maven.compiler.source>
    <maven.compiler.target>1.8</maven.compiler.target>
    <junit.version>4.12</junit.version>
    <log4j.version>1.2.17</log4j.version>
    <lombok.version>1.16.18</lombok.version>
    <mysql.version>5.1.47</mysql.version>
    <druid.version>1.1.16</druid.version>
    <mybatis.spring.boot.version>1.3.0</mybatis.spring.boot.version>
  </properties>

  <!-- 子模块继承之后，提供作用：锁定版本+子modlue不用写groupId和version  -->
  <dependencyManagement>
    <dependencies>
      <!--微服务标配-->  
      <!--spring boot 2.2.2-->
      <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-dependencies</artifactId>
        <version>2.2.2.RELEASE</version>
        <type>pom</type>
        <scope>import</scope>
      </dependency>
      <!--spring cloud Hoxton.SR1-->
      <dependency>
        <groupId>org.springframework.cloud</groupId>
        <artifactId>spring-cloud-dependencies</artifactId>
        <version>Hoxton.SR1</version>
        <type>pom</type>
        <scope>import</scope>
      </dependency>
      <!--spring cloud alibaba 2.1.0.RELEASE 使用Nacos等需要使用该jar包-->
      <dependency>
        <groupId>com.alibaba.cloud</groupId>
        <artifactId>spring-cloud-alibaba-dependencies</artifactId>
        <version>2.1.0.RELEASE</version>
        <type>pom</type>
        <scope>import</scope>
      </dependency>
 	  <!--mysql依赖-->
      <dependency>
        <groupId>mysql</groupId>
        <artifactId>mysql-connector-java</artifactId>
        <version>${mysql.version}</version>
      </dependency>
        <!--数据源-->
      <dependency>
        <groupId>com.alibaba</groupId>
        <artifactId>druid</artifactId>
        <version>${druid.version}</version>
      </dependency>
        <!--mybatis-->
      <dependency>
        <groupId>org.mybatis.spring.boot</groupId>
        <artifactId>mybatis-spring-boot-starter</artifactId>
        <version>${mybatis.spring.boot.version}</version>
      </dependency>
      <dependency>
        <groupId>junit</groupId>
        <artifactId>junit</artifactId>
        <version>${junit.version}</version>
      </dependency>
      <dependency>
        <groupId>log4j</groupId>
        <artifactId>log4j</artifactId>
        <version>${log4j.version}</version>
      </dependency>
      <dependency>
        <groupId>org.projectlombok</groupId>
        <artifactId>lombok</artifactId>
        <version>${lombok.version}</version>
        <optional>true</optional>
      </dependency>
    </dependencies>
  </dependencyManagement>
       
</project>
```

![](images/QQ截图20200610232859.png)

## 子工程(基本)

```java
/**  1.建module   2.改POM   3.写YML   4.主启动   5.业务类  **/
```

**建module**

![](images/QQ截图20200610233826.png)

![](images/QQ截图20200610234140.png)

![](images/QQ截图20200610234248.png)

**改pom**

```xml
  <dependencies>
      	<!--springBoot标配：每个项目都要-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-actuator</artifactId>
        </dependency>
      
        <!--辅助标配：每个项目都要-->
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
       
      	<!--mybatis与springBoot整合：看项目功能-->
        <dependency>
            <groupId>org.mybatis.spring.boot</groupId>
            <artifactId>mybatis-spring-boot-starter</artifactId>
        </dependency>
      <!--数据库连接池：看项目功能-->
        <dependency>
            <groupId>com.alibaba</groupId>
            <artifactId>druid-spring-boot-starter</artifactId>
        </dependency>
        <!--mysql驱动包：看项目功能-->
        <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
        </dependency>
        <!--jdbc：看项目功能-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-jdbc</artifactId>
        </dependency>
    </dependencies>
```

**写YML**

```yaml
server:
  port: 8001  #服务端口号(如果端口号是80浏览器服务默认的端口号是80，因此只需输入网址即可)
  
spring:
  application:
    name: cloud-payment-service  #微服务的名称，一般命名好了不要轻易改
  datasource:
    type: com.alibaba.druid.pool.DruidDataSource   # 当前数据源操作类型
    driver-class-name: org.gjt.mm.mysql.Driver     # mysql驱动包
    url: jdbc:mysql://localhost:3306/huaji_v01?
    useUnicode=true&characterEncoding=utf-8&useSSL=false
    username: root
    password: 123456

mybatis:
  mapperLocations: classpath:mapper/*.xml
  type-aliases-package: com.huaji.springcloud.entities    # 所有Entity别名类所在包     
```

**主启动**

```java
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentMain8001 {

    public static void main(String[] args) {
        SpringApplication.run(PaymentMain8001.class,args);
    }
}
```

## 子工程(公共)

**1.pom.xml(公共工程只需要加一些基本的工具依赖就行了)**

```xml
  <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-devtools</artifactId>
            <scope>runtime</scope>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>cn.hutool</groupId>
            <artifactId>hutool-all</artifactId>
            <version>5.1.0</version>
        </dependency>
    </dependencies>
```

**2.将一些公共的部分抽取出来放入公共工程中，注意包名要和其他子工程一致**

**3.测试Maven环境**

![](images/QQ截图20200526124414.png)

**4.将原项目的删除后，在各自的pom文件总添加依赖**

```xml
<!--注意名字-->
  <dependency>
        <groupId>com.huaji.springcloud</groupId> <!--包名-->
        <artifactId>cloud-api-commons</artifactId><!--项目名 artifactId名-->
        <version>${project.version}</version>
 </dependency>
```

## 热部署

**第一步：在子工程pom里面添加依赖**

```xml
<!--热部署-->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-devtools</artifactId>
    <scope>runtime</scope>
    <optional>true</optional>
</dependency>
```

**第二步：聚合父类总工程的pom添加依赖**

```xml
    <!--热部署-->
	<build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
                <configuration>
                    <fork>true</fork>
                    <addResources>true</addResources>
                </configuration>
            </plugin>
        </plugins>
    </build>
注意： 不在dependencies里面，放在最底部
```

**第三步：编译设置**

![](images/QQ截图20200526094250.png)

**第四步：ctrl+shift+alt+/**

![](images/QQ截图20200526094826.png)

**第五步：重启idea**

## 技术花絮

```java
// 获取配置文件内容
import org.springframework.beans.factory.annotation.Value;
 @Value("${server.port}")
 private String serverPort;

//休眠3秒
import java.util.concurrent.TimeUnit;
 TimeUnit.SECONDS.sleep(3);

//日志
import lombok.extern.slf4j.Slf4j;
@Slf4j

//实体类注解
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor  //构造函数含有所有已声明字段属性参数
@NoArgsConstructor   //使用后创建一个无参构造函数

//Map Object等参数，一定要加该注解
@RequestBody

//UUID,生成唯一性ID
UUID.randomUUID().toString()

//获取当前时区    
ZonedDateTime zd = ZonedDateTime.now();
System.out.println(zd);
    
httpClient
```

# 服务注册中心

```
什么是服务治理：
	管理服务与服务之间的依赖关系，实现服务调用、负载均衡、容错等，实现服务发现与注册。
什么是服务注册与发现：
	在服务注册与发现中，有一个注册中心。当服务器启动的时候，会把当前自己服务器的信息比如服务地址通讯地址	  等以别名方式注册到注册中心上。另一方（消费者|服务提供者），以该别名的方式去注册中心上获取到实际的服     务通讯地址，然后再实现本地RPC远程调用。
```

## Eureka

```
Eureka有两个组件：
	1.一个是Eureka Server,当各个微服务节点配置启动后会在Eureka Server中进行注册，然后它上面就会		存储所有可用服务节点的信息。(每隔30秒发送一次心跳判断服务是否存在，过了90秒不在就会移除)
	2.另一个是EurekaClient用于服务之间进行交互的，内置了一个使用轮询负载算法的负载均衡器。
```

![](images/QQ截图20200611101327.png)

### **注册中心**

```java
localhost:7001  //进入服务台
```

**改pom**

```xml
<!--子工程(基本)依赖都要-->

<!--eureka-server-->
<dependency>
   	<groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-netflix-eureka-server</artifactId>
</dependency>
<dependency>
    <groupId>junit</groupId>
    <artifactId>junit</artifactId>
</dependency>
```

**写YML**

```yaml
#注册中心可以不需要微服务名，其他的要
###############################单机版##################################
server:
  port: 7001

eureka:
  instance:
    hostname: localhost
  client:
    register-with-eureka: false  #false表示不向注册中心注册自己。
    fetch-registry: false  #false表示自己就是注册中心，职责就是维护服务实例，并不需要去检索服务。
    service-url:
      defaultZone: http://localhost:7001/eureka/
     #defaultZone: http://${eureka.instance.hostname}:${server.port}/eureka/ 
   #server:
   #关闭自我保护机制，保证不可用服务被及时踢除
   #enable-self-preservation: false
   #eviction-interval-timer-in-ms: 2000 
```

![](images/QQ截图20200611111131.png)

```yaml
################################集群版(防止单点故障)################################## 
### --------------------------------7001配置-----------------------------
server:
  port: 7001

eureka:
  instance:
    hostname: eureka7001.com #eureka服务端的实例名称(自定义对应ip的域名)
  client:
    register-with-eureka: false   
    fetch-registry: false 
    service-url:
      #集群指向其它eureka
      defaultZone: http://eureka7002.com:7002/eureka/    
 ### ----------------------------------7002配置-----------------------------
server:
  port: 7002

eureka:
  instance:
    hostname: eureka7002.com #eureka服务端的实例名称(自定义对应ip的域名)
  client:
    register-with-eureka: false    
    fetch-registry: false   
    service-url:
      #集群指向其它eureka
      defaultZone: http://eureka7001.com:7001/eureka/
      
  #多台用逗号分隔    
```

**主启动**

```java
//添加该注解表示Eureka的服务注册中心
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;
@EnableEurekaServer
```

### 服务注册

**改pom**

```xml
<!--子工程(基本)依赖都要-->

<!--eureka-client-->
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
</dependency>
```

**写YML**

```yaml
###############################单机版##################################
eureka:
  client:
    #表示是否将自己注册进EurekaServer默认为true。
    register-with-eureka: true
    #是否从EurekaServer抓取已有的注册信息，默认为true。
    #单节点无所谓，集群必须设置为true才能配合 ribbon使用负载均衡
    fetchRegistry: true
    service-url:
      #单机--注册中心地址
      defaultZone: http://localhost:7001/eureka 
	  #集群版--注册中心地址
      defaultZone: http://eureka7001.com:7001/eureka,http://eureka7002.com:7002/eureka
```

![](images/QQ截图20200611115754.png)

```yaml
#集群的服务提供者[端口号不一样]微服务名是一样的，其他配置都一样
#注意：在使用消费者调用服务者的时候RestTemplate要赋予负载均衡的能力
```

```yaml
#YML其他配置信息:可加可不加。
eureka:
  client:  # 内容省略....用于表示instance和client是平级的	
  instance:
      #主机名称:服务名称修改，就是在控制台Status下显示的那一栏
      instance-id: payment8001
      #访问路径可以显示IP地址
      prefer-ip-address: true
```

**主启动**

```java
//添加该注解
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
@EnableEurekaClient
```

### 补充(服务发现Discovery)

**主启动**

```java
//添加该注解
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
@EnableDiscoveryClient
```

**controller**

```java
import org.springframework.cloud.client.discovery.DiscoveryClient;

@Resource
private DiscoveryClient discoveryClient;

 @GetMapping(value = "/payment/discovery")
 public Object discovery() {
        /*有多少服务*/
        List<String> services = discoveryClient.getServices();
        for (String element : services) {
            log.info("*****element: " + element);
        }
        /*该服务有多少提供者*/
        List<ServiceInstance> instances =
            discoveryClient.getInstances("CLOUD-PAYMENT-SERVICE");
        for (ServiceInstance instance : instances) {
            log.info(instance.getServiceId() 
                     + "\t" + instance.getHost() + "\t" 
                     + instance.getPort() + "\t" + instance.getUri());
        }
        return this.discoveryClient;
    }
```

### 补充(自我保护机制)

```
某时刻某一个微服务不可用了，Eureka不会立刻清理，依旧会对该微服务的信息进行保存属于CAP里面的AP分支。
```

**注册中心改YML**

```yaml
eureka:
  client:  #省略...
  server:
    #关闭自我保护机制，保证不可用服务被及时踢除
    enable-self-preservation: false
    #两秒钟检测
    eviction-interval-timer-in-ms: 2000
```

**服务注册改YML**

```yaml
eureka:
  client:   # 内容省略....用于表示instance和client是平级的	
  instance:	
    #Eureka客户端向服务端发送心跳的时间间隔，单位为秒(默认是30秒)
    lease-renewal-interval-in-seconds: 1
    #Eureka服务端在收到最后一次心跳后等待时间上限，单位为秒(默认是90秒)，超时将剔除服务
    lease-expiration-duration-in-seconds: 2
```

**测试：把服务注册方项目一停止，eureka将马上将其踢出去**

## Zookeeper

![](images/QQ截图20200611125524.png)

```java
//注意：Zookeeper是临时节点
//使用docker启动Zookeeper
```

**改POM**

```xml
<!--子工程(基本)依赖都要-->

<!-- SpringBoot整合zookeeper客户端 -->
    <dependency>
        <groupId>org.springframework.cloud</groupId>
        <artifactId>spring-cloud-starter-zookeeper-discovery</artifactId>
        <!--先排除自带的zookeeper3.5.3-->
        <exclusions>
            <exclusion>
                <groupId>org.apache.zookeeper</groupId>
                <artifactId>zookeeper</artifactId>
            </exclusion>
        </exclusions>
    </dependency>
 <!--添加zookeeper3.4.9版本-->
    <dependency>
        <groupId>org.apache.zookeeper</groupId>
        <artifactId>zookeeper</artifactId>
        <version>3.4.9</version>
    </dependency>
```

**写YML**

```yaml
#服务别名----注册zookeeper到注册中心名称
spring:
  application: #省略...
  cloud:
    zookeeper:
      connect-string: 192.168.5.110:2181  #linux主机名：zookeeper端口号。集群用逗号分隔
```

**主启动**

```java
//该注解用于向使用consul或zookeeper作为注册中心时注册服务
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
@EnableDiscoveryClient
```

## Consul

```java
Consul提供了服务治理，配置中心，控制总线等功能
https://www.consul.io/downloads.html   //下载网址
https://www.springcloud.cc/spring-cloud-consul.html  //中文文档
```

**启动**

![](images/QQ截图20200611163125.png)

**改POM**

```xml
<!--子工程(基本)依赖都要-->

<!--SpringCloud consul-server -->
    <dependency>
        <groupId>org.springframework.cloud</groupId>
        <artifactId>spring-cloud-starter-consul-discovery</artifactId>
    </dependency>
```

**写YML**

```yaml
spring:
  application: #省略...
  cloud:
    consul:
      host: localhost
      port: 8500
      discovery:
      	 service-name: ${spring.application.name}	
#        hostname: 127.0.0.1
```

**主启动**

```java
//该注解用于向使用consul或zookeeper作为注册中心时注册服务
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
@EnableDiscoveryClient
```

![](images/QQ截图20200611170000.png)

## Nacos*

![](images/QQ截图20200614114432.png)

**Nacos下载和安装**

```java
Nacos就是注册中心加配置中心的组合等价于 Eureka + Config + Bus
Nacos是CAP中的AP

https://github.com/alibaba/Nacos    
https://nacos.io/zh-cn/			//下载地址,注意需要JAVA8的环境
https://github.com/alibaba/nacos/tags
http://localhost:8848/nacos    //访问地址
```

![](images/QQ截图20200614103602.png)

**改POM**

```xml
<!--SpringCloud ailibaba nacos,该包天生集成了ribbon，天生具有负载均衡的能力 -->
<dependency>
    <groupId>com.alibaba.cloud</groupId>
    <artifactId>spring-cloud-starter-alibaba-nacos-discovery</artifactId>
</dependency>
```

**写YML**

```yaml
spring:
  application: #省略...
  cloud:
    nacos:
      discovery:
        server-addr: localhost:8848 #配置Nacos地址

#提供者要暴露的
management:
  endpoints:
    web:
      exposure:
        include: '*'
```

```yml
#消费者将要去访问的微服务名称(注册成功进nacos的微服务提供者)--不重要，不是必须的，建议而已
service-url:
  nacos-user-service: http://nacos-payment-provider       
  
@Value("${service-url.nacos-user-service}")
private String serverURL;  
```

**主启动**

```java
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
@EnableDiscoveryClient
```

# 服务调用

## RestTemplate注解(公共)

```
RestTemplate提供了多种便捷访问远程Http服务的方法，
是一种简单便捷的访问restful服务模板类，是Spring提供的用于访问Rest服务的客户端模板工具集。
（url,requestMap,ResponseBean.class）这三个参数分别代表REST请求地址、请求参数、HTTP响应转换被转换成的对象类型。
```

**第一步：注入spring容器**

```java
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class ApplicationContextConfig {

    @Bean
    @LoadBalanced //赋予负载均衡的能力
    public RestTemplate getRestTemplate(){
        return new RestTemplate();
    }
}
```

**第二步：使用**

![](images/QQ截图20200611173946.png)

```java
public static final String PAYMENT_URL = "http://localhost:8001";
public static final String PAYMENT_URL = "http://CLOUD-PAYMENT-SERVICE"; 

@Autowired
private RestTemplate restTemplate;

//......
return restTemplate.postForObject
(PAYMENT_URL + "/payment/create", payment, ResultMsg.class);

restTemplate.getForObject(...);
```

```java
//返回对象为ResponseEntity对象，包含了响应中的一些重要信息，比如响应头，响应状态码，响应体等
  ResponseEntity<CommonResult> entity =
       restTemplate.getForEntity(PAYMENT_URL + "/payment/get/" + id,CommonResult.class);
					//2xx代表成功
    if (entity.getStatusCode().is2xxSuccessful()) {
        return entity.getBody();
    } else {
        return new CommonResult<>(444, "操作失败");
    }
```

![](images/QQ截图20201130183842.png)

## Ribbon

```
主要提供客户端负载均衡和服务调用的一个小组件

LB负载均衡(Load Balance)是什么
就是将用户请求平摊的分配到多个服务上，从而达到系统的HA(高可用).
常见的负载均衡有软件Nginx,LVS,硬件F5等。

Ribbon负载均衡和Nginx负载均衡的区别
Nginx是服务器负载均衡，客户端所有请求都会交给Nginx，然后由nginx实现转发请求。即负载均衡是由服务端实现
Ribbon本地负载均衡，在调用微服务接口时候，会在注册中心上获取注册信息服务列表，从而在本地实现远程服务调用技术。
```

```
Ribbon工作分为两步
第一会先选择在同一区域内负载较少的server.
第二再根据用户指定的策略，从server取到的服务注册列表中选择一个地址。其中Ribbon提供了多种策略：
比如轮询、随机、和根据响应时间加权
```

![](images/QQ截图20200611172402.png)

**改POM**

```xml
<!--本来Ribbon需要引入以下依赖，但新版的eureka已经和Ribbon做了整合所以就不需要引了-->
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-netflix-ribbon</artifactId>
</dependency>
```

**负载均衡规则**

![](images/QQ截图20200611174515.png)

![](images/QQ截图20200611175347.png)

**负载均衡算法**

![](images/QQ截图20200611175714.png)

![](images/QQ截图20200611180855.png)

![](images/QQ截图20200611181132.png)

## OpenFeign*

```java
//官网地址
https://cloud.spring.io/spring-cloud-static/Hoxton.SR1/reference/htmlsingle/#spring-cloud-openfeign
```

```
Ribbon+RestTemplate它是一套模板化的调用方法，但开发中服务依赖可能不止一处，往往一个接口会被多出调用，所以通常都会针对每个微服务自行封装一些客户端类来包装这些依赖服务的调用。
Fegin就是在这基础上做了进一步封装，由它来实现依赖服务接口的定义，使用的时候创建一个接口并使用注解的方式来配置它就可以了
OpenFeign是Spring Cloud在Feign的基础上添加了springMVC注解的支持
```

**改POM**

```xml
    <dependency>
        <groupId>org.springframework.cloud</groupId>
        <artifactId>spring-cloud-starter-openfeign</artifactId>
    </dependency>
```

**写YML**

![](images/QQ截图20200611192022.png)

```yaml
#设置feign客户端超时时间(OpenFeign默认支持ribbon)
ribbon:
##指的是建立连接所用的时间，适用于网络状况正常的情况下,两端连接所用的时间
  ReadTimeout: 5000
##指的是建立连接后从服务器读取到可用资源所用的时间
  ConnectTimeout: 5000
```

![](images/QQ截图20200611192431.png)

![](images/QQ截图20200611192531.png)

```yaml
logging:
  level:
    # feign日志以什么级别监控哪个接口
    com.huaji.springcloud.service.PaymentFeignService: debug
```

**主启动**

```java
import org.springframework.cloud.openfeign.EnableFeignClients;
@EnableFeignClients
```

**service接口**

![](images/QQ截图20200611190644.png)

![](images/QQ截图20200611190925.png)

# 服务降级

```
微服务链路中互相调用，A调用B,B调用C,如果某个链路出现问题了就会发生级联故障，就是所谓的雪崩。
```

## Hystrix

```
主要解决的是分布式链路系统中，某一链路发生超时、异常等情况，不会导致整体服务失败，避免级联故障。
“断路器”某个链路或者说服务单元发生故障后，向调用方返回一个符合预期可处理的备选响应，而不是长时间的等待或者抛出调用方法处理的异常，这样保证了服务调用方的线程不会被长时间不必要地占用，从而避免故障在分布式系统中蔓延，乃至雪崩。
```

 **改POM**

```xml
   <!--hystrix-->
    <dependency>
        <groupId>org.springframework.cloud</groupId>
        <artifactId>spring-cloud-starter-netflix-hystrix</artifactId>
    </dependency>
```

**写YML**

```yaml
#客户端调用用OpenFeign所以要让它支持hystrix
feign:
  hystrix:
    enabled: true
```

**主启动**

```java
//回路的意思
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
@EnableCircuitBreaker
//客户端如果使用OpenFeign用这个就行了
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
@EnableHystrix
```

### **服务降级**

```
向调用方返回一个符合预期可处理的备选响应，而不是长时间的等待或者抛出调用方法处理的异常。
程序异常，超时，服务熔断触发。(注意：服务降级可以放在服务端也可以放在客户端，但一般放在客户端)
```

**普通方式**

```java
 //方法处理超过3秒或者逻辑报错，都是使用兜底的方法处理，作为服务降级
    @HystrixCommand(fallbackMethod = "paymentInfo_TimeOutHandler", 
                    commandProperties = {@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "3000") //线程的超时时间为3秒
    })
    public String paymentInfo_TimeOut(Integer id) {
        //省略......
    }

	//兜底的方法
    public String paymentInfo_TimeOutHandler(Integer id) {
        return "线程池:" + Thread.currentThread().getName() + " " + id ;
    }
```

**全局方式**

```java
@DefaultProperties(defaultFallback = "payment_Global_FallbackMethod")
public class OrderHystirxController {
    
    //如果方法没指定局部兜底方法，则使用全局通用的
    @HystrixCommand
    public String paymentInfo_TimeOut(@PathVariable("id") Integer id) {
       //省略...
    }
    
     // 全局通用的兜底方法
    public String payment_Global_FallbackMethod() {
       //省略...
    }
    
}
```

**结合OpenFeign方式**

```java
//注解添加 fallback属性，值为实现类名
@FeignClient(value = "CLOUD-PROVIDER-HYSTRIX-PAYMENT",
             fallback = PaymentFallbackService.class)
@Component
public interface PaymentHystrixService
{
    @GetMapping("/payment/hystrix/ok/{id}")
    public String paymentInfo_OK(@PathVariable("id") Integer id);

    @GetMapping("/payment/hystrix/timeout/{id}")
    public String paymentInfo_TimeOut(@PathVariable("id") Integer id);
}


//接口实现类
import org.springframework.stereotype.Component;

@Component
public class PaymentFallbackService implements PaymentHystrixService {
    @Override
    public String paymentInfo_OK(Integer id) {
        return "我是服务降级A";
    }

    @Override
    public String paymentInfo_TimeOut(Integer id) {
        return "我是服务降级B";
    }
}
```

### **服务熔断**

```
熔断就像险丝达一样是一种保护程序链路的一种方式，当某个链路出现响应时间太长或者报错等问题，则会开启熔断让请求不再调用当前服务；然后过了一会会尝试让部分请求通过，如果请求正常，再关闭熔断。
断路器开启或关闭的条件：
当满足一定的阀值的时候(默认是10秒内超过20个请求次数)
当失败率达到一定的时候（默认是10秒内超过50%的请求失败）
关闭时长默认是5秒，然后尝试让其中一个请求通过,如果成功则关闭，如果失败则继续关闭
```

![](images/QQ截图20200612111039.png)

![](images/QQ截图20200612111134.png)

```java
  //=====服务熔断
  //在时间窗口期（10000毫秒）内，请求次数(10)，失败率（60）达到多少，则跳闸
    @HystrixCommand(fallbackMethod = "paymentCircuitBreaker_fallback",    commandProperties = {
  // 是否开启断路器
  @HystrixProperty(name = "circuitBreaker.enabled", value = "true"),
  // 请求次数
  @HystrixProperty(name = "circuitBreaker.requestVolumeThreshold", value = "10"),
  // 时间窗口期
  @HystrixProperty(name = "circuitBreaker.sleepWindowInMilliseconds", value = "10000"), 
  // 失败率达到多少后跳闸
  @HystrixProperty(name = "circuitBreaker.errorThresholdPercentage", value = "60"),
    } )
    public String paymentCircuitBreaker(@PathVariable("id") Integer id) {
    		//省略...
    }
	
	//兜底的方法
    public String paymentCircuitBreaker_fallback(@PathVariable("id") Integer id) {
          //省略...
    }
```

### **服务监控**

```
将每秒执行多少次、请求多少成功、多少失败等信息，用图形化的方式展示出来
```

**改POM**

```xml
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-netflix-hystrix-dashboard</artifactId>
</dependency>
```

```xml
<!--所有需要监控的项目都需要添加这个依赖，一般来说都子工程(基本)就配了，在这里只是重声下-->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-actuator</artifactId>
</dependency>
```

**写YML**

```yaml
server:
  port: 9001
```

**主启动**

```java
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
@EnableHystrixDashboard
```

**被监控的项目上配置一下，这是一个小坑**

![](images/QQ截图20200612114817.png)

![](images/QQ截图20200612115251.png)

![](images/QQ截图20200612115616.png)

## sentienl*

```java
https://github.com/alibaba/Sentinel/wiki/%E4%BB%8B%E7%BB%8D  //文档
https://spring-cloud-alibaba-group.github.io/github-pages/greenwich/spring-cloud-alibaba.html#_spring_cloud_alibaba_sentinel

主要是防止服务雪崩、服务降级、服务熔断、服务限流

Sentinel分为两个部分：
.核心库（Java 客户端）不依赖任何框架/库，能够运行于所有java运行时环境，同时对Dubbo/springCloud等框架也有较好的支持
.控制台（Dashboard）基于SpringBoot开发，打包后可以直接运行，不需要额外的Tomcat等应用容器
```

```java
https://github.com/alibaba/Sentinel/releases   //下载地址

//运行的前提是java8 以及8080端口不能被占用
cmd 
java -jar sentinel-dashboard-1.7.0.jar
//进入页面 用户名和密码都是 sentinel  
localhost:8080  
```

**改POM**

```xml
    <!--SpringCloud ailibaba nacos -->
    <dependency>
        <groupId>com.alibaba.cloud</groupId>
        <artifactId>spring-cloud-starter-alibaba-nacos-discovery</artifactId>
    </dependency>
    <!--SpringCloud ailibaba sentinel-datasource-nacos 后续做持久化用到-->
    <dependency>
        <groupId>com.alibaba.csp</groupId>
        <artifactId>sentinel-datasource-nacos</artifactId>
    </dependency>
    <!--SpringCloud ailibaba sentinel -->
    <dependency>
        <groupId>com.alibaba.cloud</groupId>
        <artifactId>spring-cloud-starter-alibaba-sentinel</artifactId>
    </dependency>
```

**写YML**

```yaml
spring:
  application: #省略...
  cloud:
    nacos:
      discovery:
        server-addr: localhost:8848 #Nacos服务注册中心地址
    sentinel:
      transport:
        dashboard: localhost:8080 #配置Sentinel dashboard地址
         #默认8719端口，假如被占用会自动从8719开始依次+1扫描,直至找到未被占用的端口
        port: 8719
        
management:
  endpoints:
    web:
      exposure:
        include: '*'       
        
feign:
  sentinel:
    enabled: true # 激活Sentinel对Feign的支持        
```

**主启动**

```java
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
@EnableDiscoveryClient
```

### 流控规则

![](images/QQ截图20200614155411.png)

![](images/QQ截图20200614155537.png)

![](images/QQ截图20200613233053.png)

![](images/QQ截图20200614155848.png)

### 服务降级

```
https://github.com/alibaba/Sentinel/wiki/%E7%86%94%E6%96%AD%E9%99%8D%E7%BA%A7
```

![](images/QQ截图20200614180309.png)

![](images/QQ截图20200614180630.png)

![](images/QQ截图20200614180803.png)

### 热点Key限流

```
https://github.com/alibaba/Sentinel/wiki/%E7%83%AD%E7%82%B9%E5%8F%82%E6%95%B0%E9%99%90%E6%B5%81
```

![](images/QQ截图20200614200142.png)

```java
@GetMapping("/testHotKey")
@SentinelResource(value = "testHotKey", blockHandler = "deal_testHotKey")
public String testHotKey(@RequestParam(value = "p1", required = false) String p1,
                         @RequestParam(value = "p2", required = false) String p2) {
    //int age = 10/0;
    return "------testHotKey";
}

public String deal_testHotKey(String p1, String p2, BlockException exception){
    //sentinel系统默认的提示：Blocked by Sentinel (flow limiting)
    return "------deal_testHotKey,o(╥﹏╥)o"; 
}
```

![](images/QQ截图20200614181758.png)

### 系统规则

```
https://github.com/alibaba/Sentinel/wiki/%E7%B3%BB%E7%BB%9F%E8%87%AA%E9%80%82%E5%BA%94%E9%99%90%E6%B5%81
```

![](images/QQ截图20200614183617.png)

### 服务熔断

```java
    @RequestMapping("/consumer/fallback/{id}")
    //fallback只负责业务异常
    //blockHandler只负责sentinel控制台配置违规
    //IllegalArgumentException.class 表示发生这个异常不会进入兜底方法，而是直接抛出这个异常
    @SentinelResource(value = "fallback",fallback = "handlerFallback",
                      blockHandler = "blockHandler",
           			  exceptionsToIgnore = {IllegalArgumentException.class})
    public CommonResult<Payment> fallback(@PathVariable Long id) {
		
    }

    //本例是fallback
    public CommonResult  handlerFallback(@PathVariable  Long id,Throwable e) {
       	System.out.println(e.getMessage());
        //省略...
    }
    //本例是blockHandler
    public CommonResult blockHandler(@PathVariable  Long id,
                                     BlockException blockException) {
      	System.out.println(blockException.getMessage());
        //省略...
    }
```

### 持久化规则

**改POM**

```xml
<!--SpringCloud ailibaba sentinel-datasource-nacos 后续做持久化用到-->
<dependency>
    <groupId>com.alibaba.csp</groupId>
    <artifactId>sentinel-datasource-nacos</artifactId>
</dependency>
```

**写YML**

```yaml
spring:
  application:
    name: cloudalibaba-sentinel-service
  cloud:
    sentinel:
      transport: #省略...
      datasource:
        dsl:
          nacos:
            server-addr: localhost:8848
            dataId: ${spring.application.name}
            groupId: DEFAULT_GROUP
            data-type: json
            rule-type: flow
```

![](images/QQ截图20200614215711.png)

```
[
  {
        "resource": "/rateLimit/byUrl",
        "limitApp": "default",
        "grade": 1,
        "count": 1,
        "strategy": 0,
        "controlBehavior": 0,
        "clusterMode": false
    }
]

resource:资源名称
limitApp:来源应用
grade:阀值类型，0表示线程数，1表示QPS
count:单机阀值
strategy:流控模式，0表示直接，1表示关联，2表示链路
controlBehavior:流控效果，0表示快速失败，1表示Warm Up 2表示排队等待
clusterMode:是否集群
```

# 服务网关

## Gateway

```java
让它统一的挡在前面进行 反向代理 日志 限流 权鉴 安全加固等等工作
//官网
https://cloud.spring.io/spring-cloud-static/spring-cloud-gateway/2.2.1.RELEASE/reference/html/
//关于单一过滤
https://cloud.spring.io/spring-cloud-static/spring-cloud-gateway/2.2.1.RELEASE/reference/html/#gatewayfilter-factories
```

![](images/QQ截图20200612175431.png)

```
Route(路由) 路由是构建网关的基本模块，它由ID,目标URL,一系列的断言和过滤器组成，如果断言为true则匹配
Predicate(断言)
Filter(过滤)可以在请求被路由前或者之后对请求进行修改

工作流程：
客户端向Gateway发送请求，然后在Gateway Handler Mapping中找到与请求相匹配的路由进行转发，然后我们再通过过滤器将请求发送到我们实际干活的逻辑上。过滤器还可以在代理请求前(pre)或请求后(post)执行一些业务逻辑。

Filter在pre类型的过滤可以做参数校验，权限校验，流量监控，日志输出，协议转换等，
在post类型的过滤器中可以做响应内容，响应头的修改，日志的输出，流量监控等
```

**改POM**

```xml
   <!--gateway-->
    <dependency>
        <groupId>org.springframework.cloud</groupId>
        <artifactId>spring-cloud-starter-gateway</artifactId>
    </dependency>

    <!--注意！注意！住址！：网关需要 "排除" 这两个依赖-->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-actuator</artifactId>
    </dependency>
```

**写YML**

![](images/QQ截图20200612193851.png)

```java
//路由配置的第二种方式：
package com.huaji.springcloud.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GateWayConfig {
    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder routeLocatorBuilder) {
        RouteLocatorBuilder.Builder routes = routeLocatorBuilder.routes();
        //相当于 localhost:9527/guonei 就能跳到 http://news.baidu.com/guonei
        routes.route("path_route_atguigu",
                r -> r.path("/guonei")
                        .uri("http://news.baidu.com/guonei")).build();

        return routes.build();
    }
}
```

![](images/QQ截图20200612200820.png)

```yaml
########################## 普通路由匹配 ###########################################
spring:
  application: #省略....
  cloud:
    gateway:
      routes:
        - id: payment_routh #路由的ID，没有固定规则但要求唯一，建议配合服务名
          uri: http://localhost:8001          #匹配后提供服务的路由地址
          predicates:
            - Path=/payment/get/**         # 断言，路径相匹配的进行路由

        - id: payment_routh2  #路由的ID，没有固定规则但要求唯一，建议配合服务名
          uri: http://localhost:8001     
          predicates:
            - Path=/payment/lb/**         # 断言，路径相匹配的进行路由
           #- After=2020-05-29T13:37:50.774+08:00[Asia/Shanghai]
           #- Before=2020-05-29T13:37:50.774+08:00[Asia/Shanghai]
           #- Cookie=username,zzyy
           #- Header=X-Request-Id, \d+  # 请求头要有X-Request-Id属性并且值为整数的正则表达式
########################## 负载均衡动态路由匹配 #####################################
spring:
  application: #省略....
  cloud:
    gateway:
      discovery:
        locator:
          enabled: true #开启从注册中心动态创建路由的功能，利用微服务名进行路由
      routes:
        - id: payment_routh #路由的ID，没有固定规则但要求唯一，建议配合服务名
          uri: lb://cloud-payment-service #lb(负载均衡）://cloud-payment-service(服务名)
          predicates:
            - Path=/payment/get/**         # 断言，路径相匹配的进行路由

        - id: payment_routh2  #路由的ID，没有固定规则但要求唯一，建议配合服务名
          uri: lb://cloud-payment-service #匹配后提供服务的路由地址
          predicates:
            - Path=/payment/lb/**         # 断言，路径相匹配的进行路由
            
#---
#注册进eureka，此处和前者有些许不同，故而这里重写下
eureka:
  instance:
      hostname: cloud-gateway-service
  client: #服务提供者provider注册进eureka服务列表内
    service-url:
      register-with-eureka: true
      fetch-registry: true
      defaultZone: http://eureka7001.com:7001/eureka            
```

![](images/QQ截图20200612202322.png)

**主启动**

```java
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
@EnableEurekaClient
```

**单一过滤器**

```
https://cloud.spring.io/spring-cloud-static/spring-cloud-gateway/2.2.1.RELEASE/reference/html/#gatewayfilter-factories
```

**自定义拦截器**

```java
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.Date;

@Component
@Slf4j
public class MyLogGateWayFilter implements GlobalFilter,Ordered{

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain){
        log.info("***********come in MyLogGateWayFilter:  "+new Date());
        String uname = exchange.getRequest().getQueryParams().getFirst("uname");

        if(uname == null){
            log.info("*******用户名为null，非法用户，o(╥﹏╥)o");
            exchange.getResponse().setStatusCode(HttpStatus.NOT_ACCEPTABLE);
            return exchange.getResponse().setComplete();
        }
        return chain.filter(exchange);
    }

    //过滤器的顺序一般值越小，优先级越高
    @Override
    public int getOrder(){
        return 0; 
    }
}
```

# 服务配置

```
微服务每个服务粒度相对较小，因此系统中会出现大量的服务，由于每个服务都需要配置信息才能运行，所以一套集中式的，动态配置管理设施是必不可少的
```

## Config

```
SpringCloud为各个微服务应用提供了一个中心化的外部配置
```

![](images/QQ截图20200612212201.png)

![](images/QQ截图20200612214347.png)

### 服务端(配置中心)

```
在GitHub上建一个名为springcloud-config的新Repository,获取git地址
```

**改POM**

```xml
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-config-server</artifactId>
</dependency>
```

**写YML**

```yaml
spring:
  application: #省略......
  cloud:
    config:
      server:
        git:   
          #GitHub上面的git仓库名字
          uri: git@github.com:wxq292775032com/springcloud-config.git 
          #搜索目录
          search-paths:
            - springcloud-config
      ####读取分支
      label: master
      

#服务注册到eureka地址
eureka:
  client:
    service-url:
      defaultZone: http://localhost:7001/eureka      
```

**主启动**

```java
import org.springframework.cloud.config.server.EnableConfigServer;
@EnableConfigServer
```

![](images/QQ截图20200612215015.png)

### 客户端（Client）

**改POM**

```xml
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-config</artifactId>
</dependency>

<!--此处做重申该依赖需要加（除了网关一般都会加），它的意思是我自身发生变化了能被别人监控到-->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-actuator</artifactId>
</dependency>
```

**写YML**

```yaml
#此处使用bootstrap.yml
#application.yml是用户资源配置、bootstrap.yml是系统级，优先级更高。

spring:
  application: #省略...
  cloud:
    #Config客户端配置
    config:
      #下述3个综合：master分支上config-dev.yml的配置文件被读取
      #http://locaohost:3344/master/config-dev.yml
      label: master #分支名称
      name: config #配置文件名称
      profile: dev #读取后缀名称   
      uri: http://localhost:3344 #服务端配置中心地址

#服务注册到eureka地址
eureka:
  client:
    service-url:
      defaultZone: http://localhost:7001/eureka
      
# 暴露监控端点
management:
  endpoints:
    web:
      exposure:
        include: "*"      
```

**关于客户端刷新问题**

```
如Linux运维修改GitHub上的配置文件内容做调整，服务端能即使响应，客户端则不能。
```

![](images/QQ截图20200612222534.png)

## Nacos*

**改POM**

```xml
   <!--nacos-config-->
    <dependency>
        <groupId>com.alibaba.cloud</groupId>
        <artifactId>spring-cloud-starter-alibaba-nacos-config</artifactId>
    </dependency>
    <!--nacos-discovery-->
    <dependency>
        <groupId>com.alibaba.cloud</groupId>
        <artifactId>spring-cloud-starter-alibaba-nacos-discovery</artifactId>
    </dependency>
```

**写YML**

```
项目初始化时，要保证先从配置中心进行配置拉取，拉取配置之后，才能保证项目的正常启动。
bootstrap优先级高于application
```

```yaml
### application.yml
spring:
  profiles:
    active: dev # 表示开发环境
    #active: test # 表示测试环境
    #active: info
```

```yaml
### bootstrap.yml
spring:
  application: #省略...
  cloud:
    nacos:
      discovery: #省略...
      config:
        server-addr: localhost:8848 #Nacos作为配置中心地址
        file-extension: yaml #指定yaml格式的配置
        group: TEST_GROUP  #分组
        namespace: 14787d5e-7620-4fcb-a806-63afbcdf622a  #命名空间
        
# ${spring.application.name}-${spring.profile.active}.${spring.cloud.nacos.config.file-extension}
# nacos-config-client-dev.yaml        
```

![](images/QQ截图20200614122121.png)

![](images/QQ截图20200614122147.png)

**controller**

```java
@RefreshScope //支持Nacos的动态刷新功能。
```

**命名空间/分组/DataID**

![](images/QQ截图20200614134414.png)

![](images/QQ截图20200614134843.png)

![](images/QQ截图20200614135054.png)

![](images/QQ截图20200614135153.png)

# 服务总线

## Bus

![](images/QQ截图20200612223446.png)

```
总线：就是一个消息主题一个广播，让很多的实例连上来，各个实例都可以方便地广播让其他实例都知道的消息。

基本原理：ConfigCient实例都监听MQ中统一topic(默认是springCloudBus).当一个服务刷新数据的时候，
就会把这个信息放入到Topic中，这样其他监听同一Topic的服务就能得到通知，然后去更新自身的配置
```

```java
//虚拟机docker启动RabbitMQ
```

**改POM**

```xml
<!--添加消息总线RabbitMQ支持-->
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-bus-amqp</artifactId>
</dependency>
```

**写YML**

```yaml
spring:
  #rabbitmq相关配置
  rabbitmq:
    host: 192.168.5.103
    port: 5672
    username: guest
    password: guest
    
##rabbitmq相关配置,暴露bus刷新配置的端点
management:
  endpoints: #暴露bus刷新配置的端点
    web:
      exposure:
        include: 'bus-refresh'
       #include: "*"     或者用*
```

**刷新**

![](images/QQ截图20200613190831.png)

```java
http://localhost:3344/actuator/bus-refresh   //刷新
//单独刷新(config-client服务名)
http://localhost:3344/actuator/bus-refresh/config-client:3355 
```

## Stream(消息驱动)

```java
https://spring.io/projects/spring-cloud-stream#overview    //官网
https://m.wang1314.com/doc/webapp/topic/20971999.html   //中文版

作用：屏蔽消息中间件的差异，降低切换成本，统一消息的编程模型。
运作：通过inputs 或 outputs 来与 SpringCloud Stream的binder对象交互，而binder对象负责与消息中间件交互。
三个核心概念：发布-订阅、消费组、分区

现在只支持： kafaka  rabbitMQ

关于注解：
	Binder 很方便的连接中间件，屏蔽差异
	Channel 通道，在消息通讯中实现存储和转发的媒介
	Source和Sink 发布消息（输出），接受消息（输入）
```

![](images/QQ截图20200613220821.png)

![](images/QQ截图20200613221445.png)

**改POM**

```xml
<!--Stream和Rabbit整合的依赖-->
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-stream-rabbit</artifactId>
</dependency>
```

**写YML**

```yaml
spring:
  application: #省略...
  cloud:
      stream:
        binders: # 在此处配置要绑定的rabbitmq的服务信息；
          defaultRabbit: # 表示定义的名称，用于于binding整合
            type: rabbit # 消息组件类型,表示用的是RabiitMQ
            environment: # 设置rabbitmq的相关的环境配置
              spring:
                rabbitmq:
                  host: 192.168.5.103  
                  port: 5672
                  username: guest
                  password: guest
        bindings: # 服务的整合处理
          output: # 这个名字是一个通道的名称,表示这是一个消息的生产者发送(消息推送管道)
         #input:  #表示消息的消费者，接受者（消息接受管道） 
            destination: studyExchange # 表示要使用的Exchange名称定义，约定好的通道名
            # 设置消息类型，本次为json，文本则设置“text/plain”
            content-type: application/json 
            binder: defaultRabbit # 设置要绑定的消息服务的具体设置
         #  group: atguiguA     #group用于消费接受者 （重要，下方有描述）      
```

```yaml
#关于 group 属性可以解决两个问题
#1.重复消费：（不同组全面消费，同一组竞争消费）
	#如果多个消费者不在一个组上，那么消息生产假如发送一条消息，那么各个消费者都会收到这一条消息。
	#如果多个消费者在一个组上，消息生产者如果发送一条消息，那么这条消息只会让一个消费者收到，如果多条消	   息，消息者会轮流接受。
#2.消息持久化：如果消费者配置了group属性，即使项目停止后，再启动也能收到消息，没配置则不会收到。
```

**消息推送管道**

```java
import com.huaji.springcloud.service.IMessageProvider;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.messaging.MessageChannel;
import org.springframework.integration.support.MessageBuilder;

import javax.annotation.Resource;

import org.springframework.cloud.stream.messaging.Source;

import java.util.UUID;

@EnableBinding(Source.class) //定义消息的推送管道
public class MessageProviderImpl implements IMessageProvider {
    @Resource
    private MessageChannel output; // 消息发送管道

    @Override
    public String send() {
        String serial = UUID.randomUUID().toString();
        output.send(MessageBuilder.withPayload(serial).build());
        return null;
    }
}
```

**消息接受管道**

```java
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.cloud.stream.messaging.Sink;
import org.springframework.stereotype.Component;
import org.springframework.messaging.Message;

@Component
@EnableBinding(Sink.class)
public class ReceiveMessageListenerController {
    
    @StreamListener(Sink.INPUT)
    public void input(Message<String> message){
        System.out.println("接受到的消息: "+message.getPayload());
    }
}
```

## Sleuth(分布式请求链路跟踪)

![](images/QQ截图20200613232917.png)

```java
https://dl.bintray.com/openzipkin/maven/io/zipkin/java/zipkin-server/  //下载地址
```

![](images/QQ截图20200613233649.png)

**改POM**

```xml
 <!--包含了sleuth+zipkin-->
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-zipkin</artifactId>
</dependency>
```

**写YAM**

```yaml
spring:
  application: #省略...
  zipkin:
    base-url: http://localhost:9411
  sleuth:
    sampler:
      #采样率值介于 0 到 1 之间，1 则表示全部采集,一般用0.5
      probability: 1
```

## Nacos*

# Nacos集群和持久化配置

```
https://nacos.io/zh-cn/docs/cluster-mode-quick-start.html
```

![](images/QQ截图20200614140954.png)

**nacos切换成mysql数据库**

![](images/QQ截图20200614141119.png)

![](images/QQ截图20200614141145.png)

```properties
###################################################################
spring.datasource.platform=mysql

db.num=1
db.url.0=jdbc:mysql://192.168.5.105:3306/nacos_config?
characterEncoding=utf8&connectTimeout=1000&socketTimeout=3000&autoReconnect=true
db.user=root
db.password=123456
```

**linux上nacos的集群配置**

```java
//第一步： 
	进入linux中的nacos里的conf目录，对application.properties切换成mysql
	(nacos-mysql脚本要先执行哦)。
	application.properties.example 为demo案例。
//第二步：
	拷贝 cluster.conf.example 名字为 cluster.conf然后对其进行修改 。
    cp cluster.conf.example  cluster.conf
    vi cluster.conf
    例：
		192.168.5.105:3333
		192.168.5.105:4444
		192.168.5.105:5555
//第三步：
    编辑nacos的启动脚本 startUp.sh
```

![](images/QQ截图20200614141755.png)

​													    -Dserver.port=${PORT}	

```java
//第四步：执行方式
[root@localhost bin]#   ./startup.sh -p 3333
[root@localhost bin]#   ./startup.sh -p 4444
[root@localhost bin]#   ./startup.sh -p 5555
//查看启动个数
ps -ef | grep nacos | grep -v grep| wc -l 
```

**nginx的配置，由它作为负载均衡器**

![](images/QQ截图20200614141915.png)

# Seata

**分布式事务管理问题**

![](images/QQ截图20200615105339.png)

**理论介绍**

```java
http://seata.io/zh-cn/
https://github.com/seata/seata/releases/tag/v1.2.0   //下载
```

![](images/QQ截图20200615113403.png)

![](images/QQ截图20200615145232.png)

![](images/QQ截图20200615113719.png)

![](images/QQ截图20200615145537.png)

**Seata安装配置**

```
第一步： 自定义事务组名称。
第二步： 事务日志存储模式为DB,并修改mysql连接信息。
第三步： 创建seata数据库，并将seata/conf目录下的db_store.sql脚本进行运行。
lock_table  行锁  、global_table 全局 、branch_table 分支
（1.0以后要下载source code里面的脚本）
第四步： 指明注册中心为nacos，并修改nacos连接信息
第五步： bin/seata-server.bat  双击运行，注意nacos要先启动
```

![](images/QQ截图20200615114356.png)

![](images/QQ截图20200615114425.png)

**案例实践**

```
Seata是蚂蚁金服和阿里巴巴共同开源的分布式事务解决方案
请使用1.0以后的版本，0.9的不支持集群
```

```
这里我们创建三个服务，一个订单服务，一个库存服务，一个账户服务

当用户下单时，会在订单服务中创建一个订单，然后通过远程调用库存服务来扣减下单商品的库存
再通过远程调用账户服务来扣减用户账户里面的余额
最后在订单服务中修改订单状态为已完

该操作跨越三个数据库，有两次远程调用，很明显会有分布式事务问题
下订单 扣库存 减余额
```

```
重要！重要！重要！
每个数据库下都要建个seata日志回滚表，脚本在：seata\conf目录下的db_undo_log.sql
```

**改POM**

```xml
<!--nacos-->
<dependency>
    <groupId>com.alibaba.cloud</groupId>
    <artifactId>spring-cloud-starter-alibaba-nacos-discovery</artifactId>
</dependency>
<!--seata排除原本的使用0.9-->
<dependency>
    <groupId>com.alibaba.cloud</groupId>
    <artifactId>spring-cloud-starter-alibaba-seata</artifactId>
    <exclusions>
        <exclusion>
            <artifactId>seata-all</artifactId>
            <groupId>io.seata</groupId>
        </exclusion>
    </exclusions>
</dependency>
<dependency>
    <groupId>io.seata</groupId>
    <artifactId>seata-all</artifactId>
    <version>0.9.0</version>
</dependency>
<!--feign-->
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-openfeign</artifactId>
</dependency>
```

**写YML**

```yaml
server:
  port: 2020

spring:
  application:
    name: seata-order-service
  cloud:
    alibaba:
      seata:
        #自定义事务组名称需要与seata-server中的对应
        tx-service-group: fsp_tx_group
    nacos:
      discovery:
        server-addr: localhost:8848
  datasource:
    driver-class-name: com.mysql.jdbc.Driver
    url: jdbc:mysql://192.168.5.104:3306/seata_order
    username: root
    password: 123456

#OpenFeign需要用到则加
feign:
  hystrix:
    enabled: false

logging:
  level:
    io:
      seata: info

mybatis:
  mapperLocations: classpath:mapper/*.xml
```

![](images/QQ截图20200615142701.png)

**主启动**

```java
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableDiscoveryClient
@EnableFeignClients
@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)//取消数据源的自动创建
```

**使用seata做数据源代理**

```java
import com.alibaba.druid.pool.DruidDataSource;
import io.seata.rm.datasource.DataSourceProxy;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.transaction.SpringManagedTransactionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import javax.sql.DataSource;

/**
 * 使用Seata对数据源进行代理
 */
@Configuration
public class DataSourceProxyConfig {

    @Value("${mybatis.mapperLocations}")
    private String mapperLocations;

    @Bean
    @ConfigurationProperties(prefix = "spring.datasource")
    public DataSource druidDataSource(){
        return new DruidDataSource();
    }

    @Bean
    public DataSourceProxy dataSourceProxy(DataSource dataSource) {
        return new DataSourceProxy(dataSource);
    }

    @Bean
    public SqlSessionFactory sqlSessionFactoryBean
        (DataSourceProxy dataSourceProxy) throws Exception {
        
        SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
        sqlSessionFactoryBean.setDataSource(dataSourceProxy);
        sqlSessionFactoryBean.setMapperLocations(
            new PathMatchingResourcePatternResolver().getResources(mapperLocations));
        sqlSessionFactoryBean.setTransactionFactory(
            new SpringManagedTransactionFactory());
        return sqlSessionFactoryBean.getObject();
    }
}
```

**service**

```java
@Service
public class OrderServiceImpl implements OrderService {
    
    //省略....
    
    @Override					//名字随便取，要唯一		//rollbackFor发生任何异常通通回滚
    @GlobalTransactional(name = "fsp-create-order", rollbackFor = Exception.class)
    public void create(Order order) {
        //省略....
    }
}
```

# 雪花算法（分布式全局ID唯一）

```
   在复杂分布式系统中，往往需要对大量的数据和消息进行唯一标识，如在美团点评的金融、支付、餐饮、酒店
猫眼电影等产品的系统中数据日渐增长、对数据分库分表后需要有一个唯一ID来标识一条数据或消息；
```

```
ID生成规则部分硬性要求：
    1.全局唯一
        不能出现重复的ID号
    2.趋势递增
         在MySQL的InnoDB引擎中使用的是聚集索引
         由于多数RDBMS使用Btree的数据结构来存储索引数据
         在主键的选择上面我们应该尽量使用有序的键保证写入的性能
    3.单调递增     
         保证下一个ID一定大于上一个ID,例如事务版本号、IM增量消息、排序等特殊需求
    4.信息安全
        如果ID是连续的，恶意用户的拔取工作容易做了，直接按照顺序下载指定URL即可；
        如果是订单号就更危险了，竞对可以直接知道我们一天的单量。
        所以在一些应用场景下，需要ID无规则不规则，让竞争对手不好猜   
    5.含时间戳
        这样就能够在开发中快速了解这个分布式id的生成时间  

ID号生成系统的可用性要求：
  高可用
      发一个获取分布式ID的请求，服务器就要保证99.99%的情况下创建一个
      分布式系统的唯一ID
  低延迟
      发一个获取分布式ID的请求，服务器就要快，极速
  高QPS  
      假如并发一口气10万个创建分布式ID请求同时杀过来，服务器
      要定的住且一下子成功创建10万个分布式ID        
```

```java
 UUID.randomUUID().toString()   //生成唯一性ID
 缺点是入数据库的性能比较差，为什么无序的UUID会导致入库性能变差呢？
    1.无序，无法预测他的生成顺序，不能生成递增有序的数字。
        首先分布式id一般都会作为主键，但是安装mysql官方推荐主键尽量越短越好，
        UUID每一个都很长，所以不是很推荐
    2.主键，ID作为主键时在特定环境会存在一些问题   
        比如做DB主键的场景下，UUID就非常不适用MySQL官方有明确的建议要尽量越短
        越好36个字符长度的UUID不符合要求  
   3.索引，B+树索引的分裂
       既然分布式id是主键，然后主键时包含索引的，然后mysql的索引是通过b+树来
       实现的，每一次新的UUID数据的插入，为了查询的优化，都会对索引底层的b+
       树进行修改，因为UUID数据是无序的，所以每次UUID数据的插入都会对主键B+
       树进行很大的修改，这一点很不友好。插入完全无序，不但会导致一些中间节点
       产生分裂，也会白白创造出很多不饱和的节点，这样大大降低了数据库插入的性能
```

```
数据库自增ID机制适合作分布式ID吗？答案是不太合适
   1：系统水平扩展比较困难，比如定义好了步长和机器台数之后，如果要添加机器该怎么做？
   2:数据库压力还是很大，每次获取ID都得读写一次数据库，非常影响性能，不符合分布式ID里面的
   延迟和高QPS的规则
```

```
在Redis集群情况下，同样和MySQL一样要设置不同的增长步数，同时key一定要设置有效期。
可以使用redis集群来获取更高的吞吐量
假如一个集群中有5台Redis。可以初始化每台Redis的值分别是1，2，3，4，5然后步长都是5。
各个Redis生成的ID为
  1，6，11，16，21
  2，7，12，17，22
  3，8，13，18，23
  4，9，14，19，24
  5，10，15，20，25 
```

```
雪花算法是Twitter的分布式自增Id算法snowflake。
经测试snowflake每秒能够产生26万个自增可排序的ID
1.SnowFlake生成ID能够按照时间有序生成
2.生成id的结果是64Bit大小的整数，为一个Long型（换成字符串后长度最多19）。
3.分布式系统内不会产生ID碰撞（由datacenter和workerId作为区分）。
```

![](images/QQ截图20200615161902.png)

![](images/QQ截图20200615162315.png)

![](images/QQ截图20200615162359.png)

![](images/QQ截图20200615165935.png)

**工具类**

```java
import cn.hutool.core.lang.Snowflake;
import cn.hutool.core.net.NetUtil;
import cn.hutool.core.util.IdUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
@Slf4j
public class IdGeneratorSnowflake {

    private long workerId  = 0;

    private long datacenterId = 1;

    private Snowflake snowflake = IdUtil.createSnowflake(workerId,datacenterId);

    @PostConstruct  //加载一些初始化的工作
    public void init(){
        try {
            workerId = NetUtil.ipv4ToLong(NetUtil.getLocalhostStr());
            log.info("当前机器的workerId:{}",workerId);
        }catch (Exception e ){
            e.printStackTrace();
            log.warn("当前机器的workerId获取失败",e);
            workerId = NetUtil.getLocalhostStr().hashCode();
        }
    }

    public synchronized long snowflakeId(){
        return snowflake.nextId();
    }

    public synchronized long snowflakeId(long workerId,long datacenterId){
        Snowflake snowflake = IdUtil.createSnowflake(workerId,datacenterId);
        return snowflake.nextId();
    }   
}
```

**测试**

```java
@Autowired
private IdGeneratorSnowflake idGeneratorSnowflake;

@GetMapping("/test")
public String getIDBysnowFlake(){
    ExecutorService threadPool = Executors.newFixedThreadPool(5);
    for (int i=0;i<20;i++){
        threadPool.submit(()->{
            System.out.println(idGeneratorSnowflake.snowflakeId());
        });
    }
    threadPool.shutdown();
    return "";
}
```

