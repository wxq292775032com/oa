package com.huaji.v01.common.util;

import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public final class DateTimeTools {

    private static Logger log = LoggerFactory.getLogger(DateTimeTools.class);

    private DateTimeTools() {
    }

    public static final String YYYY_MM = "yyyy-MM";
    public static final String YYYY_MM_DD = "yyyy-MM-dd";
    public static final String YYYY_MM_DD_HH = "yyyy-MM-dd HH";
    public static final String YYYY_MM_DD_HH_MM = "yyyy-MM-dd HH:mm";
    public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
    public static final String YYYY_MM_DD_HH_MM_SS_FFF = "yyyy-MM-dd HH:mm:ss.SSS";

    public static final String YYYYMM = "yyyyMM";
    public static final String YYYYMMDD = "yyyyMMdd";
    public static final String YYYYMMDDHH = "yyyyMMddHH";
    public static final String YYYYMMDDHHMM = "yyyyMMddHHmm";
    public static final String YYYYMMDDHHMMSS = "yyyyMMddHHmmss";

    public static final String YYYY$MM ="yyyy/MM";
    public static final String YYYY$MM$DD ="yyyy/MM/dd";
    public static final String YYYY$MM$DD$HH = "yyyy/MM/dd HH";
    public static final String YYYY$MM$DD$HH$MM = "yyyy/MM/dd HH:mm";
    public static final String YYYY$MM$DD$HH$MM$SS = "yyyy/MM/dd HH:mm:ss";

    /**
     * 字符串是否是日期格式
     */
    private static final String[] parsePatterns = {"yyyy-MM-dd", "yyyy年MM月dd日", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy/MM/dd", "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd HH:mm"};

    public static boolean isDateFormat(String str) {
        try {
            DateUtils.parseDateStrictly(str, parsePatterns);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    /**
     * 获取数据库系统日期时间对应数据库 TIMESTAMP
     */
    public static Timestamp getTimestamp() {
        return new Timestamp(System.currentTimeMillis());
    }

    /**
     * 时间戳转Timestamp
     *
     * @param timestamp 时间戳
     * @return date.getTime()
     * timestamp.getTime()
     */
    public static Timestamp getTimestamp(long timestamp) {
        return new Timestamp(timestamp);
    }

    /**
     * 获取date
     */
    public static Date getDate() {
        return new Date();
    }

    /**
     * 时间戳转Date
     */
    public static Date getDate(long timestamp) {
        return new Date(timestamp);
    }

    /**
     * 将日期转换成字符串格
     */
    public static String strByPattern(Date date, String pattern) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(pattern);
            String dates = sdf.format(date);
            return dates;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 将日期转换成字符串格
     */
    public static String strByPattern(Timestamp timestamp, String pattern) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(pattern);
            String dates = sdf.format(timestamp);
            return dates;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 字符串转Date
     */
    public static Date dateByPattern(String dateStr, String pattern) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(pattern);
            Date d = sdf.parse(dateStr);
            return d;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

    /**
     * 字符串转Timestamp
     */
    public static Timestamp timestampByPattern(String dateStr, String pattern) {
        Date d = dateByPattern(dateStr, pattern);
        if (d != null) {
            return getTimestamp(d.getTime());
        }
        return null;
    }

    /**
     * 将毫秒转成分秒 mm:ss 格式
     */
    public static String dateTimeToMMSS(long times) {
        long hour = times / (60 * 60 * 1000);
        long mis = 0;
        if (hour > 0) {
            mis = hour * 60;
        }
        long minute = ((times - hour * 60 * 60 * 1000) / (60 * 1000));
        long second = (times - hour * 60 * 60 * 1000 - minute * 60 * 1000) / 1000;
        if (second >= 60) {
            second = second % 60;
            minute += second / 60;
        }
        if (minute >= 60) {
            minute = minute % 60;
            hour += minute / 60;
        }
        String sm = "";
        String ss = "";
        minute = minute + mis;

        if (minute < 10) {
            sm = "0" + String.valueOf(minute);
        } else {
            sm = String.valueOf(minute);
        }
        if (second < 10) {
            ss = "0" + String.valueOf(second);
        } else {
            ss = String.valueOf(second);
        }
        return sm + ":" + ss;
    }

    /**
     * 在一个时间上加上或减去周
     */
    public static Date addOrMinusWeek(long ti, int i) {
        Date rtn = null;
        GregorianCalendar cal = new GregorianCalendar();
        Date date = new Date(ti);
        cal.setTime(date);
        cal.add(3, i);
        rtn = cal.getTime();
        return rtn;
    }

    /**
     * 在一个时间上加上或减去秒数
     */
    public static Date addOrMinusSecond(long ti, int i) {
        Date rtn = null;
        GregorianCalendar cal = new GregorianCalendar();
        Date date = new Date(ti);
        cal.setTime(date);
        cal.add(13, i);
        rtn = cal.getTime();
        return rtn;
    }

    /**
     * 对指定的时间进行加减
     *
     * @param flag 分钟：1   小时：2   天：3  月：4  年：5
     * @param num  正数增加、负数减少 （分钟、小时，天，月，年）
     * @param date 指定日期
     * @return
     */
    public static Date getChangeTime(int flag, int num, Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int key = 0;
        if (flag == 1) {
            key = Calendar.MINUTE; //分
        } else if (flag == 2) {
            key = Calendar.HOUR_OF_DAY; //小时
        } else if (flag == 3) {
            key = Calendar.DAY_OF_MONTH; //日
        } else if (flag == 4) {
            key = Calendar.MONTH; //月
        } else if (flag == 5) {
            key = Calendar.YEAR; //年
        } else {
            return calendar.getTime();
        }
        calendar.add(key, +num);
        return calendar.getTime();
    }

    /**
     * flag:
     * 1.前一天的最后的时间点
     * 2.当天0点时间
     * 3.当天的最后时间点
     * 4.第二天0点时间
     * 5.本周一0点时间
     * 6.上个月的第一天的时间
     * 7.本月第一天0点时间
     * 8.本月的最后一天的最后时间点
     * 9.下个月的第一天0点时间
     * Pattern:日期格式
     * date: 指定日期
     */
    public static String getDateTime(int flag, String Pattern, Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat(Pattern);
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        switch (flag) {
            case 1:  //前一天的最后的时间点
                cal.set(5, cal.get(5) - 1);
                cal.set(11, 23);
                cal.set(14, 59);
                cal.set(13, 59);
                cal.set(12, 59);
                cal.set(2, cal.get(2));
                break;
            case 2:  //当天0点时间
                cal.set(Calendar.HOUR_OF_DAY, 0);//控制时
                cal.set(Calendar.MINUTE, 0);//控制分
                cal.set(Calendar.SECOND, 0);//控制秒
                break;
            case 3: //当天的最后的时间点
                cal.set(11, 23);
                cal.set(14, 59);
                cal.set(13, 59);
                cal.set(12, 59);
                cal.set(2, cal.get(2));
                break;
            case 4: //第二天0点时间
                cal.set(5, cal.get(5) + 1);
                cal.set(11, 0);
                cal.set(14, 0);
                cal.set(13, 0);
                cal.set(12, 0);
                cal.set(2, cal.get(2));
                break;
            case 5: //本周一0点时间
                cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONDAY), cal.get(Calendar.DAY_OF_MONTH), 0, 0, 0);
                cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
                break;
            case 6: //上个月的第一天0点
                cal.set(5, 1);
                cal.set(11, 0);
                cal.set(14, 0);
                cal.set(13, 0);
                cal.set(12, 0);
                cal.set(2, cal.get(2) - 1);
                break;
            case 7: //本月第一天0点时间
                cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONDAY), cal.get(Calendar.DAY_OF_MONTH), 0, 0, 0);
                cal.set(Calendar.DAY_OF_MONTH, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
                break;
            case 8: //本月最后一天的最后时间点
                cal.set(5, cal.getActualMaximum(5));
                cal.set(11, 23);
                cal.set(14, 59);
                cal.set(13, 59);
                cal.set(12, 59);
                cal.set(2, cal.get(2));
                break;
            case 9: //下个月的第一天0点
                cal.set(5, 1);
                cal.set(11, 0);
                cal.set(14, 0);
                cal.set(13, 0);
                cal.set(12, 0);
                cal.set(2, cal.get(2) + 1);
                break;
        }
        return sdf.format(cal.getTime());
    }

}