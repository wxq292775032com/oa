package com.huaji.v01.common.util;

import java.util.regex.Pattern;

public class ValidatorTools {
    /*
     * 校验URL
     */
    public static final String REGEX_URL = "^(((file|gopher|news|nntp|telnet|http|ftp|https|ftps|sftp)://)|(www\\.))+(([a-zA-Z0-9\\._-]+\\.[a-zA-Z]{2,6})|([0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}))(/[a-zA-Z0-9\\&%_\\./-~-]*)?$" ;
    public static boolean isURL(String str){ return  Pattern.matches(REGEX_URL,str); }

    /*
     * 校验日期 格式：2019-10-31 08:01
     */
    public static  final  String REGEX_DATE = "^(((((1[6-9]|[2-9]\\d)\\d{2})-(0?[13578]|1[02])-(0?[1-9]|[12]\\d|3[01]))|(((1[6-9]|[2-9]\\d)\\d{2}-(0?[469]|11)-(0?[1" +
            "-9]|[12]\\d|30))|(((1[6-9]|[2-9]\\d)\\d{2})-0?2-(0?[1-9]|1\\d|2[0-8]))|(((1[6-9][2-9]\\d)(0[48]|[2468][048]|[1348]|[2468][048]|[13579][26])|(16|[2468][048]|[3579]" +
            "[26])00))-0?2-29)) ((0[0-9]|1[0-9]|2[0-3]):([0-5][0-9])))$";
    public static boolean isDate(String str){ return Pattern.matches(REGEX_DATE, str); }

    /**
     * 校验是纯数字
     */
    public static final String REGEX_ALL_NUMBER = "^[0-9]*$";
    public static boolean isNumber(String str) {
        return Pattern.matches(REGEX_ALL_NUMBER, str);
    }

    /**
     * 校验IP地址
     */
    public static final String REGEX_IP_ADDR = "(25[0-5]|2[0-4]\\d|[0-1]\\d{2}|[1-9]?\\d)\\.(25[0-5]|2[0-4]\\d|[0-1]\\d{2}|[1-9]?\\d)\\.(25[0-5]|2[0-4]\\d|[0-1]\\d{2}|[1-9]?\\d)\\.(25[0-5]|2[0-4]\\d|[0-1]\\d{2}|[1-9]?\\d)";
    public static boolean isIPAddr(String ipAddr) {
        return Pattern.matches(REGEX_IP_ADDR, ipAddr);
    }

    /**
     * 校验身份证
     */
    public static final String REGEX_ID_CARD = "^(\\d{6})(\\d{4})(\\d{2})(\\d{2})(\\d{3})([0-9]|X)$";
    public static boolean isIDCard(String idCard) {
        return Pattern.matches(REGEX_ID_CARD, idCard);
    }

    /**
     * 校验是纯汉字
     */
    public static final String REGEX_CHINESE = "^[\u4E00-\u9FA5]{0,}$";
    public static boolean isChinese(String chinese) {
        return Pattern.matches(REGEX_CHINESE, chinese);
    }

    /**
     * 校验是手机号
     */
    public static final String REGEX_MOBILE = "^1([38][0-9]|4[579]|5[0-3,5-9]|6[6]|7[0135678]|9[89])\\d{8}$";
    public static boolean isMobile(String mobile) {
        return Pattern.matches(REGEX_MOBILE, mobile);
    }

    /**
     * 校验是中文或是字母
     */
    public static final String REGEX_ChineseOrLetters = "^[\\u4e00-\\u9fa5a-zA-Z]{1,30}$";
    public static boolean isChineseOrLetters(String str) {
        return Pattern.matches(REGEX_ChineseOrLetters, str);
    }

    /**
     * 判断字符串是否是数字且限定最大长度
     */
    public static boolean judgeNum(String str,int maxLength){
        return  Pattern.matches("^[0-9]{1,"+maxLength+"}+$", str);
    }

    /**
     * 判断字符串是否是字母且限定最大长度
     */
    public static boolean judgeLetter(String str,int maxLength){
        return  Pattern.matches("^[a-zA-Z]{1,"+maxLength+"}+$", str);
    }

    /**
     * 是否字母开头
     */
    public static boolean judgeLetter(String str){
        return  Pattern.matches("^[a-zA-Z]+$", str);
    }

    /**
     * 英文字母开头或混合数字且限定字母最大出现次数,
     */
    public static boolean judgeEnAndNum(String str,int maxLength){
        return  Pattern.matches("^[a-zA-Z]{1,"+maxLength+"}+[0-9]*$", str);
    }

    public static void main(String[] args) {
        System.out.println(judgeLetter("2aaaa",5));
        System.out.println(isNumber("3333c"));
    }
}
