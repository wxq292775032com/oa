package com.huaji.v01.common.util;

import java.io.*;

import javax.servlet.http.HttpServletResponse;

/**
 * @author WuXiaoQiang
 * @Date 2019.6.5
 * IO流工具类   注意：为保持该工具类的纯粹性，不允许将业务代码写入该类
 */
public class StreamTools implements Serializable {

    /*使用字节流写入文件*/
    public static void outputStream(String path, String text, boolean append) {
        OutputStream fis = null;
        try {
            String parentPath = FileTools.getParent(path);
            if (!FileTools.exists(parentPath)) {
                FileTools.mkdirs(parentPath);
            }
            if (StringTools.isBlank(text)) return;
            //写入
            fis = new FileOutputStream(new File(path), append);
            byte[] words = text.getBytes();
            fis.write(words, 0, words.length);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /*使用字节流读取文件*/
    public static String inputStream(String path) {
        InputStream file = null;
        StringBuffer str = new StringBuffer();
        try {
            file = new FileInputStream(path);
            int read;
            //读取
            byte[] words = new byte[1024];
            while ((read = file.read(words)) != -1) {
                str.append(new String(words, 0, read));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (file != null) {
                try {
                    file.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return str.toString();
    }

    /*使用字节流进行复制*/
    public static void copyStream(String currentPath, String targetPath) {
        InputStream fis = null;   //读取
        OutputStream fos = null;  //写入
        try {
            String parentPath = FileTools.getParent(targetPath);
            if (!FileTools.exists(parentPath)) {
                FileTools.mkdirs(parentPath);
            }
            fis = new FileInputStream(currentPath);
            fos = new FileOutputStream(new File(targetPath), false);
            int len;
            byte[] words = new byte[1024];
            while ((len = fis.read(words)) != -1) {
                fos.write(words, 0, len);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    ;
                }
            }
        }
    }

    /*使用字符流读取文件*/
    public static String Reader(String path) {
        Reader fr = null;
        BufferedReader br = null;
        StringBuffer sb = new StringBuffer();
        try {
            fr = new FileReader(path);
            br = new BufferedReader(fr);
            String line = null;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fr != null) {
                try {
                    fr.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return sb.toString();
    }

    /*使用字符流写入文件*/
    public static void writer(String path, String text) {
        writer(path, text, false);
    }

    public static void writer(String path, String text, int newLine) {
        writer(path, text, newLine, false);
    }

    public static void writer(String path, String text, boolean append) {
        writer(path, text, 0, append);
    }

    public static void writer(String path, String text, int newLine, boolean append) {
        Writer wr = null; //1.创建流
        BufferedWriter br = null;
        try {
            if (StringTools.isBlank(text)) {
                return;
            }
            String parentPath = FileTools.getParent(path);
            if (!FileTools.exists(parentPath)) {
                FileTools.mkdirs(parentPath);
            }
            wr = new FileWriter(path, append);
            br = new BufferedWriter(wr);
            //2.写入信息
            if (newLine > 0) {  //是否要换行
                int indexStart = 0;
                int indexEnd = newLine;
                int len = text.length();
                while (len > 0) {
                    if (newLine < len) {
                        String info = text.substring(indexStart, indexEnd);
                        br.write(info);
                        br.newLine(); //换行
                        indexStart = indexStart + newLine;
                        indexEnd = indexEnd + newLine;
                        len = text.substring(indexStart).length();
                    } else {
                        br.write(text.substring(indexStart));
                        len = 0;
                    }
                }
            } else {
                br.write(text);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            //3.关闭流
            try {
                if (br != null)
                    br.close();
                if (wr != null)
                    wr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /*使用字符流进行复制*/
    public static void copy(String currentPath, String targetPath) {
        //1.创建流
        Reader rd = null;
        BufferedReader br = null;
        Writer wr = null;
        BufferedWriter bw = null;
        StringBuffer sb = new StringBuffer();
        try {
            //读取文件中的信息
            rd = new FileReader(currentPath);
            br = new BufferedReader(rd);
            String line; //存储读取到的信息
            //写入
            String parentPath = FileTools.getParent(targetPath);
            if (!FileTools.exists(parentPath)) {
                FileTools.mkdirs(parentPath);
            }
            wr = new FileWriter(targetPath, false);
            bw = new BufferedWriter(wr);
            while ((line = br.readLine()) != null) {
                bw.write(line);
                bw.newLine();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            //3.关闭流
            try {
                if (bw != null)
                    bw.close();
                if (br != null)
                    br.close();
                if (wr != null)
                    wr.close();
                if (rd != null)
                    rd.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /*操作二进制文件*/
    public static void executeFile(String currentPath, String targetPath) {
        DataOutputStream out = null;
        DataInputStream dis = null;
        try {
            //创建输入流对象
            FileInputStream fis = new FileInputStream(currentPath);
            dis = new DataInputStream(fis);
            //创建输出流对象
            String parentPath = FileTools.getParent(targetPath);
            if (!FileTools.exists(parentPath)) {
                FileTools.mkdirs(parentPath);
            }
            FileOutputStream outFile = new FileOutputStream(targetPath);
            out = new DataOutputStream(outFile);
            int temp;
            //读取文件并写入文件
            while ((temp = dis.read()) != -1) {
                out.write(temp);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (dis != null)
                try {
                    dis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            if (out != null)
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }
    }

    /*序列化*/
    public static void serialize(String path, Object obj) {
        //创建一个对象输出流
        OutputStream os = null;
        ObjectOutputStream oos = null;
        try {
            //序列化
            os = new FileOutputStream(path);
            oos = new ObjectOutputStream(os);
            oos.writeObject(obj);
        } catch (IOException io) {
            io.printStackTrace();
        } finally {
            if (os != null) {
                try {
                    os.close();
                } catch (IOException io) {
                    io.printStackTrace();
                }
            }
            if (oos != null) {
                try {
                    oos.close();
                } catch (IOException io) {
                    io.printStackTrace();
                }
            }
        }
    }

    /*反序列化*/
    public static Object deserialization(String path) {
        //创建对象输入流
        FileInputStream is = null;
        ObjectInputStream ois = null;
        try {
            //反序列化
            is = new FileInputStream(path);
            ois = new ObjectInputStream(is);
            return ois.readObject();
        } catch (IOException io) {
            io.printStackTrace();
        } catch (ClassNotFoundException c) {
            c.printStackTrace();
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException io) {
                    io.printStackTrace();
                }
            }
            if (ois != null) {
                try {
                    ois.close();
                } catch (IOException io) {
                    io.printStackTrace();
                }
            }
        }
        return null;
    }

    /**
     * 从输入流中读取数据
     * @param inStream
     * @return
     * @throws Exception
     */
    public static byte[] readInputStream(InputStream inStream) throws Exception{
        ByteArrayOutputStream outStream = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        int len = 0;
        while( (len = inStream.read(buffer)) !=-1 ){
            outStream.write(buffer, 0, len);
        }
        byte[] data = outStream.toByteArray();//网页的二进制数据
        outStream.close();
        inStream.close();
        return data;
    }

    public static void writeResponse(HttpServletResponse response, String message){
        response.setCharacterEncoding("UTF-8");//通知response以UTF-8发送
        response.setContentType("text/html;charset=UTF-8");//设置浏览器以UTF-8打开
        response.setHeader("Content-type", "text/html;charset=UTF-8");
        PrintWriter writer = null;
        try {
            writer = response.getWriter();
            writer.print(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

