package com.huaji.v01.common.util;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.shiro.crypto.hash.Md5Hash;
import org.apache.tomcat.util.codec.binary.Base64;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

/**
 * @author WuXiaoQiang
 * @Date 2019.6.20
 * 加密工具类   注意：为保持该工具类的纯粹性，不允许将业务代码写入该类
 */
public class MD5Tools {

    private MD5Tools() {
    }

    /*生成32位密文*/
    public static final String MD5encrypt(String s) {
        char[] HexDigits = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
        String strEncode = "";
        try {
            byte[] strTemp = s.getBytes("UTF-8");
            MessageDigest mdTemp = MessageDigest.getInstance("MD5");
            mdTemp.update(strTemp);
            byte[] md = mdTemp.digest();
            int j = md.length;
            char[] str = new char[j * 2];
            int k = 0;
            for (int i = 0; i < j; i++) {
                byte strTemp2 = md[i];
                str[(k++)] = HexDigits[(strTemp2 >>> 4 & 0xF)];
                str[(k++)] = HexDigits[(strTemp2 & 0xF)];
            }
            strEncode = new String(str);
        } catch (NoSuchAlgorithmException e) {
            return strEncode;
        } catch (UnsupportedEncodingException e) {
            return strEncode;
        }
        return strEncode;
    }

    /*生成32位的密文*/
    public static String Md5_32(String plainText) {
        return md5Hex(plainText);
    }

    /*生成16位的密文*/
    public static String Md5_16(String plainText) {
        return md5Hex(plainText).substring(8, 24);
    }

    private static String md5Hex(String d) {
        return DigestUtils.md5Hex(d);
    }

    /*使用shiro提供的md5散列进行加密*/
    public static String shiroMd5(String plainText,int intensity){
        Md5Hash md5Hash = null;
        String resultPwd = "";
        switch (intensity){
            case 1: //生成普通的MD5加密
                md5Hash = new Md5Hash(plainText);
            case 2: //进行加盐的方式进行加密增强(可以动态把用户名作为盐值)
                md5Hash = new Md5Hash(plainText,"x0*7ps");
            case 3: //在加盐的基础上进行加密1024次
                md5Hash = new Md5Hash(plainText,"x0*7ps",1024);
        }
        resultPwd = md5Hash.toHex();
        return resultPwd;
    }

    private String getSalt(int num){ //随机盐
        StringBuilder sb = new StringBuilder();
        char[] chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ~!@#$%^&*".toCharArray();
        for(int i =0;i<num;i++){
              char achars = chars[new Random().nextInt(chars.length)];
              sb.append(achars);
        }
        return sb.toString();
    }

    /*base64 加密*/
    public static String Base64(String strs) {
        try {
            return new String(Base64.encodeBase64(strs.getBytes("utf-8")));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return null;
    }

    /*base64 解密*/
    public static String Base64_J(String strs) {
        try {
            return new String(Base64.decodeBase64(strs), "utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return null;
    }

}
