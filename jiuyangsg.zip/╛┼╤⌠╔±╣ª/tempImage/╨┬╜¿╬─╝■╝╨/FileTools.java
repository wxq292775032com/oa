package com.huaji.v01.common.util;


import org.apache.commons.lang.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Random;

/**
 * @author WuXiaoQiang
 * @Date 2019.4.4
 * File工具类   注意：为保持该工具类的纯粹性，不允许将业务代码写入该类
 */

public class FileTools {

    /*获取一个File对象*/
    public static File getFile(String path) {
        return new File(path);
    }

    /*判断文件夹或目录是否存在*/
    public static boolean exists(String path) {
        if (StringTools.isBlank(path)) return false;
        return getFile(path).exists();
    }

    /*判断是否是文件*/
    public static boolean isFile(String path) {
        if (StringTools.isBlank(path)) return false;
        return getFile(path).isFile();
    }

    /*判断是否是目录*/
    public static boolean isDirectory(String path) {
        if (StringTools.isBlank(path)) return false;
        return getFile(path).isDirectory();
    }

    /*获取父级路径*/
    public static String getParent(String path) {
        if (StringTools.isBlank(path)) return null;
        return getFile(path).getParent();
    }

    /*获取相对路径*/
    public static String getPath(String path) {
        if (StringTools.isBlank(path)) return null;
        return getFile(path).getPath();
    }

    /*获取绝对路径*/
    public static String getAbsolutePath(String path) {
        if (StringTools.isBlank(path)) return null;
        return getFile(path).getAbsolutePath();
    }

    /*获取文件或者目录名称*/
    public static String getName(String path) {
        if (StringTools.isBlank(path)) return null;
        return getFile(path).getName();
    }

    /*删除文件或者目录*/
    public static boolean delete(String path) {
        if (StringTools.isBlank(path)) return false;
        return getFile(path).delete();
    }

    /*获取文件的长度，单位为字节，若文件不存在，则返回 0L*/
    public static long length(String path) {
        if (StringTools.isBlank(path)) return 0L;
        return getFile(path).length();
    }

    /*获取文件最后修改的时间*/
    public static String updateTime(String path) {
        if (StringTools.isBlank(path)) return null;
        Date date = new Date(FileTools.getFile(path).lastModified());
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String stringDate = format.format(date);
        return stringDate;
    }

    /*创建目录*/
    public static boolean mkdirs(String path) {
        if (StringTools.isBlank(path)) return false;
        return getFile(path).mkdirs();
    }

    /*创建文件*/
    public static boolean createNewFile(String path) {
        if (StringTools.isBlank(path)) return false;
        String parentPath = getParent(path);
        if (!exists(parentPath)) {
            mkdirs(parentPath);
        }
        try {
            if (!exists(path)) ;
            return getFile(path).createNewFile();
        } catch (IOException io) {
            io.printStackTrace();
        }
        return false;
    }

    /**
     * 文件上传
     * Map
     * key pathName 路径
     * key getFileName 文件名
     * key getSize  文件大小限制，如果不限制则传-1
     * prfixs 文件后缀限制，如果不限制则不传
     * result: -1file传入为空  -2Map参数有误  -3超过文件限制  -4文件后缀不符合要求  1上传成功并通过map引用传递返回上传相关信息
     */
    public static int filesUpload(MultipartFile file, HttpServletRequest request, Map<String,String> map,String...prefixs) {
        if(file == null) {
            return -1;
        }else if(StringUtils.isBlank(map.get("getSize")) || StringUtils.isBlank(map.get("pathName"))
                || StringUtils.isBlank(map.get("getFileName"))) {
            return -2;
        }else if(!"-1".equals(map.get("getSize")) && file.getSize() <= Integer.parseInt(map.get("getSize"))) {
            return -3;
        }

        // 1.获取原文件名
        String oriName = file.getOriginalFilename();
        // 2.获取原文件的后缀
        String prefix = null;
        boolean flag = false;
        if(prefixs != null && prefixs.length >0 ){
            flag = true;
            for(int i =0;i<prefixs.length;i++){
                if(prefixs[i].equalsIgnoreCase(prefix)){
                    flag = false;
                    break;
                }
            }
        }
        if(flag) {
            return -4;
        }
        //3.定义上传目标路径
        String path = request.getSession().getServletContext().getRealPath(map.get("pathName"));
        //4.定义上传文件名
        String fileName = map.get("getFileNmae")+""+prefix;
        //5.定义路径
        String desFilePath = path+fileName;
        //6.创建File对象
        File targetFile = new File(desFilePath);
        //7.目标路径是否存在，不存在则创建
        if(!targetFile.exists()) {
            targetFile.mkdirs();
        }
        //8.执行上传
        try {
            file.transferTo(targetFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
        //9.清空map.返回上传信息
        map.clear();
        map.put("oldName",oriName); //原文件名
        map.put("path",path); //上传路径
        map.put("newName",fileName); //上传文件名
        return 1;
    }

    public static String getRandomFileName(){
        String str = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        Random random = new Random();
        int ranNum = random.nextInt()*(99999-10000+1)+10000; //获取5位随机数
        return str+ranNum;
    }
}
