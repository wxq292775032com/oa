package com.huaji.v01.common.util;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesTools {
    /**
     * 获取属性文件的数据 根据key获取值
     * @param 　(注意：加载的是src下的文件,如果在某个包下．请把包名加上)
     * @param key
     * @return
     */
    public static String findPropertiesKey(String key) {

        try {
            Properties prop = getProperties();
            return prop.getProperty(key);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }

    }

    /**
     * 返回　Properties
     * @param   　(注意：加载的是src下的文件,如果在某个包下．请把包名加上)
     */
    public static Properties getProperties(){
        Properties prop = new Properties();
        String savePath = PropertiesTools.class.getResource("/config.properties").getPath();
        InputStream in = null;
        try {
            in =new BufferedInputStream(new FileInputStream(savePath));
            prop.load(in);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }finally{

        }
        return prop;
    }
}
