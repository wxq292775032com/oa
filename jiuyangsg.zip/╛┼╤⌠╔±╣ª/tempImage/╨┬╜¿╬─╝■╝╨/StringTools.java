package com.huaji.v01.common.util;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * @author WuXiaoQiang
 * @Date 2019.3.4
 * String工具类   注意：为保持该工具类的纯粹性，不允许将业务代码写入该类
 */

public class StringTools {

    /*Object转String*/
    public static String objString(Object obj) {
        if (obj == null) return null;
        return String.valueOf(obj);
    }

    /*Object转Int*/
    public static Integer objInt(Object obj) {
        if (obj == null) return null;
        return Integer.parseInt((String) obj);
    }

    /*Object转char*/
    public static char getAsChar(Object obj) {
        if (obj == null || "".equals(obj)){
            return '\0';
        }
        if (obj instanceof Character){
            return ((Character)obj).charValue();
        }
        if ((obj instanceof String) && (((String)obj).length() == 1)) {
            return ((String)obj).charAt(0);
        }
        return  new Character(obj.toString().charAt(0));
    }

    /*String转byte*/
    public static byte stringToByte(String str){
        if(isBlank(str)){
            return 0;
        }
        return new BigDecimal(str).byteValue();
    }

    /*String转short*/
    public static short stringToShort(String str){
        if(isBlank(str)){
            return 0;
        }
        return new BigDecimal(str).shortValue();
    }

    /*String转int*/
    public static int stringToInt(String str){
        if(isBlank(str)){
            return 0;
        }
        return new BigDecimal(str).intValue();
    }

    /*String转long*/
    public static long stringToLong(String str){
        if(isBlank(str)){
            return 0;
        }
        return new BigDecimal(str).longValue();
    }

    /*String转float*/
    public static float stringToFloat(String str){
        if(isBlank(str)){
            return 0;
        }
        return new BigDecimal(str).floatValue();
    }

    /*String转double*/
    public static double stringToDouble(String str) {
        if(isBlank(str)){
            return 0;
        }
        return new BigDecimal(str).doubleValue();
    }

    /*String转boolean*/
    public static boolean stringToBoolean(String str){
        if ( ("true".equalsIgnoreCase(str)) || ("y".equalsIgnoreCase(str))) {
            return new Boolean(true);
        }
        return new Boolean(false);
    }

    /*字符是否为空*/
    public static boolean isBlank(String str) {
        return (StringUtils.isBlank(str) || str.equalsIgnoreCase("NULL"));
    }

    /*字符是否不为空*/
    public static boolean isNotBlank(String str) {
        return !isBlank(str);
    }

    /*是否是数字*/
    public static boolean isNumber(String str) {
        if (isBlank(str)) return false;
        return StringUtils.isNumeric(str);
    }

    /*是否是数字(包含小数)*/
    public static final String reg = "^[-+]?(\\d+\\.{0,1}\\d*)$";
    public static boolean isNumber2(String str) {
        return str.matches(reg);
    }

    //是否数字(包含小数和逗号),校验金额
    public static boolean isNumber3(String str) {
        if (isBlank(str)) {
            return false;
        } else {
            str = str.replaceAll(",", "").replaceAll(".", "");
        }
        return StringUtils.isNumeric(str);
    }

    /*首字母大写*/
    public static String capitalize(String str) {
        if (!isBlank(str)) {
            str = StringUtils.capitalize(str);
        }
        return str;
    }

    /*首字母小写*/
    public static String uncapitalize(String str) {
        if (!isBlank(str)) {
            str = StringUtils.uncapitalize(str);
        }
        return str;
    }

    /*去除下划线,下划线后字母大写*/
    public static String lowerRMUnderScode(String str) {
        if (isBlank(str)) {
            return null;
        }
        StringBuffer sb = new StringBuffer();
        String value = lowerCase(str);
        sb.append(value);
        int count = sb.indexOf("_");
        while (count != 0) {
            int num = sb.indexOf("_", count);
            count = num + 1;
            if (num != -1) {
                char ss = value.charAt(count);
                char ia = (char) (ss - 32);
                sb.replace(count, count + 1, ia + "");
            }
        }
        return sb.toString().replaceAll("_", "");
    }

    /*更换为大写字母,原大写字母前加入下划线*/
    public static String upperUnderScode(String str) {
        if (isBlank(str)) {
            return null;
        }
        StringBuffer sb = new StringBuffer();
        char[] array = str.toCharArray();
        for (char ch : array) {
            if (Character.isUpperCase(ch)) {
                sb.append("_");
            }
            sb.append(ch);
        }
        return upperCase(sb.toString());
    }

    /*字母转小写*/
    public static String lowerCase(String str) {
        return StringUtils.lowerCase(str);
    }

    /*字母转大写*/
    public static String upperCase(String str) {
        return StringUtils.upperCase(str);
    }

    /*获取字符串从左边开始第 len 个数字*/
    public static String left(String str, int len) {
        return StringUtils.left(str, len);
    }

    /*获取字符串从右边开始第 len 个数字*/
    public static String right(String str, int len) {
        return StringUtils.right(str, len);
    }

    /* 获取 str中有多少个 sub 字符*/
    public static int countMatches(String str, String sub) {
        return StringUtils.countMatches(str, sub);
    }

    /* str中是否包含searchChar */
    public static boolean contains(String str, String searchChar) {
        return StringUtils.contains(str, searchChar);
    }

    /*格式化金额*/
    private static DecimalFormat df = new DecimalFormat("#,##0.0000");

    public static String moneyFormat(Double money) {
        if (money == null) {
            return null;
        }
        return df.format(money);
    }

    /**
     * 从字符串中提取数字
     */
    public static String extractionOfDigital(String str) {
        str = str.trim();
        StringBuffer sb = new StringBuffer();
        if(str != null && !"".equals(str)) {
            for(int i =0;i<str.length();i++) {
                if(str.charAt(i) >=48 && str.charAt(i) <=57) {
                    sb.append(str.charAt(i));
                }
            }
        }
        return sb.toString();
    }

    //计算分页数据
    public static Map<String,Integer> getStartAndEndNumber(int page, int limit){
        int startIndex = 0;
        if(page==0){
            startIndex = (page-1) * limit;
        }else{
            startIndex = (page-1) * limit+1;
        }
        int endIndex = startIndex + limit-1;
        Map<String,Integer> map = new HashMap<String,Integer>();
        map.put("startIndex",startIndex);
        map.put("endIndex",endIndex);
        return map;
    }

    /**
     * 含有中文的字符串转成Unicode
     * @param str
     * @return
     * @throws Exception
     */
    public static String strToUnicode(String str){
        if(isBlank(str)){
            return str;
        }
        return StringEscapeUtils.escapeJava(str);
    }
    public static String strToHtml(String str){
        if(isBlank(str)){
            return str;
        }
        return StringEscapeUtils.escapeHtml(str).replaceAll("'","&apos;");
    }
}
