package org.news.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigManager {
	//用于读取Java的配置文件
	private static Properties props = null;
	
	//创建静态块
	static{
			//读取流
		InputStream is = null;
		 // getClassLoader()     |  //getResourceAsStream
		 //是取得该Class对象的类装载器  |  //调用类加载器的方法加载 资源 ，返回的是字节流
		  is = ConfigManager.class.getClassLoader().getResourceAsStream(
	                "database.properties");
		  if (is == null){
	         throw new RuntimeException("找不到数据库参数配置文件！");  
		  }
		  props = new Properties();//实例化
		  try {
			  props.load(is); //读取
		} catch (IOException e) {
			 throw new RuntimeException("数据库配置参数加载错误！", e);
		}finally{
			try {
                is.close();  //关闭
            } catch (IOException e) {
                e.printStackTrace();
            }
		}
	}
	
	//通过key值返回数据的方法
	 public static String getProperty(String key) {
	        return props.getProperty(key);
	    }
}
