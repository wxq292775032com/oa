package com.huaji.v01.common.util;

import com.sun.istack.internal.logging.Logger;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.InputStream;

public class TestUtil {

     private static final Logger log = Logger.getLogger(TestUtil.class);

    /*获取Mybatis的SqlSession对象*/
    public static SqlSession getSqlSession(String resource){
        SqlSession session = null;
        try {
            // 1.读取全局配置文件
            InputStream is = Resources.getResourceAsStream(resource);
            // 2.创建SqlSessionFactory对象
            SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
            // 3.创建SqlSession对象
            session = factory.openSession(true);  //true关闭事务控制（默认）
        }catch (Exception e){
            log.info(e.getMessage());
        }finally {
           // session.close();
        }
        return session;
    }

    /*实例化spring的上下文*/
    public static ApplicationContext getContext(String resource){
        ApplicationContext applicationContext = null;
        try {
            applicationContext = new ClassPathXmlApplicationContext(resource);
        }catch (Exception e){
            log.info(e.getMessage());
        }
        return applicationContext;
    }

    /**
     *    Redis：  DistributedLock     RedisUtil
     *    其他  SpringUtil   PingUtils
     *    短信 NumbericTools     MobileCode
     *    缓存  Memcached
     *    邮件： MailTools
     *    HTML模板： CreateHtmlUtils
     */
}
