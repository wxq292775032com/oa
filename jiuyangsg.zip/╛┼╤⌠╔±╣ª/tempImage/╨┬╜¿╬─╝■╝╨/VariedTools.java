package com.huaji.v01.common.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class VariedTools {

    /**
     *  根据年份获取生肖
     */
    public static final  String[] animals = {"猴", "鸡", "狗", "猪", "鼠", "牛", "虎", "兔", "龙", "蛇", "马", "羊"};
    public static String getShengXiao(int year){
        int index = year % 12;
        return animals[index];
    }

    /**
     *  根据日期获取星座
     */
    public static final String[] constellationArray = { "水瓶座", "双鱼座", "白羊座","金牛座", "双子座", "巨蟹座",
            "狮子座", "处女座", "天秤座", "天蝎座", "射手座","摩羯座" };
    public static final  int[] constellationEdgeDay = { 20, 19, 21, 21, 21, 22, 23, 23, 23, 23, 22, 22 };
    public static String getConstellation(String date) {
        try{
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date dateParam = sdf.parse(date);

            Calendar time = Calendar.getInstance();
            time.setTime(dateParam);
            int month = time.get(Calendar.MONTH);
            int day = time.get(Calendar.DAY_OF_MONTH);
            if (day < constellationEdgeDay[month]) {
                month = month - 1;
            }
            if (month >= 0) {
                return constellationArray[month];
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return constellationArray[11];
    }


    public static void main(String[] args) {
        String dateStr = "1994-1-24";
        System.out.println( getShengXiao(1991));
    }
}
