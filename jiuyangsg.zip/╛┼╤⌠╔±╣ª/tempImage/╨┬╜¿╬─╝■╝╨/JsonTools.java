package com.huaji.v01.common.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.charset.Charset;
import java.util.List;

/**
 * @author WuXiaoQiang
 * @Date 2020.3.4
 * JSON工具类   注意：为保持该工具类的纯粹性，不允许将业务代码写入该类
 */
public class JsonTools {

    /**
     * 将数据以json格式返回客户端
     */
    public static void outPut(Object obj, HttpServletResponse response) {
        ServletOutputStream ouputStream = null;
        try {
            String message = JSON.toJSONStringWithDateFormat(obj, "yyyy-MM-dd HH:mm:ss");
            response.setContentType("text/html;charset=utf-8");
            ouputStream = response.getOutputStream();
            byte[] bytes = message.getBytes("UTF-8");// 设置编码方式
            ouputStream.write(bytes, 0, bytes.length);
            ouputStream.flush();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (ouputStream != null) {
                try {
                    ouputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 获取JSON格式的字符串
     */
    public static String getString(Object obj) {
        return JSON.toJSONString(obj);
    }

    /**
     * 获取JSON格式字符串，同时对日期类型进行格式化
     */
    public static String getString(Object obj, String dateFormat) {
        return JSON.toJSONStringWithDateFormat(obj, dateFormat);
    }

    /**
     * 字符串转JSONOBject对象
     */
    public static JSONObject getJSONObject(String jsonStr) {
        return JSON.parseObject(jsonStr);
    }

    /**
     * 字符串转JSONArray
     */
    public static JSONArray getJSONArray(String jsonStr) {
        return JSON.parseArray(jsonStr);
    }

    /**
     * 字符串转换Bean
     */
    public static <T> T getObject(String jsonStr, Class<T> clazz) {
        return JSON.parseObject(jsonStr, clazz);
    }

    /**
     * 字符串转List
     */
    public static <T> List<T> getList(String jsonStr, Class<T> clazz) {
        return JSON.parseArray(jsonStr, clazz);
    }

    /**
     * 是JSONObject
     */
    public static boolean isJSONObject(String jsonStr) {
        if (StringTools.isBlank(jsonStr)) {
            return false;
        }
        try {
            JSONObject.parseObject(jsonStr);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 是JSONArray
     */
    public static boolean isJSONArray(String jsonStr) {
        if (StringTools.isBlank(jsonStr)) {
            return false;
        }
        try {
            JSONArray.parseArray(jsonStr);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 写JSON字符到文本
     */
    public static void writeJSONText(String path, String jsonStr) {
        writeJSONText(path, jsonStr, null, false, 1);
    }

    public static void writeJSONText(String path, Object obj) {
        writeJSONText(path, null, obj, false, 2);
    }

    private static void writeJSONText(String path, String jsonStr, Object obj, boolean append, int flag) {
        Writer wr = null;
        BufferedWriter br = null;
        try {
            String parentPath = FileTools.getParent(path);
            if (!FileTools.exists(parentPath)) {
                FileTools.mkdirs(parentPath);
            }
            wr = new FileWriter(path, append);
            br = new BufferedWriter(wr);
            if (flag == 1) {
                JSON.writeJSONString(br, jsonStr);
            } else if (flag == 2) {
                JSON.writeJSONStringTo(obj, br);
            }
        } catch (IOException io) {
            io.printStackTrace();
        } finally {
            try {
                if (wr != null) wr.close();
                if (br != null) br.close();
            } catch (IOException io) {
                io.printStackTrace();
            }
        }
    }

    /**
     * 读取JSON格式的文本转成 Java对象
     */
    public static <T> T readerJSONText(String path, Class<T> T) {
        InputStream file = null;
        try {
            file = new FileInputStream(path);
            return JSON.parseObject(file, Charset.defaultCharset(), T);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (file != null) {
                try {
                    file.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }


}

