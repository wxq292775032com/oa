package com.huaji.v01.common.util;

import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.*;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.*;

public class ExcelTools {

    public static void excel(String[] headers, List<Map<String, Object>> dataList, HttpServletResponse response) {
        String fileName = null; //工作表名
        ServletOutputStream fOut = null; //输出流
        HSSFWorkbook workBook = null; //工作簿
        try {
            fileName = DateTimeTools.strByPattern(new Date(), DateTimeTools.YYYYMMDDHHMMSS);// 文件名默认当前日期，精确到分
            // Excel表头，取数据表字段，需添加国际化支持，如果需要对数据值翻译，增加CodeTable
            workBook = exportExcel(fileName, headers, dataList);

            //设置response属性,导出Excel
            response.setContentType("application/vnd.ms-excel");
            response.setHeader("content-disposition", "attachment;filename=" + fileName + ".xls");
            fOut = response.getOutputStream();
            workBook.write(fOut);
            fOut.flush();
            fOut.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (fOut != null)
                    fOut.close();
                if(workBook != null)
                    workBook.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static HSSFWorkbook exportExcel(String sheetName, String[] headers, List<Map<String, Object>> dataset) {
        //1.创建工作簿
        HSSFWorkbook workbook = new HSSFWorkbook();
        //2.创建工作表
        HSSFSheet sheet = workbook.createSheet(sheetName);

        try {
            // 设置表格默认列宽度为15个字节
            sheet.setDefaultColumnWidth(15);

            //创建样式对象，用于标题样式
            HSSFCellStyle style1 = workbook.createCellStyle();
            // 设置这些样式
            style1.setFillForegroundColor((short) 40);
            style1.setFillPattern((short) 1);
            style1.setBorderBottom((short) 1);
            style1.setBorderLeft((short) 1);
            style1.setBorderRight((short) 1);
            style1.setBorderTop((short) 1);
            style1.setAlignment((short) 2);
            // 生成一个字体
            HSSFFont font = workbook.createFont();
            font.setColor((short) 20);
            font.setFontHeightInPoints((short) 12);
            font.setBoldweight((short) 700);
            // 把字体应用到当前的样式
            style1.setFont(font);

            // 创建样式对象，用于除标题外的样式
            HSSFCellStyle style2 = workbook.createCellStyle();
            // 设置这些样式
            style2.setFillForegroundColor((short) 43);
            style2.setFillPattern((short) 1);
            style2.setBorderBottom((short) 1);
            style2.setBorderLeft((short) 1);
            style2.setBorderRight((short) 1);
            style2.setBorderTop((short) 1);
            style2.setAlignment((short) 2);
            style2.setVerticalAlignment((short) 1);
            // 生成一个字体
            HSSFFont font2 = workbook.createFont();
            font2.setBoldweight((short) 400);
            // 把字体应用到当前的样式
            style2.setFont(font2);

            //创建第一行，标题行
            HSSFRow row = sheet.createRow(0);
            for (int it = 0; it < headers.length; ++it) {
                HSSFCell index = row.createCell(it);
                index.setCellStyle(style1);
                String header = headers[it];
                HSSFRichTextString map = new HSSFRichTextString(header);
                index.setCellValue(map);
            }

            //创建余下行
            for (int i = 0; i < dataset.size(); i++) {
                row = sheet.createRow(i+1);
                Map map = dataset.get(i);

                //单元格
                for (int j = 0; j < headers.length; j++) {
                    HSSFCell cell = row.createCell(j);
                    cell.setCellStyle(style2);
                    Object value = map.get(headers[j]);
                    if (value == null) {
                        value = " ";
                    }
                    cell.setCellValue(value.toString());
                }
            }
            return workbook;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /*
     * 来调用带页码的EX导出
     * */
    public static void excelStr(String[] headers, Map<String, List> dataList, HttpServletResponse response) {
        String fileName = null;
        ServletOutputStream fOut = null;
        HSSFWorkbook workBook = null;
        try {
            // 文件名默认当前日期，精确到分
            fileName = DateTimeTools.strByPattern(new Date(), DateTimeTools.YYYYMMDDHHMMSS);
            // Excel表头，取数据表字段，需添加国际化支持，如果需要对数据值翻译，增加CodeTable
            workBook = ExcelTools.exportExcelStr(headers, dataList);

            //设置response属性,导出Excel
            response.setContentType("application/vnd.ms-excel");
            response.setHeader("content-disposition", "attachment;filename=" + fileName + ".xls");
            fOut = response.getOutputStream();
            workBook.write(fOut);
            fOut.flush();
            fOut.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (fOut != null)
                    fOut.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /*
     * 带页码的EX导出方法
     * */
    public static HSSFWorkbook exportExcelStr(String[] headers, Map<String, List> dataList) {
        //1.创建工作簿
        HSSFWorkbook workbook = new HSSFWorkbook();
        //2.创建工作表
        HSSFSheet sheet = null;
        try {
            Iterator<Map.Entry<String, List>> it = dataList.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String, List> entry = it.next();
                List list = entry.getValue();
                sheet = workbook.createSheet(entry.getKey());
                sheet.setDefaultColumnWidth(15);  // 设置表格默认列宽度为15个字节

                //创建样式对象1
                HSSFCellStyle style1 = workbook.createCellStyle();
                // 设置这些样式
                style1.setFillForegroundColor((short) 40);
                style1.setFillPattern((short) 1);
                style1.setBorderBottom((short) 1);
                style1.setBorderLeft((short) 1);
                style1.setBorderRight((short) 1);
                style1.setBorderTop((short) 1);
                style1.setAlignment((short) 2);
                //设置字体
                HSSFFont font = workbook.createFont();
                font.setColor((short) 20);
                font.setFontHeightInPoints((short) 12);
                font.setBoldweight((short) 700);
                style1.setFont(font);

                //创建样式对象2
                HSSFCellStyle style2 = workbook.createCellStyle();
                // 设置这些样式
                style2.setFillForegroundColor((short) 43);
                style2.setFillPattern((short) 1);
                style2.setBorderBottom((short) 1);
                style2.setBorderLeft((short) 1);
                style2.setBorderRight((short) 1);
                style2.setBorderTop((short) 1);
                style2.setAlignment((short) 2);
                style2.setVerticalAlignment((short) 1);
                //设置字体
                HSSFFont font2 = workbook.createFont();
                font2.setBoldweight((short) 400);
                style2.setFont(font2);

                //创建第一行，标题行
                HSSFRow row = sheet.createRow(0);
                for (int c = 0; c < headers.length; ++c) {
                    HSSFCell index = row.createCell(c);
                    index.setCellStyle(style1);
                    String header = headers[c];
                    HSSFRichTextString value = new HSSFRichTextString(header);
                    index.setCellValue(value);
                }

                //创建余下行
                for (int i = 0; i < list.size(); i++) {
                    row = sheet.createRow(i+1);
                    Map map = (Map)list.get(i);

                    //单元格
                    for (int j = 0; j < headers.length; j++) {
                        HSSFCell cell = row.createCell(j);
                        cell.setCellStyle(style2);
                        Object value = map.get(headers[j]);
                        if (value == null) {
                            value = " ";
                        }
                        cell.setCellValue(value.toString());
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return workbook;
    }

//------------------------------------------------------------------------------------------------------------------------------
    /**
     * CSV文件生成方法
     */
    public static void createCSVFile(String[] head, List<Map<String, Object>> dataList, HttpServletResponse response, HttpServletRequest request) {
        File csvFile = null;
        BufferedWriter csvWtriter = null;
        String tomcatPath = "";
        String fileName = "";
        try {
            // 获取/temp/的绝对路径
            tomcatPath = request.getServletContext().getRealPath("/temp/");
            //给要导出的csv文件命名
            fileName = DateTimeTools.strByPattern(new Date(), DateTimeTools.YYYYMMDDHHMMSS);

            csvFile = new File(tomcatPath + "/" + fileName + ".csv");
            File parent = csvFile.getParentFile();
            if (parent != null && !parent.exists()) {
                boolean mkBool = parent.mkdirs();
            }
            boolean csvBool = csvFile.createNewFile();
            csvWtriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(csvFile), "GBK"));
            // 写入文件头部
            Map map = new LinkedHashMap();
            for (int i = 0; i < head.length; i++) {
                String heads = head[i].toString();
                map.put(heads, heads);
            }
            writeRow(map, csvWtriter, map);
            for (int m = 0; m < dataList.size(); m++) {
                writeRow(dataList.get(m), csvWtriter, map);
            }
            // 写入文件内容
            csvWtriter.flush();
            //通过浏览器下载文件
            downloadFile(request, response, fileName);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (csvWtriter != null)
                    csvWtriter.close();
                //删除本地文件
                deleteFile(tomcatPath + "/", fileName + ".csv");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 写入文件内容
     */
    private static void writeRow(Map<String, Object> row, BufferedWriter csvWriter, Map<String, Object> header) throws IOException {
        for (Iterator propertyIterator = header.entrySet().iterator(); propertyIterator.hasNext(); ) {
            Map.Entry headO = (Map.Entry) propertyIterator.next();
            for (Iterator dataList = row.entrySet().iterator(); dataList.hasNext(); ) {
                Map.Entry propertyEntry = (Map.Entry) dataList.next();
                if (propertyEntry.getKey().equals(headO.getKey())) {
                    StringBuffer sb = new StringBuffer();
                    String rowStr = sb.append("\"").append(propertyEntry.getValue()).append("\"\t").toString();
                    csvWriter.write(rowStr);
                    if (propertyIterator.hasNext()) {
                        csvWriter.write(",");
                    }
                }
            }
        }
        csvWriter.newLine();
    }

    /**
     * 导出（浏览器下载CSV文件）
     */
    public static void downloadFile(HttpServletRequest request, HttpServletResponse response, String uri) throws IOException {
        FileInputStream inputStream = null;
        OutputStream outputStream = null;
        try {
            // 获取服务其上的文件名称
            String tomcatPath = request.getServletContext().getRealPath("/temp/");
            File file = new File(tomcatPath + "/" + uri + ".csv");
            response.setContentType("application/csv;charset=UTF-8");
            response.setHeader("Content-Disposition", "attachment;filename=" + uri + ".csv");

            // 将此文件流写入到response输出流中
            inputStream = new FileInputStream(file);
            outputStream = response.getOutputStream();
            byte[] buffer = new byte[1024];
            int i = -1;
            while ((i = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, i);
            }
            outputStream.flush();
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 删除单个文件
     * @param filePath 文件目录路径
     * @param fileName 文件名称
     */
    public static void deleteFile(String filePath, String fileName) {
        File file = new File(filePath);
        if (file.exists()) {
            File[] files = file.listFiles();
            if (files != null && files.length > 0) {
                for (int i = 0; i < files.length; i++) {
                    if (files[i].isFile()) {
                        if (files[i].getName().equals(fileName)) {
                            files[i].delete();
                            return;
                        }
                    }
                }
            }
        }
    }

    //-------------------------------------------------------------------------------------------------------

    //读取excel表格xls
    public static List readExcel_xls() {
        //1.创建输入流
        FileInputStream fip = null;
        //2.在输入流中获取正常工作簿
        HSSFWorkbook wb = null;
        //3.在工作薄中获取目标工作表
        Sheet sheet = null;
        try {
            fip = new FileInputStream("D:\\20201002090037.xls");
            wb = new HSSFWorkbook(fip);
            sheet = wb.getSheetAt(0);

            //4.获取目标行
            List rowList = new ArrayList();
            for (int i = 0; i < sheet.getPhysicalNumberOfRows(); i++) {
                Row row = sheet.getRow(i);
                //5.获取目标行的单元格
                List cellList = new ArrayList();
                for (Cell item : row) {
                    item.setCellType(Cell.CELL_TYPE_STRING);//设置为字符串格式，就不会出现类型转换异常了
                    String value = item.getStringCellValue();
                    cellList.add(value);
                }
                rowList.add(cellList);
            }
            return rowList;
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (fip != null) {
                    fip.close();
                }
                if (wb != null) {
                    wb.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    //写进excel表格xls
    public static void wirdExcel_xls(){
        //1.创建输出流
        FileOutputStream fop = null;
        //2.创建工作簿
        HSSFWorkbook wb = null;
        //3.创建工作表
        Sheet sheet = null;
        try {
            fop = new FileOutputStream("D:\\103.xls");
            wb = new HSSFWorkbook();
            sheet = wb.createSheet("103");

            //4.创建目标行
            List<List> rowList = readExcel_xls();
            for (int i =0 ;i<rowList.size();i++) {
                Row row = sheet.createRow(i);
                List cellList = rowList.get(i);
                //5.创建单元格
                for (int j =0;j<cellList.size();j++) {
                    row.createCell(j).setCellValue(cellList.get(j)+"");
                }
            }
            wb.write(fop);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                if (fop != null) {
                    fop.close();
                }
                if (wb != null) {
                    wb.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    //读取excel表格xlsx
    public static List readExcel_xlsx(){
        //1.获取工作簿
        XSSFWorkbook wb = null;
        //2.获取工作表
        XSSFSheet sheet = null;
        try {
            wb = new XSSFWorkbook("D:\\工作簿.xlsx");
            sheet = wb.getSheetAt(0);

            //3.获取目标行
            List rowList = new ArrayList();
            for(Row row :sheet) {
                //4.获取目标行的单元格
                List cellList = new ArrayList();
                for(Cell cell:row) {
                    cell.setCellType(Cell.CELL_TYPE_STRING);//设置为字符串格式，就不会出现类型转换异常了
                    cellList.add(cell.getStringCellValue());
                }
                rowList.add(cellList);
            }
            return rowList;
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if(wb !=null){
                try {
                    wb.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    //写入excel表格xlsx
    public static int wirteExcle_xlsx(){
        //1.创建输出流
        FileOutputStream out = null;
        //2.创建工作簿
        XSSFWorkbook wb = null;
        //3.创建工作表
        XSSFSheet sheet = null;
        try {
            out = new FileOutputStream("D:\\gongzuobiao2.xlsx");
            wb = new XSSFWorkbook();
            sheet = wb.createSheet("工作表一");

            //单元格样式
            XSSFCellStyle cellStyle = wb.createCellStyle();
            cellStyle.setFillForegroundColor(IndexedColors.PINK.getIndex()); //背景颜色
            cellStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);//颜色填充规则，此为实芯规则
            //字体样式
            XSSFFont font = wb.createFont(); //字体
            font.setFontName("黑体");  //字体黑体
            font.setColor(IndexedColors.BLUE.getIndex()); //颜色
            cellStyle.setFont(font);

            //4.创建目标行
            List<List> rowList = readExcel_xlsx();
            for(int i =0;i<rowList.size();i++){
                XSSFRow row = sheet.createRow(i);
                List cellList = rowList.get(i);
                //5.创建单元格
                for(int j =0;j<cellList.size();j++){
                    Cell cell = row.createCell(j);
                    cell.setCellValue(cellList.get(j)+"");
                    cell.setCellStyle(cellStyle); //设置样式
                }
            }
            wb.write(out);
            out.flush();
            return 1;
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                if(out != null) out.close();
                if(wb != null) wb.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return 0;
    }
}
