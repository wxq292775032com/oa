package com.huaji.v01.common.util;

import org.dom4j.*;
import org.dom4j.io.XMLWriter;

import java.io.File;
import java.io.FileWriter;
import java.util.*;

public class XmlType {

    /**
     * 1.获取文档的根节点.
     * Element rootElm = document.getRootElement();
     *
     * 2.取得某节点的单个子节点.
     * Element memberElm=root.element("member"); // member"是节点名
     *
     * 3.取得节点的文字
     * String text=memberElm.getText();//也可以用:
     * String text=root.elementText("name");//这个是取得根节点下的name字节点的文字.
     *
     * 4.取得某节点下名为"member"的所有字节点并进行遍历.
     * List nodes = rootElm.elements("member");
     * for (Iterator it = nodes.iterator(); it.hasNext();) {
     *   Element elm = (Element) it.next();
     *   // do something
     * }
     *
     * 5.对某节点下的所有子节点进行遍历.
     *for(Iterator it=root.elementIterator();it.hasNext();){
     *   Element element = (Element) it.next();
     *    // do something
     * }
     *
     * 6.在某节点下添加子节点.
     * Element ageElm = newMemberElm.addElement("age");
     *
     * 7.设置节点文字.
     * ageElm.setText("29");
     *
     * 8.删除某节点.
     * parentElm.remove(childElm);// childElm是待删除的节点,parentElm是其父节点
     *
     * 9.添加一个CDATA节点.
     * Element contentElm = infoElm.addElement("content");
     * contentElm.addCDATA(diary.getContent());
     */



    public static Object xml2map(Element element) {

        Map<String, Object> map = new HashMap<String, Object>();
        List<Element> elements = element.elements();
        if (elements.size() == 0) {
            map.put(element.getName(), element.getText());
            if (!element.isRootElement()) {
                return element.getText();
            }
        } else if (elements.size() == 1) {
            map.put(elements.get(0).getName(), xml2map(elements.get(0)));
        } else if (elements.size() > 1) {
            // 多个子节点的话就得考虑list的情况了，比如多个子节点有节点名称相同的
            // 构造一个map用来去重
            Map<String, Element> tempMap = new HashMap<String, Element>();
            for (Element ele : elements) {
                tempMap.put(ele.getName(), ele);
            }
            Set<String> keySet = tempMap.keySet();
            for (String string : keySet) {
                Namespace namespace = tempMap.get(string).getNamespace();
                List<Element> elements2 = element.elements(new QName(string, namespace));
                // 如果同名的数目大于1则表示要构建list
                if (elements2.size() > 1) {
                    List<Object> list = new ArrayList<Object>();
                    for (Element ele : elements2) {
                        list.add(xml2map(ele));
                    }
                    map.put(string, list);
                } else {
                    // 同名的数量不大于1则直接递归去
                    map.put(string, xml2map(elements2.get(0)));
                }
            }
        }
        return map;
    }


    //示例代码，无用方法
    public void modifyDoc() throws DocumentException {
        String xmlStr = "<root><a>test</a></root>";
        Document document = DocumentHelper.parseText(xmlStr);
        Element root= document.getRootElement();// 获得根节点；bai

        Object obj = XmlType.xml2map(root);
        System.out.println(obj);

        // 进行迭代；读取根节点下的所有节点 
      /*  for (Iterator<Element> i = root.elementIterator();i.hasNext();) {
            Element element  = i .next();
            System.out.println("节点名称："+element.getName());
            System.out.println("节点值："+element.getData());
        }*/

        try {
            Document doc = null;//new File("file/catalog.xml");  获取节点
            List list = doc.selectNodes("//article");
            Iterator<Element> it = list.iterator();
            while (it.hasNext()) {
                Element el = it.next();
               // el.getName() + "#" + el.getText() + "#" + el.getStringValue();
                //修改title元素
                Iterator<Element> elIter = el.elementIterator("title");
                while(elIter.hasNext()) {
                    Element titleEl = elIter.next();
                    titleEl.getTextTrim();
                }
            }
            //写入到文件
        XMLWriter output = new XMLWriter(new FileWriter(new File("file/catalog-modified.xml")));
        output.write(doc);
        output.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * List<Element> childNodes = xml_node.elements();
     *  for( Element child : childNodes){
     *      String value = child.getText();
     *         String name = child.getName();
     *  }
     */


}
