Vue概念

```
1. Vue.js是目前最火的一个前端框架，React是最流行的一个前端框架（React除了开发网站，还可以开发手机	  APP,Vue语法也可以用于进行手机App开发的，需要借助于Weex)
2. Vue.js 是一套构建用户界面的框架，只关注视图层，方便与第三方库或既有项目整合。
3. Vue.js 一个核心的概念，就是让用户不在操作DOM元素，让程序员可以更多的时间去关注业务逻辑。
4. MVC是后端的分层开发概念，MVVM是前端视图层的概念，主要关注与 视图层分离，也就是说；MVVM是把前端视图层，分为了 三部分Model,View,ViewModel
5. M:这里的M保存的是每个页面中单独的数据; V 就是每个页面中的HtML结构； VM 他是一个调度者，分割了M和V，每当V层想要获取后保存数据的时候，都要有VM做中间的处理。
6.MVVM的思想，主要是为了让我们开发更加方便，因为MVVm提供了数据的双向绑定：注意：数据的双向绑定是有VM提供的。
```

## 基本代码(事件和指令)

```html
<!-- ***** 基础演示 ***** -->
<!-- 1.导入Vue的包 -->
<script src="./lib/vue-2.4.0.js"></script>

<!-- 2.创建一个Vue的实例-->  
<script>
	//当我们导入包之后，在浏览器的内存中，就多了一个 Vue 构造函数
    //我们new 出来的这个vm对象，就是我们MVVM中的，VM调用者
    var vm = new Vue({
        el: '#app',   //表示，当我们 new 的这个 Vue实例，要控制页面上的哪个区域
        // 这里的 data 就是MVVM中的M（model），专门用来保存每个页面的额数据的
        data:{ //data 属性中，存放的是 el 中要用到的数据
        	msg:'欢迎学习Vue'  //通过 Vue提供的指令，很方便的将数据渲染到页面上，程序员不用手动操作								DOM元素
    	}
    })	
</script>
<!-- 将来 new 的Vue实例，会控制这个元素中的所有内容 -->
<!-- Vue 实例所控制的这个元素区域，就是我们的 View -->
<div id="app">
    <p>{{msg}}</p>
</div>

<!-- ***** 三个指令 ***** -->
<!-- 读取data:属性的值 -->
<!-- .... v-cloak (能够解决 插值表达式闪烁的问题)....  -->
<!-- .... v-text(也能解决闪烁问题，但它会覆盖元素中原本的内容，而插值表达式只会替换自己占位符)....  -->
<!-- ... v-html(可以解析html标签).... -->
<!-- ... v-bind(提供用于绑定属性的指令，注意  ：title 等同于 v-bind:title) ... -->
<style>
    [v-cloak]{
        display:none;
    }
</style>
	<div id="app">
        <p v-cloak>{{msg}}</p>
        <h4 v-text="msg"></h4>
        <div v-html="msg"></div>
        <input type="button" value="按钮" v-bind:title="mytitle" />
        			<!-- v-bind里面的属性值可以使用JS合法的表达式，所以可以拼接字符串 -->
        <input type="button" value="按钮" v-bind:title="mytitle +‘123’" />
	</div>

<!-- ... v-on用于事件绑定(@:click 等同于 v-on:click) ...-->
<script>
    var vm = new Vue({
        el:'#app',
        data:{
            //省略....
        }，
        methods:{  //这个 methods属性中定义了当前Vue实例所有可用的方法
            show:function(){
                    alert('Hello')
            }
   		}
    })
</script>
					<!-- 可以绑定不同事件 -->
<input type="button" value="按钮" v-on:click="show" />
//事件加小括号可以传参
```

## 跑马灯

```html
<!-- 1.导入Vue的包 -->
<script src="./lib/vue-2.4.0.js"></script>
<!-- 2.创建一个控制区域 -->
<div id="app">
	<input type="button" value="浪起来" @click="lang" />
	<input type="button" value="低调" />
	<h4>{{msg}}</h4>
</div>
	
<script>
    var vm = new Vue({
        el:'#app',
        data:{
           msg: 'hello!!! Word! ',
           intervalId:null // data上定义 定时器Id  
        }，
        methods:{  //这个 methods属性中定义了当前Vue实例所有可用的方法
            lang:function(){
        		//注意：如果想获取data上的数据，或调用methods中的方法，必须通过this.
        		if(this.intervalId != null)return;		
        
        		var _this = this; //此处赋值是因为 setInterval获取不到this
                this.intervalId = setInterval(function(){
					var start = _this.msg.substring(0,1);
                    var end = _this.msg.substring(1);
                    _this.msg = end + start;	
                    //注意： VM实例，会监听自己身上 data 中所有数据的改变，只要数据一发生变化，就						会自动把最新的数据，从data上同步到页面中去
                },400)
        		
        		// 注意：箭头函数的作用是内部的this永远与外部函数的this保持一致
                setInterval(function() => { }）  
            },
            stop(){ //停止定时器
				clearInterval(this.intervalId);
                this.intervalId = null;
            }    
   		}
    })
</script>
```

## 事件修饰符

```html
<!-- .stop 阻止冒泡 (点击里层事件不让外层时间触发) -->
<!-- .prevent 阻止默认事件 -->
<!-- .capture 添加时间侦听器时使用时间捕获模式(先捕获先触发) -->
<!-- .self 只当事件在该元素本身（比如不是子元素）触发时触发回调 -->
<!-- .once 事件只触发一次 -->
<!-- @click.prevent.once="" （修饰符一次可以使用多个，链式）-->

<div id="app">
    <div @click="divlHandler">
    	<input type="button" value="点击" @click.stop="btnHandler" />
        <a href="http://www.baidu.com" @click.prevent="点击事件名">有问题，先百度</a>
    </div>
</div>


<script>
    var vm = new Vue({
        el: '#app', 
        data:{ },
        methods:{
            divlHandler function(){ console.log("我是div")},
        	btnHandler  function(){ console.log("我是按钮")}
        }
    })	
</script>

```

## 双向数据绑定

```html
<!-- v-Modle(可以实现数据从M到V里面去，也可以实现V到M里面去;只能用在表单元素中) -->
```

## 在Val中使用样式

```html
使用class样式
1. 数组(red,this是样式名)
<h1 :class="['red','thin']"> 这是一个 </h1>
2. 数组中使用三元表达式(falg 为data里面的 boolean)
<h1 :class="['red','thin',flag?'active':'']"> 这是一个 </h1>
3. 数组中嵌套对象
<h1 :class="['red','thin',{'active':flag}]"> 这是一个</h1>
4. 直接使用对象（属性可以带引号也可以不带引号）
<h1 :class="{red:true,italic:true,active:true,thin:true}"> 这是一个</h1>
<h1 :class="classObj"> 这是一个</h1>
<script>
    var vm = new Vue({
        el:'#app',
        data:{
            flag:true,
            classObj:{red:true,thin:true,italic:false,active:false}
        }
    })
</script>

使用内联样式
 1.直接在元素上通过 style的形式，书写对象
<h1 :style="{color:'red','font-size':'40px'}">内容...</h1>	
 2.将样式对象，定义到 data 中，并直接饮用到 style中
data:{
	h1StyleObj:{color:'red','font-size':'40px','font-weight':'200'}
}
<h1 :style="h1StyleObj">内容...</h1>
3.通过数组饮用多个data上的样式对象
<h1 :style="{h1StyleObj,h1StyleObj2}"></h1>
```

## Vue指令之v-for 和 key属性

```html
1.迭代数组
<p v-for="item in list">{{item}}</p>
<p v-for="(item,i) in list">索引：{{i}}  值：{{item}} </p>

2.迭代数组中对象中的属性
<p v-for="user in list">Id：{{user.id}}  值：{{user.name}} </p>
<p v-for="(user,i) in list">Id：{{user.id}}  值：{{user.name}} 索引：{{1}} </p>

3.对象
<p v-for="(val,key) in user">{{ val }} --- {{key}} --- {{i}}</p>
<p v-for="(val,key,i) in user">{{ val }} --- {{key}} --- {{i}} </p>

<script>
    var vm = new Vue({
        el:"#app",
        data:{
            id:'',
            name:'',
            list:[1,2,3,4,5,6],
            list2:[
                {id:1,name:'zs1'},
                {id:2,name:'zs2'},
                {id:3,name:'zs3'}
            ]，
            user:{
            	id:1,
            	name:'托尼颗'，
            	gender:'男'
        	}
        },
        methods:{
           add(){
        	 this.list2.push({id:this.id,name:this.name}) 
     		   //删除 splice   遍历 some(return true)  findIndex
    		}
        }
    })
</script>

<!-- 在2.2.0+的版本里，当在组件中使用 v-for时，key现在是必须的
	用v-for正在更新已渲染过的元素列表时，它默认用“就地复用”策略。如果数据项的顺序被改变，Vue将不是移动
	DDM元素来匹配数据项的顺序，而是简单复用此处每个元素，并且确保它在特定索引下显示它已被渲染过的每个元素。
	为了给Vue一个提示，以便它能跟踪每个节点的身份，从而重用和重新排序现有元素，你需要为没想提供一个唯一key属性
--->
<!-- 注意：v-for 循环的时候，key属性只能使用 number或string -->
<!-- 注意： key在使用的时候，必须使用 v-bind 属性绑定形式，指定key值 -->
<p v-for="item in list2" :key="item.id">
    <input type="checkbox"/>{{item.id}} 
</p>
```

## if结构

```html
<!-- v-if 的特点 每次都会重新删除或创建元素，有较高的切换性能消耗 -->
<!-- v-show的特点 每次不会重新进行DOM的删除和创建操作，只是切换了元素的display:none样式，有较高初始化消耗 -->
<!-- 如果元素涉及到频繁的切换，最好不要使用v-if,而是推荐使用 v-show -->
<!-- 如果元素可能永远也不会被显示出来被用户看到，则推荐使用v-if -->
<h3 v-if = "flag">... <h3>
<h3 v-show="flag">...</h3>    
    
<script>
    var vm = new Vue({
        el:"#app",
        data:{
          flag:true
        },
        methods:{}
    })
</script>    
```

## list加强筛选

```html
<!--自定义一个search方法，同时，把所有的关键字，通过传参的形式，传递给了search方法 -->
<!-- search是个指令可以访问data里面任何数据 -->
<!-- 在search方法内部，通过执行for循环，把所有符合搜索关键字的数据，保存到一个新新数组中返回 -->
<tr v-for="item in search(keyWords)" :key="item.id">
    <td>{{ item.id }}</td>
    <td v-text="item.name"></td>
    <td>
        <a href="" @click:prevent="del(item.id)">删除</a>
    </td>
</tr> 
<script>
    var  vm = new Vue({
		el:'#app',
        data:{
            id:'',
            name:'',
            keywords:'',
            list:[
                {id:1,name:'奔驰'，ctime:new Date()},
        		{id：2,name:'宝马'，ctiem:new Date()}
            ]
        },
        methods:{
            add(){ //添加的方法。。。
                
            },
            del(id) { // 根据Id删除数据
                    
            },
            search(keywords){ //根据关键字,进行数据的搜索
                var newList = [];
                this.list.forEcah(item=>{
                    if(item.name.indexOf(keywords) != -1){
                            newList.push(item);
                    }
                })   
                return newList;
               
                //方法2：
                //注意： forEach  some  filter(查询到的符合条件的得到一个新数组)  findIndex 这                           些都属于数组的新方法
                //都会对数组中的每一项，进行遍历，执行相关的操作
               return this.list.filter(item=>{
                     //注意：ES6中，为字符串提供了一个新方法，叫做                                                     String.prototype.includes('要包含的字符串')
                    //如果包含返回true,否则返回false
                    if(item.name.includes(keywords)){
                        return tiem
                    }
                })
            }  
            
        }    
    })
</script>
```

## 过滤器

```html
<!-- 在Vue.js允许你自定义过滤器，可用作一些常见的文本格式化，过滤器可以用在两个地方：mustache 和 v-bind表达式 -->
<!--过滤器调用时候的格式 {{name | 过滤器名称}} -->

<!-- 定义过滤器 -->
<script>
    // 过滤器名称怎么拿？直接从funciton的第一个参数拿
    //过滤器中的funciton,第一个参数，已经被规定死了，永远都是 过滤器 管道符前面 传递过来的数据
    Vue.filter('过滤器名称'，funciton(){
		return data + '123'
    })
</script>

<!-- 实例 -->
<div id="app">
    <p>{{ msg | msgFormat }}</p>
    <p>{{ msg | msgFormat2（'疯狂'） }}</p>
    <!-- 过滤器可以多次调用，执行顺序先处理第一个过滤器，处理完的结果交给第二个处理 -->
    <p>{{ msg | msgFormat2（'疯狂'）| msgFormat3 }}</p>
</div>

<script>
    // 定义一个 Vue 全局的过略器，名字叫做 msgFormat
    Vue.filter('msgFormat',function(msg){
        return msg.replace('输出'，'不输出')；
        // return msg.replace(/单纯/g,'邪恶')；
    })
    Vue.filter('msgFormat2',function(msg，arg){
        return msg.replace('输出'，arg)；
        // return msg.replace(/单纯/g,'邪恶')；
    })
     Vue.filter('msgFormat3',function(dateStr,pattern == ""){
        var dt = new Date(msg)
        //
        var y = dt.getFullYear();
        var m = dt.getMonth();
        var d = dt.getDate();
         
       // return y+"-"+m+"-"+d;
       //  return '${y}-${m}-${d}';
         
         if(pattern.toLowerCase() === 'yyyy-mm-dd'){
             return '${y}-${m}-${d}';
         }else {
             var hh = dt.getHours()
             var mm = dt.getMinutes();
             var ss = dt.getSeconds();
             return '${y}-${m}-${d} ${hh}:${mm}:${ss}';
         }
         
    })
    
    var  vm = new Vue({
        el:'#app',
        data:{
            msg:'单纯内容输出'
        }，
        methosd:{}
    })
</script>

<!-- 定义私有过滤器 -->
<!-- 过滤器调用的时候，采用的是就近原则，如果私有过滤器和全局过滤名称一致了，这个时候优先调用私有过略器-->
<script>
    var vmPrivate = new Value({
        el:'#app2',
        data:{},
        methods:{},
        filters:{ //定义私有过略器 
            dateFormat:function(dateStr,pattern){
                var dt = new Date(dateStr);
                // padStart 如果时间是一位数，前面自动补零
                var m = (dt.getMonth()+1).toString.padStart(2,0);
                
                //省略内容....
            }
        }
    })
</script>

```

## 按键修饰符

```html
@keyUp.enter="add"
.enter .tab  .delete .esc  .space  .up .down  .left  .right 
<!-- 其余的可以网上搜索 键值对应码  如  @keyU.113   按f2触发 -->

<!-- 或者定义全局按键修饰符 -->
Vue.config.keyCodes.f2 = 113;
@keyUp.f2="add"

<!-- 在Vue中所有 *指令*，在调用的时候，都以V-开头 -->

<!--
	使用 Vue.directive() 定义全局的指令  v-focus
	其中：参数1： 是指令名称，在定义的时候指令的名称前面，不需要加 v-前缀
	但是： 在调用的时候，必须在指令名称前 加上 v- 前缀来进行调用
	参数2：是一个对象，这个对象身上，有一些指令相关的函数，这些函数可以在特定的阶段，执行相关的操作
-->
<script>
    Vue.directive('focus',{
        bind:function(el){  // 每当指令绑定到元素上的时候，会立即执行这个bind函数，只执行一次
            // 注意： 在每个函数中，第一参数，永远是 el，表示 被绑定了指令的那个元素，这个el参数是一				个原生的JS对象
            
            //不管元素有没有插入到页面中去，这个元素肯定有了一个内联样式
            el.style.color = 'red'
            // 和样式相关的凑在哦一般可以在bind执行
        },
        inserted:function(el，binding){ // inserted 表示元素 插入到 DOM 中的时候，会执行 inserted函数								【触发一次】
             //一个元素，只有插入DOM之后，才能获取焦点 
            // 和 Js行为相关的操作，最好在inserted 中去执行，防止 Js行为不生效
            el.fcous();
            
            //  v-focus("aaa")
            console.log(binding.name); //输出指令名称
            console.log(binding.value); //输出值  1+1 =2
            console.log(binding.expression); //输出值  1+1=’1+1‘
        },
        updated:function(el){  // 单VNode更新的时候，会执行 updated,可能会触发多次
            
        }
    })
</script>
<!-- 私有指令 -->
<script>
    var vm2 = new Value({
        el:'#app2',
        data:{},
        methods:{},
        directives:{  //自定义私有指令
            'fontweight':{
                bind:function(el,binding){
                    el.style.fontWeight = binding.value
                }
            }，
            'fontsize':function(el,binding){  //注意：这个function 等同于把代码写到了bind和                                                      update中去
        		el.style.fontSize = binding.value
    		}
                        
        }
    })
</script>

<!-- 函数简写 -->

```

## Vue实例的生命周期

```html
生命周期： 从Vue实例创建、运行、到销毁期间，总是伴随着各种各样的事件，这些事件，统称为生命周期
生命周期钩子： 就是生命周期事件的别名而已
主要生命周期函数分类：
	创建期间的生命周期函数：
		. beforeCreate:实例刚在内存中被创建出来，此时，还没有初始化好 data 和 methods属性
		. created:实例已经在内存中创建Ok,此时 data 和 methods已经创建OK,此时还没有开始编译模板
		. beforeMount:此时已经完成了模板的编译，但是还没有载到页面中
	运行期间的生命周期函数
    	.beforeUpdate:状态更新之前执行此函数，此时 data 中的状态值是最新的，但是界面上显示的数据还      	  是旧的，因为此时还没有开始重新渲染DOM节点。
    	.updated:实例更新完毕之后调用此函数，此时 data 中的状态值 和 界面上显示的数据，都已将完成更           新，界面已经被重新渲染好了。
    销毁期间的生命周期函数
    	.beforeDestroy： 实例销毁之前调用。在这一步，实例仍然完全可用。
    	.destroyed: Vue 实例销毁后调用。调用后，Vue 实例指示的所有东西都会分解绑定，所有的事件监听          器会被移除，所有的子类实例也会被销毁
    	
<script>
    var vmPrivate = new Value({
        el:'#app',
        data:{},
        methods:{},
        beforeCreate(){
            //注意：在beforeCreate 生命周期函数执行的时候，data 和 methods中的数据都还没有初始化
        }，
        created(){ //这是遇到的第二个生命周期函数
        	//在created中，data和 methods 都已经被初始化了
        	//如果要调用 methods 中的方法，或者操作 data 中的数据，最早，只能在created中操作
    	},
        beforeMount(){ //这是遇到的第3个生命周期函数，表示 模板已经在内存中编辑弯沉过了，但是尚未把                    模板渲染到页面中
        }，
        mounted(){ //这是遇到的第4个生命周期函数、表示、内存中的模板，已经真实的挂载到了页面中，用户  已经可以看到渲染好的页面了
          //这是实例创建期间的最后一个生命周期函数，当执行完mounted就表示，实例已经被完全创建好了  
        },
   		//接下来是运行中的两个事件
        //这俩个事件会根据data数据的改变，有选择性的触发0次到多次
        beforeUpdate(){
			//界面还没有被更新，数据更新了会被触发
            // 页面中的显示的数据还是旧的，此时 data 数据是最新的，页面尚未和最新的数据保持同步
        },
        updated(){
			//这个执行的时候，页面和 data 数据已经保持同步了，是最新的的
        }    
    })
</script>
    	
```

## vue-resource实现get,post,jsonp请求

```html
<!-- 设置根路径 -->
Vue.http.options.root = '/root';
<!-- 如果我们通过全局配置了，请求的数据及接口 根域名，则在每次单独发起 http 请求的时候，请求url路径应该是相对路径开头，前面不能带 / ,否则不会启用根路径 -->
api/getprodlist
<!-- 全局启用emulateJSON -->
Vue.http.options.emulateJSON = true;


<!-- 除了  vue - resource之外，还可以使用  ‘axios’ 的第三方包实现数据的请求 -->
<!-- 1.导包vue-resource-->
<!-- 注意： vue-resource 依赖于 Vue,所以先后顺序要注意 -->
<!-- this.$http.jsonp -->
<!-- 跨域可以使 vscode 的插件解决 -->
<!-- promise消除异步回调地狱的 ES6里面有-->
<script src="./lib/vue-resource-1.3.4.js"></script>


methods:
	this.$http.get("/someUrl",[options]).then(successCallback,errorCallback);
    this.$http.post("/someUrl",[body],[options]).then(successCallback,errorCallback);

<script>
    var vm = new Vue({
        el:'#app',
        data:{},
        methods:{
            getInfo(){ //发起get请求
                this.$http.get('请求地址').then(function(result){
                    //回调函数
                    //通过 result.body 拿到服务器返回的成功的数据
                })
            }，
            postInfo(){
        		//手动发起的 Post请求，默认没有表单格式，所以，有的服务器处理不了
        		// 通过 post 方法的第三个参数，设置 提交内容类型 为普通表单数据格式
          		this.$http.post('请求地址',{name:this.name},                                                                  {emulateJSON:true}).then(result=>{
					console.log(result.body)
        		})
    		},
            jsonpInfo(){ //发起JSON P 请求
                this.$http.jsonp('请求地址').then(result=>{
                    console.log(result.body);
                })   
            }    
        }
    })
</script>

<!-- 关于跨域问题 -->
1.由于游览器的安全限制，不允许AJAX访问协议不同，域名不同，端口好不同的 数据接口，浏览器认为这种访问不安  全
2.可以通过动态创建script标签的形式，把script标签的src属性，指向数据接口的地址，因为script标签不存在跨域限制，这种数据获取方法，称作JSONP(注意：根据JSONP的实现原理，知晓，JSONP只支持Get请求) 
具体实现过程：
	.现在客户端定义一个回调方法，预定义对数据的操作；、
	.再把这个回调方法的名称，通过URL传参的形式，提交到服务器的数据接口；
	.服务器数据接口组织好要发送给客户端的数据，再拿着客户端传递过来的回调方法名称，拼接出一个调用方法的      字符串，发送给客户端去解析执行？
    .客户端你到服务器返回的字符串之后，当作Script脚本去执行，这样就能够拿到JSONP的数据了；
<!-- 创建node -->     
<!-- app.js -->
// 导入 http 内置模块
const http = require('http')
// 这个核心模块能够帮我们解析 URL地址，从而拿到 pathname  query
const urlModule = require('url')

// 创建一个 http 服务器
const server = http.createServer()

// 监听 http 服务器的 request 请求
server.on('request',function（req,res）{
	
    const {pathname:url,query} = urlModule.parse(req.url,true);
	
   
	if(url === '/getscript'){
	    // 拼接一个合法的JS脚本,这里拼接的是一个方法的调用
		var scriptStr = '${query.callback}()';
		//res.end 发送 客户端，客户端去把 这个 字符串 ，当作Js代码去解析执行
		res.end(scriptStr)
    } else {
		res.end('404')
    }	

})

//指定端口号并启动服务器监听
server.listen(3000,function(){
	console.log('请求地址');
})

<!-- 客户端JSONP页面 -->
<script>
    function showInfo（）{
        
    }
</script>
<script src = "node.js页面?callback=showInfo"></script>

https://www.bilibili.com/video/BV1n4411b7z7?p=34   //跨域学习地址
```

### axios

```html
<script src="https://unpkg.com/axios/dist/axios.min.js">

axios.get("地址")。then(funciton(response){
    
},funciton(err){})
```



## Vue中的动画

```html
<!-- 1.使用transition 元素，把需要被动画控制的元素，包裹起来 -->
<!-- transition元素是Vue官方提供的 -->
<transition  name="my">
    <h2 v-if="flag">
        内容...
    </h2>
</transition>

<!-- 2.自定义两组样式，来控制 transition内部的元素实现动画 -->
<styel>
    <!-- v-enter [这是一个时间点] 是进入之前，元素的起始状态，此时还没有开始进入 -->
    <!-- v-leave-to []  是动画离开之后，离开的终止状态，此时，元素动画已经结束 -->
    .my-enter,
    .my-leave.to{
         opacity:0;
    	 transform: translatex(80px);
    }
    <!-- v-enter-active [入场动画的时间段] -->
    <!-- v-leave-active [离场动画的时间段] -->
    .my-enter-active,
    .my-leave-active{
    	transition:all 0.4s ease;
    } 
    
    <!-- 注意 v- 替换 transition 的 name属性名  -->
</styel>

<!-- animate动画 -->
<!-- 1.导包（第三方的动画类库） -->
<link rel="stylesheet" href="./lib/animate.css"/>
<!-- 入场bounceIn  离场 bounceOut -->
<transition enter-active-class="animated 样式"  leave-active-class="animated 样式"  :duration="200">
	//注意 enter-active-class也可以放在元素身上; 
    //:duration 是入场和离场的时长 :duration={enter:200,leave:400}
</transition>
<!-- 样式类库 -->
https://daneden.github.io/animate.css/

<!-- 动画之钩子函数（动画的生命周期函数） -->
<!-- 属性中声明javaScript钩子 -->
<transition>
	v-on:before-enter="beforeEnter"
    v-on:enter = "enter"
    v-on:after-enter="afterEnter"
    v-on:enter-cancelled = "enterCancelle"
    
    v-on:beforre-leave = "beforeLeave"
    v-on:leave:"leave"
    v-on:after-leafe="afterLeave"
    v-on:leave-cancelled="leaveCancelled"
</transition>
<!-- 实例 -->
<transition @before-enter="beforeEnter" @enter="enter" @after-enter="afterEnter">
	
</transition>

<script>
    var vm = new Vue({
        el:''
        data:{},
        methods:{
            //注意：动画钩子函数的第一个函数：el，表示要执行动画的那个DOM元素，是原生的JS DOM对象，可以认为，el是通过 document.getElementByid('') 方式获取到原生对象        
                beforeEnter(el){
        			//beforeEnter 表示动画入场之前，此时，动画尚未开始，可以在beforeEnter 中，设置元素开始动画之前的起始样式	
        			//设置小球开始动画之前的，起始位置
        			el.style.transform = "translate(0,0)";
    			},
                enter(el,done){
                    //这句话没有实际的作用，但是如果不写，出不来动画效果
                    el.offsetWidth
                    //enter 表示动画开始之后的样式，这里可以设置小球完成动画之后的结束状态 
                    el.style.transform = "translate(150px,450px)";
                    //中间过渡的时长
                    el.style.transition="all 1s ease"
                    
                    //这里的 done,是afterEnter这个函数，也就是说：done是函数引用
                    //如果不调那么afterEnter会出现一些延迟的情况
                    done()
                },
                afterEnter(el){
                   //动画完成之后，会调用 afterEnter
                    
                }
        }             
    })
</script>

<!-- 列表动画 -->
<!-- 在实现列表过渡的时候，如果需要过渡的元素，是通过v-for循环渲染出来的 
		不能使用transition包裹，需要使用 transitionGroup-->
<!--给transitionGroup加上appear属性可以添加入场时的效果 -->
<!--通过为transition-Group设置 tag属性（tag="ul"）,可以指定渲染元素，如果不指定默认span标签  -->
<transition-Group></transition-Group>

附加:
<!--下面的 .v-move 和 .v-leave-active 配置使用，能够实现列表后续的元素，渐渐地漂上来的效果  -->
<style>
.v-move{
	transition:all 0.6s  ease;
}
.v-leave-active{
	position:absolute;
}
</style>
```

## 组件

```html
什么是组件：组件的出现，就是为了拆分Vue实例的代码量，能够让我们以不同的组件。来划分不同的功能模块，将来我们需要什么功能，我就可以去调用对应的组件即可；
组件化和模块化的不同：
	模块化：是从代码逻辑的角度进行划分的；方便代码分层开发，保证每个功能模块的职能单一
	组件化：是从UI界面的角度进行划分的；前端的组件化，方便UI组件的重用
<!-- 定义全局组件第一种方式 -->
<script>
    //1.1使用Vue.etend来创建全局的Vue组件 	
    var com1 = Vue.extend({
        template:'<h3>...内容... </h3>'  //通过template属性，指定了组件要展示的HTML结构
    })
    //1.2 使用Vue.component('组件的名称'，创建出来的组件模板对象)
    Vue.component('myCom1',com1)
</script>

<div id="app">
<!-- 如果要使用组件，直接，把组件的名称，以HTML标签的形式，引入到页面中，即可 -->
<!-- 组件引用时，如果使用驼峰命名，在需要把大写的驼峰改为小写的字母，同时，两个单词之间使用-链接，如果不使用驼峰则不需要 -->
    <my-com1></my-com1>
</div>

<!-- 定义全局组件第二种方式 -->
Vue.component('myCom1', Vue.extend({
    template:'<h3>...内容... </h3>' 
}）)

<!-- 定义全局组件第三种方式 -->
<!-- 注意：组件模板属性指向模板内容，必须有且只能有唯一的一个跟元素-->
Vue.component('myCom1',{
    template:'<h3>...内容... </h3>' 
})

<!--定义全局组件第四种方式 -->
<!--注意： 要在被控制的#app外面定义-->
<template id="tmp1">
    <div>
        <h1></h1>
    </div>
</template>
<script>
    Vue.component('myCom1',{
        template:'#tmp1'  //引用
    })
</script>

<!-- 定义私有主键方式1 -->
var vm2 = new Vue({
	el:'app2',
	data{},
    components:{  //定义实例内部私有组件
        login:{
			template:'<h1></h1>'
        }
    }
})
<!--使用-->
<div id="app2">
    <login></login>
</div>    

<!-- 定义私有组件方式2 -->
<template id="templ2">
    <h2></h2>
</template>

 var vm2 = new Vue({
	el:'app2',
	data{},
    components:{  //定义实例内部私有组件
        login:{
			template:'#templ2'
        }
    }
})
```

组件中的data和methods

```html
<!-- data -->
<script>
    //1. 组件可以有组件的 data 数据
    //2. 组件的 data 和 实例的 data 有点不一样，实例中的data可以为一个对象，但组件中的data必须是一个方法
    //3.组件中的data 除了必须为一个方法之外，这个方法内部，还必须返回一个对象才行
    //4.组件中的 data 数据，使用方式，和实例中的data使用方式完全一样
    Vue.component('mycom1',{
        template:'<h1> {{msg}} </h1>'，
        data:function(){
            return {
				msg:'这是组件中的data定义的数据'
            };
    	}
    })
</script>

<!-- methods -->
<template id="temp1">
    <div>
    	<input type="button" value="+1"  @click="increment">
        <h3>{{count}}</h3>
    </div>
</template>

<script>
vue.component('counter',{
	template:'#temp1',
    data:functon(){
		return {count:0};
    },
    methods:{
        increment(){
			this.count++;
        }
    }
    })
</script>

<!-- 不同组件之间的切换第一种方式  --->
<div id="app">
    <a href="" @click.prevent="flag=true" >登录</a>
    <a href="" @click.prevent="flag=false">注册</a>
   
    <login v-if="flag"></login>
    <register v-elase ="flag"></register>
</div>

<!-- 不同组件之间切换第二种方式 -->
<div id="app">
    <a href=""  @click.prevent="comName='login'">登录</a>
    <a href=""  @click.prevent="comName='register'">注册</a>
    
    <component :is="comName"></component>
</div>

<script>
    Vue.component('login',{
        template:'<h3>...</h3>'
    })
    
    Vue.component('register',{
        template:'<h3>...</h3>'
    })
    
    var vm = new Vue({
        el:'#app',
        data:{
            comName:''//
        },
        methods:{
            
        }
    })
</script>

<!--组件之间添加动画-->
<!-- mode属性用于设置组件切换模式 -->
<style>
	.v-enter,
    .v-leave-to{
        opacity:0;
        transform:translateX(150px)
    }
    
    .v-enter-active,
    .v-leave-active{
        transition:all 0.5s ease;
    }
</style>


<transition mode="out-in">
    <component :is="comName"></component>
</transition>
```

## 父组件向子组件传递

```html
<!-- 传值 -->
<div id="app">
    <!-- 父组件，可以在引用子组件的时候，通过属性绑定（v-bind:）的形式，把需要传递给 子组件的数据，以属性绑定的形式，传递到子组件内部，供子组件使用 -->
    <com1 v-bind:parentmsg="msg"></com1>
</div>

<script>
	//创建Vue实例，得到ViewModel

    var VM = new Vue({
        el:'#app',
        data:{
            msg:'123 父组件中的数据'
        },
        methods{},
        components:{
           //结论：经过演示，发现，子组件中，默认无法访问到父组件中data上的数据和methods中的方法 
           com1：{
             data(){  // 注意：子组件中的数据是自身私有的，data的数据都是可读可写的
        		return {}  	
   			 },       
              template:'<h1>这是子组件---{{parentmsg}}</h1>',
             // 注意： 组件中所有props 中的数据，都是通过父组件传递给子组件的
             // props中的数据都是只读的     
              props:['parentmsg'],  //把父组件传递过来的 parentmsg属性，先在props数组中，定义一下，这样才能使用这个数据     
           }          
        }             
        
    })
</script>

<!-- 传方法 -->
<div id="app">
    <!-- 父组件向子组件传递方法，使用的是 事件绑定机制； v-on,当我们自定义了一个事件属性之后，那么，子组件就能够，通过某些方式，来调用传递进去这个方法了;-->
    <!-- func自定义的方法名字 -->
    <!-- 注意show方法加（）表示调用方法将返回值返回给它，不加括号表示把方法的引用原封不动交给它 -->
    <com2 @func="show"></com2>
</div>

<template id="tmp1">
    <div>
        <h1>这是自组件</h1>
        <input type="button" value="按钮" @click="myclick">
    </div>
</template>

<script>
    //定义了一个字面量类型的组件模板对象
    var com2 = {
        template:'#tmp1' 
        methods:{
            myclick(){
                // emit  是触发调用的意思(调用父组件的方法)
				this.$emit('func')
                //传参形式的调用，第二个参数为参数
                this.$emit('func','你好')
            }
    	}
    }
    
    var vm = new Vue({
        el:'#app',
        data:{},
        methods:{
            show(data){
                console.log('调用了父组件身上的show方法')
             // 还可以通过传参的方式 让子组件向父组件传值
            }
        }，
        components:{
        	com2
    	}
        
    })
    
    
</script>
```

## 获取DOM元素和组件

```html
<h3 id="myh3" ref ="myh3">哈哈 </h3>
console.log(this.$refs.myh3.innerText)
this.$refs.myh3.show()  //调用方法
```

## 路由

```
什么是路由？
	1.后端路由：对于普通网站，所有超链接都是URL地址，所有URL地址都对应服务器上对应的资源
	2.前端路由：对于单页面应用程序来说，主要通过URL中的hash（#号）来实现不同页面之间的切换，同时Hash有一个特点：HTTP请求中不会包含hash相关的内容；所以单页面程序中的页面跳转主要用hash实现
	3.在单页面应用程序中，这种通过hash改变来切换页面的方式，称作前端路由（区别于后端路由）
```

```html
<!-- 1.安装 vue-router 路由模块 -->
<script scc="./lib/vue-router-3.0.1.js"></script>

<script>
    var login = {
        template: '<h1>登录组件</h1>'
    }
    var register = {
        template: '<h1>登录组件</h1>'
    }
    
	//2. 创建一个路由对象，当导入 vue-router 包之后，在window 全局对象中，就有了一个路由的构造函数，叫做 VueRouter 
    // 在 new 路由对象的时候，可以为 构造函数 ，传递一个配置对象
    var routerObj = new VueRouter({
       // route  //这个配置对象中的 route 表示【路由匹配规则的意思】
        routes:[  //路由匹配规则
           // 每个路由规则，都是一个对象，这个规则对象，身上，有两个必须的属性：
           // 属性1 是 path， 表示监听 哪个路由链接地址；
           // 属性2 是 component，表示，如果，路由是前面匹配到的 path ,则展示 component属性对应的哪个组件 
            // 注意： component 的属性值，必须是一个 组件的模板对象，不能是组件的引用名称
         //   {path:'/',component:login}  默认进入的组件但一般使用下面这种
            {path:'/',redirect:'/login'}  // 默认进入的组件,注意这里的redirect和Node中的是两码事
            {path:'/login',component:login} ，
            {path:'/register',component:register}
        ]，
        // 修改样式有两种方法，一种是修改默认提供的 .router-link-active
        // 改 linkActiveClassa
        linkActiveClassa;'myActive'
    });
    
    
    // Vue实例
    var vm = new Vue({
        el: '#app',
        data:{},
        methods:{},
        router:routerObj  //将路由规则对象，注册到vm 实例上，用来监听URL 地址的变化，然后展示对应的组件
    })
</script>

<div id="app">
    <!-- 注意前面要加#号（作为了解，一般使用 router-link） -->
    <a href="#/login">登录</a>
    <a href="#/register">注册</a>
    
    <!-- router-link 默认渲染为a标签-->
    <!-- 可以设置tag属性来指定标签 -->
    <router-link to="/login" tag="span">登录</router-link>
    <router-link to="/register">注册</router-link>
    
    <!--这是 vue-router 提供的元素，专门用来当做占位符的，将来，路由规则匹配到的组件，就会展示到这个router-view 中去 -->
    <router-view></router-view>
</div>

<!-- 路由动画 -->
<transition>
 	<router-view></router-view>
</transition>
  
```

## 路由规则里面定义参数

```html
<div id="app">
	
</div>

<script>
    var login = {
        template:'<h1>登录</h1>'
    }
    var login = {
        template:'<h1>登录</h1>'
    }
    
    var vm = new Vue({
        el:'#app'
        data:{},
        methods{},             
        
    })
</script>

<!-- 路由规则中定义参数 -->
<div id="app">
	<!-- 如果在路由中，使用 查询字符串，给路由传递参数，则不需要修改路由规则的path属性 -->
	<router-link to="/login?id=10&name=zs">登录</router-link>
	<router-link to="/register">注册</router-link>	
	<router-view></router-view>
    
    <!--路由传参的第二种方式-->
    <router-link to="/login/22">登录</router-link>
	<!-- 修改路由规则-->
    //{path:'/login/:id',component:login}
    
</div>
<script>
    var login = {
        template:'<h1>登录--- {{$route.query.id}}  --{{$route.query.name}} </h1>'，
        created(){ //组件的生命周期钩子函数
            console.log(this.$route.query.id);
            
            //第二种方式获取值则使用
            console.log(this.$route.params.id)
        }
    }
    var register = {
        template:'<h1>注册</h1>'
    }
    
    var router = new VaueRouter({
        routes:[
            {path:'/login',component:login},
            {path:'/register',component:register}
        ]
    })
    
    var vm = new Vue({
        el:'#app',
        data:{},
        methods:{},
        router:router
    })
</script>
```

## 路由嵌套

```html
<div id="app">
    <router-link to="/account">Account</router-link>
    
    <router-view></router-view>
</div>

<template id="tmpl">
    <div>
        <h1>这是 Account 组件</h1>
        
        <router-link to="/account/login">登录</router-link>
        <router-link to="/account/register">注册</router-link>
    </div>
</template>

<script>
    //组件的模板对象
    var account = {
        template:'#temp1'
    }
    
    var login = {
        template:'<h2>login</h2>'
    }
     var register = {
        template:'<h2>register</h2>'
    }
    
    var router = new VueRouter({
        routes:[
            {
                path:'/account',
                component:account
                children:[
                 {path:'login',component:login },
            	 {path:'register',component:register },
                ]
            }
        ]
    })
    
    //创建 Vue实例，得到 ViewModel
    var vm = new Vue({
        el:'#app',
        data:{},
        methods:{},
        router
    })
</script>
```

## 路由命名视图实现经典布局

```html
<style>
    html,body{
        margin:0;
        padding:0;
    }
    .header{
        background-color:orange;
        height:80px;
    }
    h1{
        margin:0;
        padding:0;
        font-size:16px;
    }
    
    .container{
        display:flex;
        height:600px;
    }
    .left{
        background-color:lightgreen;
        flex:2;
    }
    .main{
        background-color:lightgreen;
        flex:8;
    }
</style>

<body>

<div id="app">
    <router-view></router-view>
    <div class="container">
         <router-view name="left"></router-view>
         <router-view name="main"></router-view>
    </div>
</div>


<script>
    var header = {
        template:'<h1 class="header">Header头部区域</h1>'
    }
    
    var leftBox = {
        template:'<h1 class="left">Left侧边区域</h1>'
    }
    
    var mianBox = {
        template:'<h1 class="main">主体区域</h1>'
    }
    
    //创建路由对象
    var router = new VueRouter({
        routes:[
            {path:'/',component:{
                'default':header,
                'left':leftBox,
                'main':mianBox
            }}
        ]
    })
    
    //创建 Vue 实例，得到 ViewModel
    var vm = new Vue({
        el:'#app',
        data:{},
        methods{},
        router
    })
</script>
</body>
```

## 监听

```html
<!-- 第一种方式可以通过 keyup  change 这些事件来监听 -->

<!-- 第二种方式 -->
<script>
    var vm = new Vue({
        el:
        data:{
        	firstname:'',
        	lastname:'',
        	fullname:'',
    	},
        methods:{},
        watch:{ // 使用这个 属性，可以监视 data 中指定数据的变化，然后出发这个 watch 中对应的function 处理函数
            'firstname':function(newVal,oldVal){
                //第一种获值方式
                this.fullname = this.firstname + '-' + this.lastname
                //第二种获值方式(newVal为新值，oldVal为旧值)
                this.fullname = newVal
            }，
            'lastname':function(newVal){
                this.fullname = this.firstname + "-" + newVal;
            },
             //监听路由地址的改变   
            '$route.path':function(newVal,oldVal){
               console.log(newVal +'---' + oldVal);     
            }    
        },
        computed:{  //在 computed 中，可以定义一些属性，这些属性叫着【计算属性】,计算属性的本质就是一个方法，只不过，我们在使用这些计算属性的时候，是把他们的名称，直接当做属性来使用的；并不会把计算属性当做方法去调用
           //注意：计算属性引用的时候不要加（）调用，直接把它当普通属性去使用就好了
           //注意：只要计算属性，这个function内部，所用到的任何data中的数据发生了变化，就会立即重新计算这个计算属性的值
            'fullname':function(){
                return this.firstname + '-' +this.lastname
            }      
        }    
    })
</script>
```

<!-- -->

## 其他

```
var vm = new Vue({
    el:
    data:{},
    methods:{},
    filters:{},
    directives:{},
    
    beforeCreate(){},
    created(){},
    beforeMound(){},
    mounted(){},
    beforeUpdate(){},
    updated(){},
    beforeDestroy(){},
    destroyed(){}
   
})

尚蛙谷
```

