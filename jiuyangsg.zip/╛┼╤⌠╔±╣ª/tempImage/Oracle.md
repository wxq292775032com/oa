### 概念论述

```
1.数据库： 在Oracle中属于一个专业名词，是一个逻辑概念。在物理上表现为数据文件、日志文件和控制文件。
2.全局数据库名：用于区分一个数据库的标识。
3.数据库实例：由这个实例来访问数据库中的数据。
4.表空间：数据库由若干个表空间构成，用户在数据库建立的所有内容，都被存在表空间中。
5.数据文件.dbf  控制文件.ctl   日志文件.log
```

### 配置网络服务

```
监听协议  地址  端口号   服务名
tnsnames.ora  客户端   listener.ora 服务器

sys 超级用户
system
scott/tiger
若scott/tiger用户被锁：==========================
conn  sys/bdqn  as sysdba;
alter user scott account  unlock; //解锁
conn scott/tiger  //弹出一个修改密码的对话框，修改一下密码就可以

修改sys和system用户密码：=========================
进入sqlplus  进行密码重置
sqlplus/as sysdba
空
alter  user sys  identified by  oracle;
conn sys/oracle as  sysdba;
aleter  user  system  identified by oracle;
```

### 数据类型

```

1. 字符数据类型
    1.1. char ：固定长度的字符串，长度可以是1-2000字节。如果不指定长度默认为1。
         当用户输入值小于长度，数据库用空格填充至固定长度。如果用户大于指定长度，则数据库返回错误报告。
    1.2. varchar2 : 可变长度。
    1.3. nchar: 和char一样，只是长度一个按字节，而另一个按字符。（一字符等于两字节）。
    1.4. nvarchar2: 和varchar2一样，同样是一个按字节，一个按字符。
 2. 数值数据类型 
    2.1. number：可以存正数、负数、零、定点数和精度为38位的浮点数。
          number(p,s);  s表示小数点右边的位数  p表示有效位数有几位
3. 日期时间数据类型
   3.1. date : 用于存储日期和时间数据    sysdate  获取当前日期和时间
   3.2. timestamp ： 该数据类型包含时区信息，秒精确到小数点6位       systimestamp  返回当前日期时间和时区
   附加： alter  session  set nls_date_format = 'YYYY-MM-DD HH24:MI:SS';
     环境变量： 变量名  nls_date_format   变量值  YYYY-MM-DD HH24:MI:SS
4. LOB数据类型
   4.1  clob :存储大量字符数据。
   4.2  blob :可以存储较大的二进制对象。如图形，视频剪辑。
   4.3  bfile:能够将二进制文件存储在数据库外部的操作系统文件中。
   4.4  nclob:存储大的字符数据，同时支持固定宽度字符和可变宽度字符。 
```

### 表操作

```
创建表： create table  teacher(
      tname varchar2(20) not null
)
更改表：
    添加
    alter table teacher add(
        age number(7,2),
        hirdate date
    )
    修改
   alter table  teacher modify(tname varchar2(30)));
   删除
   alter table teacher drop column wechat;
   显示表 
   desc teacher
删除表
  drop table teacher      
    sqlplus t04/t04
 ================================
 truncate table dept 毁灭删除
    导入脚本
    @加上sql文件的路径
    
    ==========
    slect * from dual   哑表
```

### 函数

```
	单行函数：对于表中查询的每一行只返回一个值，可以出现在select子句和where子句中
    大致分为：数字函数 字符函数 日期函数 转换函数  其他函数
    1四舍五入函数： round(sal,1) sal表示个位，1表示小数点后一位
    2截取 substr(tid,1,2) tid表示字段后面表示从第一位开始截取两位（第一位可以用1表示也可以用零表示）
    2长度 length(tid)
    2去空格 trim(tid)
    3 sysdate+1/4  表示加六个小时
    4 to_date('1986-12-12','yyyy-mm-dd') 
    4 to_char(111,,'999.999')
     to_char(sysdate,'yyyy-mm-dd hh24:mi:ss');
    4 to_number() 把char类型转换为number类型 
    4 nvl(a,b) a为null则值为b
    4 nvl2(a,b,c) a为null显示c不为空显示b
    5 decode(条件,值1,返回,值2,返回,默认显示)
    聚合函数
    avg() min() max() sum() count()
    group by 
    having count(1)>10
    分析函数
    根据一组行计算聚合值,用于做排名的
    //排名123456
                      根据deptno分组 然后进行排序
    row_number() over(partition by deptno order by sal)
    //排名113456
    rank() over(partition by deptno order by sal)
    //排名1123456
    dense_rank() over(partition by deptno order by sal)
```

### 集合操作符号

```
集合操作符号将两个查询的结果组合成一个结果
返回各个查询的所有记录
union    这个会去重
union all  这个不会
intersect  返回两个查询共有的记录
minus  两个结果相减之后剩余的记录
```

### 伪列

```
ROWID 是表中行的存储地址，该地址唯一标识数据库中的一行，
    可以使用rowid伪列快速定位表中的一行
ROWNUM
    返回结果中行的序列，可以使用它来限制返回行数
```

### 表空间

```
分为 永久性表空间 临时性表空间  撤销表空间
永久性表空间：一般保存 表 视图 过程 和索引等的数据
    SYSTEM  SYSAUX  USERS  EXAMPLE
临时性表空间： 只用于保存系统中短期活动的数据
撤销表空间：用来帮助回退未提交的事务数据

注意：每个子系统创建一个表空间，一个表空间不同数据放在不同
磁盘上，如果有几个开发人员，请为每个开发人员单独创建测试
表空间
创建表空间：
    create tablespace  tablespacename 
      datafile 'filename'[size integer[k|M]]--filename数据文件路径  size文件大小
      [autoextend[off|on]]  -- 可不可以扩展（默认不自动扩展）
                                
 例子：创建两个表空间
 create  tablespace  tp_hr  datafile
     'd:\data\tp_hr01.dbf' size 30M,
     'd:\data\tp_hr02.dbf' size 30M  autoextend on ;
 查看表空间
         存储位置                   大小         是否扩展
   select file_name,tablespace_name,bytes,autoextensible
   from dba_data_files
   where  tablespace_name='tp_hr';    
   
   建议使用语法中默认缺省值
   一般一个表空间对应一个数据文件（方便管理）
   一般不用自动扩展
   
   数据插入失败，表空间已满
   方法一： 更改数据文件的大小
   方法二： 向表空间内添加数据文件
   
 更改数据文件的大小
   alter database  datafile
   'd:\data\tp_hr01.dbf'
   resize 80M;

  向表空间添加数据文件
 alter tablespace tp_hr
 add datafile
 'e:\data\tp_hr02.dbf' size 20M
 autoextend on;
 
 当历史数据只允许查询，不希望被修改
 表空间只读：
 alter tablespace tp_hr readonly;

  删除表空间
  drop tablespace tablespacename 
  [including contents] 有数据要加这个子句才能删除
  先备份再删除
```

### 用户管理

```
1.创建用户
   需求： 为操作人力资源管理子系统创建用户A_hr,要求能够将该用户
   下的数据存储在tp_hr表空间、能够将备份数据存储在tp_bak表空间
   ，并且在第一次登入时用户自己重新修改密码。
   提取信息：
       创建用户并提供缺省密码
       能够使用 tp_hr表空间
       能够使用 tp_bak表空间
      第一次登录允许修改密码
  创建用户的核对清单
      1.选择用户名和密码   A_hr  bdqn
      2.识别用户需求用于存储对象的表空间  tp_hr      tp_bak  
      3.决定每个表空间的限额        unlimited(不限额) 10M
      4.分配缺省表空间和临时表空间   
          不给这项不会报错系统会自动给users表作为默认表空间
          tp_hr(自定义)  temp(系统临时)
      5.创建用户
      6.向用户授予权限和角色
语法
    create USER user
        identified  by  password
        [default tablespace tablespace]  缺省表空间
        [temporary tablespace tablespace] 临时表空间
          限额    多大？    或者  不受限制    在哪个表空间上
        [quota{integer[k|M] | unlimited} on tablespace ]
        [quota{integer[k|M] | unlimited} on tablespace ]
        如果有这条语句用户一次登入时就要修改密码
        [password expire]
   例：   
       create user A_hr  identified  by bdqn
       default tablespace  tp_hr
       temporary tablespace  temp
       quota unlimited on tp_hr
       quota 10M on tp_bak
       password  expire;     
            
2.查看用户
   select * from dba_users
   where username = 'A_hr'

   查看表空间限额
   select * from dba_ts_quotas
   where username= 'A_hr'   
                
  3.1 先创建完用户，再根据要求进行修改
     alter  user A_hr  password  expire;    
  
  3.2 更改表空间的用户限额
     alter  user A_hr  quota 20M  on tp_bak;   
   
   3.3  删除  
           删除表空间时先备份用户数据再删除 
     drop user user [cascade]
     cascade选项将删除方案中的所有对象
     不能删除当前与Oracle服务器连接的用户
```

### 权限管理  

```
1. 系统权限
        1.1什么是系统权限
            1.1.1：系统：使用户可以在数据库中执行特定的操作
            1.1.2：对象：使用户可以访问和操纵特定的对象
        1.2授予系统权限
                   把什么权限
        grant {system_priv|role}   授予系统权限或者授予某个角色 
            [,{system_priv|role}]...
            给是谁
        TO {user|role|public}    给某个用户或者给某个角色或者给某个public
        [,{user|role|public}]...
        [with admin option]    可不可以有这个权限   
     其中
         system_priv  指定要授予的系统
         role   指定要授予的角色名
         public 将系统权限授予所有用户
         with anmin option 使被授予者进一步将权限或角色
                         授予其他用户或角色
                 
         -- 授予连接会话权限
         grant create session to A_hr;  
         
         -- 授予创建表权限
         grant create  table to A_hr;
         
         -- 权限合并
         grant create session,create table to A_hr;
         
         --多个用户
         grant create session,create table to A_hr,A_oe
         
         --将权限授予所有用户
         grant create  session,create table to public 
         
         --使被授权者进一步将权限或角色授予其他用户或角色
         grant create table to A_hr with admin option
         
         --撤销权限
         revoke create table from A_hr;
         
         --查询权限
         select * from DBA_SYS_PRIVS 
         WHERE Grantee - 'A_hr'
      
          1.3撤销系统权限
              
       grant{obj_priv[(column_list)][,obj_priv[(column_list)]]...
           |ALL[privileges]}
        on [schema.]object
        to {user|role|public}[,{user|role|public}]...
        [WITH grant option]
       }   
       其中
       obj_priv 指定要授予的对象权限
       column_list  指定表或视图列
       all  将所有权限授予已被授予with grant option的对象
       on object  标识将要被授予权限的对象
       with grant option  被授予者将对象权限或角色授予其他用户角色
       
       例:
           --授予用户A_hr修改System模式下employer表（ename,sal）的权限
           GRANT UPDATE(ename,sal)on employee
           to A_hr
          
          --授予所有权限
          grant all on employee
          to A_hr
          with grant option
          
          --撤销权限
          revoke all on employee from A_hr
          
    2. 对象权限
        2.1什么是对象权限
        2.2授予对象权限
        2.3撤销对象权限
    3. 管理角色
        什么是角色
            connect 需要连接上数据库的用户，特别是哪些不需要创建表
            的用户，通常赋予该角色
            resource 更为可靠和正式的数据库用户可以授予该角色,
            可以创建表，触发器，过程等
            dba 数据库管理员角色，拥有管理数据库的最高权限
        Grant connect,resource to A_hr
        角色的优点
        使用预定义角色
        
        数据库用户权限授权按最小分配原则
        不允许使用sys和System用户建立数据库应用对象
        禁止grant dba to user
        删除或锁定数据库测试用户scoot
        修改可用用户的默认密码
        对查询用户只能开放查询权限
        对新建用户初次登录数据强制修改密码
        开发环境、测试环境、生产环境中相同用户的权限设置必须全一致
```

### 序列

```
创建序列
    CREATE SEQUENCE TOYS_SEQ
        START WITH 10     --以多少开始
        INCREMENT BY 10   --每次增加多少
        MAXVALUE 2000     --最大值
        MINVALUE 10       --最小值
        NOCYCLE            --不循环
        CACHE 10; 
 NEXTVAL 返回序列的下一个值
 CURRVAL 返回序列当前值 
 
修改序列：注意不能修改序列的 start with 参数
    alter sequence toys_seq maxvalue 5000 cycle; 
删除序列          
   drop sequence toys_seq;   
   
   数据类型为char(32)
sys_guid()生成不一样的32位码 

  在不需要并行或者远程的环境中使用 序列作为主键
  在并行的环境里或者希望避免使用序列的情况下使用函数
  不同数据库但需要后来合并到一起的情况下使用sys_guid() 
  
  select sys_guid() from dual 伪表
```

### 同义词和视图

```
同义词
    什么是同义词
      同义词是现有对象的一个别名
      简化SQL语句
      隐藏对象的名称和所有者
      提供对对象的公共访问
      同义词有两种类型： 私有同义词和公有同义词
      私有同义词只能在自己的模式内访问，且不同与当前模式对象同名
      公有同义词可以被所有的数据库用户访问,可以同名
      创建私有同义词
         create or replace synonym emp for employee;
      创建公有同义词
        create public synonym employee for empl
        
      grant select on employee to A_oe;
      ----以A_oe用户登录
      select * from  empl
      
      存在同名表和公有同义词，数据库优先选择表
      存在同名公有同义词和私有同义词数据库优先选择私有同义词
    创建同义词
    私有同义词和公有同义词区别
视图
    什么是视图
    视图的作用
    视图的语法
      create or replace view v_myOrders
      as
      select * from  orders
      where sales_rep_id = (
          select empno 
          from employee
          where ename=(select lser from dual)
      )
      
    select * from v_myOrders  
```

### 索引

```
b树索引  （默认）
              索引名      哪个表哪个列
  create index idx_id no t(id)
反向键索引(用户连续增长的那一列，可以用反向键索引)7192变2917
  create index idx_reverse_empno no emp(empno) reverse;
位图索引
 create bitmap index idx_bit_job on employee(job);
 不直接存储rowId,而是存储字节位到Rowid的映射
基于函数索引
  create index idx_lowercase
  on employee(Lower(last_name));
  
  select * from employee
  where lower(tlast name)='scott';
组合索引
  组合索引是在表的多个列上创建索引
  当某几个字段在sql语句的where子句中经常通过AND操作符联合在一起使用作为
  用过滤条件
  符合索引字段排序的原则
    最频繁使用字段排在第一位
    使用频率相同，则将最具选择性的字段放在前面（唯一性最高）
索引使用原则
  在适当的表和字段上创建索引。如果经常检索的数据少于表中的15%
  则需要创建索引；
  限制表中索引的数目。索引越多对修改表时，索引做出修改的工作量越大

删除索引
drop index idex_empno;
```

### 区分表

```
什么是分区表
   允许用户将一个表分成多个分区
   用户可以执行查询，只访问表中的特定分区
   将不同的分区存储在不同的磁盘，提高访问性能和安全性
   可以独立地备份和恢复每个分区
什么时候需要分区表
分区表的类型
 范围分区(以列的值的范围来作为分区依据)
 //1.创建表的同时创建分区
 1 create table graderecord  
 2   (  
 3   sno varchar2(10),  
 4   sname varchar2(20),  
 5   dormitory varchar2(3),  
 6   grade int  
 7 )
                         分区键按哪列分区？
    partition by range(column_name)  
     (  
                                 小于一个范围
10   partition part1 values less than(60), --不及格  

11   partition part2 values less than(85), --及格  
12   partition part3 values less than(maxvalue) --优秀  
13 )  
//查询分区情况
  select table_name,partition_name
  from user_tab_partitions
  where table_name=upper('表名')
  //查询数据
  select * from 表名 parttion('分区名')
  
 //2.在现有表中添加分区表 
  create table 新表名
  partition by range(分区键)
  (
      ........
      
  )
  as  select * from 旧表名
  注意：不存在分区条件就报错
 间隔分区
   实现范围分区的自动化
   最开始分区是永久分区，随着数据增加自动创建新的分区
   partition by range(column_name)
                               如果给年1年一年涨，给月一月一月涨
                               1    'year' or 'month'
      interval(numtoyminterval(n,' interval_unit'))
      (partition p1 values less than(range1))
分区表的管理 
  添加分区
    alter table  表名  add  partition 分区名
    values less than(to_data('','yyyy-mm-dd'))
   --添加最后一个分区写法
   alter table 表名 add  partition 分区名
   values less than(maxvalue)
  删除分区
  alter table 表名  drop partition 分区名
  分区删除了，分区里的数据也就删除了
  合并分区
  拆分分区
  移动分区
 ---准备表空间
     创建   
    create tablespace 表空间
    dtafile ''
    授予权限
    alter user 用户名 quota unlimited on  表空间
 ----移动分区
 alter table  表名 move partition 分区名 tablespase 表空间
---移动完表空间设置为只读
  alter tablespace tp sales bak read only; 
 
  截断分区
```

### 过程语言

```
PL/SQL 是过程语言(Procedural Language)与结构化查询语言(SQL)
 结合而成的编程语言
 
PL/SQL块
  分为三个部分，声明部分、可执行部分和异常处理部分
  [declare
      declarations]
  begin
     executable statements
 [exception  
     handlers]
 end;            
例子：
    DECLARE
     -- 声明部分定义变量、游标和自定义异常
       qty_onhand  number(5);
     begin
     -- 包含SQL和PL/SQL语句的可执行部分
     -- select into 语句一定是返回一条，0条或多条都会报错
       select quantity into qty_onhand
       from Products
       where product = '芭比娃娃';
     if qty_on_hand >0 then
       update Products  set quantity = quantity+1
       where product = '芭比娃娃';
       insert into purchase_record
       values('已购买芭比娃娃',sysdate)
     end if;
     commit;   
     exception
        when others then
          dbms_output.put_line('出错:'||SQLERRM)    
标识符
  规则：
  标识符不能超过30字符
  第一个字符必须为字母
  不分大小写
  不能用减号
  不能是sql保留字
  经验：一般不要把变量名和字段名一样，容易得不到正确的结果
  变量类型：
   number(2)、number(3,3)
   integer  
   binary_integer
   char(5)
   varchar2(20)            v_name  varchar(30)
   date                    v_entry_date  Date;
   Boolean
 属性类型                    表中的列是什么类型就是什么类型
  %type    例：   v_emp_name  EMP.ename%type
  %rowtype   例： v_emp_rec  emp%rowtype   一行类型(点谁就是哪个列了 v_emp_rec.xxx) 
 游标类型
 Cursor
 异常类型
 Exception           
 自定义数据类型
 Self defined type 

PL/SQL数据类型

运算符和表达式

变量赋值
  v_ISD :=5;  
  v_Name := 'steven';
  v_Name2 := substr(v_Name,1,3)
  v_Start_Date :=sysdate;
  v_Full_Name = v_last_name || v_first_name; 
  
  select count(*) into v_cnt
  from emp
  where deptno = v_deptno;
  
  select *  into r_emp
  from emp
  where deptno = v_deptno;
  v_empno := r_emp.empno;

注释

控制语句

  if  x = 3 then
     insert....
  elsif  x<4 then
     ......
  else
     update .....
  end if;         

  case  x(表达式)
   when 5 then
     y :=50;
   when 6 then
     y :=1000;
   else
     y :=0;
  and case;    
  
 case
    when x=3 then
       y :=30;
    when  x<3 then
       y :=1000;
    else
      y :=1;
  end case     
  
  x:=1;
  while x>3 loop
     Do something;
     x :=x-1;
  end loop            
  
 loop
    ....
    exit when...
 end loop;
 
    k变量  从1到5循环五次
 for k in 1..5 loop
    ....
 end loop;   
               
                             
PL/SQL的优点
与SQl紧密集成，简化数据处理
 支持SQL,在PL/SQL中可以使用：
     数据操纵命令
     事务控制命令
     游标控制
     SQL函数和SQL运算符
 支持所有SQL数据类型
 支持NULL值
 支持%TYPE 和 %ROWTYPE属性类型
 更佳的性能, PL/SQL经过编译执行
 支持面向对象编程
 安全性，可以通过存储过程限制用户。 
```

### pl/Sql 编程-异常处理

```
pl/Sql 编程-异常处理
  预定异常
   
 dup_val_on_index  重复的值存储在使用唯一索引的数据库列中 
 no_data_found  语句无返回行异常
 too_many_rows  返回多行 
  非预定异常
    e_integrity EXCEPTION;
    pragma exception_init(e_integrity,-2291)
  用户自定义异常
    raise  异常变量名  
    
    
  RAISE_APPLICATION_ERROR存储过程
  
  
  begin
   过程及sql语句
  exception
     when no_data_found then
      dbms_output.put_line('雇员号不正确')
     when too_many_rows then
      dbms_output.put_line('查询只能返回单行')
     when others then
      dbms_output.put_line('错误号：'||SQLCODE||'错误描述：'||SQLERRM) 
   --非预定义  when e_integrity then
       dbms_output.put_line('该部门不存在');
       raise; 抛出异常
    END;   
    
        
 --创建子程序
 create or replace procedure  account_status(
     due_date  date,
     today date
 )
 is
 begin
   if  due_date < today then
      RAISE_APPLICATION_ERROR(-2000,'Account past due.')
   end if;
 end  
```

### 游标

```
什么是游标？
游标分类
  隐式游标-游标的属性
      隐式游标自动声明、打开和关闭，其名为sql
      通过检查游标的属性可以获得最近执行的dml语句的信息
      %FOUND-SQL 语句影响了一行或多行时为true
      %NOTFOUND  没有影响任何行为true
      %ROWCOUNT  影响行的记录数
      %ISOPEN   游标是否打开,始终为false
    例：
      declare
         v_name employee.ename%type;
      begin
         select ename into v_name
         from employee
         where empn=30;
      if  sql%NOTFOUND then
        dbms_output.put('不存在该员工');
      else
        ....
       end if;
    exception
       when no_data_found then
          ......
    end;                     
      
      
  显示游标-游标的技巧
    declare
       ---声明游标，绑定结果集
                           参数类型不能声明长度
       cursor emp_cursor (no number) is 
         select ename,sal
         from employee
         where depno=no;
         --存放结果集的变量
       v_ename employee.ename%type;
       v_sal employee.sal&type;  
    begin
      if not  emp_cursor%ISOPEN then
        open emp_cursor(20); --打开游标
      end IF; 
      --循环提取
      loop      
         fetch emp_cursor  into v_enam,v_sal;--提取行
         exit when emp_cursor%NOTFOUND; --提取完马上判断是否为空
         dbms_output.put_line(v_ename)
      end loop;
      close emp_cursor; --关闭游标
      
      
     ---循环游标
       declare
       ---声明游标，绑定结果集
                           参数类型不能声明长度
       cursor emp_cursor (no number) is 
         select ename,sal
         from employee
         where depno=no;
       begin
          -- 自动为引用游标类型的变量，并且自动打开游标
        for emp_record  in emp_cursor(13) loop
            dbms_output.put_line(emp_record.ename||':'||emp_record.sal)
        end loop;
        
       --使用显示游标更新行
         declare
             cursor emp_cursor is
               select ename,sal,e.deptno,dname
               from employee e inner join dept d
               on e.deptno=d.deptno
               for update of e.job; --锁定要修改的表(如果不写of后边表示两个表都被锁定)
             emp_record  emp_cursor%rowtype;   
         begin
            if not  emp_cursor%ISOPEN then
                open emp_cursor; --打开游标
            end IF;    
            LOOP
                 fetch emp_cursor  into v_enam,v_sal;--提取行
                 exit when emp_cursor%NOTFOUND; --提取完马上判断是否为空
                 if emp_record.deptno = 30 then
                   update employee  set  sal = sal+100
                   where currrent of emp_cursor  --当前游标指谁改谁
                 end id
            end loop
            close emp_cursor;
          end;
          rollback;         
          
--- 使用游标类型变量
   游标变量可以赋值
   游标变量可以作为存储过程的参数
   创建游标变量需要两个步骤:
        声明REF 游标类型
        声明REF 游标类型的变量
    declare
            --声明一个类型   引用类型的游标
       type  MY_CTYPE is  ref  cursor;
           --定义一个变量
       cv  my_ctype;
       -- cv  sys_refcursor;  系统定义的一个游标变量和上面效果一样
       --------
         声明强类型的REF游标
         type my_ctype  is ref  cursor
         return  employee%rowtype;
         emp_cur my_curtype;
         声明弱类型
         type my_ctype  is  ref  cursor;
         emp_cur my_ctype;  --指定变量
         open cursor_name  for  select_statement;
       
       
       --------
       
       
       
       v_lastname  employee.ename%type;
       query_2  varchar2(200) := 'select * from dept';
       v_employee  employee%rowtype;
       v_dept dept%rowtype;
     begin
        open  cv for
           select ename
           from  employee
           where  job = 'manager'
           order by ename;
       loop
          fetch cv  into  v_lastname;
          Exit  where  cv%notfound;   
          dbms_output.put_line('')
        end loop;
        ----------------------------------------
        open  cv for  query_2;
        loop
           fetch cv
              into  v_dept;
           exit where  cv%notfound;
           dbms_output.put.line(v_dept.dname);
         end loop
         close cv;
     end                                 
  REF游标-特点
  
  总结
   游标是系统为用户开设的一个数据缓冲区，存放sql语句的执行结果
```

### 存储过程

```
  什么是子程序
      编译并存储在数据库中
      子程序的各个部分：
          声明部分
          可执行部分
          异常处理部分（可选）
       子程序的分类：
          过程 - 执行某些操作
         函数 - 执行操作并返回值   
  存储过程
     创建存储过程
        create [or replace] procedure
          ---名               参数
          <procedure name> [(parameter list)]
        is|as  
           -- 局部变量声明
          <local variable  declaration>
        begin
          <executable  statements>  
        [exception
            <exception handlers>] 
        end;     
        
       例子：
       create or replace procedure  add_employee
        ( eno  number,  --输入参数，雇员编号
          name varchar2, --输入参数，雇员名称
          salary  number, --输入参数，雇员薪水
          dno  number, --输入参数，雇员部门编号
          job  varchar2  default 'clerk' --输入参数，雇员公众默认clerk
        )  is
        begin
            insert into  employee
                        (empno,ename,sal,job,deptno)
                values
                        (eno,name,salary,job,dno)
       end;                         
 
     传递参数的三种参数
         in
            用于接收调用程序的值
            默认的参数模式
         out
           用于向调用程序返回值
         in out 
           用于接收调用程序的值，并向调用程序返回更新的值
      运行存储过程
           begin
           add_employee(211,'ss',200,10,'manager')
        end;  
     调试存储过程
        1.获得debug connect session权限
        grant debug connect session to A_hr
        2.选中添加调试信息
        3.进入测试窗口，编写调用存储过程代码
        4.单击测试脚本中的开始调试器按钮或者f9进入调试状态
        5.单击单步进入按钮，进行调试
     删除存储过程
     drop procedure 存储过程名字
  编写存储过程的规范   
    1.存储过程中不可以直接使用ddl语句，可以通过动态sql实现。但不建议
    频繁使用ddl语句
    2.存储过程必须有相应的出错处理功能
    3.存储过程变量使用%type和%rowtype类型
    4.必须在子存储过程体中作异常捕获，并将异常信息通过os_msg变量输出
    5. -1~-19999的异常为Oracle定义的异常代码
    6.存储过程必须包含两个输出参数分别用于标识过程的执行状态及过程
    提示信息（on_Flag out number,os_Msg out varchar2）执行状态和提示信息
    7."when others"必须放置在异常处理代码的最后面作为缺省处理器
    处理没有显示处理的异常
        
  将存储过程执行权限授予其他用户
  grant execute on 存储过程 to 给谁 
```

