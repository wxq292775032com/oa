## javaScript

### 基本

```javascript
1. <script type="text/JavaScript"> /*JavaScript语句*/ <script/>  内部使用
2. <script type="text/JavaScript" src="js/test.js"><script/>  外部引用
3. <input name="btn" type="button" vlaue="弹框" onclick="javascript:alert("欢迎你")"/> 标签引用
```

### 变量声明和赋值

```javascript
/*** 1. 变量 ***/ 
  1.1: var name;  先声明
  1.1: var  width = 20; 声明同时赋值
  1.2  var  x,y,z=10; 在一行中声明多个变量，各变量之间用逗号分隔。
/*** 2. 基本类型类型 ***/
     //2.1: 基本数据类型
          2.1.1: undefined (未定义类型)
          2.1.2: null (空类型)
          2.1.3: number(数字类型)
          2.1.4: String (字符串)
          2.1.5: boolean(布尔类型) 
     // 2.2: 类型判断  type(变量或值)
          2.2.1: undefined、number、String、boolean 这几中类型是什么就返回什么
          2.2.2: 如果变量是null类型,或者变量是一种引用类型，如对象，函数，数组，则返回object类型的结果
          2.2.3: null==undefined 返回true;  
     //2.3: String对象常用的方法
          2.3.1: length            
          2.3.2: indexOf(str,index) 返回索引位置,index是可选值，表示从第几位开始查找,值有str参数时表示从第一位开始找。
          2.3.3: toLowerCase() 把字符串转为小写
          2.3.4: toUpperCase() 把字符串转为大写
          2.3.5: substring(index1,index2); 截取
          2.3.6: split("") 将字符串分割为数组
    //2.4: 数组
          //2.4.1:创建数组: 
             2.4.1.1:  var arryName = new Array(size);  可以不指定长度
                            arryName[0] = "";
                            arryName[1] = "";
             2.4.1.2:  var arryName = new Array("a","b","c");
             2.4.1.3:  var arryName = [];
             2.4.1.4:  var arryName = ["a","b","c"];
          //2.4.2: 数组常用方法和属性
             2.4.2.1: length
             2.4.2.2: var str = arryName.josin("-");  把数组所有元素放入一个字符串通过一个分隔符进行分割。
             2.4.2.3: sort() 对数组排序
             2.4.2.4: push() 向数组末尾添加一个或多个元素，并返回新的长度
/*** 3.数字类型转换 ***/
       3.1: parseInt() 解析字符串返回一个整数。
       3.2: parseFloat()  解析字符串返回一个浮点数。
       3.3: isNaN() 数字false; 不是数字true;
/*** 4. 逻辑判断和循环和java一致 **/
```

### BOM对象

```javascript
/**  1. window对象是BOM的核心,在浏览器中打开网页后 **/
        //1.1 window对象常用的方法(window是全局对象所以可以直接写方法)。
            1.1.1: prompt("提示信息","输入框的默认信息");  弹框用户点击取消返回null,确定返回文本框内容。    
            1.1.2: alert("");  弹框。
            1.1.3: confirm(""); 取消返回false,确认返回true。
            1.1.4: close();  关闭浏览器。
            1.1.5: open("url"); 打开一个新的浏览器窗口，加载给定URL所指定的文档。
            1.1.6: setTimeout(function,num);  指定毫秒数后调用函数。
           1.1.7: setInterval(function,num); 按周期(以毫秒计)循环调用。 
       // 1.2 子对象
            //1.2.1: document  文档对象
                1.2.1.1: document.referrer; 返回载入当前文档的URL，当前文档如果不是通过超链接访问的，则返回值为null。
                1.2.1.2: document.URL; 返回当前文档的URL 。
                1.2.1.3: document.write(" ");  向页面输出包含HTML标签的内容。
                1.2.1.4: document.getElementById("");  返回指定id对象。
                1.2.1.5: document.getElementsByName(""); 返回一组相同name属性的元素。
                1.2.1.6: document.getElementsByTagName(""); 按标签访问一组页面元素。
                    .innerHTML  .innerText  .value
           //1.2.2: location  地址对象
                1.2.2.1: window.location.href = "http://www.baidu.com";  设置或返回完整的url。
                1.2.2.2: window.location.host;  设置或返回主机名和当前URL的端口号。
                1.2.2.3: window.location.hostname; 设置或返回当前URL的主机名。
                1.2.2.4: window.location.reload();  重新加载当前文档。
                1.2.2.5: window.location.replace(); 用新文档替换旧文档。
           //1.2.3: history   历史对象
                1.2.3.1: history.back(); 加载history对象列表的前一个url。
                1.2.3.2: history.forward(); 加载history对象列表中的后一个url。
                1.2.3.3: history.go(n);   history.go(1) 前进1页，history.go(-1)后退一页。 
```

### 内置对象

```javascript
//1. Date对象 
     1.1: var myDate = new Date();
           1.1.1: getDay();  获取星期几,0为表示周日,1表示周一,6表示周六。 
           1.1.2: getTime(); 返回自某一时刻(1970年1月1日)以来的毫秒数。
           1.1.3: getFullYear(); 年
           1.1.4: getMonth(); 月，其值为0~11，0为1月，11为12月。
           1.1.5: getDate();  日，其值为1~31。
           1.1.6: getHours(); 时，0~23。
           1.1.7: getMinutes(); 分，0~59。
           1.1.8: getSeconds(); 秒，0~59。
//2. Math对象
        2.1: ceil()  对数进行上舍入  
            2.1.1: Math.ceil(25.5); 返回26
            2.1.2: Math.ceil(-25.5); 返回-25
        2.2: floor() 对数进行下舍入
            2.2.1: Math.floor(25.5); 返回25
            2.1.2: Math.floor(-25.5); 返回-26
        2.3: round() 四舍五入
            2.3.1: Math.floor(25.5); 返回26
            2.3.2: Math.floor(-25.5); 返回-26        
        2.4: random() 随机数，返回的随机数包含0不包含1。
            2.4.1:  var iNum = Math.floor(Math.random()*100+1));  1~100中的整数
            2.4.2:  var iNum = Math.floor(Math.random()*98+2));  返回2~99(只有98个数字，第一个值为2)  
```

###  对象/函数

```javascript
1. 自定义函数
     function name(a,b,c){}
2. 对象
     2.1: var bag = new Object();
          bag.name="属性";
          bag.showName = function(){
              alert(this.name);
          }
     2.2: var xxx = {
            showName:function(){  
            },
            showAge:function(age){
            }
          }
```

### 节点

```javascript
/*** 1.层次关系访问节点 ***/
       // 1.1: 会解析空格
            1.1.1: parentNode  返回节点的父节点
            1.1.2: childNodes  返回子节点集合,childNodes[i]
            1.1.3: firstChild  第一个子节点
            1.1.4: lastChild  最后一个子节点
            1.1.5: nextSibling 下一个节点
            1.1.6: previousSibling 上一个节点
       // 1.2: 不会解析空格
           1.2.1: firstElementChild 返回节点的第一个子节点
           1.2.2: lastElementChild  返回节点的最后一个子节点
           1.2.3: nextElementSibling  下一个节点
           1.2.4: previousElementSibling 上一个节点
/***2.创建和插入节点***/
      //  2.1:创建节点
           var img = createElement("img");
           img.setAttribute("src","images/a.jpg");
           img.setAttribute("alt","哈哈");
      // 2.2:添加到某个子节点后
           A.appendChild(B);
      // 2.3:把A节点插入B节点之前
           insertBefore(A,B);
      // 2.4:复制某个节点
           cloneNode(deep); 
/***3.删除和替换节点***/
      // 3.1:删除某个子节点
           var delNode = document.getElementById("first");
       delNode.parentNode.removeChild(delNode);
      // 3.2:用其他节点替换指定节点
           oldNode.parentNode.replaceChild(newNode,oldNode);
```

### 操作样式

```javascript
//1. style 属性
        document.getElementById("title").style.color="red";
        document.getElementById("title").style.fontSize="20px";
//2. className 属性
        HTML元素.className="样式名称";
//3. 获取元素样式
        HTML元素.style.样式属性;
```

### 事件

```javascript
1. onload  一个页面或一幅图像完成加载
2. onclick 鼠标单击某个对象
3. onmouseOver 鼠标移到某个元素
4. onkeydown 某个键盘被按下
5. onchange 域的内容被改变
6. onmouseout 鼠标移开
7. onblur 失去焦点
8. onfocus 获得焦点
```

### validity属性

```
1. var validityState = document.getElementById("uName").validity;  获取validityState对象
2. validityState对象的方法
  2.1: valueMissing  表单设置了required特性,则为必填，如果必填项为空该属性返回true，否则返回false
  2.2: typeMismatch  输入与type类型不匹配,如email、number、url,该属性返回true，否则返回false
  2.3: patternMismatch 输入值与pattern特性的正则表达式不匹配，该属性返回true，否则返回false
  2.4: tooLong 输入内容超过表单元素maxLength特性限定的字符长度，该属性返回true,否则返回false
  2.5: rangeUnderflow 输入值小于min特性值，该属性返回true,否则返回false
  2.6: rangeOverflow 输入值大于max特性值，该属性返回true否则返回false
3. setCustomValidity("密码不能为空"); 自定义错误提示信息
```

### 附加

```
1. document.forms[0];
2. onkeyup="verifyNum(this); 马上清除不是数值
3. reset() 将form表单置为默认值
```

## jQuery

### 初始加载

```javascript
//1. 类似于js的 onload()方法，他们都是当页面加载完成时，执行的事件。onload一个页面只能有一个方法，ready方法可以有多个。
//2. ready加载效率好，onload需要等页面的图片和视频全部加载完才执行，ready可能和图片视频等同时加载。 
    $(document).ready(function(){
         //$(selector).action(); 1.工厂函数$()  2.选择器selector  3.action()事件方法
    })
    $(function(){ // 简写  })
```

### 选择器

```javascript
//1. 基本选择器
     1.1: $("h2")  标签选择器，选取所有h2元素
     1.2: $(".title") 类选择器，选择class为title的元素
     1.3: $("#title") id选择器，选择id为title的元素
     1.4: $("div,p,.title") 并集选择器,选择所有以div,p和class为title的元素
     1.5: $("*") 全局选择器,选取所有元素   -- $(body *) body下所有元素
//2. 层次选择器
     2.1: $("#M span") 后代选择器，选取所有span元素
     2.2: $("#M>span") 子选择器，选取idM下的子元素span
     2.3: $("h2+dl") 相邻选择器，选取紧邻h2元素之后的同辈元素dl
     2.4: $("h2~dl") 选取h2元素所有同辈元素dl
//3. 属性选择器
     3.1: $("href") 选取含有href属性的元素
     3.2: $("href='#'") 选取含有href属性值为#的元素
     3.3: $("href!='#'") 选取href属性值不为#的元素
     3.4: $("href^='en'") 选取href属性以en开头的元素
     3.5: $("href$='.jpg'")选取href属性以.jpg结尾的元素
     3.6: $("href*='txt'") 选取href属性中含有txt的元素
//4.可见性过滤选择器
     4.1: $(":visible") 选取所有可见的元素
     4.2: $(":hidden") 选取所有隐藏的元素
//5.基本过滤选择器
     5.1: $("li:first") 选取所有li元素中的第一个li
     5.2: $("li:last")  选取所有li元素中的最后一个li     
     5.3: $("li:not(.three)") 选取class不是three的元素
     5.4: $("li:even") 选取所有偶数li
     5.5: $("li:odd") 选取所有奇书li
     5.6: $("li:eq(1)") 选取索引等于1的li,下标从0开始
     5.7: $("li:gt(1)") 选取索引大于1的li,下标从0开始
     5.8: $("li:lt(1)") 选取索引小于1的li,下标从0开始
     5.9: $(".contain:header") 选取class为contain元素下的所有标题元素 h1~h6
     5.10: $(":focus") 选取当前获取焦点的元素
     5.11: $(":animated") 选取所有动画元素
//6.附加
     6.1: $("#id\\#a") 选择器中含有特殊字符
     6.2: 选择器中空格也是不容忽视的，多一个空格或少一个空格，可能结果截然不同  
//7.表单选择器
     7.1:  :checked 匹配所有被选中元素(复选框,单选框，select中的option)
     7.2:  :selected 匹配所有选中的option元素
     7.3: 关于其他表单选择器和表单过滤选择器不常用也不实用暂不纳入笔记中以下是相关的网址
          https://www.runoob.com/jquery/jquery-ref-selectors.html  
```

### 事件

```javascript
/*** 1.基础事件 ***/
    //1.1: 鼠标事件
         1.1.1: click() 鼠标单击事件
         1.1.2: mouseover() 鼠标移入事件,比如鼠标移入a元素，触发一次，a子元素又触发一次。
         1.1.3: mouseout() 鼠标移出事件,比如鼠标移出a触发,移出a子元素又触发。
         1.1.4: mouseenter() --父元素作为一个整体,移入时触发一次
         1.1.5: mouseleave() --父元素作为一个整体,移出时触发一次
         1.1.6: hover(function,function) 相当于鼠标移入移出的组合
         1.1.7: dblclick() 鼠标双击事件
         1.1.8: contextmenu() 右击事件
    //1.2: 键盘事件
         1.2.1: keydown() 键盘按下时触发
         1.2.2: keyup() 键盘释放触发
         1.2.3: keypress() 按住不放会一直产生这个事件，它夹在按下和释放事件中间
       //例:
         $(document).keydown(function(event){
            console.log(event.keyCode);  //event:为当前事件对象 ，keyCode:键码对应值， console.log():控制台打印
         })  
    //1.3: 浏览器事件
           1.3.1: $(window).resize();  //窗口调动大小时触发
/*** 2.绑定事件 ***/
    //2.1: 多绑定
       $("p").on({
            mouseover:function(){ },  
            mouseout:function(){}, 
       }); 
   //2.2: 多事件
       $("p").on("mouseover mouseout",function(){    });   
   //2.3: 单事件
       $("#div1").on("click",function(){   });
   //2.4: 绑定下面的子元素   移动端tap
       $("#div1").on("click","p",function(){   });
/*** 3.控制元素事件 ***/
      3.1: show() 显示
      3.2: hide() 隐藏
      3.3: fadeOut() 淡出
      3.4: fadeIn() 淡入
      3.5: slideDown() 元素从上到下延伸显示
      3.6: slideUp() 元素从下到上缩短至隐藏
   //   附: 这些事件都有可选参数 speed:时间，毫秒计, callback:函数执行后要执行的函数
      3.7:动画  css属性参数必选,后面两个参数可选
      $("div").animate({left:'250px'},3000,function(){   });
/*** 4.表单事件 ***/
      4.1: blur() 失去焦点
      4.2: focus() 获得焦点
      4.3: select() 文本域中的内容被选中
      4.4: subimt() 表单提交事件
```

### 操作样式

```javascript
//1.设置和获取样式
    1.1: $(selector).css("属性名"); 获取样式
    1.2: $(selector).css("name",value); 设置单个样式
    1.3: $(selector).css({"name":value,"name":value}); 设置多个样式
//2.添加/删除类样式
    2.1: $(selector).addClass("class1 class2 ... classN");  添加一个或多个样式
    2.2: $(selector).removeClass("class1 class2 ... classN"); 移除一个或多个样式
//3.判断是否含有某个样式
    3.1: $(selector).hasClass("class"); 判断是否含有指定样式  
```

### 内容操作

```javascript
//以下无参都表示--获取,有参时表示--设置
1. $(selector).html("[content]");  标签不会作为文本
2. $(selector).text("[content]");  标签也当成文本
3. $(selector).val("[content]");  设置值
```

### 属性操作

```javascript
1. $(selector).attr("name");  //获取属性
2. $(selector).attr("name","value"); //设置属性
3. $(selector).attr({"name":"value","name":"value",...}); //设置多属性
4. $(selector).attr("name"); //删除元素的属性
```

### 节点操作

```javascript
//1.插入(子节点)
     1.1: $(A).append(B);  将B节点添加到A子节点后
     1.2: $(A).prepend(B); 将B节点添加到A子节点前
     1.3: $(A).appendTo(B); 将A节点追加到B子节点后
     1.4: $(A).prependTo(B); 将A节点追加到B子节点前
//2.插入(同辈)
     2.1: $(A).after(B); 将B插入A之后 (同辈)
     2.2: $(A).before(B); 将B插入A之前 (同辈)
     2.3: $(A).insertAfter(B); 将A插入B之后
     2.4: $(A).insertBefore(B); 将A插入B之前
//3.删除
     3.1: $(selector).remove(); 删除整个节点
     3.2: $(selector).empty(); 清空节点内容
     3.3: $(selector).datach(); 删除整个节点，保留绑定事件，附加数据     
//4.复制
     4.1: $(selector).clone(boolean); 参数为true 复制事件处理,false 不复制
//5.替换
     5.1: $(A).replaceWith(B); B节点替换A节点
     5.2: $(A).replaceAll(B); A节点替换B节点  
```

### 节点遍历

```javascript
1. $(selector).children([expr]);  //遍历子元素,参数时可选的
2. $(selector).next([expr]); //下一个
3. $(selector).prev([expr]); //上一个
4. $(selector).siblings([expr]); //所有同辈
5. $(selector).parent([selector]); //获取父级别
6. $(selector).parents([selector]); //获取祖先级别
7. $(selector).each(function([index],[element]){   });  //index 选择器的位置   element 表示当前元素
   附1. $(selector).first(); 集合元素中的第一个
   附2. $(selector).last(); 集合元素中的最后一个
   附3  end(); 将匹配的元素还原为之前的状态
   例:
   $(selector).first().css("name",value).end().last.css("name",value);
```

### 正则表达式

```
1. 常用表达式或符号
    1.1: /....../ 代表一个模式的开始和结束
    1.2: ^ 匹配字符串的开始
    1.3: $ 匹配字符串的结束
    1.4: \s 任何空白字符
    1.5: \S 任何非空白字符
    1.6: \d 匹配一个数字字符，等价于 [0-9]
    1.7: \D 除了数字外的任何字符，等价于[^0-9]
    1.8: \w 等价于[A-Za-z0-9];
    1.9: \W 非
    1.10: . 除了换行符外的任意字符  注: \.代表点
2. 正则表达式或重复字符
    2.1: {n} 匹配前一项n次
    2.2: {n,} 匹配前一项n次，或者多次
    2.3: {n,m} 匹配前一项至少n次，但不能超过m次
    2.4: * 匹配前一项0次或者多次,等价于{0,}
    2.5: + 匹配前一项 1 次或者多次，等价于{1,} 
    2.6: ? 匹配前一项0次或1次,也就是说前一项是可选的等价于{0,1}
3. 例
    3.1: var reg = /表达式/[附加参数]; 普通方式    附加参数:g代表全局 i代表不区分大小写 m代表可以进行多行匹配
    3.2: var reg = new RegExp("表达式","[附加参数]"); 构造函数方式    
    3.1: reg.test("字符串"); 如果字符串中含有与正则表达式匹配的文本，则返回true;否则,返回false;
    3.2: "字符串".match(reg); 找到一个或多个表达式所匹配的值   
    3.3: "字符串".replace(/字符串/g,"dog"); 替换 
```

### 补充

```javascript
//1. 链式迭代
     $("h2").css("color","red").next().css("display","block");
//2. jQuery对象和DOM对象互相转换
     2.1:  var txtName = $txtName.get(0) 或者$txtName[0]; 将jQuery转换为DOM对象
     2.2:  var $txtName = $(document.getElementById("txtName")); 将DOM对象转换为jQuery对象
//3. 让渡
    var $$ =  jQuery.noConflict();   //此时$$就代表$
```

### Ajax

```javascript
//1. 基本 
     $.ajax({
          "url": "path",    //要提交的url路径
          "type": "get/post", //发送请求的方式
          "data": "parameter",//要发送服务器的数据(参数)
          "dataType":"json/html/text",//指定返回的数据格式
          "success": function(data){  }, //回调函数
          "error": function(){ } //请求失败后执行  
      })
//2:  其他参数
      2.1: beforeSend  //发送请求前调用的函数
      2.2: complete  //请求完调用，不管成功或者失败
      2.3: timeout  //设置请求超时时间
```

