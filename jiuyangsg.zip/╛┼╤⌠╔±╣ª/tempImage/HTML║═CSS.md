## HTML

### 基本结构

```html
<!--头部-->
<html>
<head>
    <title></title>
</head>
 <!--主体-->
<body>
</body>
</html>

<!--网页的基本信息-->
1.<!DOCTYPE html>声明：  必须位于第一位，约束HTML文档结构，检验是否符合Web标准。
2.<title>：  网页标题
3.<meta>：使用该标签描述网页的摘要信息，包括文档内容类型，字符编码信息，搜索关键字等。
   3.1 ： <meta  charset="UTF-8"/> charset表示字符集编码，保存文件时要和meta标签中编码一致。
   3.2 ： <meta  name="keywords" content="IT公司"/>
   3.3 ： <meta  name="description" content="xXXIT公司XXX"/>
   实现方式为 "名称/值" 对的形式，其中keywords表示搜索关键字，description表示网站内容的具体描述。通过提供搜索关键字和内容描述信息，方便搜索引擎的搜索。
```

### 基本标签

```html
标题标签：<h1>.....</h6>
段落标签：<p></p>
换行标签：<br/>
水平线 ：<hr/>
变粗标签：<strong></strong>
字体倾斜：<em></em>   
    <span></span>   
注意：块元素独占一行支持宽高，行内元素内容撑开宽度。

<!-- 图像标签-->
 <img  src="图片地址" alt="图像替代文字" title="鼠标悬停提示文字" 
      width="宽度"  height="图片高度"/>
(图片格式)
 JPG格式 ： 采用有损压缩，会造成图像画面的失真，不过压缩之后体积很小，比较清晰，适合网页中使用。
 GIF格式 ： 图像交换格式，支持透明颜色，支持动画，在网页中引用非常广泛。
 BMP格式 ： 不适用于网页。
 PNG格式 ： 兼有GIF格式和JPG格式，同时具备GIF不具备的特性，这是一种新兴图像格式。

<!-- 超链接标签-->
<a href="链接地址" target="目标窗口位置"> 链接文本或图像 </a>
target: _self（自身窗口）  _blank（新建窗口）
href路径为"#"时，表示空链接
(a标签另外两种引用场合)
锚链接：
    1.<a name="标记名">目标位置</a>
    2.<a href="#标记名">当前位置</a>
功能性链接：
    <a href="mailto:链接地址"></a>
```

### 列表

```html
<!-- 1. 无序列表:一般用于如导航、侧边栏新闻、有规律的图文组合模块等（默认前面带·）-->
    <ul>
        <li></li>
        <li></li>
    </ul>
<!-- 2. 有序列表:默认前面有顺序标记（1.2.3...） -->
    <ol>
        <li></li>
        <li></li>
    <ol>
<!-- 3. 定义列表 --> 
    <dl>
        <dt></dt>
        <dd></dd>
        <dd></dd>
    </dl>        
```

### 表格

```html
<!-- colspan="所跨的列数"   rowspan="所跨的行数" -->
<table>
    <tr>
        <td></td>
        <td></td>
    </tr>
<table>
```

### 表单

```html
<!-- 1.form：如果action为空则默认提交到本页 -->
    <form method="get/post" action="url" onsubmit ="return funciton"> …</form>   
<!-- 2.input元素 -->
    <input type="" name="" value=""/>
       type属性值:   
            text :文本框(maxlength=“字符数” size=“长度")   
            password：密码框(size=“长度")    hidden:隐藏域
            radio：单选框  
            checkbox：复选框	默认checked
            reset:重置按钮	  
            submit:提交按钮（onclick事件）
            button:普通按钮   
            image:图片按钮	
            file:文件域	
            email:邮箱	
            url:网址
            number:数字	    
            range:滑块（min=“最小”   max=“最大”  step =“数字间隔”）  
            search:搜索框	
            hidden:隐藏域  
<!-- 3.多行文本域 -->
<textarea  name="" cols="显示列数"  rows="显示行数">在这里输入内容 </textarea> 
<!--4.下拉框:   selected = "selected"  默认 --> 
<select  name=""> 
    <option value=""></option> …
</select>
<!-- 5.标注：单击label文本则对应的radio也会被选中 -->
<label  for="male">男</label>
<input type="radio" name="gender"  id="male"/>
<lable for="female">女</lable>
<input type="radio" name="gender"  id="female"/>
<!-- 附加 -->
readonly  只读
disabled  禁用
placeholder   提示	
required  规定不能为空	
pattern  验证/正则表达式
```

### 视屏/音频

```html
<!-- 1.视频 -->
<!-- 1.1 controls属性用于提供播放、暂停和音量控件    autoplay 自动播放 -->
 <video src="视频路径"  controls="controls"></video>
<!-- 1.2 使用sources元素来链接不同的视频文件，浏览器会自动选择一个可以识别的格式 -->
 <video controls>
     <source src=""/>
     <source src=""/>
 </video>
<!-- 2.音频 -->
<!-- 2.1 -->
  <audio src="音频路径"  controls="controls"></video>
<!-- 2.2 -->
  <audio controls>
     <source src=""/>
     <source src=""/>
  </audio>
```

### iframe框架

```html
 1.<iframe src="引用页面地址" name="框架标识名"> </iframe>
 2.<a href="地址1"  target="框架标识名"/>
   <a href="地址2"  target="框架标识名"/> 
```

### 特殊符号

```
空格  &nbsp
大于  &gt
小于  &lt
引号  &quot
版权号 &copy
```

## CSS

### 样式引入

```html
<!-- 1.  行内样式 -->
<h1 style="color:red;font-size:14px;"></h1>
<!-- 2.  内部样式 -->
<style>
    h1{
        color:green;
    }
</style>
<!-- 3. 外部样式 -->
<link href="style.css" rel="stylesheet" type="text/css"/>
```

### 选择器

```html
<!-- 1. 基本选择器: 优先级  id选择器>class类选择器>标签选择器 -->
    1.1 标签选择器： h3{ }  p{} 
    1.2 类选择器：  .class{ }
    1.3 id选择器：  #id{ }
<!--2. 高级选择器：-->
   <!--2.1 层次选择器 -->
    E F 后代选择器
    E>F 子选择器
    E+F 相邻兄弟选择器
    E~F 通用兄弟选择器
   <!-- 2.2 结构伪类选择器 -->
    E:first-child 第一个子元素
    E:last-child 最后一个子元素
    E F:nth-child(n)   顺序第n个
    E:first-of-type
    E:last-of-type
    E F:nth-of-type(n) 类型第n个
   <!-- 2.3 属性选择器 -->
    E[attr] 具有属性attr的E元素
    E[attr=val] 属性是attr并且值为val的E元素
    E[attr^=val] 属性是attr并且值为val开头的E元素
    E[attr$=val] 属性是attr并且值为val结尾的E元素
    E[attr*=val] 属性是attr并且值包含val的E元素
```

### 字体样式

```html
<!-- 1.设置字体类型：可以声明多种字体类型，字体之间用逗号隔开;有些字体中间有空格需要用双引号括起来;还有英文字体要在前。--> 
    font-family:Verdana,"宋体";
<!-- 2.设置字体大小 --> 
    font-size:66px;
<!-- 3.设置字体风格: normal默认  italic斜体   oblique倾斜 -->
    font-style:normal;
<!-- 4.字体的粗细: normal默认  bold粗体  bolder更粗   lighter 更细  100、200、300 -->
    font-weight:normal;
<!-- 5. 综合使用:风粗大类 -->
    p span{font:oblique bold 12px "楷体";}
```

### 列表样式

```html
1. none 无标记  decimal数字
2. list-style-type:none; 无标记
```

### 排版网页文本

```html
<!-- 1.设置文本颜色:color:rgba(0,0,255,0.5)透明度0.5 -->
    color:#00C;
<!-- 2.文本对齐方式: left 左  right 右   center 居中  justify 两端对齐 -->
    text-align:left;  
<!-- 3.首行缩进: 单位为 em、px。-->
    text-index:2em;  
<!-- 4.设置文本行高 -->
    line-height:28px;
<!-- 5.文本装饰: none 默认  underline下划线  overline上划线  line-through删除线 -->
    text-decoration:none;
<!-- 6.图片与文本居中对齐 -->
    img,span{vertical-align:middle;}
<!-- 7.文本阴影: 阴影颜色  x轴  y轴  模糊半径 -->
    h2{text-shadow:blue 10px 10px 2px}   
```

### 超链接伪类

```html
<!-- 1.访问前的样式 -->
    a:link{color:#9EF5F9;}
<!-- 2.访问后的样式 -->
    a:visited{color:#333;}
<!-- 3.鼠标悬浮 -->
    a:hover{color:#FF7300;}
<!-- 4.单击未释放 -->
    a:active{color:#999;}
<!-- 5.综合使用： 顺序 link visited  hover  active -->  
```

### 背景属性

```html
<!-- 1. 背景颜色 -->
    background-color:#C00;
<!-- 2. 背景图片 -->
    background-image:url("图片路径")
<!-- 3. 背景重复方式: repeat 沿水平和垂直两个方向平铺  no-repeat 不平铺   repeat-x 水平方向平铺  repeat-y 垂直方向平铺 -->
    background-repeat:repeat;
<!-- 4. 背景定位 -->
    4.1:  Xpos  Ypos
      4.1.1: 0px 0px  默认从左上角出现背景图像，无偏移。
      4.1.2: 30px 40px 正向偏移，向下和向右偏移。
      4.1.3: -50px -60px 反向偏移。
   4.2: X%  Y%
       4.2.1: 30%  50% 垂直方向居中，水平方向偏移30%
   4.3: X、Y方向关键词
       4.3.1: left  center  right  top  center  bottom
       4.3.2: right  top 右上角  left  bottom 左下角  top 上方水平居中位置出现
   4.4: background-position:170px 2px;
<!-- 5. 综合使用 -->
    background:#c00 url(image/down.gif) 205px 10px no-repeat;
<!-- 6. 背景尺寸: auto 默认  cover 填充  contain 适应的背景区域 --> 
    background-size:120px 60px; 
```

### 渐变

```html
<!-- 1. 渐变需要加浏览器前缀 -->
1.1: IE:-ms- , chrome(谷歌) safari(苹果) -webkit- ,opera(欧朋):-o-, Firefox(火狐):-MoZ-
<!-- 2. 渐变方向 -->
 2.1 to top  底部到顶部
 2.2 to bottom  顶部到底部
 2.3 to left 右到左
 2.4 to right 左到右
 2.5 to top left 右下到左上
 2.6 to top right 左下到右上 
 2.7 to bottom left 右上到左下   
 2.8 to bottom right 左上到右下 
<!-- 3. -webkit-linear-gradient{position,color1,color2,...} --> 
```

### 盒子模型

```html
<!-- 1.盒子模型组成 --> 
    content 网页内容
    border 边框
    padding 内边距
    margin 外边距
<!-- 2.border(边框) -->
    2.1: border-color(边框颜色)
            2.1.1: 分开设置
                2.1.1.1: border-top-color:#369;  设置上边框颜色
                2.1.1.2: border-right-color:#369; 设置右边框颜色
                2.1.1.3: border-bottom-color:#369; 设置下边框颜色
                2.1.1.4: border-left-color:#369; 设置左边框颜色
           2.1.2: 同设
                2.1.2.1: border-color:#369 #000; 上下边框为#369 左右边框为#000
                2.1.2.2: border-color:#EEFF34; 设置四个边框为同一个颜色
           2.1.3: 同时设置四个边框颜色,设置顺序按顺时针方向 上 右 下 左，属性之间以空格隔开
    2.2: border-width(边框粗细)
           2.2.1: 分开设置
                2.2.1.1: border-top-width:5px;  设置上边框粗细
                2.2.1.2: border-right-width:10px; 设置右边框粗细
                2.2.1.3: border-bottom-width:13px; 设置下边框粗细
                2.2.1.4: border-left-width:8px; 设置左边框粗细
           2.2.2: 同设
                2.1.2.1: border-width:20px 32px; 上下边框粗细为20px 左右边框粗细为32px
                2.1.2.2: border-width:29px; 设置四个边框为同一个粗细
           2.2.3: 同时设置四个边框粗细,设置顺序按顺时针方向 上 右 下 左，属性之间以空格隔开
    2.3: border-style(边框样式)
           2.3.1: 边框值
                2.3.1.1: none 无边框
                2.3.1.2: solid 实线边框 
           2.3.2: 分开设置
                2.2.1.1: border-top-style:solid;  设置上边框为实线
                2.2.1.2: border-right-style:solid; 设置右边框为实线
                2.2.1.3: border-bottom-style:solid; 设置下边框为实线
                2.2.1.4: border-left-style:solid; 设置左边框为实线
           2.2.2: 同设 / 同时设置四个边框....
    2.2: border简写属性
            2.2.1: 同时设置一条边框三个属性
                    border-bottom:9px #f00 dashed; 设置某元素下边框为红色 9px 虚线显示。    
            2.2.2: 同时设置四条边框三个属性
                    border:9px #F00 dashed;
            2.2.3: 顺序没有限制，但通常顺序为 粗细 颜色 和样式。
<!-- 3. margin(外边距) 指的是盒子与其他盒子的距离，也就是指网页中元素与元素之间的关系。 -->
       3.1: 分开设置
           3.1.1: margin-top:1px;  设置上外边距
           3.1.2: margin-right:2px; 设置右外边距
           3.1.3: margin-bottom:2px; 设置下外边距
           3.1.4: margin-left:1px; 设置左外边距
       3.2: 同设
           3.2.1: margin:3px 5px 7px 4px;   上右下左
           3.2.2: margin:3px 5px;  上下为3px  左右为5px
           3.2.3: margin:8px;     上右下左为8
           3.2.4: margin:3px 5px 7px; 上外边距为3px  左右边距为5px  下外边距为7px
       3.3: 让整个盒子居中
           margin:0px auto;   这个元素必须是块元素，其次这个元素要设置固定宽度。
<!-- 4. padding(内边距) 用于控制内容与边框的距离 -->
       4.1  分开设置
           4.1.1: padding-top:1px;  设置上内边距
           4.1.2: padding-right:2px; 设置右内边距
           4.1.3: padding-bottom:2px; 设置下内边距
           4.1.4: padding-left:1px; 设置左内边距
       4.2  同设
           4.2.1: padding:3px 5px 7px 4px;   上右下左
           4.2.2: padding:3px 5px;  上下为3px  左右为5px
           4.2.3: padding:8px;     上右下左为8
           4.2.4: padding:3px 5px 7px; 上内边距为3px  左右边距为5px  下内边距为7px
<!-- 5. 计算尺寸 -->
       5.1: 内盒的总尺寸 =  border + padding + 内容宽度/高
       5.2: 外盒的总尺寸 = border + padding +margin + 内容宽/高      
<!-- 6. 拯救布局 -->
       6.1: 值
           6.1.1: content-box:默认值  盒子的宽度或高度 = border+padding+(margin)+width/height。
           6.1.2: border-box: 盒子的宽度高度等于元素内容的宽度或高度。
           6.1.3: inherit: 继承父元素的盒子模型模式。
       6.2: box-sizing:border-box;                
<!-- 7. 圆角边框 -->
       7.1: border-radius:20px;  左上 右上  右下 左上 一致。
       7.2: border-radius:20px 40px;  左上角和右下角取第一个值，右上角和左下角取第二个值。
       7.3: border-radius:20px 30px 10px;  第一个值是左上角，第二个值是右上角和左下角，第三个值是右下角。
       7.4: border-radius:20px  30px 40px 50px; 分别对应 左上 右上  右下 左上。
<!-- 8. 盒子阴影 -->
       8.1: box-shadow:inset x y blur-radius color;
       8.2: inser为阴影类型，可选值，不设置默认为外阴影，设置表示内阴影。
       8.3: x轴 可正移,可负移。
       8.4: y轴 可正移,可负移。
       8.5: blur-radius 代表阴影向外模糊的范围。     
       8.6: color:阴影颜色。
       8.7: 例： box-shadow:20px 10px 10px #06c;    
```

### display属性

```
 1. block  块级元素的默认值，元素会被显示为块级元素。
 2. inline 行内元素的默认值，元素会被显示为行内元素。
 3. inline-block 两者兼具。
 4. none 设置元素不会被显示。
```

### 浮动

```
    1. float
        1.1: float:left;  左浮动
        1.2: float:right; 右浮动
        1.3: float:none;  不浮动
    2. clear
        2.1: clear:left;  元素左边不允许有浮动元素
        2.2: clear:right; 元素右边不允许有浮动元素
        2.3: clear:both;  元素两边不允许有浮动元素
       2.4: clear:none;  
```

### 解决父级边框塌陷问题

```
<!--1. 浮动元素后面加空div -->
            <div class="clear"></div>
            .clear{ clear:both; margin:0;padding:0;}
<!--2. 设置父元素的高度 -->
```

### overflow属性

```
1. hidden 内容会被修剪，超出的内容将看不见
2. scroll 内容会被修剪，但浏览器会显示滚动条以便查看其余内容
3. auto  
```

### 定位

```html
<!-- 1. 指定定位 -->
        1.1: position: relative;  相对定位，是相对它原来的位置，通过指定偏移，到达新的位置。
        1.2: position: absolute;  绝对定位，它以最近一个“已经定位”的祖先元素为基准进行偏移，如果没有，则以浏览器窗口为基准。
        1.3: fixed : absolute; 固定定位，它与绝对定位优点类似，区别在于定位的基准不是祖先元素，而是浏览器窗口。
<!-- 2. 值 -->
        2.1: top:-20px;
        2.2: left:30px; 
```

### z-index属性

```html
<!--用于调整定位时重叠层的上下位置。当元素被设置了position属性时，就可以使用该属性设置重叠高低关系。-->
   <!-- 1. 设置重叠高低 -->
        z-index:1;
   <!-- 2. 设置层的透明度 -->
        opacity:x; x值为0~1,值越小越透明。
        filter:alpha(opacity=x); x值为0~100,值越小越透明。

```

### 动画

```html
<!-- 1. 变形transform -->
       <!-- 1.1: 平移 -->
           1.1.1: transform: translate(4px,8px); 向右偏移4px,向下偏移8px
       <!-- 1.2: 缩放 -->
           1.2.1: transform: scale(1.5); 放大1.5倍
           1.2.2: transform: scale(1.5,1.3); x轴放大1.5倍,y轴放大1.3倍
       <!-- 1.3: 倾斜 -->
           1.3.1: transform: skew(40deg,-20deg); x轴和y轴倾斜度。
          1.3.2: transform: skew(40deg); 水平方向倾斜。
       <!-- 1.4: 旋转 -->
          1.4.1: transform: rotate(80deg); 旋转80deg。
       <!-- 1.5：旋转并放大图片 -->
           transform: rotate(-90deg) scale(2);        
           -webkit-transform: rotate(-90deg) scale(2);
           -moz-transform: rotate(-90deg) scale(2); 
           -o-transform: rotate(-90deg) scale(2);
```

### 过渡

```html
1. transition: property duration function delay;
       1.1: property: 用来定义动画的css属性,一般用 all 表示所有元素支持property属性的样式。
       1.2: duration: 指定完成所过渡的时间,即旧属性到换新属性所花费的时间，单位为S。
       1.3: funciton: (可选)指定过渡速度。
           1.3.1: ease: 速度由快到慢。
           1.3.2: liner: 匀速。
           1.3.3: ease-in: 渐显效果。
           1.3.4: ease-out: 渐隐效果。
           1.3.5: ease-in-out: 渐显渐隐。    
       1.4: delay: 过渡效果延迟时间。
```

### 关键帧

```html
 <!-- 1. 设置关键帧 @-webkit-keyframes  @-moz-keyframes -->
       @keyframes name{
           0%{ /* css样式*/ }
           33%{ /* css样式*/ }
           66%{ /* css样式*/ }
           100%{/* css样式*/ }       
       }    
 <!-- 2. 调用关键帧: @keyframes 只是用来声明一个动画，如果不通过别的css属性调用这个动画，是无任何效果的。-->
       2.1: animation: 可以在不触发任何事件的情况下也能调用动画，transiton则需要触发一个事件(hover事件、active事件等)
           2.1.1: animation: name  duration funciton delay count direction state mode;
               2.1.1.1: name: 是由@keyframes创建的动画名称。
               2.1.1.2: duration: 指定过渡事件，function 指定过渡速度， delay 过渡延迟效果 。
               2.1.1.3: count: 动画的播放次数,默认值1,表示执行一次，还有个特殊值 infinite 表示动画无限次播放。
               2.1.1.4: direction: 动画播放方向,有两个值，normal表示向前播放，alternate表示向前播放后，又反过来播放。
               2.1.1.5: state: 动画的播放状态,有两个值,paused将正在播放的元素动画停下来，running将暂停的动画重新播放。
               2.1.1.6: mode: forwards表示动画结束继续应用最后关键帧的位置，backwards表示迅速应用动画的初始祯，both,两者兼具。
```

