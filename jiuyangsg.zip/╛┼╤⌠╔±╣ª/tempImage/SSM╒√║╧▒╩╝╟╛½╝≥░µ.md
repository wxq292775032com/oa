# MyBatis框架（精简）

### 核心配置文件

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE configuration
PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
"http://mybatis.org/dtd/mybatis-3-config.dtd">
<configuration>
	<settings>	
		<!--<setting name="logImpl" value="LOG4J"/>-->
		<setting name="lazyLoadingEnabled" value="false"/>
	<!--<setting name="autoMappingBehavior" value="NONE"/> -->
	</settings>
	<typeAliases>
		<package name="cn.smbms.pojo"/>
	</typeAliases>
</configuration>
```

### ★Mapper文件

  **Mapper配置文件的头信息**

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper
PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
"http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="">    <!-- namespace要和对应接口的完全限定名一致 -->
</mapper>
```

#### **sql标签（重点）**

**select查询**

```xml
				                       <!--resultMap自定义映射结果/resultType普通返回值--> 
<select id="与接口的方法名一致" parameterType="入参类型" resultMap/resultType >  </select> 
```

**resultMap(自定义映射结果)**

```xml
<resultMap id="" type="结果类型(通常是java实例类)">
    <!--普通映射--> 
    <id property="类普通属性" column="数据库字段"/>  
    <result property="类普通属性" column="数据库字段"/>
    <!-- 高级映射 -->    
    	<!--第一种User一对一关系-->
    <association property="类实体对象属性" javaType="javaBean类型" resultMap="外部引用">
	    <id property="类普通属性" column="数据库字段"/>  
      	<result property="类普通属性" column="数据库字段"/>
    </association>
        <!--第二种 List<User>一对多关系   List<List<User>>-->       
    <collection property="类实体对象属性" ofType="javaBean类型" resultMap="外部引用">
      	<id property="类普通属性" column="数据库字段"/>  
      	<result property="类普通属性" column="数据库字段"/>
    </collection> 
</resultMap>
```

**Insert update  delete  （增删改）**

```xml
<update/delete/insert id="" parameterType="入参"> ${}获值</update>
```

**注解**

```java
@Param("")   注解
在接口中使用可以实现多参数入参,使用注解映射文件中不需要写入参类型。(单参时也推荐使用注解)
例子：int updatePwd(@Param(“id”)Integer id,@Param(“name”)){}
```

**动态Sql**

```xml
1. <!-- 条件判断 -->
<if test=""> </if>

2. <!-- 若有返回值就插入where  test，以及智能处理 and 和 or -->
<where> </where>

3.<!-- 只能忽略和添加 -->
<trim prefix="where" prefixOverrides="and|or" suffixOverrides =",">
<trim prefix="set" suffixOverrides="," suffix="where id = #{id}" >
 Prefix 前缀
 Suffix 后缀
 prefixOverrides 首部忽略指定内容
 suffixOverrides 尾部忽略指定内容
    
4.<!-- 动态配置set关键字，可剔除追加到末尾的任何不相关的逗号 -->
<set> </set>

5.<!--迭代一个集合，通常用于in条件-->
<foreach collection="array/list/map(用key值)" item="a" 
         open="(" separator="," close=")" index="下标名">
      #{a}            
</foreach>

6.<!--和JSTL元素作用一样，作用如switch-->
  	<choose>
    	<when test="">
        </when>
        <otherwise>
        </otherwise>
    </choose>
```

# Spring框架（精简）

### IOC依赖注入

**(设值注入)P命名空间注入方式**

```xml
 <!-- p命名空间的特点是使用属性而不是子元素的形式配置Bean的属性 （注意添加相关的头信息）-->
 <!--  p:属性名="值" -->
 <!--  P:dao-ref="对象id" -->
<bean id="user" class="entity.User"  p:age="123"  p:dao-ref=""/>
```

**(构造注入)C命名空间注入方式**

```xml
<!-- c命名空间和p命名空间差不多，使用属性而不是子元素的形式配置Beand属性（注意添加相关的头信息）-->
<!--  c:属性名="值" -->
<!-- c:dao-ref="对象id" -->
<bean id="user" class="entity.User"  c:age="123"  c:dao-ref=""/>
```

**★注解实现IOC(重点)**

```java
1.//注解定义Bean
@Repository("定义名") //用于标注DAO类
@Service("定义名")    //用于标注业务类
@Controller("定义名") //用于标注控制器类
2.//注解实现组件装配
//指定名称，如不指定名称默认按名称（属性名/set后名）匹配，如找不到则按类型查找
 @Resource(name="")
```

```xml
<!--配置文件 自动扫描(注意相关命名空间)-->
<context:component-scan base-package="service,dao">
</context:component-scan>
```

### ★注解实现AOP之环绕增强

```java
定义增强处理类：  @Aspect
环绕增强：  @Around("execution(表达式)")
```

**关于表达式**

```java
//声明一个公用的表达式
//调用此方法就可以直接获得表达式
@pointcut("execution(*service.userService.*(..))")
    	public void pointcut(){} 

//表达式例子：
public * addNewUser(entity.user)  任何返回值
public void * (entity.user)  匹配所有方法
public void addNewUser(..)  任意/所有参数
* com.service.*.*(..)  该包下所有类所有方法
* com.service..*.*(..) 及其子包下所有类，所有方法
```

**关于增强方法的参数**

```java
ProceedingJoinPoint 
proceed()//执行目标方法
getTarget()   //被代理的目标对象
getSignature().getName()  //被代理的目标方法
getArgs()	 //目标方法的参数数组     Arrays.toString(jp.getArgs())
```

**配置文件中启动注解支持**

```xml
<bean class="增强处理类"></bean>
<!--启动对Spring AOP的Aspectj注解的支持-->
<aop:aspectj-autoproxy/>
```

**实例：**

```java
@Around("pointcut()")  //此为以声明的表达式方法
	public Object aroundLogger(ProceedingJoinPoint jp)throws Throwable{
		System.out.println("孙悟空");
		Object result;
		try {
			result = jp.proceed();  //执行目标方法
			System.out.println("大闹天空");
			return result;
		} catch (Throwable e) {
			System.out.print(jp.getSignature().getName()+"方法发生异常"+e);
			throw e;
		}finally{
            System.out.print(jp.getSignature().getName()+"方法结束");
		}
	}
```

### ★声明式事务

```xml
<!--事务管理器-->
<bean id="txManager"
      class="org.springframework.jdbc.datasource.DataSourceTransactionManager">
		<property name="dataSource" ref="dataSource"/>
</bean>
<!--事物增强，设定事务的属性-->
<tx:advice id="txAdvice" transaction-manager="txManager">
	<tx:attributes>
		<tx:method name="find*" timeout="1000"></tx:method>
		<tx:method name="*"  propagation="REQUIRED"/>
	</tx:attributes>
</tx:advice>
<!-- 配置切面 -->
<aop:config>
	<aop:pointcut id="myPoint" expression="execution(* cn.smbms.service..*.*(..))" />
	<aop:advisor advice-ref="txAdvice" pointcut-ref="myPoint"/>
</aop:config>
```

```text
<tx:method> 参数：
	propagation：  
			SUPPORTS  适用于查询语句，有事务则执行事务，没有事务就不执行
			REQUIRED  默认方法，有事务则使用当前事务，否则开始一个新事务
	read-only:  设为true查询时性能提高
	timeout:  事务超时时间，以秒为单位，默认值为-1表示不超时
	rollback-for: 触发回滚异常的类型（多个异常用逗号隔开），默认为RuntimeException			
```

### 配置文件头信息

**基本头信息（IOC头信息）**

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
     xsi:schemaLocation="http://www.springframework.org/schema/beans
         http://www.springframework.org/schema/beans/spring-beans.xsd">
```

**AOP要添加的头信息**

```xml
     xmlns:aop="http://www.springframework.org/schema/aop"
         http://www.springframework.org/schema/aop
         http://www.springframework.org/schema/aop/spring-aop-3.2.xsd
```

**p命名空间要添加的头信息**

```xml
xmlns:p="http://www.springframework.org/schema/p"
```

**c命名空间要添加的头信息**

```xml
xmlns:c="http://www.springframework.org/schema/c"
```

**context扫描注解的头信息**

```xml
xmlns:context="http://www.springframework.org/schema/context"
http://www.springframework.org/schema/context
http://www.springframework.org/schema/context/spring-context-3.2.xsd
```

# SpringMVC框架/SSM整合(精简)

### **★web.xml配置Servlet**

```xml
<!-- 
《DispatcherServlet是整个SpringMVC框架的核心，它负责截获请求并将其分派给相应的处理器处理》
1.配置了一个名为springmvc的Servlet。该Servlet是DispatcherServlet类型，它就是SpringMVC的入口。
2.<load-on-startup>1</load-on-startup>
  通过配置标记容器在启动的时候就加载此DispatcherServlet即自动启动
3.然后通过servlet-mapping映射到“/”，即DispathcherServlet需要截获并处理该项目的所有URL请求。
4.在配置DispatcherServlet的时候,通过设置contextConfigLocation参数指定SpringMVC配置文件的位置. -->
<servlet>
 	<servlet-name>springmvc</servlet-name>
 		<servlet-class>
 		        org.springframework.web.servlet.DispatcherServlet
 		</servlet-class>
 		<init-param>
 		         <param-name>contextConfigLocation</param-name>
 		         <param-value>classpath:springmvc-servlet.xml</param-value>
 		</init-param>
 	<load-on-startup>1</load-on-startup>  
</servlet>
<servlet-mapping>
 	<servlet-name>springmvc</servlet-name>
 	<url-pattern>/</url-pattern>
</servlet-mapping>
```

```xml
<!---------------过滤器------------>
 <filter>
 	<filter-name>EncodingFilter</filter-name>
 	<filter-class>
 		 org.springframework.web.filter.CharacterEncodingFilter
 	</filter-class>
 	<init-param>
 		<param-name>encoding</param-name>
 		<param-value>UTF-8</param-value>
 	</init-param>
 	<init-param>
 		<param-name>forceEncoding</param-name>
 		<param-value>true</param-value>
 	</init-param>
 </filter>
 <filter-mapping>
 	<filter-name>EncodingFilter</filter-name>
 	<url-pattern>/*</url-pattern>
 </filter-mapping>
```

```xml
<!-- 在web中使用监听类启动spring容器-->
   <context-param>
   <param-name>contextConfigLocation</param-name>
   <param-value>classpath:applicationContext-*.xml</param-value>
   </context-param>
   <listener>
   		<listener-class>
   			org.springframework.web.context.ContextLoaderListener
   		</listener-class>
   </listener>
```

### ★Springmvc-servlet.xml

**注解扫描**

```xml
1.<!-- <mvc:annotation-driven>完成Handler对注解的支持 --> 
<mvc:annotation-driven>
    <mvc:message-converters>
   <!-- 解决json传递中文乱码的问题-->	
        <bean class="org.springframework.http.converter.StringHttpMessageConverter">
			<property name="supportedMediaTypes">
				<list>
					<value>application/json;charset=UTF-8</value>
				</list>
			</property>
		</bean>
   <!-- 解决json传递日期格式问题-->
   <!-- 默认为yyyy-MM-dd HH:mm:ss 类型 对于特殊字段可用 @JSOnFieId 控制（注解优先）-->
        <bean class="com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter">
			<property name="supportedMediaTypes">
				<list>
					<value>text/html;charset=UTF-8</value>
					<value>application/json</value>
				</list>
			</property>
			<property name="features">
				<list>
					<value>WriteDateUseDateFormat</value>
				</list>
			</property>
		</bean>
	</mvc:message-converters>
</mvc:annotation-driven>
2. <!--对控制器包进行扫描-->
<context:component-scan base-package="cn.smbms.controller"/>
```

**配置视图解析器**

```xml
<!-- 配置视图解析器 /WEB-INF/jsp/index.jsp  主要处理JSP视图模板的映射-->
<bean class="org.springframework.web.servlet.view.InternalResourceViewResolver">
	<property name="prefix" value="/WEB-INF/jsp/"></property>   		
	<property name="suffix" value=".jsp"></property>
</bean>
<!-- 配置多视图解析器-->
1.favorParameter 属性，表示支持参数匹配，可根据请求参数的值确定MIME类型，默认请求参数为format。
2.mediaTypes 属性，若请求参数后缀为.json则以application/json的格式进行数据的展示
3.viewResolvers 属性，表示视图解析器
<bean class="org.springframework.web.servlet.view.ContentNegotiatingViewResolver">
	<property name="favorParameter" value="true"/>
	<property name="defaultContentType" value="text/html"/>
	<property name="mediaTypes">
		<map>
			<entry key="html" value="text/html;charset=UTF-8"/>
			<entry key="json" value="application/json;charset=UTF-8"/>
			<entry key="xml" value="application/xml;charset=UTF-8"/>	
		</map>
	</property>
	<property name="viewResolvers">
	  <list>
       <bean class="org.springframework.web.servlet.view.InternalResourceViewResolver">
			<property name="prefix" value="/WEB-INF/jsp/"/>
			<property name="suffix" value=".jsp"></property>
	   </bean>
	  </list>
	</property>
</bean>
```

 **引用静态资源** 

```xml
<mvc:resources location="/static/" mapping="/static/**"/>
```

**全局异常**

```xml
<!-- springMVC是通过HandlerExceptionResolver进行程序异常处理。发生异常就会跳入相应的异常页面显示·	异常-->
<!-- 全局异常的配置  -->
<bean class="org.springframework.web.servlet.handler.SimpleMappingExceptionResolver">
	<property name="exceptionMappings">
		<props>   <!--可以指定多个异常 error为逻辑视图名-->
			<prop key="java.lang.RuntimeException">error</prop>
		</props>
	</property>
</bean>
<!--视图显示： ${exception.message} -->	
```

**上传文件**

```xml
<!--此处的id名必须为multipartResolver-->
<bean id="multipartResolver" 
		class="org.springframework.web.multipart.commons.CommonsMultipartResolver">
		<property name="maxUploadSize" value="5000000"/>
		<property name="defaultEncoding" value="UTF-8"/>
</bean>
```

**配置拦截器**

```java
1.//创建interceptor包再创建拦截器java类
public class SysInterceptor extends HandlerInterceptorAdapter{
	public boolean preHandle(HttpServletRequest request,
							HttpServletResponse response,
							Object handler)throws Exception{
		HttpSession session = request.getSession();
        //Constants.USER_SESSION 此为登入网页成功时，存入sesssion的用户信息
		User user = (User)session.getAttribute(Constants.USER_SESSION);
		if(user == null){
			response.sendRedirect(request.getContextPath()+"/401.jsp");
			return false;  //拦截请求，重定向到/WebRoot/401.jsp,进行友好信息提示
		}
		return true;    //放过请求，进入控制器的处理方法
	}
}
```

```xml
2.<!--配置文件中配置-->
<mvc:interceptors>
	<mvc:interceptor>
		<mvc:mapping path="/sys/**"/>
		<bean class="cn.smbms.interceptor.SysInterceptor"/>
	</mvc:interceptor>
</mvc:interceptors>
```

**自定义转换器**

```xml
<!--解决springMVC框架对时间转换的问题-->
<!--以前直接通过<mvc:annotation-driven/>标签来支持注解驱动的功能	                             （@DateTimeFormat(pattern="yyyy-MM-dd")）满足了日期类型的转换需求，现在也可以通过自定义转        换器，来规定转换的规则-->
1. 创建一个工具类继承Converter接口，实现convert 方法-
注意导包：import org.springframework.core.convert.converter.Converter;
	public class StringToDateConverter implements Converter<String, Date>{
		private String datePattern;
		public StringToDateConverter(String dataPattern){
			System.out.println("xxxxxxxxxxxxxxx"+dataPattern);
			this.datePattern=dataPattern;
		}
		@Override
		public Date convert(String s) {
			Date date = null;
			try {
				date = new SimpleDateFormat(datePattern).parse(s);
				System.out.println(date);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			return date;
		}
	}
 2. 在SpringMVC 配置文件中配置  
    <bean id="myConversionService" 
		class="org.springframework.context.support.ConversionServiceFactoryBean">
	    <property name="converters">
	    	<list>
	    		<bean class="cn.smbms.tools.StringToDateConverter">
	    			<constructor-arg type="java.lang.String" value="yyyy-MM-dd"/>
	    		</bean>
	    	</list>
	    </property>
	</bean>
 3.注意在  mvc:annotation-driven 标签中添加属性   
   <mvc:annotation-driven conversion-service="myConversionService"/>
```

### **★applicationContext.xml整合文件**

```xml
1●<!-- 读取properties文件内的数据库配置文件信息  -->   
 <!-- JNDI获取数据源（使用dbcp连接池） -->
 <context:property-placeholder location="classpath:database.properties"/>
 <bean id="dataSource" class="org.apache.commons.dbcp.BasicDataSource"> 
     <property name="driverClassName" value="${driver}"/>
     <property name="url" value="${url}"/>
     <property name="username" value="${user}"/>
     <property name="password" value="${password}"/>
     <property name="initialSize" value="${initialSize}"/>
     <property name="maxActive" value="${maxActive}"/>
     <property name="maxIdle" value="${maxIdle}"/>
     <property name="minIdle" value="${minIdle}"/>
     <property name="maxWait" value="${maxWait}"/>
     <property name="removeAbandonedTimeout" value="${removeAbandonedTimeout}"/>
     <property name="removeAbandoned" value="${removeAbandoned}"/>
     <!-- sql心跳 -->
     <property name="testWhileIdle" value="true"/>
     <property name="testOnBorrow" value="false"/>
     <property name="testOnReturn" value="false"/>
     <property name="validationQuery" value="select 1"/>
     <property name="timeBetweenEvictionRunsMillis" value="60000"/>
     <property name="numTestsPerEvictionRun" value="${maxActive}"/>
  </bean>
3●<!-- 获取sqlSessionFactory --> 
  <bean id="sqlSessionFactory" class="org.mybatis.spring.SqlSessionFactoryBean">
     <property name="dataSource" ref="dataSource"/>
     <property name="configLocation" value="classpath:mybatis-config.xml"/> 
  </bean>
4●<!-- 扫描注解--> 
<bean class="org.mybatis.spring.mapper.MapperScannerConfigurer">
    	<property name="basePackage" value="cn.smbms.dao"/>
</bean>
5●<!--  配置事务  -->
	5.1<!--配置事务管理器-->
 <bean id="transactionManager"
   class="org.springframework.jdbc.datasource.DataSourceTransactionManager">
      <property name="dataSource"  ref="dataSource"/>
 </bean>
	5.2<!--事物增强，设定事务的属性-->
<tx:advice id="txAdvice" transaction-manager="txManager">
	<tx:attributes>
	    <tx:method name="find*" timeout="1000"></tx:method>
		<tx:method name="*"  propagation="REQUIRED"/>
	</tx:attributes>
</tx:advice>
	5.3<!--切面织入-->
<aop:config proxy-target-class="true">
    <aop:pointcut  id="transService" expression=
                  "execution(* *cn.smbms.service..*(..))"/>
    <aop:advisor pointcut-ref="transService" advice-ref="txAdvice"/>
</aop:config>	
6●<!-- AOP事务处理  -->
<aop:aspectj-autoproxy/>
```

### ★创建Controller（bean）

```java
1.//标识注解
@Controller //标注在类上面，使其成为一个可处理HTTP请求的控制器
```

 **@RequestMapping**

```java
//将不同的请求映射到对应的控制器处理方法上
//可以标注在类上面和方法上面
//1.请求信息可以为数组形式 2.还可以有请求方法  3.请求参数（参数名要和方法里的参数名一致）
//必须保证全局唯一性
@RequestMapping("/index")
@RequestMapping(value={"/welcome","/yangyang"},method=RequestMethod.GET,params="username") 
```

**@RequestParam**

```java
//value  参数名
//required   默认true  表示请求中必须包含对应的参数名，如果不存在就会抛出异常,false为不会
//defaultValue   默认参数名（不推荐使用）
//用对象做入参，那么如：from 表单中的name属性值 要和实体类的属性相对应。
@RequestParam
@RequestParam(value="user",required=flase)
```

**@ResponseBody**

```java
//(ajax)将标注该注解的处理方法的返回结果直接写入HTTP ResponseBody中,一般会在异步获取数据时使用！
```

**指示符与API对象**

```java
//转发和重定向
指示符<重定向>------redirect:
(默认)指示符<转发>------forward:   
// 使用servletAPI对象 ，通过直接入参创建 session  request response
HttpSession,
HttpServletRequest,       //request.getServletContext.getApplication
HttpServletResponse
```

**模型数据**

```java
// 方式一：ModelAndView作为返回值
	//既可以包含视图信息，又包含模型数据信息。
	ModelAndView mView = new ModelAndView();
    //2.-----添加模型数据（要返回的数据）
      // 第一个参数为key值，第二个参数为 key对应的value。
      ModelAndView addObject(String attributeName,Object attributeValue);
      //添加Map对象到Model中
      ModelAndview addAllObjects(Map<String,?> modelMap) 
   // 2.-----设置视图(选择哪个视图)
     void setView(View view) // 指定一个具体的视图对象
     void setViewName(String viewName)  //指定一个逻辑视图名
//方式二：Model(隐含模型)类型作为入参,将参数放入Model中即可，另外返回字符串类型的逻辑视图名
    //例: public String index(String username,Model model){}
          addAttribute("key",值);
    // 注：在Model中增加模型数据，若不指定key,则默认使用对象的类型作为key
    // 注：也可以直接用Map入参，但是不推荐
//方式三： @ModelAttribute 参数前加此注解;和入参中添加Model,再将对象放入Model中效果一样。
	public String addUser(@ModelAttributte("user") Usre user){}
```



# 附加一：properties文件

```properties
driver = com.mysql.jdbc.Driver
url = jdbc:mysql://localhost:3306/smbms?useUnicode=true&characterEncoding=utf-8
user = root
password =root
minIdle=45
maxIdle=50
initialSize=5
maxActive=100
maxWait=100
removeAbandonedTimeout=180
removeAbandoned=true
```

# 附加二：配置数据源参数的描述

```reStructuredText
initialSize: 数据库连接池在初始化连接时，第一次就要创建的连接个数，默认为0.
maxActiv:定义连接池中同时连接的最大连接数，默认连接数为8。比如若设置为50，则表示可以支持单击并发50左右的处理能力。
maxIdle：定义连接池中可允许的最大空闲连接数，默认连接数为8。超时设置的空闲连接数的连接将被释放掉，若设置为负数则表示 不受限制。
minIdle: 定义连接池中最小的连接数，默认连接数为0。低于该数值的连接池将会创建新的连接。  
maxWait: 等待的连接时间，当连接池中没有连接可用的话，连接池需要等待的连接释放的最大时间。若等待时间超过这个设置时间，则会抛出异常，若该值设置为-1，则表示无限等待下去。配置该数值可以避免因线程池不够用而导致的请求被无限挂起和连接不可用问题。
removeAbandoned:定义该配置项的作用是告诉连接词是否开启无用连接回收的机制，默认为false,这里调整为true.
removeAbandonedTimeout: 当开启了无用连接回收的机制之后，配置该配置项可以控制连接池在超出配置的时间后回收没有用的连接，这个配置默认为300秒，建议稍微少一点，尽量快速地回收没有用的连接。
testWhileIdle: 定义开启Evict的定时校验（循环校验）
timeBetweenEvictionRunsMillis: 定义Evict的时间间隔，单位毫秒，此处设值为6000,即1分钟，这个值大于0才会开启Evict
testOnBorrow: 定义在进行borrowObject处理时，对拿到连接是否进行校验，false为不校验，默认为false.
testOnReturn: 定义在returnObject时，对返回的连接是否进行校验，false为不校验，默认为false
validationQuery: 定义校验使用的SQL语句，跟MySQL简单通信下，校验连接是否有效。注意该SQL语句不能太复杂，复杂的校验SQL会严重影响性能。
numTestPerEvictionRun:定义每次校验连接的数量。一般情况下，该值会和maxActive大小一样，每次可以校验所有的连接
```

