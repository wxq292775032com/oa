Hibernate框架

## ★★两大核心配置

### ★配置文件(hibernate.cfg.xml)

```xml
<hibernate-configuration>
    <session-factory>
        <!--连接池c3p0 注意相关的jar包-->
        <property name="hibernate.connection.provider_class">
            org.hibernate.connection.C3P0ConnectionProvider
        </property>
        <!------------------★连接四要素★---------------->
        <!----如果引用hibernate.properties就不需再编写这四要素，而且hibernate会自动引入----->
        <property name="hibernate.connection.driver_class"> <!--数据库JDBC驱动 -->
            <!--oracle.jdbc.driver.OracleDriver-->
            oracle.jdbc.OracleDriver
        </property>
        <propertyname="hibernate.connection.url">   <!--数据库 URL -->
            jdbc:oracle:thin:@localhost:1521:orcl
        </property>
        <property name="hibernate.connection.username">scott</property><!--用户-->
        <property name="hibernate.connection.password">tiger</property><!--密码-->
		<!-------------------★辅助参数★----------------->
        <!--配置当前会话-->
        <property name="current_session_context_class">thread</property>
        <!--配置方言（不同数据库选择不同方言）-->
        <propertyname="hibernate.dialect">
            org.hibernate.dialect.Oracle10gDialect
        </property>
        <!--显示sql语句-->
        <property name="show_sql">true</property>
        <!--格式化sql语句-->
        <property name="format_sql">true</property>
        <!--自动创建表-->
        <property name="hbm2ddl.auto">update</property>
        <!-------------------★映射信息★------------------>
        <mapping resource="cn/bdqn/pojo/Student.hbm.xml"/><!--映射文件方式引用-->
        <mapping class="cn.hibernatedemo.entity.Dept"/>  <!--注解方式引用-->
    </session-factory>
</hibernate-configuration>
```

**hibernate.properties**

```properties
hibernate.connection.driver_class=oracle.jdbc.driver.OracleDriver
hibernate.connection.url=jdbc:oracle:thin:@localhost:1521:orcl
hibernate.connection.username=scott
hibernate.connection.password=666666
```

### ★对象关系映射(*.hbm.xml)

```xml
<!--★建议创建实体类时 实现(implements) Serializable 接口 -->
<hibernate-mapping>	<!--package=""-->
    <!--class元素添加这个dynamic-update="true"更新方法一中只更新值改变的字段-->
	<class name="实体类完全限定名" table="`数据库表名`" dynamic-update="true" >
<!--------------------主键映射------------------------->
        <id name="属性名" type="java.lang.Byte" column="`数据库字段`">
			<generator class="assigned"/>
		</id>
<!--------------------普通字段映射---------------------->        
		<property name="属性名" type="java.lang.String" column="`数据库字段`" />
<!--------------------连级映射------------------------->
<!--*** 多对一：如街道表为"多"的一方，区县表则为"一"（在街道实体类添加个区县对象）-->
        <many-to-one name="区县对象属性"   column="`街道表外键`" class=" "/> 
 
<!-- 一对多：如区县表为"一"的一方，街道表为"多"的一方（在区县实体类添加街道set集合）-->
        <set name="街道集合对象属性" cascade="save-update"  inverse="true">
			<key column="`街道表对应区县的外键`"/>  
			<one-to-many class="街道类完全限定名"/>
		</set>

<!-- 多对多：一个项目有多个员工，一个员工可以进行多个项目，项目类里添加员工set集合，员工类添加
			项目set集合-->
<!-- 理解：查找关系表中的项目外键得到对应的雇员外键，通过雇员外键获取雇员信息-->
<!-- 关系表中总有一方要放弃的项目的维护权，放弃维护权的一方添加 inverse="true"，
	拥有维护全的一方可以添加 cascade="save-update"	-->
        <set name="集合属性"   table="`关系表`" cascade="save-update">
			<key column="`关系表中项目的外键(自己)`"/>
			<many-to-many class="完全限定名（set集合类型）" column="`获得对应的外键`"/>
		</set>
	</class>
</hibernate-mapping>
```

```xml
--------------------generator：（id元素的子元素，用于指定主键的生成策略）
	class属性用来指定具体主键生成策略。
    param 元素用来传递参数。
常用的主键生成策略：
	（1）assigned:主键由应用程序负责生成，无须Hibernate参与。这是没有指定<generator>元素的默认生成		  策略。
     (2)increment:对类型为long、short或int主键，以自动增长的方式生成主键的值。主键按数值顺序递增，		增量为1 （☆多线程并发时会出问题）
     (3)identity:对如SQLServer、DB2、MySQL等支持标识列的数据库
        例：<generator class="identity"></generator>
     (4)sequence:对如Oracle、DB2等支持序列的数据库
        例：  <generator class="sequence">
        		<param name="sequence">序列名</param>
        	 </generator>
	 (5)native:由Hibernate根据底层数据库自行判断采用何种主键生成策略
        例（推荐）：<generator class="native"></generator>
```

```reStructuredText
-------------cascade属性：可以通过逗号来拼接多个参数（尽量使用在一对多的一这一方）
	--默认(none)情况忽略其他关联的对象
	--save-update: 当通过Session的save(),update(),saveOrUpdate()方法保存或更新当前
		对象时，级联保存所有关联的瞬时状态的对象或更新游离状态的对象
	--delete:（危险） 当通过Session的delete()方法删除当前对象时，会级联删除所有关联的对象
    
-------------inverse属性：默认为false,表示会主动维护关联关系，为性能着想一般设为true关闭主动维护。
	            （在代码中，一定要把双方对象的关系互相关联好）
```

### ☆对象关系映射(注解实现)

```java
注意：一般用 javax.persistence.Entity包下的
@Entity  将一个类声明为一个持久化类
@Table(name="`数据库表`") 为持久化类指定表(其实指定Entity后框架会根据类名自动映射，但还是建议写上)
@Column(name="`DNAME`") 将属性映射到数据库字段
@Transient 忽略标记的属性(与表无关的属性一定要标记，否则会报错)
@Id  关于主键,除了要添加 @Column 还要这个@id 
 主键增长方式(@Id默认增长方式assigned)：
	方式一：	//GenerationType.SEQUENCE  使用序列生成主键(Oracle)
			   //GenerationType.IDENTITY  使用数据库自动生成主键值(MySQL，SQLServerl)
			   //GenerationType.AUTO  根据不同的数据库选择不同的策略
			   		      //增长策略                          //引用
    @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="EMP_GEN")
							//指定序列名         //指定引用名
    @SequenceGenerator(sequenceName="EMP_SEQ",name="EMP_GEN") //序列生成器
			//initialValue="初始值"  allocationSize="增量"
    方式二：
    				 //引用
    @GeneratedValue(generator="EMP_INC")
    				//指定Hibernate增长策略   //指定引用名
	@GenericGenerator(strategy="increment",name="EMP_INC")

//-------------------------- 注解关联关系----------------------------------------------
  《一对多》
 //targetEntity  注解解析的时候，会根据集合泛型寻找所以可以不指定
 //fetch 为是否延迟不用指定也可以，默认是延迟
 //cascade 关于级联操作，不过建议用Hibernate包下的@Cascade属性进行操作	  @Cascade({CascadeType.SAVE_UPDATE})
 //mappedby 也起到了inverse属性的作用，会将其设置为true
	@OneToMany(targetEntity=Emp.class,fetch=FetchType.LAZY,cascade={CascadeType.ALL},
              mappedBy="集合类型类中的外键对象属性")
  《多对一》
  //targetEntity 名字一样会自动映射，可以不用指定
  //在多对一的一方默认是立即加载(MAGER)所以要保持延迟的特点需要明确指定fetch
  //在这一方级联操作意义不大 cascade
  @ManyToOne(fetch= FetchType.LAZY)
  @JoinColumn(name="`DEPTNO`")   //指定外键
  《多对多》
  		主导权一方：
  			@ManyToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	        @JoinTable(name="关系表",schema="SCOTT",
		joinColumns={@JoinColumn(name="关系表我的外键",nullable=false,updatable=false)},
	inverseJoinColumns={@JoinColumn(name="集合外键",nullable=false,updatable=false)})
        另一方：
        												 //主导方关于我方的集合属性(自己)
      	@ManyToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY,mappedBy="empLoyees")
```

### 附加：头信息

**hibernate.cfg.xml**

```xml
<!DOCTYPE hibernate-configuration PUBLIC
	"-//Hibernate/Hibernate Configuration DTD 3.0//EN"
	"http://www.hibernate.org/dtd/hibernate-configuration-3.0.dtd">
<hibernate-configuration>
</hibernate-configuration>
```

**entity.xml**

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE hibernate-mapping PUBLIC "-//Hibernate/Hibernate Mapping DTD 3.0//EN"
 "http://www.hibernate.org/dtd/hibernate-mapping-3.0.dtd" >
<hibernate-mapping>
</hibernate-mapping>
```

## ★★数据操作

### ★创建Session对象

```java
(1)读取并解析配置文件及映射文件
    Configuration  conf = new  Configuration().configure();
(2)依据配置文件和映射文件的信息，创建SessionFactory对象
	SessionFactory  sf = conf.buildSessionFactory();
(3)打开Session
	Session  session = sf.getCurrentSession(); //或者使用 sf.openSession()
//-----------以上三步可以编写成一个Util工具类----------------
(4)开始一个事务
	Transaction tx = session.beginTransaction();
(5)数据库操作。
	session.★增删改/★查
(6)结束事务
	tx.commit()  //提交事务    
	tx.rollback() //回滚事务
//注意：如果使用openSession获得Session对象，则需要    session.close()方法
```

```java
public class HibernateUtil {
	private static Configuration conf;
	private static SessionFactory sf;
	static{
		try {
			conf = new Configuration().configure();
			sf = conf.buildSessionFactory();
		} catch (Exception e) {
			e.printStackTrace();
			throw new ExceptionInInitializerError(e);
		}
	}
	private HibernateUtil(){}
	public static Session getSession(){
		return sf.getCurrentSession();
	}
}
```

### ★增删改

```java
//-------添加
save(对象); 
//--------删除
方法1： delete(session.load(Class a,id));    通过load查询然后进行删除
方法2： delete(对象)
//-------修改
方法1：通过load或get查询找到要修改的对象，然后重新set赋值，提交事务就修改成功了。
方法2： update(对象)
方法3： merge(对象)  也有动态更新的效果，而且不需要重新赋值
//---附加：
方法： saveOrUpdate()  传入的对象有id值则更新，没有id值则保存
```

### **★查询区**

**按主键查询**

```java
方法1： Object get(Class a,Serializable id)  若数据不存在，返回null
方法2： Object load(Class a,Serializable id) 若数据不存在，使用抛出ObjectNotFoundException
```

**HQL查询** ·

```java
(1)定义HQL语句------------------★------------------------------
//不写select 表示查询全部 ，加了表示有选择的查询(投影查询)，查询的对象状态不是持久状态 
//★投影查询查多个字段返回的是数组，List<Object[]>, 
//★投影查询也可以返回对象,String  hql = "select new pet(id,name) from Emp"，需要相关构造方法
//id是个特殊关键字，id在HQL里就表示主键
 String  hql = "from Emp";   //HQL语句
//★使用占位符
	按参数位置绑定: from  User  where name=?
	按参数名称绑定: from  user  where  name=:name
(2)创建HQL对象-------------------★-----------------------------
 Query query = session.createQuery(hql);   
//★为参数赋值
    针对具体数据类型：
    	setXXX(int position, xxx value)   
    	setXXX(String name,xxx value)
    任意类型参数：    	
		setParameter(int position, Object  value) 
		setParameter(String name,Object  value)
    转为命名参数定制
		setProperties(对象)  //变量名一定要和它的get方法保持一致
(3)执行查询-----------------------★----------------------------
 List(Emp) empList=query.list();     	   //方式一 
 Iterator(Emp) empList=query.Iterator();   //方式二 执行效率更高
 long empList=query.uniqueResult();        //方式三 多列返回数组(返回唯一值，结果不唯一会报错)

//----------------------分页------------------------
setFirstResult()  偏移量    //下标从0开始
setMaxResult()    页大小
```

**多表连接查询**

```java
//***语法建立在关联属性上(最左边的是原始类型其他的都是关联属性)
1.内连接(只会获取两边能够匹配上的值)：inner join [fetch]  加了fetch表示迫切内连接区别在于返回值。
 String hql = "from Dept d inner join d.emps"; //不需要on因为本身有关联,返回 List<Object[]>
 String hql = "from Dept d inner join fetch d.emps"; //返回List<Dept>最左边的对象
2.左外连接：left join [fetch]   
 String hql = "from User u left join u.houses";   // 返回值与内连接一致
 String hql = "from User u left join fetch u.houses" 
3.隐式内连接(Hibernate 会根据关联关系自动使用等值连接(等效于内连接)查询)
 String hql = "from House h where h.user.name='龙四'" ;
 String hql ="select e.empName, e.dept.deptName from Emp e ";
//***语法没有建立在关联属性上
4.等值连接(效果如内连接）
 String hql = "from User u ,House h where u = h.user" ;  //返回：List<Object[]>
//课堂补充
添加这个 select distinct 可以去重 
```

**分组/排序/聚合函数/子查询**

```java
[select...] from...  [where...]  [group by...[having...]]  [order by...]
count() sum() min() max() avg()
//***当不能确定查询结果的类型时，可以使用以下方法来确定查询结果类型
    Object count = session.createQuery
    					("select count(distinct job) from Emp").uniqueResult()
    System.out.print(count.getClass.getName())
//子查询
  value>all(子查询所有结果)  value>any(子查询任意一个结果)  in 相当于=any   exists 任意结果
```

## ★附加

### ☆OpenSessionInView模式

**web.xml**

```xml
<!--解决延迟加载获取数据报错的的问题-->  
<filter>
  		<filter-name>openSession</filter-name>
  		<filter-class>cn.wxq.web.OpenSessionInViewFilter</filter-class>
  </filter>
  <filter-mapping>
  		<filter-name>openSession</filter-name>
  		<url-pattern>/*</url-pattern>
  </filter-mapping>
```

**java类**

```java
import javax.servlet.Filter;
public class OpenSessionInViewFilter implements Filter{
	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1,
			FilterChain arg2) throws IOException, ServletException {
		Transaction tx = null;
		try {
			tx = HibernateUtil.currentSession().beginTransaction();
			arg2.doFilter(arg0, arg1);
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			if(tx!=null)
				tx.rollback();
		}
	}
}
```

### ☆对象状态

```reStructuredText
状态：
瞬时状态(Transient)
	和数据库毫无关系的对象
持久状态(Persistent)
	这个状态的对象和数据库有关联的，添加在session缓存里(get() load() save() update())
游离状态(Detached)
	和数据库有关联，但没添加到session缓存里面
附加：当游离态的对象被垃圾回收了之后，内存中就不存在该记录的信息，但是数据库中存在，与session也无关了，这种状态叫做“无名态”（官方没有定义，人为取的）。
	
三种状态之间的转换：
	瞬时转持久： save()   saveOrupdate()
	持久转瞬时： delete()
	持久转游离：close()关闭session  clear()清除所有缓存  evict()清除传入的对象
	游离转瞬时： delete()
```

### ☆延迟加载

```xml
延迟加载是当在真正需要数据时，才执行SQL语句进行查询，避免了无谓的性能开销
延迟加载策略的设置分为:
	<class>类级别：  lazy ="false(立即加载) / true(延迟加载)"
	<set> 一对多关联级别：  lazy="false(立即加载) / true(延迟加载)/ extra(推荐：增强延迟加载)" 
	<many-to-one>元素：  lazy="false(立即加载) /proxy(延迟加载) / no-proxy(无代理延迟加载)
 默认都为true. lazy设置只对load()有效，get()永远都是立即查询
查询用 ：get()  更新需要查询时用 ：load()
```

### ☆错误记载

```reStructuredText
could not initialize proxy - no Session
无法初始化代理-没有会话    原因：（Session关闭了）

Unknown entity   
未知的实体   原因：（没有引入映射文件） 

Batch update returned unexpected row count from update [0]; actual row count: 0; expected: 1
返回意外的行数;实际行数:0;预期:1     原因：（我在更新数据时，显式地使用了id的setId()方法为其指定值。但是我的实体类的id指定了主键生成策略，此时不能显式使用setId()方法设置id的值。）

数据库报错： [Err] ORA-01861: 文字与格式字符串不匹配    
这个错误一般出现在时间字段上，即你插入的时间格式和数据库现有的时间格式不一致，
解决的方法是格式化你插入的时间：to_date('2007-12-28 10:07:24' , 'yyyy-mm-dd hh24:mi:ss')
```

## Hibernater概念(杂七杂八)

**Hibernate优缺点**

```reStructuredText
--优点
1.Hibernate支持许多面向对象的特性，如组合、继承、多态等，使开发人员不需要再面向业务领域和面向数据库模型之间来回切换。
2.可移植性好。系统不会绑定在某个特定的关系型数据库上。
--缺点
1.不适合大规模的批量数据处理。
2.不适合以数据为中心大量使用存储过程的应用。
```

```reStructuredText
Hibernate的官方网站  http://hibernate.org
托管网站  https://sourceforge.net/projects/hibernate/files
hibernate-distribution-3.6.10.Final\project\etc  (hibernate.cfg.xml)
hibernate-distribution-3.6.10.Final\project\hibernate-core\src\main\resources\... (dtd文件)(window-prefereces-搜索xml-xml Catalog)
```

刷新缓存机制

```reStructuredText
1.Session是Hibernate持久化操纵的主要接口，它具有一个缓存机制，可以管理和跟踪所有持久化对象。
2.当对象存入Session缓存中时，Session会为对象复制一份“快照”。当对象发生改变时，对象即为“脏对象”。
3.当事务提交时，Hibernate会对Session缓存的对象进行检测(即比较对象当前属性与它的快照是否发生变	   化)，这种检查称为“脏检查”。
4.如果对象发生了变化，Session会根据对象最新的属性值，执行Sql语句
注意：当缓存中对象属性发生变化时，Session并不会立即执行脏检查和相关sql语句，而是在特定时间，刷新缓存时才执行。
刷新缓存：
	1.显式调用Session的flush()方法进行刷新缓存的操作，会触发脏检查，视情况执行sql语句
	2.调用Transaction的commit()方法时，commit()方法会先调用Session的flush()方法
```

**HQL语句**

```reStructuredText
HQL是一种面向对象的查询语言，其中没有表和字段的概念，只有类、对象和属性的概念。
```

**反向工具**

```reStructuredText
1.
右角格子标记---MyEclipse Database Explorer---
打开Open现有连接模板/新建New连接模板----
Driver template： 选择数据库类型
Driver name:  命名
Connection URL:  连接字符串
User name: 用户名
Password: 密码
-------
Display the selected schemas--add-数据库-Finish 结束
2.展开数据库，选中一张表，右键Hibernate Reverse/Broese选择导到哪个包,
   第一个勾表示创建映射信息  （update Hibernate...表示在配置文件中导入路径）
    第二个勾表示创建一个持久化类（Create abstract class 不需要勾）
next 下一步  
id Generator  主键生成策略
next 下一步
如果是导出一张表下面四个勾都不要勾
Finish 完成
```

临时

```reStructuredText
1.currentSession().createSQLQuery("").addEntity("");
2.currentSession().createCriteria
```

# Struts2框架

## ★★两大控制器

### ★核心控制器(web.xml)

```xml
<filter>
      <filter-name>struts2</filter-name>
         <filter-class><!--核心控制器-->
          org.apache.struts2.dispatcher.ng.filter.StrutsPrepareAndExecuteFilter
         </filter-class>
    </filter>			
<filter-mapping>
        <filter-name>struts2</filter-name>
        <url-pattern>/*</url-pattern>
</filter-mapping>
```

### ★业务控制器

**1.struts.xml文件配置**

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE struts PUBLIC
	"-//Apache Software Foundation//DTD Struts Configuration 2.3//EN"
	"http://struts.apache.org/dtds/struts-2.3.dtd">
<struts>  
    <include file=" "></include>   <!-- 拆分引入 -->
    <constant name=" " value=" "></constant> <!-- 设置常量 -->
  
    <!--（常用）注意查看下面的具体描述，***尤其是action元素*** -->
    <package name="default" namespace="/" extends="struts-default">
        <default-action-ref name="error"/> <!--当没有对应的url请求时，作为默认是请求-->
        <global-results><result name="">/a.jsp</result></global-results><!--全局结果-->
       
        <action name="请求的URL名" class="对应的action类的完全限定名" method="调用的方法">
            <result name="success">/helloWorld.jsp</result>
            <result name="input" type="redirect">/login.jsp</result>
        </action>
    </package> 
</struts>
描述：1.packge元素用于定义处理请求的逻辑单元，name属性值必须唯一
	 2.action元素用于将一个请求的URL对应到一个Action类
	 3.result元素设定Action处理结束后下一步做什么，name为逻辑视图名
```

**struts.xml文件配置具体描述**

```xml
<!--------------------constant元素-------------------->
constant 配置常量，可以改变Struts2框架的一些行为
位置：struts2-core-2.3.16.3.jar/org.apache.struts2/default.properties
例：<constant name="struts.i18n.encoding" value="UTF-8"></constant> 
   <constant name="struts.enable.DynamicMethodInvocation" value="true"/>
<!---------------------package元素--------------------->
包的作用:简化维护工作，提高重用性,包可以“继承”已定义的包，并可以添加自己包的配置
name属性为必须的且唯一，用于指定包的名称。
extends属性指定要扩展的包   一般是；struts-default
amespace属性定义该包中action的命名空间，可选。
例：<...namespce="/">    localhost:8080/ssh/a.action
   <namespace="/user">  localhost:8080/ssh/user/a.action
<!---------------------（★★★重点★★★）action元素----------------------->
 作用：封装工作单元、接收请求、返回结果字符串
 <....method="execute">更改属性实现Action中不同方法的调用，默认值:execute
 <重点****：动态方法调用>
打开动态开关:<constant name="struts.enable.DynamicMethodInvocation" value="true"/>
第一种方式：发送请求的时候  url名!方法名  如： actionName!methodName.action
第二种方式：使用通配符*   
<action name="*User" class="" method="{1}"> 
    <result name="success">/page/{1}.jsp</result>  </action>
<重点****返回结果result>   
   常用结果类型：
	dispatcher: 默认结果类型，后台使用RequestDispatcher转发请求
	redirect:后台使用的sendRedirect()将请求重定向至指定的URL(重定向后，属性和参数的值丢失)
	refdirectAction: 主要用于重定向到Action(当一个请求完成时，需要请求到另一个action处理请求)
    子标签 <result><param name=""></param> </result>
    动态结果：根据通过${nextDispose}获取nextDispose属性值选择不同的action
    	<action name="doLogisn"  class=""  method="doLogin">
			<result type="redirectAction">${nextDispose}</result>
		</action>
		<action name="common">
			<result>/page/common.jsp</result>
		</action>
		<action name="manager">
			<result>/page/manager.jsp</result>
		</action>
   <***全局结果***>
       所有action可以共用的结果，如果result和action的result出现同名，那么aciton元素会覆盖全局   result结果，只有在action中无法找到与逻辑视图对应结果时,才会去全局结果中寻找
       <global-results>
			<result name="error">/error.jsp</result>
	   </global-results>
```

**2.创建Action类**

```java
//方式一：实现com.opensymphony.xwork2.Action 接口
public class HelloWorldAction implements Action {
    @Override                                  //返回逻辑视图名
	public String execute() throws Exception { return SUCCESS; }
}

//方式二(推荐)：继承com.opensymphony.xwork2.ActionSupport 类(此类也同时实现了Action接口)
public class LoginAction extends ActionSupport {
   //在执行execute()方法时，会先执行此方法进行数据验证，如果发现错误就会返回“input”  否则继续执行后	  续方法
    @Override
	public void validate() {  
    	if(name.length()==0)
			this.addFieldError("name", "用户名不能为空");//添加错误信息
		if(password.length()==0)
			this.addFieldError("password", "用户密码不能为空");
    }
    
    @Override
	public String execute() throws Exception { }
}
```

```java
/** 注：在Struts2中，就可以直接使用Action类的属性来接收用户的输入，即当表单提交时，Struts2自动对请求参数进行转换，并对具有相同名字的Action属性进行赋值，并且在jsp页面中通过el表达式等可以重新获取值（注意添加get()/set()方法）*/
```

## ★★其他重点

### ★访问SeervletAPI的方式

```java
//解耦的访问方式:不依赖原生的Servlet API,通过ActionContext类获取这个三个Map对象
		Map request=(Map)ActionContext.getContext().get("request");
        Map<String,Object> session = ActionContext.getContext().getSession();
		Map<String,Object> application = ActionContext.getContext().getApplication();
// 与Servlet API耦合的访问方式：ServletActionContext
	    HttpSession session=ServletActionContext.getRequest().getSession();
		HttpServletRequest request = ServletActionContext.getRequest(); 
		ServletContext application =  ServletActionContext.getServletContext();
```

```tex
如何合理选择访问Servelt API方式
	能使用ActionContext就尽量不要使用ServletActionContext
除非需要访问如下对象才使用ServletActionContext
	request.getServletPath()
	request.getPathInfo()
	request.getContextPath() 
	request.getReqeustURI()
```

### ★Struts2标签

**UI标签(表单标签)**

```jsp
<%@taglib prefix="s" uri="/struts-tags" %>   导入Struts2标签库
<s:form>...</s:form>   form表单
<s:textfield> 文本框   <s:password> 密码框  <s:textarea> 多行文本域  <s:hidden> 隐藏域
<s:radio>  单选框   <s:checkbox> 复选框   <s:submit>  提交按钮  <s:rest> 重置按钮
```

例：

```jsp
<!--Action类:  private String[] hobbies; 
如果要指定下标位置，需要action类中实例化hobbies属性-->
jsp页面:    <s:textfield name="hobbies" lable="爱好"/>  
           <s:textfield name="hobbies" lable="爱好"/>

<!--Action类: private List  hobbies;-->
jsp页面:    <s:textfield name="hobbies" lable="爱好"/>
           <s:textfield name="hobbies" lable="爱好"/>
           <s:textfield name="numbers[0]" lable="数字"/>
 	       <s:textfield name="numbers[1]" lable="数字"/>

<!--Action类：private List<User>  users;-->
jsp页面：  <s:textfield name="users.name" lable="姓名"/>
```

**UI标签（输出信息）**

```jsp
<s:property value="message" default="值为空，默认输出"/>   显示属性信息 和 el表达式差不多
<s:fielderror fieldName="password">  //输出addFieldError()里的错误信息，可以不指定fieldName
<s:debug></s:debug> 用于调试，可查看ActionContext中的内容
<s:set name="" value=""/> 用于创建一个URL(字符串常量要加单引号)
<s:date formate="yyyy-MM-dd" name="日期属性" id="表示引用该元素的id值(一般不这么用)"/> 显示时间
<s:url value="url"> <s:param name="parname" value="parvalue"/></s:url>  url地址%{#url}
<!--<s:actionerror/>  显示Action错误
<s:actionmessage/>    显示Action消息-->
暂时附加标签：
    push ： 将值压入值栈顶
```

```xml
对象访问：user.name	user.address.streetName
数组/集合: 属性名[index]  属性名.key   size/length 获取集合长度
创建集合对象：set创建的所有对象都是非值栈对象(非值栈里的东西访问要加#号)
	<s:set name="userList" value="{'Jason','Tom','Marry'}"/>
	<s:property value="#userList[1]"/>
	<s:property value="#userList.size"/>
创建Map:
	<s:set name="map" value="#{'cn':'China','us':'the United States'}"/>
	<s:property value="#map.cn"/>
	<s:property value="#map['cn']"/>
创建作用域：
	<s:set name="age" value="20" scope="request"></s:set>
	<s:set name="username" value="'Jason'" scope="session"></s:set>
	<s:set name="count" value="5" scope="application"></s:set>
显示作用域：
<s:property value="#request.age"/><br>
<s:property value="#session.username"/><br>
<s:property value="#application.count"/><br>
<s:property value="#attr.count"/><br>
```

**通用标签**

```jsp
条件标签：  <s:if test="" >...</s:if>     <s:elseif>...</s:elseif>    <s:else>
迭代标签：  <s:iterator value="" status="" id="" >....</s:iterator>
   id属性： 当前对象(用id的话前面要加#,因为它是非值栈)
   value属性： 需要进行遍历的集合对象
   status属性： 当前迭代元素的IteratorStatus实例（状态信息）			
```

```reStructuredText
status属性:
		getCount 集合对象的总数   isEven()是否为偶数（所在的行号是奇偶行）isFirst()是否为第一个
		isLast() 是否为最后一个  etIndex() 下标
```

### ★拦截器

**定义拦截器类**

```java
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
public class 拦截器类名 extends AbstractInterceptor{
	@Override
	public String intercept(ActionInvocation invocation) throws Exception {
		long startime= System.currentTimeMillis();//示例获取当前时间
        //invoke方法先执行会把所有拦截器执行完,然后执行Action
		String result = invocation.invoke();
		long endTime = System.currentTimeMillis();//示例获取执行后的时间
		System.out.print("耗时："+(endTime-startime));//获耗时
		return result;
	}
}
```

**定义拦截器和引用拦截器**

```xml
<!--关于拦截器定义(要定义在packge标签里)-->
<interceptors>
    <!--定义拦截器-->
    <interceptor name="myTime" class="拦截器类完全限定名"></interceptor>
     <!--定义拦截栈-->
    <interceptor-stack name="myTimerStack">
        <interceptor-ref name="defaultStack"></interceptor-ref> <!--引用默认的拦截器-->
    	<interceptor-ref name="myTime"></interceptor-ref>  <!--引用定义的拦截器-->
    </interceptor-stack>
</interceptors>
   
<!--关于拦截器引用-->
<!--方式1(推荐)：默认引用,只要在相同包里的url请求，都会见效-->
 <default-interceptor-ref name="myTimerStack"></default-interceptor-ref>
 
<action name="index" class="cn.ssh.ch08.IndexAction">
   <result>/index.jsp</result>
   <!--方式2action内引用，可以应用拦截器栈，也可以引用单个拦截器(注意引用自定义拦截器后，默认拦截器就要自己手动引用)--> 
   <interceptor-ref name="myTimerStack"></interceptor-ref> 
 </action>
```

### ★自定义转换器

**1.创建转换类**

```java
/*继承org.apache.struts2.util.StrutsTypeConverter类 实现convertForomString() 和convertToString() 方法*/
public class DateConverter extends StrutsTypeConverter {
	private final DateFormat[] dfs={
			new SimpleDateFormat("yyyy年MM月dd日"),
			new SimpleDateFormat("yyyy-MM-dd"),
			new SimpleDateFormat("MM/dd/yy"),
			new SimpleDateFormat("yyyy.MM.dd"),
			new SimpleDateFormat("yyyyMMdd"),
			new SimpleDateFormat("yyyy/MM/dd")	
	};
	@Override
	public Object convertFromString(Map context, String[] values, 
			Class toType) {
		String dateStr=values[0];
		for(DateFormat df: dfs){
			try {
				return df.parse(dateStr);
			} catch (ParseException e) {				
				continue;
			}
		}
		throw new TypeConversionException();
	}
	@Override
	public String convertToString(Map context, Object object) {
		Date date=(Date)object;
		return new SimpleDateFormat("yyyy-MM-dd").format(date);
	}
}
```

**2.全局应用/局部应用**

```properties
##全局应用:在src目录创建 xwork-conversion.properties(转换类型全名=类型转换器类全名)
	java.util.Date=com.wxq.converter.DateConverter
##局部应用:在对应类的目录中创建一个名为(对应类的类名-conversion.properties)的属性文件
##  (对应类的属性名=类型转换器类全名)
    date=com.wxq.converter.DateConverter
```

**3.向用户输出类型转换错误**

```properties
## 前提条件:1.extends="struts-default"  2.继承ActionSupport类  3.配置input返回 
##	   4.页面使用Struts2表单标签或 <s:fielderror>标签
全局方式：
#在src目录下创建资源文件message.properties并修改键值
xwork.error.action.execution=Error during Action invocation
xwork.exception.missing-action=There is no Action mapped for action name {0}.
xwork.exception.missing-package-action=There is no Action mapped for namespace {0} and action name {1}.
xwork.default.invalid.fieldvalue="{0}"写上输出信息(字段无效)(注意它会转换格式u4E94\u718A).
struts.messages.error.file.too.large=上传报错信息: {0} "{1}" "{2}" {3}
#在struts.xml中指定资源文件的基名
<constant name="struts.custom.i18n.resources" value="message"/>
局部方式(推荐):
	#在要转换类的文件夹中创建(与转换类同名.properties)
	invalid.fieldvalue.类属性 = 协商输出内容
	    
```

### ★文件上传

**jsp页面**

```jsp
<s:form action="upload2.action" enctype="multipart/form-data" method="post">
    <s:file name="upload"></s:file>
    <s:file name="upload"></s:file>
    <s:submit value="上传"></s:submit>
</s:form>
```

**上传类**

```java
public class UploadTest extends ActionSupport {
	//封装上传到服务器的文件对象
    //如果多个文件使用数组upload,uploadContentType,uploadFileName
	private File upload;
	//封装上传文件的类型(此处前面upload与上面对应,后面ContentType为固定)
	private String uploadContentType;
	//封装上传文件名称(此处前面upload与上面对应,后面ContentType为固定)
	private String uploadFileName;
	
	//获取上传文件的保存路径，是应用上下文中的相对路径(此处使用配置文件赋值)
	private String savePath;

    @Override
	public String execute() throws Exception {			
		File destFile = new File (ServletActionContext.getRequest().
                             getRealPath(savePath)+"\\"+this.getUploadFileName());
		FileUtils.copyFile(upload, destFile);
		return "success";
	}
    //省略get()/set()方法
}
```

**配置文件**

```xml
<constant name="struts.multipart.maxSize" value="5000000"/> <!--修改文件总大小的常量-->

<action name="upload" class="cn.ssh.c11.UploadTest">
	<param name="savePath">/upload</param>
	<result name="success">/upload.jsp</result>
	<interceptor-ref name="fileUpload">
	        <param name="maximumSize">512000</param><!--单个文件上传大小限制-->
	        <param name="allowedTypess">image/jpeg,image/gif</param><!--图片类型-->
	</interceptor-ref>
    <!--默认拦截器之所以放后面是因为上面修改了默认的fileUpload拦截器，同名的拦截器出现了两次，只有第一个会被调用所以默认拦截器必须放后面，否则修改无效-->
	<interceptor-ref name="defaultStack"></interceptor-ref>
</action>
```

### **★文件下载**

**action类**

```java
public class DownloadAction extends ActionSupport {
	private String fileName;//下载文件的文件名
	private String inputPath; //读取下载文件的目录
	
	private InputStream inputStream;//读取下载文件的输入流
    
	public String execute(){
		return this.SUCCESS;
	}
    
    //省略其他get()/set()方法
    public InputStream getInputStream() throws FileNotFoundException {
		String path= ServletActionContext.getRequest().
                       getRealPath(inputPath+"\\"+fileName);
		return new BufferedInputStream(new FileInputStream(path));
	}
    附加：	String str = new String(fileName.getBytes("utf-8"),"ISO8859-1");
```

**配置文件**

```xml
<action name="download" class="cn.ssh.c11.DownloadAction">
	<param name="inputPath">/upload</param>
	<result type="stream">
		<param name="contentType">application/octet-stream</param>
		<param name="inputName">inputStream</param>
        							<!--attachment下载时弹出对话框；filename为文件名-->
		<param name="contentDisposition">attachment;filename="${fileName}"</param>
		<param name="bufferSize">4096</param>
	</result>
</action>
```

```reStructuredText
 关键点：结果类型发生的变化
    stream结果类型：将文件数据（通过InputStream获取）直接写入响应流。
	相关参数配置
       contentType     设置发送到浏览器的MIME类型
       contentLength  设置文件的大小
       contentDisposition   设置响应的HTTP头信息中的Content-Disposition参数的值
       inputName   指定Action中提供的inputStream类型的属性名称
       bufferSize   设置读取和下载文件是的缓冲区大小

  contentType对应的文件类型(文件下载类型MIME)
  Word   application/msword
  Excel    application/vnd.ms-excel
  PPT      application/vnd.ms-powerpoint
  图片     image/gif、image/bmp、image/jpeg
  文件文本  text/plain
  HTML网页  text/html
  任意的二进制数据(推荐 )   application/octet-stream
```

**jsp页面**

```jsp
 <a href="download.action?fileName=Koala.jpg">下载</a>
```

## Struts2概念(杂七杂八)

**Struts2的优势**

```reStructuredText
   1.实现MVC模式，层次结构清晰，使开发者专注业务逻辑实现
   2.丰富的标签库提高开发效率
   3.基于AOP思想的拦截器机制降低业务间的耦合度   
   4.通过配置文件即可掌握系统间各部分间的关系
   5.更方便的异常处理机制
   6.高可扩展性
官网： http://struts.apache.org
```

**Action接口中常量字符串的逻辑含义**

```reStructuredText
SUCCESS  对应值  success    表示程序处理正常
NONE     对应值  none 		 表示处理正常结束，但不返回用户任何显示
ERROR    对应值  error      报错
INPUT    对应值  input      表示输入不完整，需要继续输入
LOGIN    对应值  login      表示需要用户输入正确后才能顺利执行
```

**OGNL**

```reStructuredText
1.OGNL主要作用，用于数据流入和流出传递的过程，以及数据传递过程时的类型转换。
2.框架在处理每个请求时，都会创建该请求对应的运行环境，并将请求对应的Action对象放入其中(值栈)。
3.OGNL的作用就是将数据映射到值栈中，以及处理数据类型转换。
4.值栈就是框架创建的一个存储区域，用来保存Model对象。它具有栈的特征，可以存放多个对象，如果存放
  多个对象，它们是按照先后顺序压入值栈的。
```

**Struts2架构分析**

```xml
  1.客户端发出请求会经过核心过滤器(FilterDispatcher)，过滤器调用ActionMapper对象然后获得带有 Action详细信息的ActionMapper对象回来。
  2.接下来过滤器将控制权委派给ActionProxy,AcitonProxy会创建一个代理类ActionInvocation对象，它在调用Action之前会依次调用所有配置的拦截器。
  3.当Action执行返回字符串，ActionInvocation负责查找结果字符串对应的Result,然后执行这个Result。
  <!----涉及的对象
  ActionMapper 根据请求的URI查找是否存在对应Action调用
  ActionMapping  保存调用Action的映射信息，如namespace、name等
  ActionProxy  在XWork和真正的Action之间充当代理
  ActionInvocation 表示Action的执行状态，保存拦截器、Action实例
  Interceptor   在请求处理之前或者之后执行的Struts组件-->
```

**拦截器**

```reStructuredText
1.Struts 2将核心功能放在多个拦截器中实现，拦截器可自由选择和组合，增强了灵活性，有利于系统的解耦
拦截器方法在Action执行之前和之后执行。
2.拦截器栈相当于多个拦截器的组合
3.在拦截器方法内部调用了下一个拦截器
---------------拦截器三个阶段执行周期：
	1.做一些Action执行前的预处理
	2.将控制交给后续拦截器或返回结果字符串
	3.做一些Action执行后的处理
---------------内置拦截器：
params拦截器：负责将请求参数设置为Action属性
servletConfig拦截器：将源于Servlet API的各种对象注入到Action
fileUpload拦截器：对文件上传提供支持
exception拦截器：捕获异常，并且将异常映射到用户自定义的错误页面
validation拦截器：调用验证框架进行数据验证
workflow拦截器：调用Action类的validate() ，执行数据验证
----------------关于定义拦截器类：
   需要实现Interceptor接口
   void init()  初始化拦截器所需资源
   void destroy() 释放在init()中分配的资源
   String  intercept(ActionInvocation ai)
   推荐继承AbstractInterceptor类，它对 init()和destroy()提供了空实现，我们只需要实现intercept方法即可。
```

附加

```text
1.jsp发送请求
2.web.xml 拦截请求
3.struts.xml  通过请求寻找到对应的Action类
4.通过Action获取数据处理请求，在通过struts.xml返回信息给jsp
```

# SSH整合

## **Spring和Hibernate整合**

### **★applicationContext.xml**

**配置数据源**

```xml
<!--***********第一种方法：引用原来Struts2的配置文件****************** -->
<bean id="sessionFactory"  class="org.springframework.orm.hibernate3.LocalSessionFactoryBean">
		<property name="configLocation">
			<value>
			     classpath:hibernate.cfg.xml
			</value>
		</property>
</bean>

<!--**********第二种方法(推荐)：在applicationContext.xml中配置Struts2的配置文件**********-->
  <!--定义dbcp数据源-->			<!--配置c3P0 ComboPooledDatasource-->
<bean id="dataSource" class="org.apache.commons.dbcp.BasicDataSource">	
	 <property name="driverClassName" 
               value="oracle.jdbc.driver.OracleDriver">	</property>
	<property name="url" value="jdbc:oracle:thin:@127.0.0.1:1521:xe"></property>
	<property name="username" value="scott"></property>
	<property name="password" value="tiger"></property>
</bean>
  <!--配置sessionFactory-->
<bean id="sessionFactory" 	    class="org.springframework.orm.hibernate3.LocalSessionFactoryBean">
    <!-- 引用数据源  -->
	<property name="dataSource" ref="dataSource"></property>
	<!-- 添加Hibernate配置参数 -->
	<property name="hibernateProperties">
		<props>
			<prop key="hibernate.dialect">
                    org.hibernate.dialect.Oracle10gDialect</prop>
			<prop key="show_sql">true</prop>
			<prop key="format_sql">true</prop>
			<prop key="javax.persistence.validation.mode">none</prop>
		</props>
	</property>
  <!-- 添加对象关系映射文件 -->
<property name="mappingResources">  <!--第一种-->
	<list>
		<value>cn/houserent/entity/HouseUser.hbm.xml</value>
	</list>
</property>
  <!--实际开发中，对象关系映射文件可以能会非常多，为了减少配置文件代码，可以使用
		mappingDirectoryLocations属性指定映射文件躲在的目录，简化映射文件的配置-->
<property name="mappingDirectoryLocations">  <!--第二种-->
	<list>
		<value>classpath:cn/houserent/entity</value>
	</list>
</property>
</bean>
```

**配置声明式事务**

```xml
<!-- 定义事务管理器 -->
<bean id="txManager" 
	class="org.springframework.orm.hibernate3.HibernateTransactionManager">
	<property name="sessionFactory" ref="sessionFactory"/>
</bean>
<!--定义事务属性，声明事务规则 -->	
<tx:advice id="txAdvice" transaction-manager="txManager">
	<tx:attributes>
		<tx:method name="find*" read-only="true"/>
		<tx:method name="add*" read-only="false" propagation="REQUIRED"/>
		<tx:method name="*" read-only="true"/>			
	</tx:attributes>
</tx:advice>
<!-- 定义切面 -->
<aop:config>
	<aop:pointcut id="serviceMethod"  expression=
                "execution(* cn.houserent.service..*.*(..))"/>
	<aop:advisor advice-ref="txAdvice" pointcut-ref="serviceMethod"/>	
</aop:config>
```

**头信息**

```xml
<beans xmlns="http://www.springframework.org/schema/beans"
	xmlns:aop="http://www.springframework.org/schema/aop" 
	xmlns:context="http://www.springframework.org/schema/context"
	xmlns:tx="http://www.springframework.org/schema/tx" 
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://www.springframework.org/schema/beans 
	http://www.springframework.org/schema/beans/spring-beans-3.2.xsd 
	http://www.springframework.org/schema/aop 
	http://www.springframework.org/schema/aop/spring-aop-3.2.xsd 
	http://www.springframework.org/schema/context 
	http://www.springframework.org/schema/context/spring-context-3.2.xsd 
	http://www.springframework.org/schema/tx 
	http://www.springframework.org/schema/tx/spring-tx-3.2.xsd ">
    
</beans>
```

### **★HibernateTemplate**

```java
//Spring提供的模板类HibernateTemplate可以简化编码，省略大量流程化的代码
public class UserDaoImpl extends HibernateDaoSupport implements UserDao {
	//例子：
    public void save(User user){
        this.getHibernateTemplate().save(user);
    }    	
}

//HibernateTemplate类中提供了 setSessionFactory()方法，当注入SessionFactory Bean时，会自动创·建HibernateTemplate实例。这样就可以通过该类提供的getHibernateTemplate()方法直接获取该实例使用，无需额外声明HibernateTemplate或SessionFactory类型的属性。
//例：在Spring配置文件中
<bean id="userDao" class="cn.houserent.dao.UserDaoImpl">
	<property name="sessionFactory" ref="sessionFactory"> </property>
</bean>
```

**HibernateTemplate常用的方法**

|                          **方法**                          |                       **功能**                        |
| :--------------------------------------------------------: | :---------------------------------------------------: |
|              List  find(String  queryString)               |            根据HQL查询字符串来返回实例集合            |
|      List   find(String queryString,Object...values)       |     查询HQL，并将占位符“？”绑定到给定的参数Object     |
| List  findByValueBean(String queryString,Object valueBean) |    查询HQL，将命名参数绑定到给定的valueBean属性值     |
|             Serializable  save(Object  entity)             |                     保存新的实例                      |
|                void   update(Object entity)                |             根据给定的持久化对象更新记录              |
|               void    delete(Object entity)                |                 删除指定的持久化实例                  |
|           void   deleteAll(Collection  entities)           |               删除集合内全部持久化实例                |
|     Object    get(class  entityClass,Serializable  id)     |            根据主键加载特定持久化类的实例             |
|     Objec t  load(class  entityName,Serializable  id)      | 延迟加载实例，调用Hibernate Session 对象的load()方法  |
|               Object   merge(Object  entity)               | 将给定的entity按OID复制到持久化对象中并返回持久化对象 |
|            void   saveOrUpdate(Object  entity)             |            根据实例状态，选择保存或者更新             |
|           void   setMaxResults(int  maxResults)            |                 设置结果集的最大行数                  |

**使用HibernateCallback实现自定义功能**

```java
/*虽然HibernateTemplate针对Hibernate Session提供大量封装好的方法，但也失去了直接使用Hibernate Session的灵活性,在实现一些特殊功能的时候HibernateTemplate可能就无法解决了(如：分页)，为了解决这个问题，Spring提供了HibernateCallback接口，而HibernateTemplate则提供了一些方法和该接口配合。*/
public List<House> findUsers(final int page, final int size) {
		return this.getHibernateTemplate().execute(
            new HibernateCallback<List<House>>(){
			@Override
			public List<HouseUser> doInHibernate(Session session)
					throws HibernateException, SQLException {
				Query query =session.createQuery("from HouseUser");
				query.setFirstResult((page-1)*size);
				query.setMaxResults(size);
				return query.list();
			}
		}
        );
	}
//1.方法中的局部变量传递给内部类使用时，必须把变量声明为final
//2.HibernateCallback接口中声明doInHibernate()方法，该方法以Hibernate Session为参数，在该方法实现中，就可以通过入参得到原始的Hibernate Session,从而实现自定义的操作
//3.HibernateTemplate的execute()方法要求提供一个HibernateCallback接口的实例作为参数，该方法执行时会调用该实例的doInHibernate()方法，并为该方法传入原始的Hibernate Session对象
```



## Spring和Struts2整合

### **★web.xml**

```xml
<!-- 指定Spring配置文件 -->
 <context-param>
  	<param-name>contextConfigLocation</param-name>
  	<param-value>classpath:applicationContext.xml</param-value>
 </context-param>
<!-- 配置监听器启动Spring -->
<listener>
  	  <listener-class>
        org.springframework.web.context.ContextLoaderListener
      </listener-class>
</listener>
<listener>
  	<listener-class>
        org.springframework.web.context.request.RequestContextListener
    </listener-class>
  </listener>

<!-- ***可以解决延迟加载的问题(要配置在Struts2拦截器前面) ****-->
  <filter>
  	  <filter-name>OpenSessionInViewFilter</filter-name>
  	  <filter-class>
          org.springframework.orm.hibernate3.support.OpenSessionInViewFilter
      </filter-class>
<!--<init-param>  如果spring配置文件配置的名不是sessionFactory,那么就要添加这个具体指定。
  		<param-name>sessionFactoryBeanName</param-name>
  		<param-value>具体名</param-value>
  	</init-param> -->
  </filter>
  <filter-mapping>
  	   <filter-name>OpenSessionInViewFilter</filter-name>
  	   <url-pattern>*.action</url-pattern>
  </filter-mapping>

<!-- ***sturts2拦截器*** -->
<filter>
  	<filter-name>Struts2</filter-name>
  		<filter-class>
       		 org.apache.struts2.dispatcher.ng.filter.StrutsPrepareAndExecuteFilter
     	</filter-class>
</filter>
<filter-mapping>
  	<filter-name>Struts2</filter-name>
  	<url-pattern>/*</url-pattern>
</filter-mapping>
```

```reStructuredText
由于不需要在Spring中配置Action，当Struts2创建好Action的实例后，如何为其注入业务Bean呢？
Struts2提供的整合插件使用了Spring的自动装配机制。它默认情况下会使用按名称匹配的方式为Action自动
注入业务Bean。（Action业务类属性的setter方法和sprng配置文件中所需业务Bean名一定要匹配）
附加：通过struts.xml中配置struts.objecFactory.spring.autoWire常量，可以改变插件的自动装配策略
如：<constant name="struts.objectFactory.spring.autoWire" value="type"/>
```

**不自动注入方式**

```xml
有时候自动注入方式显得灵活性不足，无法满足需求。为了解决种类问题，可以把Action像业务类和DAO一样声明在Spring的配置文件中，这样就可以更加灵活地配置Action了,但代价是在Spring配置文件中需要定义很多
Aciton Bean的id,如非必须，应优先考虑自动注入方式

<!-- 在Spring配置文件中配置Action Bean，注意 scope="prototype"属性 -->
<bean id="userAction" class="cn.houserent.action.UserAction" scope="prototype">
    <property name="userBiz" ref="userBiz"/>
</bean>

<!--在struts.xml中配置Action-->
<!--class属性的值不再是Action类的全限定名，而是Spring配置文件中相应的Action Beand名称-->
<action name="user" class="userAction">
    <result name="success">success.jsp</result>
</action>
```

```xml
spring配置action时，如prototype作用域采用默认的singleton会有线程安全问题，所以要改成prototype。
对于Web环境下的应用，还可以使用request、session、globalSession这三种作用域
<!--指定Bean的作用域为request,对于每次请求都创建一个新的实例，避免受到上一次请求状态的影响，Struts2的Action也可以采用该作用域-->
<bean id="xxx" class="Xxx" scope="request"/>
<!--指定Bean的作用域为session，在会话范围内共享Bean的实例，实现有状态的操作-->
<bean id="xxx" class="Xxx" scope="session"/>
<!--指定Bean的作用域为globalSession-->
<bean id="xxx" class="Xxx" scope="globalSession"/>
注意：在使用Web环境下的作用域时，还要在web.xml文件中配置一个请求监听器
<listener>
    <listener-class>
        	org.springframework.web.context.request.RequestContextListener
    </listener-class>
</listener>
```

## 使用注解方式实现SSH集成

**使用Hibernate注解代替映射文件**

```xml
使用Hibernate注解后，在配置SessionFactory的对象关系映射时不再需要XML配置文件，同时由AnnotationSessionFactoryBean的packagesToScan属性替代mappingResources
<bean id="sessionFactory"  class="org.springframework.orm.hibernate3.annotation.AnnotationSessionFactoryBean">
		            <!--省略前面参数、数据源等-->
    <!--加载由注解定义的持久化类-->
    <!--通过packagesToScan属性，可以添加某个包下的所有带注解的持久化类-->
    <!--多个包路径，用英文逗号隔开即可-->
    <property name="packagesToScan" value="cn.houserent.entity"/>
</bean>
```

**spring标注注解**

```xml
<!--在applicationContext中使用注解扫描-->
<context:component-scan base-package="cn.houserent"/>

<!--dao层注解-->
@Repository("houseDao")
public class HouseDaoImpl extends HibernateDaoSupport implements HouseDao {
	public HouseDaoImpl(){}  //保留无参构造方法
	@Autowired//使用注解构造注入
	public HouseDaoImpl(@Qualifier("sessionFactory")SessionFactory sessionFactory){
		this.setSessionFactory(sessionFactory);
	} 	
}
<!--Service层注解-->
@Service("houseBiz")
public class HouseBizImpl implements HouseBiz{
	@Autowired
	@Qualifier("houseDao")
	private HouseDao houseDao;
	//省略getter、setter
}
<!--控制层注解-->
<!--如果是Struts2自己创建Action，那么没有使用Sring注解的必要-->
<!--如果Action由Spring来创建管理，则可以使用注解-->
@Controller("userAction")
public class  UserAction  extends ActionSupport{
	@Autowired
	@Qualifier("houseBiz")
	private HouseBiz houseBiz;
}
```

**注解实现声明式事务**

```xml
<!--注意：事务管理器(txManager)还是需要手动在application中配置-->
<!--在applicationContext启动对事务注解的扫描-->
<tx:annotation-driven transaction-manage="txManager">
<!--需要再哪个类或方法中添加事务在上面标注此注解就可以了,具体属性参见SSM笔记-->
@Transactional()
```