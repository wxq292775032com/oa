# MyBatis框架

### ★核心配置文件

​                                                                                      `注意：元素节点是有顺序的`

**引用配置文件（数据源）**

```xml
<!-- 第一种方式：引用引入database.properties文件 --> 
<properties resource="database.properties"/>  
<!-- 第二种方式：引用引入database.properties文件 --> 
<properties>			        
        <property name="driver" value="com.mysql.jdbc.Driver"/>       
        <property name="url" value="jdbc:mysql://location:3306/smbms"/>
        <property name="username" value="root"/>
        <property name="password" value="root"/>
 </properties>
```

**设置和改变MyBatis运行中的行为**

```xml
<settings>
          <setting name="logImpl" value="LOG4J"/>
    <!-- 是否自动映射属性  --> 
          <setting name="autoMappingBehavior" value="NONE"/>   
</settings>
```

**关于别名**

```xml
<typeAliases>
    		第一种方式：单个设置别名
           <typeAlias alias="user" type="cn.smbms.pojo.User"/>   
    	   （推荐)第二种方式：自动扫描指定包下的JavaBean    
           <package name="cn.smbms.pojo"/>               
</typeAliases>
```

**运行环境**

```xml
<environments default="development">               <!-- 默认运行环境 --> 
	<environment id="development">                 <!-- 可以配置多套id名不能一样 --> 
		<transactionManager type="JDBC"></transactionManager>
	    	<dataSource type="POOLED">  <!--POOLED自带数据源，JNDI基于tomact数据源-->
	        	<property name="driver" value="${driver}"/>    <!--引用数据源 --> 
           		<property name="url" value="${url}"/>
           	    <property name="username" value="${user}"/>
           		<property name="password" value="${password}"/>
            </dataSource>
   </environment>
</environments>
```

**引用Mapper.xml配置文件**

```xml
<mappers>
    <mapper resource="cn/smbms/dao/user/UserMapper.xml"/>
</mappers>
```

------

### ★核心接口和类

```java
InputStream is = Resources.getResourceAsStream("mybatis-config.xml");
//获取SqlSessionFactory对象
SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is)
//获取SqlSession对象
SqlSession session = factory.openSession(false);  //true关闭事务控制（默认）
//执行
session.selectList(“cn.smbms.dao.user.UserMapper.id名”);
session.getMapper(UserMapper.class).getUserList();//推荐
//关闭（很重要必须执行）
session.close();
```

------

### **★Mapper文件sql操作**

**select查询**

```xml
				                               <!--自定义映射结果/普通返回值--> 
<select id="与接口的方法名一致" parameterType="入参类型" resultMap/resultType >  </select>                     
```

$$
描述：
		基础类型:string int double arrayList boolean List byte date hashmap
        		long  integer  float  map                                                         复杂类型(多参): 实体类 Map(通过key获值)
        	    超过四个以上的参数，最好封装成对入参
        获值方式：  ${}
$$

**resultMap(自定义映射结果)**

```xml
<resultMap id="" type="结果类型(通常是java实例类)">
    <!--普通映射--> 
    <id property="类普通属性" column="数据库字段"/>  
    <result property="类普通属性" column="数据库字段"/>
    <!-- 高级映射 -->    
    	<!--第一种User一对一关系-->
    <association property="类实体对象属性" javaType="javaBean类型" resultMap="外部引用">
	    <id property="类普通属性" column="数据库字段"/>  
      	<result property="类普通属性" column="数据库字段"/>
    </association>
        <!--第二种 List<User>一对多关系   List<List<User>>-->       
    <collection property="类实体对象属性" ofType="javaBean类型" resultMap="外部引用">
      	<id property="类普通属性" column="数据库字段"/>  
      	<result property="类普通属性" column="数据库字段"/>
    </collection> 
</resultMap>
```

**Insert update  delete  （增删改）**

```xml
<update/delete/insert id="" parameterType="入参"> ${}获值</update>
 <!-- 注意：增删改都只返回影响行数，所以没有返回值 -->
 <!-- 增加的同时返回新的主键 -->
1.useGeneratedKeys="true"  eyProperty="id" keyColumn="id"
2.<selectKey keyProperty="id" order="AFTER" resultType="java.lang.Integer">
            select LAST_INSERT_ID()
        </selectKey>
```

**注解**

```reStructuredText
@Param("")   注解
在接口中使用可以实现多参数入参,使用注解映射文件中不需要写入参类型。(单参时也推荐使用注解)
例子：int updatePwd(@Param(“id”)Integer id,@Param(“name”)){}
```

------------------------------------------------------------------------------------------------------------------------------------------------

**动态Sql**

```xml
1. <!-- 条件判断 -->
<if test=""> </if>

2. <!-- 若有返回值就插入where  test，以及智能处理 and 和 or -->
<where> </where>

3.<!-- 只能忽略和添加 -->
<trim prefix="where" prefixOverrides="and|or" suffixOverrides =",">
<trim prefix="set" suffixOverrides="," suffix="where id = #{id}" >
 prefix 前缀
 suffix 后缀
 prefixOverrides 首部忽略指定内容
 suffixOverrides 尾部忽略指定内容
    
4.<!-- 动态配置set关键字，可剔除追加到末尾的任何不相关的逗号 -->
<set> </set>

5.<!--迭代一个集合，通常用于in条件-->
<foreach collection="array/list/map(用key值)" item="a" 
         open="(" separator="," close=")" index="下标名">
      #{a}            
</foreach>

6.<!--和JSTL元素作用一样，作用如switch-->
  	<choose>
    	<when test="">
        </when>
        <otherwise>
        </otherwise>
    </choose>
```

### 配置文件的头信息

  **myBatis-config.xml核心配置文件的头信息**

```xml
 	<?xml version="1.0" encoding="UTF-8"?>
	<!DOCTYPE configuration
	 PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
	 "http://mybatis.org/dtd/mybatis-3-config.dtd">
    <configuration>     <!-- 根节点 -->
		--内容
	</configuration>
```

  **Mapper配置文件的头信息**

```xml
 <?xml version="1.0" encoding="UTF-8"?>
 <!DOCTYPE mapper
  PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
  "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
  <!-- 根节点以及命名空间，要和响应接口一致 -->
  <mapper namespace="cn.smbms.dao.user.UserMapper">    
		--内容
  </mapper>
```

### 框架概念介绍

**框架介绍**

```reStructuredText
框架优势：
	1.不用考虑公共问题，框架已经帮我们做好了。
	2.可以专心于业务逻辑，保证核心业务逻辑的开发质量。
	3.结构统一，便于学习和维护。
	4.构架集成了前人的经验，可以帮助新手写出稳定，性能优良结构优美的高质量程序。
框架技术：
	1.是一个应用程序的办成品。
	2.提供可重用的公共结构。
	3.按一定规则组织的一组组件。
```

**主流框架**

```reStructuredText
Struts2:      
		1.mvc设计模式的实现
		2.基于拦截器
		3.可变和重用的标签
	    4.在做web层做应用开发时使用
Hibernate:
		1.持久化框架，在DAO层替代JDBC繁琐的程序代码。
		2.对象和数据库之间建立一个映射关系（ORM）
Spring:
		1.开源的轻量级
		2.IOC依赖注入容器/AOP实现
		3.声明式事物
		4.简化java应用
		5.它是一个粘合剂，可以将大家组装在一起，由它统一管理
SpringMVC:
		1.Spring框架在web层的控制的实现，和Struts2是一样可以替代Struts2框架
		2.结构最清晰的MVC Model2实现
		3.高度可配置，支持多种视图技术
		4.定制化开发
MyBatis:
		1.半自动化的ORM实现（sql语句和数据库建立一个映射）
		2.DAO层
		3.动态SQL
		4.小巧灵活，封装性没那么强性能有优势	
```

**持久化+ORM**

```reStructuredText
持久化概念:
	持久化是程序数据在瞬时状态和持久状态转换的过程，数据持久化是将内存中的数据
	模型转换的过程，数据持久化是将内存中的数据模型转换为存储模型，以及将存储模型
	转换为内存中数据模型的统称。   存储模型(关系模型，xml,二进制流等)
ORM:
	  ORM即对象/关系映射，是一种数据持久化技术，ORM就是在对象模型和关系数据库的表之间建立了一座桥梁。
   原因:
	   1.编写程序的时候，以面向对象的方式处理数据
	   2.保存数据的时候，却以数据库的方式存储
   ORM的解决:
		1.在持久化对象上执行基本的增、删、改、查等
		2.对持久化对象提供一种查询语言或者API对象关系映射工具
		3.提供与事物对象交互，执行检查，延迟加载以及其他优化功能
```

### **MyBatis概念（杂七杂八）**

**MyBatis简介**

```reStructuredText
简略：
	https://github.com/mybatis   公共的代码托管的网站
	MyBatis是一个ORM框架
	实体类和Sql语句之间建立映射关系
特点：
	简单易学
	封装性不是很强，能了解底层封装过程
	SQL语句封装在配置文件中，便于统一管理和维护
	降低程序的耦合度
	方便程序代码调试
优点：
	与JDBC相比，减少了50%以上的代码量
	小巧并简单易学
	SQL代码从程序代码中彻底分离，可重用。
	提供XML标签，支持编写动态SQL
	提供映射标签，支持对象与数据库的ORM字段关系映射
缺点：
	SQL语句编写工作量大，对开发人员有一定要求，数据库移值性差。
```

**核心类和接口描述**

```reStructuredText
SqlSessionFactoryBuilder:
		1. 用来创建SqlsessionFactory对象，特点→用过即丢。
		2. build()方法读取方式有两种： 读取 XML配置文件方式(字节流/字符流)和编程构造方式。
SqlsessionFactory：
		1. 用来创建SqlSession实例的工厂，通过openSession()方法来获取SqlSession实例。
		2. 一旦创建就会在整个应用运行过程中始终存在没有理由销毁，所以最佳作用域是application。
SqlSession:	
		1. 用于执行持久化操作的对象，类似于JDBC中的connection。
		2. 对应一次数据库会话，会话结束必须关闭。
		3. 每个线程都有自己的Sqlsession实例，Sqlsession实例不能被共享，也不是线程安全的，最佳作用		   域是request作用域。
selectOne   selectList   selectMap  select  insert update  delete  
commit()   rollback  close()
		
```

**MyBatis-config.xml文件结构**

```reStructuredText
configuration 配置
	properties   可以配置在Java属性配置文件中
	settings     修改MyBatis在运行时的运行方式
	typeAliases  为Java类型命名一个别名（简称）
	typeHandlers  类型处理器
	objectFactory   对象工厂
	plugins		插件
	environments  环境
		environment  环境变量
			transactionManager  事物管理器
			dataSource  数据源
	mappers  映射器
```

**引入dtd文件**

```reStructuredText
点击MyBatis.jar文件-  org/apache/ibatis/builder/xml
复制PUBLIC 双击引号里面的，点击Myeclipse 中的windows-属性-xml-选中xmlcatalog-User
Specified  Entries-add.location 引入 dtd文件位置，将复制的东西粘贴到key中-确定
可以获得提示
```

**关于缓存**

```xml
MyBatis缓存
	一级缓存   session 作用域
	二级缓存   全局缓存
二级缓存的配置
	MyBatis的 cache配置
<settings>
	<setting name="cacheEnabled" value="true"/>
</settings>
在MapperXML文件中设置缓存，默认情况下：未开启
<cache eviction="FIFO" flushInterval="60000" size="512" readOnly="true"/>
在MapperXML文件配置支持cache后，若需要对个别查询进行调整，可以单独设置cache
<select id="selectAll" resultType="Emp" UseCache="true">
</select>
```

# **Spring框架**

### **★IOC控制反转/依赖注入**

**设值注入+构造注入**

```xml
<bean id="" class="指定类中的完全限定名">
    <!--设值注入-->
	<property name="属性名" value/ref="值/对象"/>
    
    <!--构造注入，（一个constructor-arg元素表示构造方法的一个参数） -->
    <constructor-arg index="参数位置(从0开始)" type="参数类型">
        <ref bean="对象id"/>    <!--对象赋值-->
        <value>123</value>     <!--普通赋值-->
    </constructor-arg>
</bean>
```

**p命名空间注入方式**

```xml
 <!-- p命名空间的特点是使用属性而不是子元素的形式配置Bean的属性 （注意添加相关的头信息）-->
 <!--  p:属性名="值" -->
 <!--  P:dao-ref="对象id" -->
<bean id="user" class="entity.User"  p:age="123"  p:dao-ref=""/>
```

**注入不同数据类型**

```xml
<bean id="" class="指定类中的完全限定名">
    
    <!-- 为对象属性赋值除了ref属性，还有的新的两种方式-->
    <!-- local属性和bean属性用法一样，区别在于Spring文件是可以拆分多个的，使用local属性只能在同一
		配置文件中检索Beand的id,而bean属性可以在其他配置文件中检索id-->
    <property name="对象属性名">
    	<ref bean="对象id"/>
        <ref local="对象id"/>
    </property>
    
    <!--为    集合（list）和    数组（array）  以及   set   注入值-->
    <!-- list/set 标签中可以使用<value> <ref> 或者在放一个<list>标签 -->
    <property name="属性名">
    	<list>    <!-- <set>-->         
            <value>值1</value>
            <value>值2</value>
        </list>   <!-- </set>-->         
    </property>
    
    <!-- 为map键值对赋值 -->
    <!-- Map中的键或值是Bean对象，可以把<value> 换成 <ref> -->
    <property name="属性名">
    	<entry>
            <key><value>键名</value></key>
            	 <value>值名</value>
        </entry>
    </property>
    
    <!-- 为propertys类型赋值 -->
    <property name="属性名">
        <props>
            <prop key="a">a值</prop>
            <prop key="b">b值</prop>
        </props>
    </property>
    
    <!-- 注入空字符串，以及注入null值 -->
      <property name="属性名">
        <props>
            <value></value>   --注入空字符串
            <null/>           --注入空字符串
        </props>
    </property>
</bean>
```

**注解实现IOC**

```java
//注解定义Bean
@component("定义名")  //通用注解  
@Repository("定义名") //用于标注DAO类
@Service("定义名")    //用于标注业务类
@Controller("定义名") //用于标注控制器类
//位置：属性上面  set方法上面  构造方法注入@Qualifier要放在参数前面
//注： Autowired(required=false) 没找到bean不报异常

//注解实现组件装配
1.
  @Autowired 默认按类型匹配
  @Qualifier("指定Bean名称")
2.
  //指定名称，如不指定名称默认按名称（属性名/set后名）匹配，如找不到则按类型查找
  @Resource(name="")
```

```xml
<!--配置文件 自动扫描-->
<context:component-scan base-package="service,dao">
</context:component-scan>
```

### **★AOP面向切面编程**

**配置方式**

```xml
<!-- 声明增强处理类的bean元素 -->
<bean id="theLogger" class="aop.ErrorLogger"></bean>
<aop:config>
	<!-- 定义一个切入点表达式，并命名为“pointcut” -->
    <aop:pointcut id="pointcut"	expression="execution(表达式)"/>	
    <!-- 引用包含增强的Bean -->
    <aop:aspect ref="theLogger">
        <!-- (前置增强)，→引入前置增强的方法和切入点 -->
    	<aop:before method="befor" pointcut-ref="pointcut"/>
       
        <!-- (后置增强)，→引入后置增强的方法和切入点，注入目标方法的返回值result -->
    	<aop:after-returning method="afterReturning" pointcut-ref="pointcut" 	                returning="result"/>
      
        <!-- (异常增强),→引入异常增强的方法和切入点，通过throwing属性为参数e注入异常实例。
			目标方法发生异常时触发（织入增强）-->
        <aop:after-throwing method="afterThrowing" pointcut-ref="pointcut" 
         throwing="e"/>
        
        <!-- (最终增强)，→引入最终增强的方法和切入点。类似于finaly块一般用于释放资源 -->
        <aop:after method="after" pointcut-ref="pointcut"/>
        
        <!-- (环绕增强)，→引入环绕增强的方法和切入点。相当于增强的集合可获取或修改目标方法
 			的参数、返回值，可对它进行异常处理，甚至可以决定目标方法是否执行-->
        <aop:around method="aroundLogger" pointcut-ref="pointcut"/>
    </aop:aspect>   
</aop:config>
```

**切入点表达式**

```java
public * addNewUser(entity.user)  任何返回值
public void * (entity.user)  匹配所有方法
public void addNewUser(..)  任意/所有参数
* com.service.*.*(..)  该包下所有类所有方法
* com.service..*.*(..) 及其子包下所有类，所有方法
```

**增强方法参数**

```java
JpinPoint  
		getTarget()   //被代理的目标对象
		getSignature().getName()  //被代理的目标方法
		getArgs()	 //目标方法的参数数组
ProceedingJoinPoint 
		//加上上面三个方法
		proceed()  //执行目标方法
```

**注解实现AOP**

```java
定义增强处理类：  @Aspect
前置增强：  @Before("execution(表达式)")
后置增强：  @AfterReturning(pointcut="execution(表达式)",returnning="result")
异常增强：  @AfterThrowing(pointcut="execution(表达式)",throwing="e")
最终增强：  @After("execution(表达式)")
环绕增强：  @Around("execution(表达式)")
    
附加：  @pointcut("execution(*service.userService.*(..))")
    	public void pointcut(){}
       //调用此方法就可以直接获得表达式
```

```xml
<bean class="增强处理类"></bean>
<!--启动对Spring AOP的Aspectj注解的支持-->
<aop:aspectj-autoproxy/>
```

### ★实例化Spring上下文

```java
ApplicationContext ctx = new ClassPathXmlApplicationContext("ApplicationContext.xml");
UserService userService = (UserService)ctx.getBean("userService");
```

### 配置文件头信息

**基本头信息（IOC头信息）**

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
     xsi:schemaLocation="http://www.springframework.org/schema/beans
         http://www.springframework.org/schema/beans/spring-beans.xsd">
```

**AOP要添加的头信息**

```xml
     xmlns:aop="http://www.springframework.org/schema/aop"
         http://www.springframework.org/schema/aop
         http://www.springframework.org/schema/aop/spring-aop-3.2.xsd
```

**p命名空间要添加的头信息**

```xml
xmlns:p="http://www.springframework.org/schema/p"
```

**context扫描注解的头信息**

```xml
xmlns:context="http://www.springframework.org/schema/context"
http://www.springframework.org/schema/context
http://www.springframework.org/schema/context/spring-context-3.2.xsd
```

### Spring概念（杂七杂八）

**简述**

```text
1.轻量级框架
2.Spring贯穿表现层，业务层，持久层，是一站式的企业应用开发框架。
3.Spring是面向Bean编程
4.核心技术：
	1.IOC容器    控制反转/依赖注入
	2.AOP实现    面向切面编程
	3.支持JDBC/ORM框架和web集成
```

**控制反转概念**

```reStructuredText
控制反转：就是将对象的控制权，从本身转移到IOC容器这样的过程。
目的：分离关注点，不关注实现；降低程序代码之间的耦合度，方便程序的扩展。

工厂模式：
		1.产品规范	  一个接口规范
		2.产品		接口的不同实现
		3.工厂		工厂类通过标识返回不同产品
		4.客户端/调用
```

**面向切面编程概念**

```reStructuredText
在什么位置执行什么功能？
1.AOP的目的是从系统中分离出切面，独立于业务逻辑实现，在程序执行时织入程序中运行。
2.AOP一般使用于具有横切逻辑(横切关注点)的场合，如访问控制、事物管理、性能检测等。
3.面向切面编程：采用代理机制组装起来运行，在不改变原程序的基础上对代码就行增强处理，增加新功能。
4.是一种通过预编译方式和运行期动态代理实现在不修改源代码的情况下给程序动态添加功能的技术。
5.代理机制：在代理模式中，会创建一个代理对象，通过代理对象的方法调用原对象的方法，就可以在代理对象的方法	前后插入代码，增加新功能。
```

**AOP术语**

```reStructuredText
增强处理：切面在某个特定连接点上执行的代码逻辑。
切入点：通过一个表达式告诉计算机去哪增强。
连接点：通过切入点找到具体执行点。
切面：一个模块化的横切逻辑，可能会横切多个对象（切入点和增强联合构成）。
目标对象：被增强的目标类。
AOP代理：(代理类)有AOP框架所创建的对象，实现增强处理。
织入：增强处理增强到指定位置的过程。
```

**实体引用**

```reStructuredText
< &lt;   > &gt；  &  &amp；  ‘&apos;   :&quot;
<![CDATA[P&G]]>
```

# Spring与MyBatis整合

### **★配置数据源**

```xml
<!-- 方式一 -->
<bean id="dataSource" class="org.apache.commons.dbcp.BasicDataSource" destroy-		      method="close" > 
      <property name="driverClassName" value="com.mysql.jdbc.Driver"/>
      <property name="url">
     	 <value><![CDATA[jdbc:mysql://localhost:3306/smbms?
     	 		useUnicode=true&characterEncoding=utf-8]]></value>
      </property>
      <property name="username" value="root"/>
      <property name="password" value="root"/>
 </bean>   

<!-- 方式二 引入属性文件方式-->
<bean class="org.springframework.beans.factory.config.PropertyPlaceholderConfigurer">
 	<property name="location">
 		<value>classpath:database.properties</value>
 	</property>
</bean>
<bean id="dataSource" class="org.apache.commons.dbcp.BasicDataSource"> 
     <property name="driverClassName" value="${driver}"/>
     <property name="url" value="${url}"/>
     <property name="username" value="${user}"/>
     <property name="password" value="${password}"/>
</bean>

<!-- 方式三 配置数据源（通过JNDI从服务器中获取DataSource资源）-->
<bean id="dataSource" class="org.springframework.jndi.JndiObjectFactoryBean">
 	 <property name="jndiName">
 		 <value>java:comp/env/jdbc/smbms</value>    --env前是固定的
 	 </property>
 </bean>
```

### ★配置Sqlsession工厂

```xml
<bean id="sqlSessionFactory"  class="org.mybatis.spring.SqlSessionFactoryBean">
	  <!--引用数据源组件 -->
	    <property name="dataSource" ref="dataSource"/>
	  <!-- 引用MyBatis配置文件中的配置 -->
		<property name="configLocation" value="classpath:mybatis-config.xml"/> 
    	  <!-- 扫描SQL映射文件(*.mapper) -->
		<property name="mapperLocations">
			<list>
				<value>classpath:cn/smbms/dao/**/*.xml</value>
			</list>
		</property>
</bean>	 
```

### ★实现数据库的操作

**1.（需要dao实现类）获取Sqlsession的两种方法**

```xml
<!-- 使用SqlsessionTemplate实现数据库操作 -->
<bean id="sqlSessionTemplate" class="org.mybatis.spring.SqlSessionTemplate">
	<constructor-arg name="sqlSessionFactory" ref="sqlSessionFactory"/>
</bean> 
<bean id="userMapper" class="cn.smbms.dao.user.UserMapperImpl">
    <property name="sqlSession" ref="sqlSessionTemplate"/>
</bean>

<!-- 继承SqlsessionDaosupport(dao实现类继承)-->
<bean id="userMapper" class="实现类路径"> 		 
    <property name="sqlSessionFactory" ref="sqlSessionFactory"/>
</bean>
```

**2.（不需要实现类）获取Sqlsession的两种方法**

```xml
<!-- 注意：   命名空间和接口完全限定名一致，映射文件id名和接口方法名一致 -->
<!-- 第一种 -->
<bean id="userMapper" class="org.mybatis.spring.mapper.MapperFactoryBean"> 
    <property name="mapperInterface" value="cn.smbms.dao.user.UserMapper"/>	
    <property name="sqlSessionFactory" ref="sqlSessionFactory"/>
</bean>

<!-- 第二种（重点） -->
<!-- 1.自动扫描Mapper接口直接注册为mapperFactoryBean -->
<!-- 2.所有映射器实现都会被自动注入SqlsessionFactory实例 -->
<!-- 3.id名为自动创建，根据接口名默认字母小写 -->
<!-- 4.如果要显示注入SqlSessionFactory实例的话 用这个属性 "sqlSessionFactoryBeanName"-->
<bean class = "org.mybatis.spring.mapper.MapperScannerConfigurer">
	<property name="basePackage" value="cn.smbms.dao"/>
</bean>  

<!-- 重点： 使用MapperScannerConfigurer自动完成映射注册后，在service层使用@Autowired或
	@Resource 注解实现对业务组件的依赖注入。-->
<!--<context:component-scan base-package="service"> 扫描 -->
```

### **★声明式事务**

**事务管理器**

```xml
<bean id="txManager" class="org.springframework.jdbc.datasource.DataSourceTransactionManager">
		<property name="dataSource" ref="dataSource"/>
</bean>
```

**普通方式使用**

```xml
<!--事物增强，设定事务的属性-->
<tx:advice id="txAdvice" transaction-manager="txManager">
	<tx:attributes>
		<tx:method name="find*" timeout="1000"></tx:method>
		<tx:method name="*"  propagation="REQUIRED"/>
	</tx:attributes>
</tx:advice>
<!-- 配置切面 -->
<aop:config>
	<aop:pointcut id="myPoint" expression="execution(* cn.smbms.service..*.*(..))" />
	<aop:advisor advice-ref="txAdvice" pointcut-ref="myPoint"/>
</aop:config>
```

```text
<tx:method> 参数：
	propagation：  
			SUPPORTS  适用于查询语句，有事务则执行事务，没有事务就不执行
			REQUIRED  默认方法，有事务则使用当前事务，否则开始一个新事务
	read-only:  设为true查询时性能提高
	timeout:  事务超时时间，以秒为单位，默认值为-1表示不超时
	rollback-for: 触发回滚异常的类型（多个异常用逗号隔开），默认为RuntimeException
			
```

**注解方式使用**

```java
@Transactional : 在业务实现类上添加，表示为该类所有方法添加统一事务处理，如果某方法需要采用不同的事务					管理规则，可以在该方法上再进行添加该注释重新设置。
//例： @Transactional(propagation=propagation.SUPPORTS)
注解属性：
	rollbackForClassName={"SQLException"}
	noRollbackForClassName
//配置文件扫描
<tx:annotation-driven transaction-manager="txManager"/>	
```

### 头信息

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
     xmlns:p="http://www.springframework.org/schema/p"
     xmlns:aop="http://www.springframework.org/schema/aop"
     xmlns:tx="http://www.springframework.org/schema/tx"
     xmlns:context="http://www.springframework.org/schema/context"
     xsi:schemaLocation="http://www.springframework.org/schema/beans
         http://www.springframework.org/schema/beans/spring-beans-3.2.xsd
         http://www.springframework.org/schema/context
         http://www.springframework.org/schema/context/spring-context-3.2.xsd
         http://www.springframework.org/schema/aop
         http://www.springframework.org/schema/aop/spring-aop-3.2.xsd
         http://www.springframework.org/schema/tx
         http://www.springframework.org/schema/tx/spring-tx-3.2.xsd">
```

### ★关于配置文件的拆分

```reStructuredText
拆分策略：
		公用配置+每个系统模块一个单独配置文件（包含DAO，Service，Web控制器）
		公用配置+DAO配置+Service配置+Web配置
注： 公共的东西不要让它自动装配
文件整合：
		1.ClassPathXmlApplicationContext("传入多个配置文件或者是通配符方式					                                           (applicationContext*.xml)")
		2.导入多个Spring配置文件(推荐)
		  <import resource="applicationContext-dao.xml"/>
		  <import resource="applicationContext-Service.xml"/>
```

### 附加（Spring配置补充）

```xml
<!-- 默认值，每次getBean都是同一个实例 -->
<bean ....  scope="singleton"/> 
<!--每次getBean都是不同的实例，可以避免因为共用一个实例而产生线程安全问题-->
<bean ....  scope="prototype"/> 
    
<!-- 自动为属性匹配，在xml文件中可以不指定property属性-->
<bean .... autowire="byName"/> 按类型匹配（如果有多个类型会出错）
<bean .... autowire="byType"/> 按名字匹配（没找到什么也不做）
 
<!--注: default-autowire属性放在beans标签中，就可以影响全局，
			而单个标签设置autowire属性可以重新覆盖 -->

<!--注：对于大型的应用，不鼓励使用自动装配，虽然可以减少配置工作量，
		但大大降低了依赖关系的清晰性和透明性-->
```

# Spring MVC框架

### ★web.xml配置Servlet

```xml
<!-- 
《DispatcherServlet是整个SpringMVC框架的核心，它负责截获请求并将其分派给相应的处理器处理》
1.配置了一个名为springmvc的Servlet。该Servlet是DispatcherServlet类型，它就是SpringMVC的入口。
2.<load-on-startup>1</load-on-startup>
  通过配置标记容器在启动的时候就加载此DispatcherServlet即自动启动
3.然后通过servlet-mapping映射到“/”，即DispathcherServlet需要截获并处理该项目的所有URL请求。
4.在配置DispatcherServlet的时候,通过设置contextConfigLocation参数指定SpringMVC配置文件的位置. -->
<servlet>
 	<servlet-name>springmvc</servlet-name>
 		<servlet-class>
 		        org.springframework.web.servlet.DispatcherServlet
 		</servlet-class>
 		<init-param>
 		         <param-name>contextConfigLocation</param-name>
 		         <param-value>classpath:springmvc-servlet.xml</param-value>
 		</init-param>
 	<load-on-startup>1</load-on-startup>  
</servlet>
<servlet-mapping>
 	<servlet-name>springmvc</servlet-name>
 	<url-pattern>/</url-pattern>
</servlet-mapping>
```

```xml
<!---------------过滤器------------>
 <filter>
 	<filter-name>EncodingFilter</filter-name>
 	<filter-class>
 		 org.springframework.web.filter.CharacterEncodingFilter
 	</filter-class>
 	<init-param>
 		<param-name>encoding</param-name>
 		<param-value>UTF-8</param-value>
 	</init-param>
 	<init-param>
 		<param-name>forceEncoding</param-name>
 		<param-value>true</param-value>
 	</init-param>
 </filter>
 <filter-mapping>
 	<filter-name>EncodingFilter</filter-name>
 	<url-pattern>/*</url-pattern>
 </filter-mapping>
```

```xml
<!-- 在web中使用监听类启动spring容器-->
   <context-param>
   <param-name>contextConfigLocation</param-name>
   <param-value>classpath:applicationContext-*.xml</param-value>
   </context-param>
   <listener>
   		<listener-class>
   			org.springframework.web.context.ContextLoaderListener
   		</listener-class>
   </listener>
```

### ★Springmvc-servlet.xml

```xml
<!--处理器映射(Handler）-->
	<!-- 方式一（了解就够了） -->
		<!-- 配置处理器映射Bean→HandlerMapping(Handler) 。 -->
		<!-- 它的作用就是把一个叫index.html的 URL请求指定给一个Controller处理-->
		<bean name="/index.html" class="cn.smbms.controller.IndexController"/> 

	<!-- 方式二 （注解扫描）-->
		<!--自动注册 DefaultAnnotationHandlerMapping，AnnotationMethodHandlerAdapter，
			通过这两个Bean完成对@Controller和RequestMapping注解的支持--> 
		<mvc:annotation-driven/>
		<!--对包进行扫描-->
  	    <context:component-scan base-package="cn.smbms.controller"/>
<!-- 配置视图解析器 /WEB-INF/jsp/index.jsp  主要处理JSP视图模板的映射-->
	<bean class="org.springframework.web.servlet.view.InternalResourceViewResolver">
		<property name="prefix" value="/WEB-INF/jsp/"></property>   		
		<property name="suffix" value=".jsp"></property>
	</bean>
     <!-- 注：在WEB-INF/jsp/创建相关的jsp展示数据-->
```

```xml
<!-- 配置多视图解析器：允许同样内容数据呈现不同的view  -->
   <!--springMVC可以根据请求报文头的Accept属性值，将处理方法的返回值以XML、JSON、HTML等不容形式
	输出响应,即可以通过请求报文头Accept的值来控制服务器端返回的数据格式-->
1.favorParameter 属性，表示支持参数匹配，可根据请求参数的值确定MIME类型，默认请求参数为format。
2.mediaTypes 属性，若请求参数后缀为.json则以application/json的格式进行数据的展示
3.viewResolvers 属性，表示视图解析器
4.配置了多视图解析器，返回从后台获取的User对象即可，无须再转换为JSON字符串返回
<bean class="org.springframework.web.servlet.view.ContentNegotiatingViewResolver">
	<property name="favorParameter" value="true"/>
	<property name="defaultContentType" value="text/html"/>
			<property name="mediaTypes">
				<map>
					<entry key="html" value="text/html;charset=UTF-8"/>
					<entry key="json" value="application/json;charset=UTF-8"/>
					<entry key="xml" value="application/xml;charset=UTF-8"/>		
				</map>
			</property>
	<property name="viewResolvers">
	   <list>
       <bean class="org.springframework.web.servlet.view.InternalResourceViewResolver">
				<property name="prefix" value="/WEB-INF/jsp/"/>
				<property name="suffix" value=".jsp"></property>
	   </bean>
	   </list>
	</property>
</bean>
```

```xml
<!--  引用静态资源 -->
<mvc:resources location="/static/" mapping="/static/**"/>
```

```xml
<!-- springMVC是通过HandlerExceptionResolver进行程序异常处理。发生异常就会跳入相应的异常页面显示·	异常-->
<!-- 全局异常的配置  -->
<bean class="org.springframework.web.servlet.handler.SimpleMappingExceptionResolver">
	<property name="exceptionMappings">
		<props>   <!--可以指定多个异常 error为逻辑视图名-->
			<prop key="java.lang.RuntimeException">error</prop>
		</props>
	</property>
</bean>
<!--视图显示： ${exception.message} -->	
```

### ★创建Controller（bean）

```java
//方式一继承AbstractController(了解就够了)
	public class IndexController extends AbstractController {}

//方式二 注解方式
	@Controller //标注在类上面，使其成为一个可处理HTTP请求的控制器
   
    //将不同的请求映射到对应的控制器处理方法上
    //可以标注在类上面和方法上面
	//1.请求信息可以为数组形式 2.还可以有请求方法  3.请求参数（参数名要和方法里的参数名一致）
    //必须保证全局唯一性
	@RequestMapping("/index")
    @RequestMapping
    (value={"/welcome","/yangyang"},method=RequestMethod.GET,params="username") 

	//
	//value  参数名
	//required   默认true  表示请求中必须包含对应的参数名，如果不存在就会抛出异常
	//defaultValue   默认参数名（不推荐使用）
	//用对象做入参，那么如：from 表单中的name属性值 要和实体类的属性相对应。
	@RequestParam
	@RequestParam(value="user",required=flase)

//(ajax)将标注该注解的处理方法的返回结果直接写入HTTP ResponseBody中,一般会在异步获取数据时使用！
	@ResponseBody
```

```java
//转发和重定向
指示符<重定向>------redirect:
(默认)指示符<转发>------forward:   
// 使用servletAPI对象 ，通过直接入参创建 session  request response
HttpSession,
HttpServletRequest,       //request.getServletContext.getApplication
HttpServletResponse
```



**模型数据传递**

```java
// 方式一：ModelAndView作为返回值
	//既可以包含视图信息，又包含模型数据信息。
	ModelAndView mView = new ModelAndView();
    //2.-----添加模型数据（要返回的数据）
      // 第一个参数为key值，第二个参数为 key对应的value。
      ModelAndView addObject(String attributeName,Object attributeValue);
      //添加Map对象到Model中
      ModelAndview addAllObjects(Map<String,?> modelMap) 
   // 2.-----设置视图(选择哪个视图)
     void setView(View view) // 指定一个具体的视图对象
     void setViewName(String viewName)  //指定一个逻辑视图名
//方式二：Model(隐含模型)类型作为入参,将参数放入Model中即可，另外返回字符串类型的逻辑视图名
    //例: public String index(String username,Model model){}
          addAttribute("key",值);
    // 注：在Model中增加模型数据，若不指定key,则默认使用对象的类型作为key
    // 注：也可以直接用Map入参，但是不推荐
//方式三： @ModelAttribute 参数前加此注解;和入参中添加Model,再将对象放入Model中效果一样。
	public String addUser(@ModelAttributte("user") Usre user){}
```

```java
// 局部异常：一旦在同一个Contrroller中某处发生异常就会被其捕获从而跳入其方法。（一般建议用全局异常）
	@ExceptionHandler(value={RuntimeException.class,可以指定多种异常})
	public String handlerException(RuntimeException e,
								HttpServletRequest req){
		req.setAttribute("e", e);
		return "error";
	}
//视图显示：	${e.message}
```

### ★重要杂点

```java
1.//关于时间绑定的   SpringMVC框架中的时间的数据类型无法自动绑定
 @DateTimeFormat(pattern="yyyy-MM-dd")   (将实体类中的时间类型进行一个标注)
2.//执行增删改时可以通过隐藏域来传id值
3.StringUtils.isNullOrEmpty(userCode) //判断是否为空
4.  //JSON返回
    return JSONArray.toJSON(resultMap);  
  	return JSON.toJSONString(user)
5. 数据库中datetime格式 yyyy-MM-dd HH:mm:ss   date格式：  yyyy-MM-dd 
//------
6.  因拦截器问题JSON数据变成了字符串，通过 data=eval('('+data+')') 将字符串重新变为JSON
 
```

#### ★JSON数据传递问题

```java
//1.(关于乱码问题)
  /*控制器处理方法使用@ResponseBody注解向前台页面以JSON格式进行数据传递的时候，若返回值是中文字符串
	则会出现乱码。 原因是消息转换器中固定了转换字符编码为 ISO-8859-1*/
   解决方案1：
   		在控制器处理方法上的 @RequestMapping注解中配置produces指定返回的内容类型
		@RquestMapping(produces={"application/json;charset=UTF-8"})
       /* 注意：请求信息不要加.html。请求报文头的Accept须与响应报文头中的Content-Type类型一致 
         即： application/json */
//2.(关于日期转换问题)
       /*SpringMvc中使用@ResponseBody返回JSON数据时，日期格式默认显示为时间戳*/
   解决方案1：
   		 @JSOnFieId(format="yyyy-MM-dd")
		  /*在实体类时间属性上进行注解。但该解决方案的代码具有强侵入性，紧耦合，并且修改麻烦，
            所以在实际开发，不建议采用这种硬编码的方式来处理*/

```

```xml
<!-- 中文乱码/日期转换 解决方案2：-->
<!--springMVC配置文件中的<mvc:annotation-driven>中配置-->
<mvc:annotation-driven>
  <!--装配消息转换器StringHttpMessageConverter，指定媒体类型 ： application/json。设置字符编         码为UTF-8 一次配置，永久搞定。-->
	<mvc:message-converters>
		<bean class="org.springframework.http.converter.StringHttpMessageConverter">
			<property name="supportedMediaTypes">
				<list>
					<value>application/json;charset=UTF-8</value>
				</list>
			</property>
		</bean>
   <!-- 配置FastJson的消息转换器-FastJsonHttpMessageConverter 转换时间-->
   <!-- 默认为yyyy-MM-dd HH:mm:ss 类型 对于特殊字段可用 @JSOnFieId 控制（注解优先）-->
        <bean class="com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter">
			<property name="supportedMediaTypes">
				<list>
					<value>text/html;charset=UTF-8</value>
					<value>application/json</value>
				</list>
			</property>
			<property name="features">
				<list>
					<value>WriteDateUseDateFormat</value>
				</list>
			</property>
		</bean>
	</mvc:message-converters>
</mvc:annotation-driven>
```

#### ★自定义转换/编辑器

```text
Spring MVC将ServletRequest对象以及处理方法的入参对象实例传递个DataBinder.DataBinder调用
ConversionService组件进行数据的转换、格式化的工作，并将ServletRequest中消息填充到入参对象中。
然后再调用Validator组件对yijing绑定了请求数据的入参对象进行数据的如入参对象进行数据合法性的验证，
并最终生成数据绑定结果BindingResult对象。
 Databinder ： 数据绑定的核心部件
 ConversionService： Spring类型转换体系的核心接口，解决前台form表单中时间字符串到后台Date数据类型                       的转换问题。
 BindingResult: 包含了已完成数据绑定的入参对象和相应的校验错误对象。
 //-----------------------------------
 <mvc:annotation-driven/>标签
	        DefaultAnnotationHandlermapping
	        AnnotationMethodHandlerAdapter
	        FormattingConversionServiceFactoryBean
```

```xml
<!--编写自定义的转换器-->
    <!--以前直接通过<mvc:annotation-driven/>标签来支持注解驱动的功能	                             （@DateTimeFormat(pattern="yyyy-MM-dd")）满足了日期类型的转换需求，现在也可以通过自定义转        换器，来规定转换的规则-->

1. 创建一个工具类继承Converter接口，实现convert 方法-
注意导包：import org.springframework.core.convert.converter.Converter;
	public class StringToDateConverter implements Converter<String, Date>{
		private String datePattern;
		public StringToDateConverter(String dataPattern){
			System.out.println("xxxxxxxxxxxxxxx"+dataPattern);
			this.datePattern=dataPattern;
		}
		@Override
		public Date convert(String s) {
			Date date = null;
			try {
				date = new SimpleDateFormat(datePattern).parse(s);
				System.out.println(date);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			return date;
		}
	}
 2. 在SpringMVC 配置文件中配置  
    <bean id="myConversionService" 
		class="org.springframework.context.support.ConversionServiceFactoryBean">
	    <property name="converters">
	    	<list>
	    		<bean class="cn.smbms.tools.StringToDateConverter">
	    			<constructor-arg type="java.lang.String" value="yyyy-MM-dd"/>
	    		</bean>
	    	</list>
	    </property>
	</bean>
 3.注意在  mvc:annotation-driven 标签中添加属性   
   <mvc:annotation-driven conversion-service="myConversionService"/>
```

```java
//编写自定义编辑器（了解就行）
	//创建BaseController类 让每个Controller继承它
    /*标注了@InitBinder注解的方法会在控制器初始化时调用。通过dataBinder的	                     	   registerCustomEditor()的方法注册一个自定义编辑器*/
public class BaseController {
	/**
	 * 使用@InitBinder解決SpringMvc日期类型无法绑定的问题
	 */
	@InitBinder
	public void initBinder(WebDataBinder dataBinder){
		dataBinder.registerCustomEditor(Date.class,new CustomDateEditor(new 		              SimpleDateFormat("yyyy-MM-dd"), true));
	}
}
注意：在SpringMVC中，Bean定义了Date、double等类型，如果没有做任何处理，日期 ，double都无法自定绑定。编辑器和转换器都可以解决，需灵活掌握
```

#### ☆SpringMVC表单标签

```reStructuredText
注意1:获取表单和提交表单的url是相同的，通过method是GET还是POST,就可以确定需要进入到哪个控制器的处理方		法进行请求处理，所以就可以省略action属性指定表单提交的目标URL.
		(换句话说，当不指定目标URL的时候，会自动提交到获取表单页面的URL)
注意2：表单组件标签也拥有HTML标签的各种属性:比如： id、onclick等等，都可以根据需要、灵活使用
```

```html
<!--在JSP中引入指令--> 
<%@ taglib prefix="fm"  uri="http://www.springframework.org/tags/form"%>
   <fm:form/> 	  <!--染表单元素-->
  	  <fm:input/>	  <!--输入框组件标签-->
 	  <fm:password/> <!-- 密码框组件标签-->
 	  <fm:hidden/>   <!--隐藏框组件标签--> 
 	  <fm:textarea/> <!--多行输入框组件标签-->
	  <fm:radiobutton/>  <!--单选框组件标签-->
	  <fm:checkbox/> <!--复选框组件标签-->  
   	  <fm:select/>   <!--下拉列表组件标签-->
  	  <fm:error/>    <!--显示表单数据校验所对应的错误信息-->
      <!--标签所有包含的属性-->
		path：属性路径，表示表单对象属性，相当于name
		cssClass: 表单组件对应的CSS样式类名
  		cssErrorClass: 当提交表单后报错（服务端错误），采用的CSS样式类  
		cssStyle: 表单组件对应的CSS样式
		htmlEscape: 绑定的表单属性值是否要对HTML特殊字符进行转换，默认为true

    <!---------------------------示例代码--------------------------------->  
   					<!--modelAttribute绑定模型数据的属性，建议指定-->
    <fm:form method="post" modelAttribute="user" action="">
        <fm:input path="userCode"/>
        <fm:input path="birthday" Class="Wdate" readonly="readonly" 				             onclick="WdatePicker();"/>
        <fm:radiobutton path="userRole" value="1"/>
        <fm:radiobutton path="userRole" value="2"/>
        <input type="submit" value="保存"/>
    </fm:form>
```

#### ☆数据校验JSR303

```java
//注意：JSR303是Java为Bean数据合法性校验所提供的标准框架。需要添加相关的jar包,

//1.实体类属性上使用：-------------------------------------
	// 约束注解（通过message输出信息）
         @Past    //被注释的元素必须是一个过去的日期
		 @Future  //被注释的元素必须是一个将来的日期
		 @NotNull //被注释的元素必须不为null
		 @NotEmpty // 被注释的字符串必须非空
		 @Length(min=6,max=10,message="用户密码长度为6-10")  
		 @Pattern(value) //被注释的元素必须符合指定的正则表达式	
      //---------------------不常用
		 @Null   //  被注释的元素必须为null
		 @AssertTrue  //被注释的元素必须为true
		 @AssertFalse  //被注释的元素必须为false
		 @Min(value) //被注释的元素必须是一个数字，其值必须大于等于指定的最小值
		 @Max(value) //被注释的元素必须是一个数字，其值必须小于等于指定的最大值
		 @DecimalMin(value)  //被注释的元素必须是一个数字，其值必须大于等于指定的最小值
		 @DecimalMax(value)// 被注释的元素必须是一个数字，其值必须小于等于指定的最大值
	     @Size(max,min) // 被注释的元素大小必须在指定的范围内
  		 @Digits(integer,fraction) //被注释的元素必须是一个数字，其值必须在可接受的范围内
//2.Controller处理方法参数上使用：--------------------------------
		// @Valid此注解可让Spring MVC在完成数据绑定之后，执行数据校验的工作。
		/*在入参对象前标注,而校验的结果存入后面紧跟的入参中，这个入参必须是BindingResult 或者是 				Error类型，然后根据其判断是否存在错误。*/
	//例子：
 	public String  addSave(@Valid User user,BindingResult bindingResult){
		if(bindingResult.hasErrors){
			return "user/useradd";
		}
	}
//3. 在JSP页面表单中使用：
	         <fm:errors path="userCode"/>
     用户编码：<fm:input path="userCode"/>
```

#### ☆REST风格

```java
   //REST风格，即表述性状态转移
   // 将URL中的{XXX}绑定到控制器处理方法的入参中
   // 在入参前添加@PathVariable
  @RequestMapping(value="/view/{id}")
  public String  view(@PathVariable String id)
```

#### ★文件上传

```text
springMVC为文件上传提供了 MultipartResolver接口：用于处理上传请求，将上传请求包装成可以直接获取文   件的数据，从而方便操作。而它有两个实现类：StandardServletMultipartResolver和	    	     	CommonsMultipartResolver。 前者使用了Servlet3.0标准上传方式，后者使用了Apache的
commons-fileupload来完成具体的上传操作（要导入相应的jar包）
```

```xml
1.<!--Springmvc-servlet.xml中配置-->
<!-- 配置Multipartresolver,用于上传文件，使用spring的CommonsMultipartResolver  -->
<!-- 注意defaultEncoding和JSP的pageEncoding设置要一致-->
<!--此处的id名必须为multipartResolver-->
<bean id="multipartResolver" 
	class="org.springframework.web.multipart.commons.CommonsMultipartResolver">
		<property name="maxUploadSize" value="5000000"/>
		<property name="defaultEncoding" value="UTF-8"/>
</bean>
```

```xml
  2.<!--在jsp中的form表单的配置-->
	1.method="POST"  2.指定表单内容类型，支持文件上传  enctype="multipart/form-data"
	用来上传文件的file组件	
	<input type="file"  name="a_idPicPath"/>
```

```java
3.//Controller方法中
// 要导入相关的jar包   
//单个上传将MultipartFile做为入参，多个上传将 MultipartFile[] 数组作为参数或者传入多个            // MultipartFile

//上传关键点：
@RequestMapping(value="/addsave.html",method=RequestMethod.POST)
public String addUserSave(
			@RequestParam(value="attachs",required=false) MultipartFile  attach){
    //1.判断是否为空，不为空则代表
    if(!attach.isEmpty()){
        //2.定义上传目标路径
        //获取容器根路径/static文件/uploadfiles文件夹
        //File.separator 分隔符的意思
        String path = request.getSession().getServletContext()
                         .getRealPath("static"+File.separator+"uploadfiles");
        //3.获取原文件名
        String oldFileName=attach.getOriginalFilename();//原文件名
        //4.获取原文件的后缀
        String prefix = FilenameUtils.getExtension(oldFileName);//原文件后缀
        //5.判断原文件大小
        if(attach.getSize()>500000){
              map.put("uploadFileError", "上传大小不得超过500KB");
                return "useradd";
        }
        //6.判断后缀符合不
        else if(prefix.equalsIgnoreCase("jpg")
						|| prefix.equalsIgnoreCase("png")
						|| prefix.equalsIgnoreCase("jpeg")
						|| prefix.equalsIgnoreCase("pneg")){
             //7.定义上传文件名
        	//当前系统时间+随机数+"_Personal.jpg"
		String fileName = System.currentTimeMillis()
							+RandomUtils.nextInt(1000000)+"_Personal.jpg";
        //8.创建File对象
		File targetFile = new File(path, fileName);
		if(!targetFile.exists()){  //文件不存在
			targetFile.mkdirs();   //则创建
		}
		//9.保存
		attach.transferTo(targetFile);
   	}	
       
```

```java
//多上传的例子：
@RequestMapping(value="/addsave.html",method=RequestMethod.POST)
	public String addUserSave(User user,
				HttpSession session,
				HttpServletRequest request,
				@RequestParam(value="attachs",required=false) MultipartFile[] attachs){
		String idPicPath=null;
		String workPicPath=null;
		String errorInfo=null;
		boolean flag = true;
		//定义上传目标路径
		String path = request.getSession().getServletContext()
									   //分隔符                      放置所有上传的文件
				.getRealPath("static"+File.separator+"uploadfiles");
		for(int i=0;i<attachs.length;i++){
			MultipartFile attach = attachs[i];
			//判断文件是否为空
			if(!attach.isEmpty()){
				if(i==0){
					errorInfo = "uploadFileError";
				}else if(i==1){
					errorInfo = "uploadWpError";
				}
				String oldFileName=attach.getOriginalFilename();//原文件名
				String prefix = FilenameUtils.getExtension(oldFileName);//原文件后缀
				int filesize = 500000;   //规定原文件大小
				if(attach.getSize()>filesize){
					request.setAttribute(errorInfo, "上传文件大小不得超过500KB");
					flag = false;
				}else if(prefix.equalsIgnoreCase("jpg")
						|| prefix.equalsIgnoreCase("png")
						|| prefix.equalsIgnoreCase("jpeg")
						|| prefix.equalsIgnoreCase("pneg")){
					//当前系统时间+随机数+"_Personal.jpg"
					String fileName = System.currentTimeMillis()
							+RandomUtils.nextInt(1000000)+"_Personal.jpg";
					File targetFile = new File(path, fileName);
					if(!targetFile.exists()){  //文件不存在
						targetFile.mkdirs();   //则创建
					}
					
					//保存
					try {
						attach.transferTo(targetFile);
					} catch (Exception e) {
						e.printStackTrace();
						request.setAttribute(errorInfo,"*上传失败！");
//						return "useradd";
						flag = false;
					}
					if(i==0){
						idPicPath = path+File.separator+fileName;
					}else if(i==1){
						workPicPath=path+File.separator+fileName;
					}
					
				}else {
					 request.setAttribute("uploadFileError", "*上传图片格式不正确！");
					 flag = false;
				}
			}
```

### 配置文件头信息

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xmlns:p="http://www.springframework.org/schema/p"
    xmlns:mvc="http://www.springframework.org/schema/mvc"
    xmlns:context="http://www.springframework.org/schema/context"
    xsi:schemaLocation="
        http://www.springframework.org/schema/beans
        http://www.springframework.org/schema/beans/spring-beans.xsd
        http://www.springframework.org/schema/context
        http://www.springframework.org/schema/context/spring-context.xsd
         http://www.springframework.org/schema/mvc
        http://www.springframework.org/schema/mvc/spring-mvc.xsd">
```

### 关于单例模式

```reStructuredText
单例模式：系统运行使其，有且仅有一个实例。
	1.一个类只有一个实例（最基本要求：只提供私有构造器）
	2.它必须自行创建实例（定义该类静态自身私有对象）
	3.它必须自行向整个系统提供这个实例（提供一个静态的公有方法，返回创建或者获取本身的静态的私有对象）
实现单例的三种模式：       
    懒汉模式：在类加载时不创建实例，采用延迟加载的方式，在运行调用时创建实例。
	    特点：线程不安全，延迟加载
	    解决线程问题： 同步（synchronized）
    饿汉模式：在类加载的时候，就完成初始化。
	    特点：线程安全，不具备延迟加载特性
        静态内部类： 集两者之长。	
```



### SpringMVC概念(杂七杂八)

**处理流程**

```reStructuredText
1，前端控制器(DispatcherServlet):
		客户端发出HTTP请求，Web应用服务器接收此请求，在将该请求转交给DispatcherServlet处理。
		SpringMVC就是通过这个前端控制器接收所有请求的。
		DispatcherServlet根据请求的信息（包括URL、请求参数、HTTP方法等）找到处理请求的处理器。
2.处理器映射(Handler）
	    Handler通过HandlerAdapter封装，再以统一的适配器调用Hander。
	  			DefaultAnnotationHandlerMapping  默认的映射支持，按URL同名的Bean查找
	            AnnotationMethodHandlerAdapter  支持注解
	    SpringMVC不需要定义Handler，也没做任何限制，处理器可以以任意合理的方式来表现。
3.这段时间，它会将请求信息以一定的方式转换并绑定到请求方法的入参中，对于入参的对象会进行数据转换、
  数据格式化以及数据校验等。
5.处理器完成逻辑处理后，返回一个ModelAndView对象给DispatcherServlet。（ModelAndView对象包含了逻	辑视图名和模型数据信息）
6.ModelAndView对象包含的是“逻辑视图名”,而非真正的视图对象。DispatcherServlet会通过ViewResolver
将逻辑视图名解析为真正的视图对象View。 负责数据展示的视图可以为JSP、XML、PDF、JSON等多种数据格式。
7.通过ModelAndView的模型数据对View进行视图渲染，返回给客户端。
```

**简介**

```reStructuredText
MVC:
	视图（View） 对应组件： JSP或者HTML文件
	控制器（Controller） 对应组件  Servlet
	模型（Model） -对应组件  ： JavaBean-   数据库
MVC优点
	多视图共享一个模型，大大提高代码的可重用性
	MVC三个模块相互独立，松耦合构架
	控制器提高了应用程序的灵活性和可配置性
	有利于软件工程化管理
    <完美的系统架构 = 松耦合+高重用性+高扩展性>
MVC缺点
	原理复杂
	增加了系统结构和实现的复杂性
	视图对模型数据的低效率访问、
Spring MVC框架的特点
  1.清晰地角色划分。Spring MVC 在Model、View 和 Controller方面提供了一个非常清晰的角色划分，
     这三个方面真正是各司其职。
  2.灵活的配置功能。因为Spring核心是IoC、同样在实现MVC上，也可以把各种类当作Bean来通过XML进行配置
  3.提供了大量的控制器接口和实现类。开发者可以使用Spring提供的控制器实现类，也可以自己实现控制器接口
  4.真正做到与View层的实现无关（JSP、Velocity、XSLT等）。
  5. 国际化支持
  6.面向接口编程
  7.Spring提供了Web应用开发的一整套流程，不仅仅是MVc，他们之间可以很方便地结合一起	
关于作用域
  Spring MVC 默认作用域是单例的，开发时注意资源使用问题，一般情况下Controller内部的成员变量是	  	   service对象  
（重点）一个核心三个点：
	DispatcherServlet 核心：
		处理映射器 处理适配器  处理解析器
```

