## 基本结构

```html
<!-- 1.导包之后，在浏览器的内存中，就多了一个 Vue 构造函数 -->
<script src="./lib/vue-2.4.0.js"></script>

<script>
    // 2.创建一个Vue的实例，VM调用者
    var vm = new Vue({
         el: '#app',  //控制区域
         data:{		  //data就是MVVM中的M（model）,保存页面数据
            msg:'欢迎学习Vue', 
            intervalId:null,
            array:[1,2,3,4,5,6], //数组
            user:{id:1,name:'托尼颗'，gender:'男'}， //对象
            list:[	//数组嵌套对象
                {id:1,name:'zs1'},
                {id:2,name:'zs2'},
                {id:3,name:'zs3'}
            ]， 
         },
         methods:{  //methods定义了当前Vue实例所有可用的方法
            show:function(){
                 //注意：获取data上的数据，或调用methods中的方法，必须通过this.
				this.msg
                // 注意：箭头函数的作用是内部的this永远与外部函数的this保持一致
                this.intervalId = setInterval(function() => { }）
             	
               //注意： VM实例，会监听自己身上 data 中所有数据的改变，只要数据一发生变化，就						会自动把最新的数据，从data上同步到页面中去
               
                this.list.push({id:this.id,name:this.name}) 
             
                //删除 splice   遍历 some(return true)  findIndex
            },
         	stop(){ //停止定时器
				clearInterval(this.intervalId);
                this.intervalId = null;
            } 
   		}
    })
</script>

<!-- 实例所控制的元素区域 -->
<div id="app">
    <p>{{msg}}</p>
</div>

实例  指令 事件/事件修饰符  双向绑定  样式  循环和if  过滤器 关于按键
```

## 关于指令

```html
<!-- v-cloak (能解决插值表达式闪烁的问题)-->
<style>
    [v-cloak]{
        display:none;
    }
</style>
<p v-cloak>{{msg}}</p>

<!-- v-text (能解决闪烁问题，但它会覆盖元素中原本的内容，而插值表达式只会替换自己占位符) -->
<h4 v-text="msg"></h4>

<!-- v-html (可以解析html标签)-->
<div v-html="msg"></div>

<!-- v-bind (提供用于绑定属性的指令，注意 ：title 等同于 v-bind:title) -->
<input ... v-bind:title="mytitle" />
<input ... :title="mytitle +'123'" />

<!-- 数据双向绑定 -->
<!-- v-Modle(可以实现数据从M到V里面去，也可以实现V到M里面去;只能用在表单元素中) -->
```

## 关于事件

```html
<!-- v-on (提供绑定事件，注意 @:click 等同于 v-on:click)-->
<!-- show为methods中定义的方法，事件加小括号可以传参 -->
<input ... v-on:click="show" />
<input ... @click="show" />

.事件修饰符
<!-- .stop 阻止冒泡 (点击里层事件不让外层时间触发) -->
<!-- .prevent 阻止默认事件 -->
<!-- .capture 添加时间侦听器时使用时间捕获模式(先捕获先触发) -->
<!-- .self 只当事件在该元素本身（比如不是子元素）触发时触发回调 -->
<!-- .once 事件只触发一次 -->
<!-- @click.prevent.once="" （修饰符一次可以使用多个，链式）-->

<input type="button" value="点击" @click.stop="btnHandler" />
<a href="http://www.baidu.com" @click.prevent="点击事件名">有问题，先百度</a>
```

## 使用样式

```html
<!-- 使用class样式 -->
1. 数组(red,this是样式名)
<h1 :class="['red','thin']"></h1>
2. 数组中使用三元表达式(falg 为data里面的 boolean)
<h1 :class="['red',flag?'active':'','thin']"> </h1>
3. 数组中嵌套对象
<h1 :class="['red','thin',{'active':flag}]"> 这是一个</h1>
4. 直接使用对象（属性可以带引号也可以不带引号）
<h1 :class="{red:true,italic:true,active:true,thin:true}"></h1>
<h1 :class="classObj"></h1>
<script>
  var vm = new Vue({
        el:'#app',
        data:{
            flag:true,
            classObj:{red:true,thin:true,italic:false,active:false}
        }
    })
</script>

<!-- 使用内联样式 -->
1.直接在元素上通过 style的形式，书写对象
<h1 :style="{color:'red','font-size':'40px'}"></h1>	
2.将样式对象，定义到 data 中，并直接饮用到 style中
<h1 :style="h1StyleObj"></h1>
3.通过数组饮用多个data上的样式对象
<h1 :style="{h1StyleObj,h1StyleObj2}"></h1>
data:{
	h1StyleObj:{color:'red','font-size':'40px','font-weight':'200'},
    h1StyleObj2:{color:'red','font-size':'40px','font-weight':'200'}
}
```

## for循环

```html
<!-- 1.迭代数组 -->
<p v-for="item in list">{{item}}</p>
<p v-for="(item,i) in list">索引：{{i}}  值：{{item}} </p>

<!-- 2.对象 -->
<p v-for="(val,key) in user">{{ val }} --- {{key}} --- {{i}}</p>
<p v-for="(val,key,i) in user">{{ val }} --- {{key}} --- {{i}} </p>

<!-- 3.迭代数组中对象中的属性 -->
<p v-for="user in list">Id：{{user.id}}  值：{{user.name}} </p>
<p v-for="(user,i) in list">Id：{{user.id}}  值：{{user.name}} 索引：{{i}} </p>

<!-- 在2.2.0+的版本里，当在组件中使用 v-for时，key现在是必须的
	用v-for正在更新已渲染过的元素列表时，它默认用“就地复用”策略。如果数据项的顺序被改变，Vue将不是移动
	DDM元素来匹配数据项的顺序，而是简单复用此处每个元素，并且确保它在特定索引下显示它已被渲染过的每个元素。为了给Vue一个提示，以便它能跟踪每个节点的身份，从而重用和重新排序现有元素，你需要为每项提供一个唯一key属性--->
<!-- 注意：v-for 循环的时候，key属性只能使用 number或string -->
<!-- 注意： key在使用的时候，必须使用 v-bind 属性绑定形式，指定key值 -->
<p v-for="item in list" :key="item.id">
    <input type="checkbox"/>{{item.id}} 
</p>

<!--自定义一个search方法，同时，把所有的关键字，通过传参的形式，传递给了search方法 -->
<!-- search是个指令可以访问data里面任何数据 -->
<!-- 在search方法内部，通过执行for循环，把所有符合搜索关键字的数据，保存到一个新新数组中返回 -->
<tr v-for="item in search(keyWords)" :key="item.id">
   
</tr> 

<script>
    var  vm = new Vue({
		el:'#app',
        data:{
            keywords:'' 
        },
        methods:{
            //根据关键字,进行数据的搜索
            search(keywords){ 
                //方法1
                var newList = [];
                this.list.forEcah(item=>{
                    if(item.name.indexOf(keywords) != -1){
                         newList.push(item);
                    }
                })   
                return newList;
               
                //方法2：
                //注意：forEach some filter(查询到的符合条件的得到一个新数组) findIndex 这                       些都属于数组的新方法
                //都会对数组中的每一项，进行遍历，执行相关的操作
               return this.list.filter(item=>{
                    //注意：ES6中，为字符串提供了一个新方法，叫做                                                        String.prototype.includes('要包含的字符串')
                    //如果包含返回true,否则返回false
                    if(item.name.includes(keywords)){
                        return tiem
                    }
                })
            }  
        }    
    })
</script>
```

## if结构

```html
<!-- v-if 的特点 每次都会重新删除或创建元素，有较高的切换性能消耗 -->
<!-- v-show的特点 每次不会重新进行DOM的删除和创建操作，只是切换了元素的display:none样式，有较高初始化消耗 -->
<!-- 如果元素涉及到频繁的切换，最好不要使用v-if,而是推荐使用 v-show -->
<!-- 如果元素可能永远也不会被显示出来被用户看到，则推荐使用v-if -->
<h3 v-if = "flag">... <h3>
<h3 v-show="flag">...</h3>    
    
<script>
    var vm = new Vue({
        el:"#app",
        data:{
          flag:true
        },
        methods:{}
    })
</script>   
```

